// tree_capitator.js
import { world, BlockVolume } from "@minecraft/server";
import * as Utils from "./enchantment_utils/treeUitls.js"; // Đảm bảo Utils được định nghĩa hoặc cung cấp

let locations = [];

/**
 * Phá hủy các khối gỗ liên quan khi kỹ năng Tree Capitator được kích hoạt.
 * @param { import("@minecraft/server").Player } player Người chơi.
 * @param { import("@minecraft/server").Block } block Khối hiện tại đang xử lý.
 * @param { import("@minecraft/server").Dimension } dimension Kích thước hiện tại.
 * @param { import("@minecraft/server").BlockType } blockType Loại khối gỗ đang bị phá.
 * @param { import("@minecraft/server").Vector3 } start Vị trí bắt đầu của cây (để spawn item).
 * @param { number } run ID của phiên chạy hiện tại (để theo dõi các khối đã thăm).
 */
const breakBlocks = async (player, block, dimension, blockType, start, run) => {
  // Đã thêm 'async' vào đây
  let locs = locations.find(({ run: r }) => r == run);
  if (locs == undefined) {
    locations.push({ run, locations: [] });
    locs = locations.find(({ run: r }) => r == run);
  }

  const { x, y, z } = block.location;
  const alreadyVisited =
    locs.locations.find((l) => l.x == x && l.y == y && l.z == z) != undefined;
  const drops = Utils.allowedBlocksWood.find(
    (b) => b.id == blockType.id
  )?.drops;

  // Kiểm tra điều kiện dừng: đã thăm, không phải loại gỗ mục tiêu, hoặc quá giới hạn khối
  if (
    alreadyVisited ||
    (locs.locations.length != 0 &&
      (drops == undefined || block.type.id != blockType.id)) ||
    locs.locations.length == Utils.maxBlocks
  )
    return;

  // Đặt khối thành không khí và spawn vật phẩm nếu cần
  block.setType("air");
  if (locs.locations.length != 0) {
    const inventory = player.getComponent("minecraft:inventory").container;
    const item = inventory.getItem(player.selectedSlotIndex);

    if (item && item.hasComponent("minecraft:enchantable")) {
      // Kiểm tra vật phẩm có thể phù phép
      const enchantmentsComponent = item.getComponent("minecraft:enchantable");
      const enchantments = enchantmentsComponent
        ? enchantmentsComponent.getEnchantments().map((e) => e.type.id)
        : [];

      if (enchantments.includes("minecraft:silk_touch")) {
        // Kiểm tra id phép thuật Silk Touch
        dimension.spawnItem(
          new (await import("@minecraft/server").ItemStack)(blockType.id),
          start
        );
      } else {
        // Tìm level của phép thuật Fortune nếu có
        const fortuneEnchant = enchantmentsComponent
          ? enchantmentsComponent
              .getEnchantments()
              .find((e) => e.type.id === "minecraft:fortune")
          : null;
        const level = fortuneEnchant ? fortuneEnchant.level : 0;
        const drop = drops.drops[level];
        const amount = Math.random() * (drop.max - drop.min) + drop.min;
        dimension.spawnItem(
          new (await import("@minecraft/server").ItemStack)(drops.id, amount),
          start
        );
      }
    } else {
      // Nếu vật phẩm không có enchantable component, vẫn spawn drop cơ bản
      if (drops) {
        const drop = drops.drops[0]; // Giả định level 0 nếu không có fortune
        const amount = Math.random() * (drop.max - drop.min) + drop.min;
        dimension.spawnItem(
          new (await import("@minecraft/server").ItemStack)(drops.id, amount),
          start
        );
      }
    }
  }

  // Thêm vị trí hiện tại vào danh sách đã thăm
  locs.locations.push({ x, y, z });
  // Lặp qua các khối xung quanh (khối 3x3x3)
  const blocks = new BlockVolume(
    { x: x + 1, y: y + 1, z: z + 1 },
    { x: x - 1, y: y - 1, z: z - 1 }
  ).getBlockLocationIterator();

  for (const b of blocks) {
    const block = dimension.getBlock(b);
    // Hàm đệ quy này cũng cần được gọi với 'await' vì breakBlocks đã trở thành 'async'
    await breakBlocks(player, block, dimension, blockType, start, run);
  }

  // Giảm độ bền của rìu
  const inventory = player.getComponent("minecraft:inventory").container;
  const item = inventory.getItem(player.selectedSlotIndex);
  if (item && item.hasComponent("minecraft:durability")) {
    const durabilityComponent = item.getComponent("minecraft:durability");
    if (durabilityComponent.maxDurability - durabilityComponent.damage > 0) {
      // Đảm bảo rìu không bị hỏng
      durabilityComponent.damage += 1;
      inventory.setItem(player.selectedSlotIndex, item);
    }
  }
};

// Hàm xử lý sự kiện playerBreakBlock cũng cần là async nếu nó gọi breakBlocks (async)
world.afterEvents.playerBreakBlock.subscribe(
  async ({ player, block, dimension, brokenBlockPermutation }) => {
    // Đã thêm 'async' vào đây
    const inventory = player.getComponent("minecraft:inventory").container;
    const item = inventory.getItem(player.selectedSlotIndex);
    if (!item) return;

    const durabilityComponent = item.getComponent("minecraft:durability");
    // Kiểm tra xem vật phẩm có thành phần độ bền và người chơi có tag Tree Capitator Active không
    if (
      player.hasTag("skill:treeCapitatorActive") &&
      durabilityComponent &&
      durabilityComponent.maxDurability - durabilityComponent.damage > 0
    ) {
      if (!item.typeId.includes("axe")) return;

      // Gọi breakBlocks với 'await'
      await breakBlocks(
        player,
        block,
        dimension,
        brokenBlockPermutation.type,
        block.location,
        Date.now()
      );
    }
  }
);
