// playerStats.js
import { world, system } from "@minecraft/server";
import { getPlayerProperty, setPlayerProperty } from "./utils.js";
import { resetCost } from "./config.js";

import { getTranslatedText, getPlayerLocale } from "./lang.js";

import { MessageFormData } from "@minecraft/server-ui";

// Định nghĩa các chỉ số cơ bản và tên Dynamic Property của chúng
// Stat multipliers:
// Strength: +0.5 ATK DMG per point
// Health: +1 Max HP per point (via health_boost effect)
// Regen: +0.05 heart/s per point
// Luck: +0.1% for extra drops/treasure, +0.2% for general luck
// Intelligence: +0.5% XP gain per point, -0.1% cooldown reduction per point
// Endurance: +0.1% Damage Reduction per point
// Critical Chance: +0.2% Crit Chance per point
// Critical Damage: +0.5% Crit Damage Multiplier per point
// Speed: +0.01 Movement Speed Multiplier per point (or scale Speed effect amplifier)

const STATS_CONFIG = {
  strength: {
    displayNameKey: "strength",
    property: "stats:strength",
    icon: "textures/items/diamond_sword",
    multiplier: 0.5,
  }, // Damage per point
  health: {
    displayNameKey: "health",
    property: "stats:health",
    icon: "textures/items/apple",
    multiplier: 1,
  }, // Health Boost amplifier per point
  regen: {
    displayNameKey: "regen",
    property: "stats:regen",
    icon: "textures/items/carrot",
    multiplier: 0.001,
  }, // Heart/s per point
  luck: {
    displayNameKey: "luck",
    property: "stats:luck",
    icon: "textures/items/emerald",
    dropChanceMultiplier: 0.05,
    treasureChanceMultiplier: 0.1,
  }, // % for drops/treasure
  intelligence: {
    displayNameKey: "intelligence",
    property: "stats:intelligence",
    icon: "textures/items/glowstone_dust",
    xpMultiplier: 0.005,
    cooldownReduction: 0.001,
  }, // % XP, % Cooldown Reduction
  endurance: {
    displayNameKey: "endurance",
    property: "stats:endurance",
    icon: "textures/items/iron_chestplate",
    damageReduction: 0.001,
  }, // % Damage Reduction
  critical_chance: {
    displayNameKey: "critical_chance",
    property: "stats:criticalChance",
    icon: "textures/items/redstone_dust",
    multiplier: 0.2,
  }, // % Crit Chance
  critical_damage: {
    displayNameKey: "critical_damage",
    property: "stats:criticalDamage",
    icon: "textures/items/blaze_powder",
    multiplier: 0.5,
  }, // % Crit Damage
  speed: {
    displayNameKey: "speed",
    property: "stats:speed",
    icon: "textures/items/sugar",
    multiplier: 0.01,
  }, // Movement speed multiplier
};

// Vòng lặp định kỳ để áp dụng các hiệu ứng chỉ số thụ động (ví dụ: hồi máu, tốc độ, máu tối đa)
system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const hasSetupStats = getPlayerProperty(player, "skill:setUpStartLevel", 0); // Kiểm tra cờ setup từ main.js
    if (hasSetupStats === 0) continue; // Chỉ chạy cho người chơi đã được setup

    // Apply Regen effect
    const regenStat = getPlayerStat(player, "regen");
    if (regenStat > 0) {
      // player.sendMessage(`bRUHH`);
      const healthComp = player.getComponent("minecraft:health");
      if (healthComp.currentValue < healthComp.effectiveMax) {
        // Tính lượng máu hồi
        let healAmount = STATS_CONFIG.regen.multiplier * regenStat;
        const maxHealable = healthComp.effectiveMax - healthComp.currentValue;
        if (healAmount > maxHealable) healAmount = maxHealable;

        // Hồi máu
        // player.sendMessage(`Hồi ${healthComp.currentValue + healAmount}`);
        healthComp.setCurrentValue(healthComp.currentValue + healAmount);
      }
    }

    // Apply Speed effect
    const speedStat = getPlayerStat(player, "speed");
    if (speedStat > 0) {
      // Amplifier là level - 1. Nếu speedStat là 1, amplifier là 0 (Speed I)
      //   player.addEffect("speed", 20, Math.floor(speedStat / 2), {
      //     showParticles: false,
      //   });
      player.runCommand(`effect @s speed 2 ${Math.floor(speedStat / 2)} true`);
    }
    // Apply Health Boost effect
    const healthStat = getPlayerStat(player, "health");
    const skillDefense1Level = getPlayerProperty(player, `skill:defenseSkill1`);
    // if (healthStat > 0 || skillDefense1Level > 0) {
    let hearts = 20 + healthStat * 2 + skillDefense1Level * 4;
    player.runCommand(`event entity @s cmd:hearts-${hearts}`);
    // }
  }
}, 20); // Chạy mỗi giây (20 tick)

/**
 * Lấy giá trị chỉ số của người chơi.
 * @param {import("@minecraft/server").Player} player
 * @param {string} statId
 * @returns {number}
 */
export function getPlayerStat(player, statId) {
  return getPlayerProperty(player, `stats:${statId}`, 0);
}

/**
 * Tăng hoặc giảm chỉ số của người chơi bằng một lượng cụ thể.
 * @param {import("@minecraft/server").Player} player
 * @param {string} statId
 * @param {number} amount Lượng điểm muốn tăng (dương) hoặc giảm (âm).
 */
export function modifyPlayerStat(player, statId, amount) {
  const currentStat = getPlayerStat(player, statId);
  const newStat = currentStat + amount;
  setPlayerProperty(player, `stats:${statId}`, newStat < 0 ? 0 : newStat); // Đảm bảo chỉ số không âm
}

/**
 * Đặt lại tất cả chỉ số của người chơi về 0.
 * @param {import("@minecraft/server").Player} player
 * @returns {Promise<boolean>} True nếu reset thành công, false nếu không đủ tiền hoặc hủy.
 */
export async function resetAllStats(player) {
  const locale = getPlayerLocale(player);

  // Đảm bảo getMoney được import từ moneyUtils.js
  const { getMoney } = await import("./moneyUtils.js");
  const playerMoney = getMoney(player);

  if (playerMoney < resetCost) {
    player.sendMessage(`§c${getTranslatedText("not_enough_money", locale)}`);
    return false;
  }

  const confirmForm = new MessageFormData()
    .title(getTranslatedText("reset_confirmation_title", locale))
    .body(getTranslatedText("reset_confirmation_body", locale, resetCost))
    .button1(getTranslatedText("yes_reset", locale))
    .button2(getTranslatedText("no", locale));

  const response = await confirmForm.show(player);

  if (response.selection === 0) {
    // Người chơi xác nhận reset
    // Đảm bảo removeMoney được import từ moneyUtils.js
    const { removeMoney } = await import("./moneyUtils.js");
    removeMoney(player, resetCost);

    let totalPointsSpent = 0; // Biến để lưu tổng số điểm đã dùng

    // Tính tổng số điểm đã dùng trước khi reset
    for (const statId in STATS_CONFIG) {
      const currentStatLevel = getPlayerProperty(player, `stats:${statId}`);
      if (typeof currentStatLevel === "number") {
        // Đảm bảo giá trị là số
        totalPointsSpent += currentStatLevel;
      }
      // Đặt lại từng chỉ số về 0 sau khi đã cộng vào tổng
      setPlayerProperty(player, `stats:${statId}`, 0);
    }

    // Cộng tổng số điểm đã dùng vào điểm chưa phân phối
    const currentUnspentPoints =
      getPlayerProperty(player, "stats:unspentPoints") || 0;
    setPlayerProperty(
      player,
      "stats:unspentPoints",
      currentUnspentPoints + totalPointsSpent
    );

    applyAllStatEffects(player); // Áp dụng lại hiệu ứng sau khi reset

    player.sendMessage(`§a${getTranslatedText("stats_reset_success", locale)}`);
    player.sendMessage(
      `§a${getTranslatedText("points_returned", locale, totalPointsSpent)}`
    ); // Thông báo số điểm được trả lại
    return true;
  } else {
    player.sendMessage(`§7${getTranslatedText("no", locale)}`); // Người chơi hủy
    return false;
  }
}

/**
 * Tăng giá trị của một chỉ số cụ thể cho người chơi.
 * @param {import("@minecraft/server").Player} player
 * @param {string} statId ID của chỉ số (e.g., 'strength').
 * @param {number} amount Lượng muốn tăng.
 */
export function increasePlayerStat(player, statId, amount = 1) {
  const locale = getPlayerLocale(player);
  const statConfig = STATS_CONFIG[statId];

  if (!statConfig) {
    player.sendMessage(
      `§cError: Stat configuration not found for ID: ${statId}`
    );
    return;
  }

  let unspentPoints = getPlayerProperty(player, "stats:unspentPoints");

  if (unspentPoints >= amount) {
    setPlayerProperty(
      player,
      statConfig.property,
      getPlayerProperty(player, statConfig.property) + amount
    );
    setPlayerProperty(player, "stats:unspentPoints", unspentPoints - amount);
    player.sendMessage(
      `§a${getTranslatedText(
        "stat_increased",
        locale,
        getTranslatedText(statConfig.displayNameKey, locale),
        getPlayerProperty(player, statConfig.property)
      )}`
    );
    applyAllStatEffects(player); // Apply all effects after any stat change (Quan trọng để máu, tốc độ được cập nhật)
  } else {
    player.sendMessage(`§c${getTranslatedText("no_unspent_points", locale)}`);
  }
}

/**
 * Áp dụng tất cả các hiệu ứng của chỉ số lên người chơi.
 * Gọi khi chỉ số thay đổi đáng kể hoặc khi người chơi đăng nhập/spawn.
 * @param {import("@minecraft/server").Player} player
 */
export function applyAllStatEffects(player) {
  const healthComp = player.getComponent("minecraft:health");
  if (healthComp) {
    // Set máu hiện tại bằng máu tối đa
    system.runTimeout(() => {
      healthComp.setCurrentValue(healthComp.effectiveMax);
    }, 20);
  }
  // Các hiệu ứng Speed, Regen được quản lý liên tục trong system.runInterval.
}

export { STATS_CONFIG };
