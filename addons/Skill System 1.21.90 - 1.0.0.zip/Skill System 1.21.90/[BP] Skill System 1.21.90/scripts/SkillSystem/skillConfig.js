// skillConfig.js
// Định nghĩa cấu hình cho tất cả các kỹ năng

const skillConfig = {
  mining: {
    id: "mining",
    nameKey: "mining_skill_name",
    descKey: "mining_desc",
    objectivePrefix: "mining", // Sử dụng làm phần prefix cho dynamic properties (e.g., skill:mining, skill:xpMining)
    xpObjectivePrefix: "xpMining", // Tên dynamic property đầy đủ cho XP hiện tại
    nextXpObjectivePrefix: "nextXpMining", // Tên dynamic property đầy đủ cho XP cấp tiếp theo
    iconPath: "textures/items/diamond_pickaxe",
    baseXp: 50, // XP ban đầu cần để lên cấp 1
    skillLevels: {
      // Định nghĩa các kỹ năng con và cấp độ mở khóa
      skill1: {
        nameKey: "mining_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/wood_pickaxe",
        unlockLevel: 5, // Cấp độ skill chính để mở khóa
        levelInterval: 15, // Đã sửa: Mỗi 15 cấp skill chính sau unlock, tăng 1 cấp skill con
      },
      skill2: {
        nameKey: "mining_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_pickaxe",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa: Mỗi 15 cấp skill chính sau unlock, tăng 1 cấp skill con
      },
      skill3: {
        nameKey: "mining_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_pickaxe",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa: Mỗi 15 cấp skill chính sau unlock, tăng 1 cấp skill con
        baseCooldown: 200, // Thời gian hồi chiêu cơ bản (ticks)
        cooldownReductionPerLevel: 5, // Giảm hồi chiêu mỗi cấp skill con
        baseDurationSeconds: 5, // Thời gian hiệu lực cơ bản (giây)
        durationIncreasePerLevel: 1, // Tăng thời gian hiệu lực mỗi cấp
      },
    },
    xpSources: {
      // Thông tin về cách nhận XP và hàm hiển thị UI tương ứng
      type: "ore", // Chỉ để mô tả, không dùng trong code
      function: "xpOres", // Tên hàm trong file skill riêng (ví dụ: mining.js)
    },
    pageBackKey: "back_to_skill_list", // Key bản dịch cho nút quay lại
    mainSkillPageFunction: "minerPage", // Tên hàm để quay lại trang chính của skill
  },
  woodcutting: {
    id: "woodcutting",
    nameKey: "woodcutting_skill_name",
    descKey: "woodcutting_desc",
    objectivePrefix: "woodcutting",
    xpObjectivePrefix: "xpWoodcutting",
    nextXpObjectivePrefix: "nextXpWoodcutting",
    iconPath: "textures/items/iron_axe",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "woodcutting_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/wood_axe",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "woodcutting_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_axe",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "woodcutting_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_axe",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "log",
      function: "xpLogs",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "woodcutterPage",
  },
  attack: {
    id: "attack",
    nameKey: "attack_skill_name",
    descKey: "attack_desc",
    objectivePrefix: "attack",
    xpObjectivePrefix: "xpAttack",
    nextXpObjectivePrefix: "nextXpAttack",
    iconPath: "textures/items/gold_sword",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "attack_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/wood_sword",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "attack_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_sword",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "attack_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_sword",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "mob",
      function: "xpMobs",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "swordPage",
  },
  farming: {
    id: "farming",
    nameKey: "farming_skill_name",
    descKey: "farming_desc",
    objectivePrefix: "farming",
    xpObjectivePrefix: "xpFarming",
    nextXpObjectivePrefix: "nextXpFarming",
    iconPath: "textures/items/wood_hoe",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "farming_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/wood_hoe",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "farming_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_hoe",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "farming_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_hoe",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "crop",
      function: "xpCrops",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "farmerPage",
  },
  digging: {
    id: "digging",
    nameKey: "digging_skill_name",
    descKey: "digging_desc",
    objectivePrefix: "digging",
    xpObjectivePrefix: "xpDigging",
    nextXpObjectivePrefix: "nextXpDigging",
    iconPath: "textures/items/netherite_shovel",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "digging_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/wood_shovel",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "digging_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_shovel",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "digging_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_shovel",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "soil",
      function: "xpSoils",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "diggingPage",
  },
  agility: {
    id: "agility",
    nameKey: "agility_skill_name",
    descKey: "agility_desc",
    objectivePrefix: "agility",
    xpObjectivePrefix: "xpAgility",
    nextXpObjectivePrefix: "nextXpAgility",
    iconPath: "textures/items/iron_boots",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "agility_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/iron_boots",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "agility_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/gold_boots",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "agility_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_boots",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "damage_taken",
      function: "xpAgility",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "agilityPage",
  },
  defense: {
    id: "defense",
    nameKey: "defense_skill_name",
    descKey: "defense_desc",
    objectivePrefix: "defense",
    xpObjectivePrefix: "xpDefense",
    nextXpObjectivePrefix: "nextXpDefense",
    iconPath: "textures/items/iron_chestplate",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "defense_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/chainmail_chestplate",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "defense_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/iron_chestplate",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "defense_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/diamond_chestplate",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "damage_taken",
      function: "xpDefense",
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "defensePage",
  },
  ranged: {
    id: "ranged",
    nameKey: "ranged_skill_name",
    descKey: "ranged_desc",
    objectivePrefix: "ranged",
    xpObjectivePrefix: "xpRanged",
    nextXpObjectivePrefix: "nextXpRanged",
    iconPath: "textures/ui/bow_icon",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "ranged_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/ui/bow_icon",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "ranged_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/trident",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "ranged_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/arrow", // Biểu tượng placeholder
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "mob",
      function: "xpMobs", // Chung với attack
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "rangedPage",
  },
  trading: {
    id: "trading",
    nameKey: "trading_skill_name",
    descKey: "trading_desc",
    objectivePrefix: "trading",
    xpObjectivePrefix: "xpTrading",
    nextXpObjectivePrefix: "nextXpTrading",
    iconPath: "textures/items/emerald",
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "trading_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/emerald",
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "trading_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/emerald",
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        nameKey: "trading_skill3_name",
        objectiveSuffix: "Skill3",
        icon: "textures/items/emerald",
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 200,
        cooldownReductionPerLevel: 5,
        baseDurationSeconds: 5,
        durationIncreasePerLevel: 1,
      },
    },
    xpSources: {
      type: "trading",
      function: "xpTrading", // Sẽ cần hàm này nếu muốn thêm UI cho XP
    },
    pageBackKey: "back_to_skill_list",
    mainSkillPageFunction: "tradingPage",
  },
  fishing: {
    id: "fishing",
    nameKey: "fishing_skill_name",
    descKey: "fishing_desc",
    objectivePrefix: "fishing",
    xpObjectivePrefix: "xpFishing",
    nextXpObjectivePrefix: "nextXpFishing",
    iconPath: "textures/ui/fishing_rod", // Icon cho kỹ năng Fishing
    baseXp: 50,
    skillLevels: {
      skill1: {
        nameKey: "fishing_skill1_name",
        objectiveSuffix: "Skill1",
        icon: "textures/items/gold_nugget", // Icon cho Golden Lure
        unlockLevel: 5,
        levelInterval: 15, // Đã sửa
      },
      skill2: {
        nameKey: "fishing_skill2_name",
        objectiveSuffix: "Skill2",
        icon: "textures/items/string", // Icon cho Fishing Net
        unlockLevel: 10,
        levelInterval: 15, // Đã sửa
      },
      skill3: {
        // Chuyển đổi skill3 hiện tại thành Fish Flurry
        nameKey: "fishing_skill3_name", // Tên hiển thị của skill
        descriptionKey: "fishing_skill3_description", // Mô tả tổng quát
        icon: "textures/ui/fishing_rod", // Icon cho Fishing Net
        unlockLevel: 15,
        levelInterval: 15, // Đã sửa
        baseCooldown: 60, // Giây
        cooldownReductionPerLevel: 2, // Giảm cooldown mỗi cấp
        baseDurationSeconds: 5, // Thời gian hiệu lực
        durationIncreasePerLevel: 0.5, // Tăng thời gian hiệu lực mỗi cấp
        baseDamage: 3, // Sát thương cơ bản mỗi đòn đánh từ cá
        damageIncreasePerLevel: 0.5, // Tăng sát thương mỗi cấp
        radius: 5, // Bán kính tấn công
        attackInterval: 0.5, // Tấn công mỗi 0.5 giây trong thời gian hiệu lực
        effectChance: 15, // % cơ hội gây hiệu ứng (ví dụ: làm chậm)
        effectDuration: 3, // Giây
      },
    },
    xpSources: {
      type: "fishing",
      function: "xpFishing", // Sẽ cần hàm này trong fishing.js
    },
    pageBackKey: "back_to_fishing_page",
    mainSkillPageFunction: "fishingPage", // Sẽ cần hàm này trong fishing.js
  },
};

export { skillConfig };
