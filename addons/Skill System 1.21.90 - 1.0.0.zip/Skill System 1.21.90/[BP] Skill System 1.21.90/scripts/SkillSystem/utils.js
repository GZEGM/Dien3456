// utils.js
import { system } from "@minecraft/server";
import { getTranslatedText, getPlayerLocale } from "./lang.js"; // Import cho các tin nhắn lỗi
import {
  updatePlayerSkillDataLocal,
  // Không cần getAllPlayerSkillDataLocal ở đây nếu nó chỉ được dùng trong localDataStore.js
} from "./localDataStore.js"; // IMPORT MỚI: localDataStore
import { skillConfig } from "./skillConfig.js"; // Import cấu hình skills để biết các skill cần reset
import { STATS_CONFIG, applyAllStatEffects } from "./playerStats.js"; // Cần import nếu chưa có

/**
 * Hàm tiện ích để lấy giá trị dynamic property của người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {string} propertyName Tên của dynamic property (ví dụ: 'skill:mining').
 * @param {any} defaultValue Giá trị mặc định nếu property không tồn tại.
 * @returns {any} Giá trị của dynamic property hoặc giá trị mặc định.
 */
export function getPlayerProperty(player, propertyName, defaultValue = 0) {
  try {
    const value = player.getDynamicProperty(propertyName);
    return value !== undefined ? value : defaultValue;
  } catch (e) {
    // Sử dụng getPlayerLocale để đảm bảo tin nhắn lỗi được dịch nếu có thể
    console.error(
      `[Error] ${getTranslatedText(
        "failed_to_get_dynamic_property",
        getPlayerLocale(player)
      )} ${propertyName}: ${e}`
    );
    return defaultValue;
  }
}

/**
 * Hàm tiện ích để đặt giá trị dynamic property của người chơi.
 * Đồng thời cập nhật dữ liệu vào kho lưu trữ cục bộ nếu là thuộc tính skill hoặc stat.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {string} propertyName Tên của dynamic property.
 * @param {any} value Giá trị muốn đặt.
 */
export function setPlayerProperty(player, propertyName, value) {
  try {
    // Đặt dynamic property trực tiếp lên người chơi
    player.setDynamicProperty(propertyName, value);

    // Kiểm tra nếu đây là một thuộc tính cần được lưu vào leaderboard offline
    if (
      propertyName.startsWith("skill:") ||
      propertyName.startsWith("stats:")
    ) {
      const playerId = player.id;
      const playerName = player.name;

      // Lấy toàn bộ dữ liệu skill và stat hiện tại của người chơi từ các dynamic properties.
      const playerAllData = {
        totalSkillPoint: getPlayerProperty(player, "skill:totalSkillPoint", 0),
        stamina: getPlayerProperty(player, "skill:stamina", 0),
      };

      // Thêm tất cả các skill level
      for (const skillId in skillConfig) {
        playerAllData[skillId] = getPlayerProperty(
          player,
          `skill:${skillConfig[skillId].objectivePrefix}`,
          0
        );
      }

      // Thêm tất cả các stat level
      for (const statId in STATS_CONFIG) {
        playerAllData[statId] = getPlayerProperty(
          player,
          STATS_CONFIG[statId].property,
          0
        );
      }
      playerAllData.unspentPoints = getPlayerProperty(
        player,
        "stats:unspentPoints",
        0
      );

      // *********** ĐOẠN CODE KIỂM TRA LỖI NÀY LÀ QUAN TRỌNG ***********
      if (typeof updatePlayerSkillDataLocal !== "function") {
        console.error(
          `[ERROR - Local Data Store] updatePlayerSkillDataLocal is NOT a function! ` +
            `Its type is: ${typeof updatePlayerSkillDataLocal}. ` +
            `This means localDataStore.js might not be loaded correctly or the function isn't exported.`
        );
        // Ngừng thực thi ở đây để tránh lỗi 'not a function' và xem log
        return;
      }
      // ***************************************************************

      // Cập nhật dữ liệu vào kho lưu trữ cục bộ trên entity
      updatePlayerSkillDataLocal(playerId, playerName, playerAllData);
    }
  } catch (e) {
    // Sử dụng getPlayerLocale để đảm bảo tin nhắn lỗi được dịch nếu có thể
    console.error(
      `[Error] ${getTranslatedText(
        "failed_to_set_dynamic_property",
        getPlayerLocale(player)
      )} ${propertyName} to ${value}: ${e}`
    );
  }
}

// utils.js (Thêm hàm này vào file của bạn)
import { ItemStack } from "@minecraft/server";

/**
 * Cố gắng thêm một ItemStack vào hành trang của người chơi, ưu tiên các stack hiện có.
 * Nếu không thể thêm vào inventory, item sẽ được spawn tại vị trí người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {import("@minecraft/server").ItemStack} itemStackToAdd ItemStack cần thêm.
 * @returns {boolean} True nếu item được thêm vào inventory, false nếu item bị spawn ra thế giới.
 */
export function tryAddItemToPlayerInventory(player, itemStackToAdd) {
  if (!itemStackToAdd || itemStackToAdd.amount <= 0) return true;

  const inventoryComponent = player.getComponent("minecraft:inventory");
  if (!inventoryComponent || !inventoryComponent.container) {
    console.warn(
      `Lỗi: Không tìm thấy component inventory cho người chơi ${player.name}. Item ${itemStackToAdd.typeId} sẽ được spawn.`
    );
    player.dimension.spawnItem(itemStackToAdd, player.location);
    return false;
  }

  const container = inventoryComponent.container;
  let remainingAmount = itemStackToAdd.amount;

  // 1. Gộp vào các stack hiện có
  for (let i = 0; i < container.size; i++) {
    const slot = container.getItem(i);
    if (
      slot &&
      slot.typeId === itemStackToAdd.typeId &&
      slot.isStackable &&
      slot.maxAmount > 1 &&
      (slot.getLore()?.toString() || "") ===
        (itemStackToAdd.getLore()?.toString() || "") &&
      (slot.nameTag || "") === (itemStackToAdd.nameTag || "")
    ) {
      const canAdd = slot.maxAmount - slot.amount;
      if (canAdd > 0) {
        const addAmount = Math.min(remainingAmount, canAdd);
        slot.amount += addAmount;
        container.setItem(i, slot);
        remainingAmount -= addAmount;
        if (remainingAmount <= 0) return true;
      }
    }
  }

  // 2. Thêm vào các slot trống
  for (let i = 0; i < container.size; i++) {
    const slot = container.getItem(i);
    if (!slot) {
      const newStack = new ItemStack(itemStackToAdd.typeId, remainingAmount);
      newStack.nameTag = itemStackToAdd.nameTag || "";
      if (itemStackToAdd.getLore()) newStack.setLore(itemStackToAdd.getLore());

      container.setItem(i, newStack);
      return true;
    }
  }

  // 3. Nếu không thể thêm, spawn ra ngoài
  player.sendMessage(
    `§c${getTranslatedText(
      "inventory_full_or_slot_issue",
      getPlayerLocale(player),
      itemStackToAdd.typeId.replace("minecraft:", "")
    )}`
  );
  player.dimension.spawnItem(itemStackToAdd, player.location);
  return false;
}
/**
 * Reset toàn bộ dữ liệu liên quan đến kỹ năng của một người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi cần reset skill.
 */
export function resetPlayerSkills(player) {
  const locale = getPlayerLocale(player);

  if (!player) {
    console.error("Lỗi: Người chơi không hợp lệ để reset skill.");
    return;
  }

  // Đặt lại các properties của skill chính và XP
  // Đã sửa: Giờ đây duyệt qua đối tượng `skillConfig` đã được import.
  for (const skillId in skillConfig) {
    const currentSkillConfig = skillConfig[skillId]; // Lấy cấu hình cho từng skill dựa trên skillId
    const {
      objectivePrefix,
      xpObjectivePrefix,
      nextXpObjectivePrefix,
      skillLevels,
    } = currentSkillConfig;

    // Reset cấp độ skill chính về 0
    setPlayerProperty(player, `skill:${objectivePrefix}`, 0);
    // Reset XP hiện tại về 0
    setPlayerProperty(player, `skill:${xpObjectivePrefix}`, 0);
    // Reset XP cần cho cấp độ tiếp theo về giá trị base (hoặc mặc định)
    setPlayerProperty(
      player,
      `skill:${nextXpObjectivePrefix}`,
      currentSkillConfig.baseXp || 100 // Sử dụng baseXp từ cấu hình skill hiện tại, hoặc 100 làm mặc định
    );

    // Reset cấp độ của tất cả các skill con về 0
    if (skillLevels) {
      // Lặp qua tất cả các skill con được định nghĩa trong skillLevels
      for (const subSkillKey in skillLevels) {
        const subSkillConfig = skillLevels[subSkillKey];
        // Đảm bảo subSkillConfig hợp lệ và có objectiveSuffix
        if (subSkillConfig && subSkillConfig.objectiveSuffix) {
          setPlayerProperty(
            player,
            `skill:${objectivePrefix}${subSkillConfig.objectiveSuffix}`,
            0
          );
        }
      }
    }
  }

  // Reset tổng điểm kỹ năng đã kiếm được về 0
  setPlayerProperty(player, "skill:totalSkillPoint", 0);
  // Reset cả điểm chỉ số chưa dùng (unspentPoints) về 0
  setPlayerProperty(player, "stats:unspentPoints", 0);

  // Reset tất cả các chỉ số (strength, health, ...) về 0
  for (const statId in STATS_CONFIG) {
    setPlayerProperty(player, STATS_CONFIG[statId].property, 0);
  }

  // Cập nhật lại tất cả các hiệu ứng chỉ số của người chơi sau khi reset skill.
  // Điều này đảm bảo rằng các buffs/debuffs liên quan đến skill được xóa bỏ hoặc áp dụng lại đúng.
  applyAllStatEffects(player);

  player.sendMessage(`§a${getTranslatedText("skills_reset_success", locale)}`);
  console.warn(`Đã reset toàn bộ dữ liệu skill của người chơi: ${player.name}`);
}

export function isInventoryFull(container, itemStack) {
  const size = container.size;

  for (let i = 0; i < size; i++) {
    const slot = container.getItem(i);

    // Slot is empty
    if (!slot) return false;

    // Same item type and can stack more
    if (slot.typeId === itemStack.typeId && slot.amount < slot.maxAmount) {
      return false;
    }
  }

  return true; // No room found
}

export function getRandomOffset(radius) {
  const angle = Math.random() * Math.PI * 2;
  const distance = Math.random() * radius;
  return {
    x: Math.floor(Math.cos(angle) * distance),
    z: Math.floor(Math.sin(angle) * distance),
  };
}

// Hàm triệu hồi TNT và sét quanh vị trí block đào
export function summonCrystalandLightningAt(pos, dimension) {
  const radius = 12;

  const lightningCount = Math.floor(Math.random() * 6) + 5; // 2–5 lightning
  for (let i = 0; i < lightningCount; i++) {
    const offset = getRandomOffset(radius);
    const spawnPos = {
      x: pos.x + offset.x,
      y: pos.y,
      z: pos.z + offset.z,
    };
    system.runTimeout(() => {
      dimension.spawnEntity("minecraft:lightning_bolt", spawnPos);
    }, 10);
  }

  const crystalCount = Math.floor(Math.random() * 5) + 3; // 3–8 crystals

  for (let i = 0; i < crystalCount; i++) {
    const offset = getRandomOffset(radius);
    const crystalPos = {
      x: pos.x + offset.x + 0.5,
      y: pos.y + 1,
      z: pos.z + offset.z + 0.5,
    };

    const crystal = dimension.spawnEntity(
      "minecraft:ender_crystal",
      crystalPos
    );
  }
}
