// skills/defense.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";

const defenseSkill3Cooldown = new CooldownManager("defenseSkill3");
const SKILL_ID = "defense";
const config = skillConfig[SKILL_ID];

/**
 * Hàm lên cấp cho kỹ năng Defense (Cường thân).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function defenseLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Defense (Cường thân).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function defensePage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpDefense, defenseSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Defense (Cường thân).
 * @param {import("@minecraft/server").Player} player
 */
export async function defenseSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "defense_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText("health_max", locale)} ${Math.floor(
        level * 4
      )}`, // Mô tả tác dụng lên chỉ số Health
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "defense_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((2 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20; // Convert to ticks
      const cooldownReductionPerLevel =
        skill3Config.cooldownReductionPerLevel * 20; // Convert to ticks
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second (20 ticks)
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = finalCooldownTicks / 20; // Convert back to seconds for display

      const finalDurationSeconds =
        baseDurationSeconds + level * durationIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "defense_skill3_active_desc",
        locale,
        Math.floor(finalCooldownSeconds),
        Math.floor(finalDurationSeconds) // Use the calculated duration in seconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "") // Clean up any formatting from translation if needed
        .replace(":", "")}: ${Math.floor(
        finalCooldownSeconds
      )}s\n§7Duration: ${Math.floor(finalDurationSeconds)}s`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    defensePage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Defense (Cường thân).
 * @param {import("@minecraft/server").Player} player
 */
export async function xpDefense(player) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(getTranslatedText("experience", locale));

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  // For display, let's assume a base damage of 1 to show per-damage XP.
  const baseDamage = 1;
  let estimatedXpPerDamage = baseDamage * (1 + currentSkillLevel * 0.05);
  estimatedXpPerDamage += estimatedXpPerDamage * xpBonusFromInt;

  Form.button(
    0,
    getTranslatedText("xp_from_damage_taken", locale),
    [`\n§3${estimatedXpPerDamage.toFixed(1)}§a ✦§r/sát thương nhận`],
    `textures/items/iron_chestplate`,
    1,
    false
  );

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      // No other cases needed as there's no pagination
    }
  }
}

// Xử lý sự kiện khi người chơi nhận sát thương để tăng XP Defense và áp dụng chỉ số Endurance
world.afterEvents.entityHurt.subscribe((eventData) => {
  const victim = eventData.hurtEntity;
  if (!(victim instanceof Player)) return;

  const hasSetup = getPlayerProperty(victim, "skill:setUpStartLevel", 0);
  if (hasSetup === 0) return;

  // Lượng sát thương mà game đã ÁP DỤNG lên người chơi
  const originalDamageApplied = eventData.damage;

  // Lấy component sức khỏe của nạn nhân
  let healthCmp = victim.getComponent("minecraft:health");
  let currentHealth = healthCmp.currentValue;

  // -- 1. Tính toán sát thương lẽ ra phải nhận --
  // Bắt đầu với sát thương gốc mà người chơi vừa nhận
  let calculatedDamage = originalDamageApplied;

  // Giảm sát thương từ Endurance
  const enduranceLevel = getPlayerStat(victim, "endurance");
  const damageReductionFromEndurance =
    enduranceLevel * STATS_CONFIG.endurance.damageReduction;
  calculatedDamage = Math.max(
    calculatedDamage * (1 - damageReductionFromEndurance),
    0
  );

  // Skill 2: Hấp thụ máu
  const skill2Level = getPlayerProperty(victim, `skill:${SKILL_ID}Skill2`);
  let healthAbsorbed = 0;
  if (skill2Level > 0 && Math.random() < (2 + skill2Level) / 100) {
    healthAbsorbed = Math.min(calculatedDamage, skill2Level);
    calculatedDamage = Math.max(0, calculatedDamage - healthAbsorbed); // Giảm sát thương cuối cùng
    victim.sendMessage(
      `§a${getTranslatedText(
        "defense_skill2_absorb_health",
        getPlayerLocale(victim),
        Math.floor(healthAbsorbed)
      )}`
    );
  }

  // --- 2. Xử lý bù trừ sát thương và áp dụng sát thương cuối cùng ---

  // Lượng máu mà người chơi nên MẤT (sau khi tính toán phòng thủ và hút máu)
  const netHealthLoss = calculatedDamage;

  // Máu hiện tại của người chơi LÚC SỰ KIỆN NÀY KÍCH HOẠT (đã bị trừ originalDamageApplied)
  // Máu lý tưởng của người chơi NẾU sát thương được tính toán đúng ngay từ đầu
  const desiredHealthAfterHit =
    healthCmp.currentValue + originalDamageApplied - netHealthLoss;

  try {
    healthCmp.setCurrentValue(desiredHealthAfterHit);
  } catch (e) {}

  // -- Tính XP dựa trên damage gốc (để khuyến khích phòng thủ) --
  const currentDefenseLevel = getPlayerProperty(victim, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(victim, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;
  // Standardized XP calculation: original_damage * (1 + currentSkillLevel * 0.05)
  let xpGain = originalDamageApplied * (1 + currentDefenseLevel * 0.05);
  xpGain += xpGain * xpBonusFromInt;

  setPlayerProperty(
    victim,
    `skill:xpDefense`,
    getPlayerProperty(victim, `skill:xpDefense`) + xpGain
  );
  defenseLevelUp(victim);

  activateDefenseSkill3(victim);
});

// ========================== SKILL 3 ===========================

export function activateDefenseSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = defenseSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(`§a${getTranslatedText("defense_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động
  player.addTag("skill:theShieldOfTheGodActive");

  // Đặt cooldown
  defenseSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(
      `§e${getTranslatedText("defense_skill3_ended", locale)}`
    );
    player.removeTag("skill:theShieldOfTheGodActive");
  }, finalDurationSeconds * 20);
}
