// skills/ranged.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import {
  getPlayerProperty,
  setPlayerProperty,
  getRandomOffset,
} from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { mobs } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";

const rangedSkill3Cooldown = new CooldownManager("rangedSkill3");

const SKILL_ID = "ranged";
const config = skillConfig[SKILL_ID];

/**
 * Hàm lên cấp cho kỹ năng Ranged (Xạ thủ).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function rangedLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Ranged (Xạ thủ).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function rangedPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpMobs, rangedSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Ranged (Xạ thủ).
 * @param {import("@minecraft/server").Player} player
 */
export async function rangedSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "ranged_skill1_passive_desc",
        locale,
        Math.floor(((2 + level) / 100) * 100),
        Math.floor((level + 5) / 2)
      )}`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "ranged_skill2_passive_desc",
        locale,
        Math.floor(((level + 2) / 100) * 100)
      )}\n\n§7${getTranslatedText("damage", locale)}: ${
        5 + level
      }\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((level + 2) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20; // Convert to ticks
      const cooldownReductionPerLevel =
        skill3Config.cooldownReductionPerLevel * 20; // Convert to ticks
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second (20 ticks)
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = finalCooldownTicks / 20; // Convert back to seconds for display

      const finalDurationSeconds =
        baseDurationSeconds + level * durationIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "ranged_skill3_active_desc",
        locale,
        Math.floor(finalCooldownSeconds),
        Math.floor(finalDurationSeconds) // Use the calculated duration in seconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(":", "")}: ${Math.floor(
        finalCooldownSeconds
      )}s\n§7Duration: ${Math.floor(finalDurationSeconds)}s`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    rangedPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Ranged (Xạ thủ).
 * (Sử dụng chung với Attack vì cùng là XP từ mobs)
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpMobs(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_mob", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = mobs.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence"); // Lấy chỉ số Intelligence
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const mobConfig = mobs[i];
    // Standardized XP calculation: base_mob_xp * (1 + currentSkillLevel * 0.1)
    const baseMobXp = mobConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseMobXp + baseMobXp * xpBonusFromInt; // Cộng thêm XP từ Intelligence
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${mobConfig.name} §7(${mobConfig.id})`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${mobConfig.name}`],
      `${mobConfig.texture}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpMobs(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpMobs(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

world.afterEvents.entityDie.subscribe((event) => {
  const deadEntity = event.deadEntity;
  const damageSource = event.damageSource;

  if (!damageSource || damageSource.cause !== "projectile") return;

  const shooter = damageSource.damagingEntity;
  if (!(shooter instanceof Player)) return;

  const hitEntity = deadEntity;
  const locale = getPlayerLocale(shooter);
  const hasSetup = getPlayerProperty(shooter, "skill:setUpStartLevel", 0);
  if (hasSetup === 0) return;

  const strengthLevel = getPlayerStat(shooter, "strength");
  const intelligenceLevel = getPlayerStat(shooter, "intelligence");
  const critChance = getPlayerStat(shooter, "critical_chance");
  const critDamage = getPlayerStat(shooter, "critical_damage");

  // Gửi thông báo nếu chí mạng
  if (
    Math.random() * 100 <
    critChance * STATS_CONFIG.critical_chance.multiplier
  ) {
    shooter.sendMessage(
      `§6Chí mạng bằng cung! Gây thêm sát thương +${Math.floor(
        critDamage * STATS_CONFIG.critical_damage.multiplier
      )}%`
    );
  }

  // === TÍNH XP DỰA TRÊN MOB ===
  const mobData = mobs.find((mob) => mob.id === hitEntity.typeId);
  if (mobData) {
    const currentRangedLevel = getPlayerProperty(shooter, `skill:${SKILL_ID}`);
    const baseXp = mobData.xp;
    // Standardized XP calculation: base_mob_xp * (1 + currentSkillLevel * 0.1)
    const xpFromLevel = baseXp * (1 + currentRangedLevel * 0.1);
    const bonusFromInt =
      xpFromLevel *
      (intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier);
    const totalXp = xpFromLevel + bonusFromInt; // Removed Math.floor here to keep decimals if needed later

    setPlayerProperty(
      shooter,
      `skill:xpRanged`,
      getPlayerProperty(shooter, `skill:xpRanged`) + totalXp
    );

    rangedLevelUp(shooter);
  }
});

world.afterEvents.entityHurt.subscribe((event) => {
  const { damageSource, hurtEntity } = event;
  if (
    damageSource.cause == "projectile" &&
    hurtEntity.getComponent("minecraft:health").currentValue > 0
  ) {
    const shooter = damageSource.damagingEntity;
    if (!(shooter instanceof Player)) return;

    const pos = hurtEntity.location;
    const dimension = hurtEntity.dimension;

    const locale = getPlayerLocale(shooter);
    const hasSetup = getPlayerProperty(shooter, "skill:setUpStartLevel", 0);
    if (hasSetup === 0) return;

    const inventory = shooter.getComponent("minecraft:inventory");
    const heldItem = inventory.container.getItem(shooter.selectedSlotIndex);

    // if (
    //   !heldItem ||
    //   heldItem.typeId != "minecraft:bow" ||
    //   heldItem.typeId != "minecraft:crossbow"
    // )
    //   return;

    // === Skill 1: Dấu ấn tử vong (độc) ===
    const skill1Level = getPlayerProperty(shooter, `skill:${SKILL_ID}Skill1`);
    if (
      skill1Level > 0 &&
      Math.random() * 100 < ((2 + skill1Level) / 100) * 100
    ) {
      hurtEntity.addTag(`skill:dauAnTuVong_${shooter.name}`);
      hurtEntity.runCommand(
        `effect @s poison ${Math.floor((skill1Level + 5) / 2)} 0`
      );
      hurtEntity.runCommand(
        `effect @s blindness ${Math.floor((skill1Level + 5) / 2)} 0`
      );
      shooter.sendMessage(
        `§c${getTranslatedText("ranged_skill1_active", locale)}${Math.floor(
          (skill1Level + 5) / 2
        )}s!`
      );
      system.runTimeout(() => {
        try {
          hurtEntity.removeTag(`skill:dauAnTuVong_${shooter.name}`);
        } catch (e) {}
      }, Math.floor((skill1Level + 5) / 2) * 20);
    }

    // === Skill 2: Lôi tiễn ===
    const skill2Level = getPlayerProperty(shooter, `skill:${SKILL_ID}Skill2`);
    if (
      skill2Level > 0 &&
      Math.random() * 100 < ((2 + skill2Level) / 100) * 100
    ) {
      const radius = 6;
      system.runTimeout(() => {
        hurtEntity.runCommand(
          `damage @s ${skill2Level + 5} projectile entity "${shooter.name}" `
        );
      }, 10);
      dimension.spawnEntity("minecraft:lightning_bolt", pos);
      const lightningCount = Math.floor(Math.random() * 3) + 2; // 2–5 lightning
      for (let i = 0; i < lightningCount; i++) {
        const offset = getRandomOffset(radius);
        const spawnPos = {
          x: pos.x + offset.x,
          y: pos.y,
          z: pos.z + offset.z,
        };

        dimension.spawnEntity("minecraft:lightning_bolt", spawnPos);
      }
      shooter.sendMessage(
        `§b${getTranslatedText(
          "ranged_skill2_name",
          locale,
          Math.floor(((skill2Level + 2) / 100) * 100)
        )}`
      );
    }

    activateRangedSkill3(shooter, hurtEntity, pos, dimension);
  }
});

// ======================== SKILLL 3 ======================
export function activateRangedSkill3(player, target, pos, dimension) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = rangedSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(`§a${getTranslatedText("ranged_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động
  activateSkillVanTuyenXuyenTam(player, dimension, target, pos);
  // Đặt cooldown
  rangedSkill3Cooldown.setCooldown(player, finalCooldownTicks);
  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(`§e${getTranslatedText("ranged_skill3_ended", locale)}`);
  }, finalDurationSeconds * 20);
}

// =======================================================
export function activateSkillVanTuyenXuyenTam(
  shooter,
  dimension,
  target = null,
  pos = null
) {
  const arrowCount = 15;
  const radius = 2;
  const arrows = [];
  const center = shooter.location;

  if (!target) {
    const searchPos = pos ?? center;
    const nearby = dimension.getEntities({
      location: searchPos,
      maxDistance: 20,
      excludeTypes: ["minecraft:player"],
      excludeFamilies: ["invisible", "spectator"],
    });
    if (nearby.length === 0) {
      shooter.sendMessage("§cKhông tìm thấy mục tiêu.");
      return;
    }
    target = nearby[0];
  }

  // === Giai đoạn 1: Xoay quanh shooter ===
  for (let i = 0; i < arrowCount; i++) {
    const angle = (Math.PI * 2 * i) / arrowCount;
    const x = center.x + Math.cos(angle) * radius;
    const y = center.y + 1.5;
    const z = center.z + Math.sin(angle) * radius;
    const arrow = dimension.spawnEntity("minecraft:arrow", { x, y, z });
    arrows.push({ entity: arrow, angleOffset: angle });
  }

  let ticks = 0;
  const maxSpinTicks = 10;

  const spinInterval = system.runInterval(() => {
    ticks++;

    const shooterPos = shooter.location;
    for (const data of arrows) {
      const { entity: arrow, angleOffset } = data;
      if (!arrow?.isValid) continue;

      const angle = angleOffset + ticks * 0.3;
      const x = shooterPos.x + Math.cos(angle) * radius;
      const y = shooterPos.y + 1.5 + Math.sin(ticks * 0.2) * 0.5;
      const z = shooterPos.z + Math.sin(angle) * radius;

      arrow.teleport({ x, y, z }, { facingLocation: target.location });
    }

    if (ticks >= maxSpinTicks) {
      system.clearRun(spinInterval);
      // shooter.sendMessage("§6✦ §lVẠN TUYỄN XUYÊN TÂM§r§6 hội tụ!");
      shooter.playSound("random.explode", { pitch: 1.3, volume: 2 });

      // === Giai đoạn 2: Bay lên đầu shooter ===
      for (const { entity: arrow } of arrows) {
        if (!arrow?.isValid) continue;

        const startPos = arrow.location;
        const peakY = shooter.location.y + 3.5;

        let stepUp = 0;
        const stepMax = 8;

        const upInterval = system.runInterval(() => {
          stepUp++;
          if (!arrow?.isValid) return;

          const newY = startPos.y + (peakY - startPos.y) * (stepUp / stepMax);
          arrow.teleport(
            { x: startPos.x, y: newY, z: startPos.z },
            { facingLocation: target.location }
          );

          if (stepUp >= stepMax) {
            system.clearRun(upInterval);

            // === Giai đoạn 3: Bay từ trên đầu đến target ===
            let moveTicks = 0;
            const maxMoveTicks = 20;

            const flyInterval = system.runInterval(() => {
              moveTicks++;
              if (!arrow?.isValid || !target?.isValid) {
                system.clearRun(flyInterval);
                return;
              }

              const arrowPos = arrow.location;
              const targetPos = target.location;

              const dir = {
                x: targetPos.x - arrowPos.x,
                y: targetPos.y + 1 - arrowPos.y,
                z: targetPos.z - arrowPos.z,
              };
              const length = Math.sqrt(dir.x ** 2 + dir.y ** 2 + dir.z ** 2);
              const speed = 0.6;

              const velocity = {
                x: (dir.x / length) * speed,
                y: (dir.y / length) * speed,
                z: (dir.z / length) * speed,
              };

              // ✅ Luôn cập nhật facing theo vị trí mới nhất của target
              arrow.teleport(
                {
                  x: arrowPos.x + velocity.x,
                  y: arrowPos.y + velocity.y,
                  z: arrowPos.z + velocity.z,
                },
                {
                  facingLocation: target.location, // ← luôn động
                }
              );

              const dist = Math.sqrt(
                (targetPos.x - arrowPos.x) ** 2 +
                  (targetPos.y - arrowPos.y) ** 2 +
                  (targetPos.z - arrowPos.z) ** 2
              );

              if (dist < 1.5) {
                target.applyDamage(4);
                // arrow.triggerEvent("despawn");
                dimension.spawnParticle(
                  "minecraft:explosion_particle",
                  arrow.location
                );
                system.clearRun(flyInterval);
              }
            }, 1);
          }
        }, 1);
      }
    }
  }, 1);
}
