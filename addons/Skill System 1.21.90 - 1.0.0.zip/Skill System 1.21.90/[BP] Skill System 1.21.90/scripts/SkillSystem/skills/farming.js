// skills/farming.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { crops, cropsGrowth } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "farming";
const config = skillConfig[SKILL_ID];

const farmingSkill3Cooldown = new CooldownManager("farmingSkill3"); // DÒNG MỚI

/**
 * Hàm lên cấp cho kỹ năng Farming (Nông phu).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function farmerLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Farming (Nông phu).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function farmerPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpCrops, farmingSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Farming (Nông phu).
 * @param {import("@minecraft/server").Player} player
 */
export async function farmingSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "farming_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((5 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "farming_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((10 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20; // Convert to ticks
      const cooldownReductionPerLevel =
        skill3Config.cooldownReductionPerLevel * 20; // Convert to ticks
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second (20 ticks)
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = finalCooldownTicks / 20; // Convert back to seconds for display

      const finalDurationSeconds =
        baseDurationSeconds + level * durationIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "farming_skill3_active_desc",
        locale,
        Math.floor(finalCooldownSeconds), // Use the calculated cooldown in seconds
        Math.floor(finalDurationSeconds) // Use the calculated duration in seconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "") // Clean up any formatting from translation if needed
        .replace(":", "")}: ${Math.floor(
        finalCooldownSeconds
      )}s\n§7Duration: ${Math.floor(finalDurationSeconds)}s`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    farmerPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Farming (Nông phu).
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpCrops(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_crops", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = crops.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence"); // Lấy chỉ số Intelligence
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const cropConfig = crops[i];
    // Standardized XP calculation: base_crop_xp * (1 + currentSkillLevel * 0.1)
    const baseCropXp = cropConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseCropXp + baseCropXp * xpBonusFromInt; // Cộng thêm XP từ Intelligence
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${cropConfig.xpType}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${cropConfig.xpType}`],
      `${cropConfig.blockID}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpCrops(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpCrops(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

// Hàm xử lý khi người chơi phá hủy block cây trồng
world.afterEvents.playerBreakBlock.subscribe(async (eventData) => {
  const player = eventData.player;
  const block = eventData.block;
  const brokenBlockTypeId = eventData.brokenBlockPermutation.type.id; // Sử dụng brokenBlockTypeId

  // Kiểm tra nếu block là cây trồng và đã trưởng thành hoàn toàn
  const locale = getPlayerLocale(player);
  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0) return;

  // Lấy chỉ số Intelligence và Luck
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;
  const luckLevel = getPlayerStat(player, "luck");
  const dropChanceBonus = luckLevel * STATS_CONFIG.luck.dropChanceMultiplier;

  // Tính XP dựa trên loại cây trồng và cấp độ Farming
  const cropConfig = crops.find((c) => c.blockID === brokenBlockTypeId);
  if (cropConfig) {
    const currentFarmingLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
    // Standardized XP calculation: base_crop_xp * (1 + currentSkillLevel * 0.1)
    let xpGain = cropConfig.xp * (1 + currentFarmingLevel * 0.1);
    xpGain += xpGain * xpBonusFromInt; // Cộng thêm XP từ Intelligence

    setPlayerProperty(
      player,
      `skill:xpFarming`,
      getPlayerProperty(player, `skill:xpFarming`) + xpGain
    );
    farmerLevelUp(player);

    // Skill 1: Crops plus (thêm nông sản)
    const skill1Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
    if (
      skill1Level > 0 &&
      Math.random() * 100 < ((5 + skill1Level) / 100) * 100 + dropChanceBonus
    ) {
      player.runCommand(`give @s ${cropConfig.xpType} 1`);
      player.sendMessage(
        `§a${getTranslatedText("farming_skill1_passive_desc", locale)}!`
      );
    }

    // SKILL 3
    if (player.hasTag("skill:autoPlant")) {
      let pos = block.location;
      player.runCommand(
        `setblock ${pos.x} ${pos.y} ${pos.z} ${brokenBlockTypeId}`
      );
    }
  }
});

// Xử lý Farming Skill 2: Lưỡi hái tử thần (Critical Hit chance with hoe)
world.afterEvents.entityHitEntity.subscribe((eventData) => {
  const attacker = eventData.damagingEntity;
  const victim = eventData.hitEntity;

  if (attacker && attacker instanceof Player) {
    const item = attacker
      .getComponent("minecraft:inventory")
      .container.getItem(attacker.selectedSlotIndex);
    if (!item || !item.typeId.includes("hoe")) return; // Chỉ kích hoạt nếu cầm cuốc

    const farmingSkill2Level = getPlayerProperty(
      attacker,
      `skill:${SKILL_ID}Skill2`
    );
    if (farmingSkill2Level > 0) {
      const critChanceBonus = farmingSkill2Level * 0.05; // 5% base per skill level (adjust as needed)

      // Lấy chỉ số Critical Chance và Critical Damage từ Stats
      const critChanceStat = getPlayerStat(attacker, "critical_chance");
      const critDamageStat = getPlayerStat(attacker, "critical_damage");

      const finalCritChance =
        (10 + farmingSkill2Level) / 100 +
        (critChanceStat * STATS_CONFIG.critical_chance.multiplier) / 100;

      if (Math.random() * 100 < finalCritChance) {
        let damage =
          1.5 +
          (critDamageStat * STATS_CONFIG.critical_damage.multiplier) / 100; // Base 1.5x crit damage + stat bonus
        system.runTimeout(() => {
          victim.runCommand(
            `damage @s ${Math.floor(damage)} entity_attack entity "${
              attacker.name
            }"`
          );
        }, 10);

        attacker.sendMessage(
          `§6${getTranslatedText(
            "reaper_scythe_active",
            getPlayerLocale(attacker),
            Math.floor(damage)
          )}!`
        );
      }
    }
  }
});

// ========================= SKILL 3 ========================

export function activateFarmingSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = farmingSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(
    `§a${getTranslatedText("farming_skill3_activated", locale)}`
  );
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động (tương tự woodcutting)
  player.addTag("skill:autoPlant");

  // Đặt cooldown
  farmingSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(
      `§e${getTranslatedText("farming_skill3_ended", locale)}`
    );
    player.removeTag("skill:autoPlant"); // Gỡ tag khi hết hiệu ứng
  }, finalDurationSeconds * 20);
}
