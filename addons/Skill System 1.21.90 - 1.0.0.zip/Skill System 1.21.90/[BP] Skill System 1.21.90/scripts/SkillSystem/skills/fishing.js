// skills/fishing.js
// Đảm bảo không import Vector nữa:
import { world, system, Player, ItemStack, ItemTypes } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import {
  getPlayerProperty,
  setPlayerProperty,
  tryAddItemToPlayerInventory,
} from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { fishTypes, treasureFish } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const fishingSkill3Cooldown = new CooldownManager("fishingSkill3");
const SKILL_ID = "fishing";
const config = skillConfig[SKILL_ID];

// Map tạm thời để lưu trữ inventory của người chơi trước khi câu cá
const playerInventorySnapshots = new Map(); // Key: playerId, Value: Map<itemTypeId, amount>

/**
 * Hàm trợ giúp để lấy nội dung inventory của người chơi dưới dạng Map.
 * @param {import("@minecraft/server").Player} player
 * @returns {Map<string, number>} Map chứa itemTypeId và số lượng.
 */
function getInventoryContentMap(player) {
  const inventoryMap = new Map();
  const inventoryComponent = player.getComponent("minecraft:inventory");
  if (inventoryComponent && inventoryComponent.container) {
    // Sử dụng vòng lặp thông qua container.size và getItem(i)
    for (let i = 0; i < inventoryComponent.container.size; i++) {
      const item = inventoryComponent.container.getItem(i);
      if (item) {
        inventoryMap.set(
          item.typeId,
          (inventoryMap.get(item.typeId) || 0) + item.amount
        );
      }
    }
  }
  return inventoryMap;
}

/**
 * Hàm lên cấp cho kỹ năng Fishing.
 * @param {import("@minecraft/server").Player} player
 */
export async function fishingLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Fishing.
 * @param {import("@minecraft/server").Player} player
 */
export async function fishingPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpFishing, fishingSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Fishing.
 * @param {import("@minecraft/server").Player} player
 */
export async function fishingSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "fishing_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((2 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "fishing_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((5 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      // Logic mô tả cho Skill 3 (Fish Flurry)
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;
      const baseDamage = skill3Config.baseDamage;
      const damageIncreasePerLevel = skill3Config.damageIncreasePerLevel;
      const radius = skill3Config.radius;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );

      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * durationIncreasePerLevel
      );
      const finalDamage = baseDamage + level * damageIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "fishing_skill3_active_desc",
        locale,
        finalCooldownSeconds,
        finalDurationSeconds,
        finalDamage.toFixed(1),
        radius
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7Damage: ${finalDamage.toFixed(
        1
      )}\n§7Radius: ${radius}m`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    fishingPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Fishing.
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpFishing(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_fishing", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = fishTypes.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const fishConfig = fishTypes[i];
    // XP hiển thị sẽ là XP cơ bản của cá + (XP cơ bản * Intelligence bonus) + (XP từ cấp độ Fishing * Intelligence bonus)
    // Standardized XP calculation: base_fish_xp * (1 + currentSkillLevel * 0.1)
    const baseFishXp = fishConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXpForDisplay = baseFishXp + baseFishXp * xpBonusFromInt;

    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${fishConfig.name}`,
      [`\n§3${finalXpForDisplay.toFixed(1)}§a ✦§r/${fishConfig.item}`],
      `${fishConfig.item}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow" // Placeholder texture
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow" // Placeholder texture
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier"
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpFishing(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpFishing(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

/**
 * Kích hoạt kỹ năng Fish Flurry (Skill 3 của Fishing).
 * @param {import("@minecraft/server").Player} player
 */
export function activateFishFlurry(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    player.sendMessage(
      `§c${getTranslatedText(
        "skill_not_unlocked",
        locale,
        getTranslatedText(config.skillLevels.skill3.nameKey, locale)
      )}`
    );
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;
  const baseDamage = skill3Config.baseDamage;
  const damageIncreasePerLevel = skill3Config.damageIncreasePerLevel;
  const radius = skill3Config.radius;
  const attackIntervalTicks = Math.floor(skill3Config.attackInterval * 20);
  const effectChance = skill3Config.effectChance;
  const effectDurationTicks = skill3Config.effectDuration * 20;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  const cooldownAfterSkillLevelTicks = Math.max(
    20,
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  const totalIntelligenceReductionPercentage = Math.min(
    0.95,
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;
  const finalDamage = baseDamage + skill3Level * damageIncreasePerLevel;

  const remainingCooldown = fishingSkill3Cooldown.getRemainingCooldown(player);
  const cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  player.sendMessage(
    `§a${getTranslatedText("fishing_skill3_active_message", locale)}`
  );

  system.run(() => {
    player.playSound("random.splash", player.location);
    player.addTag("skill:fishFlurryActive");
    fishingSkill3Cooldown.setCooldown(player, finalCooldownTicks);

    // Particle effect vòng tròn
    let particleIntervalId = system.runInterval(() => {
      if (!player.isValid || !player.hasTag("skill:fishFlurryActive")) {
        system.clearRun(particleIntervalId);
        return;
      }

      const numParticles = 16;
      const particleType = "minecraft:water_evaporation_bucket_emitter";
      const particleYOffset = 0.5;

      for (let i = 0; i < numParticles; i++) {
        const angle = (i / numParticles) * Math.PI * 2;
        const offsetX = radius * Math.cos(angle);
        const offsetZ = radius * Math.sin(angle);

        const particleLocation = {
          x: player.location.x + offsetX,
          y: player.location.y + particleYOffset,
          z: player.location.z + offsetZ,
        };

        player.dimension.spawnParticle(particleType, particleLocation);
      }
    }, 5);

    // Tấn công các thực thể gần
    let attackIntervalId = system.runInterval(() => {
      if (!player.isValid || !player.hasTag("skill:fishFlurryActive")) {
        system.clearRun(attackIntervalId);
        return;
      }

      const entitiesInArea = player.dimension.getEntities({
        location: player.location,
        maxDistance: radius,
        excludeTypes: ["minecraft:player"],
      });

      for (const entity of entitiesInArea) {
        if (
          entity.typeId.startsWith("minecraft:") &&
          entity.typeId !== "minecraft:fishing_hook" &&
          entity.isValid
        ) {
          // Dùng command /damage
          const cmd = `damage @e[type=${entity.typeId},x=${Math.floor(
            entity.location.x
          )},y=${Math.floor(entity.location.y)},z=${Math.floor(
            entity.location.z
          )},dx=0,dy=0,dz=0] ${Math.floor(finalDamage)} entity_attack entity "${
            player.name
          }"`;
          player.runCommand(cmd);

          try {
            entity.dimension.spawnParticle(
              "minecraft:water_evaporation_bucket_emitter",
              entity.location
            );
            entity.dimension.playSound("random.pop", entity.location);
          } catch (e) {}

          if (Math.random() * 100 < effectChance) {
            try {
              entity.addEffect("slowness", effectDurationTicks, {
                amplifier: 1,
                showParticles: true,
              });
            } catch {}
          }
        }
      }
    }, attackIntervalTicks);

    system.runTimeout(() => {
      player.sendMessage(
        `§e${getTranslatedText("fishing_skill3_ended_message", locale)}`
      );
      player.removeTag("skill:fishFlurryActive");
      system.clearRun(attackIntervalId);
      system.clearRun(particleIntervalId);
    }, finalDurationSeconds * 20);
  });
}

// ==================== Xử lý sự kiện câu cá ====================
// Kích hoạt Skill 3 khi người chơi ngồi và sử dụng cần câu
world.beforeEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  if (!(player instanceof Player)) return;

  // Nếu người chơi đang ngồi và dùng cần câu, kích hoạt Fish Flurry
  if (player.isSneaking && item?.typeId === "minecraft:fishing_rod") {
    activateFishFlurry(player);
    event.cancel = true; // Ngăn không cho cần câu thực hiện hành động mặc định (ném móc câu)
    return; // Dừng xử lý tiếp để tránh xung đột
  }

  // Logic lưu snapshot inventory khi bắt đầu sử dụng cần câu (chỉ khi không kích hoạt skill)
  if (item?.typeId === "minecraft:fishing_rod") {
    const inv = player.getComponent("minecraft:inventory")?.container;
    let totalFishCountBefore = 0;
    for (let i = 0; i < inv.size; i++) {
      const it = inv.getItem(i);
      if (it && fishTypes.some((f) => f.item === it.typeId)) {
        totalFishCountBefore += it.amount;
      }
    }
    setPlayerProperty(player, "skill:fishCountBefore", totalFishCountBefore);
    playerInventorySnapshots.set(player.id, getInventoryContentMap(player));
  }
});

// Xử lý khi người chơi dừng sử dụng cần câu (vẫn giữ nguyên cho việc câu cá thông thường)
world.afterEvents.itemStopUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  const locale = getPlayerLocale(player);
  if (!(player instanceof Player) || item?.typeId !== "minecraft:fishing_rod")
    return;

  // Nếu skill Fish Flurry đang hoạt động, không xử lý sự kiện câu cá thông thường
  if (player.hasTag("skill:fishFlurryActive")) {
    return;
  }

  const beforeCountTotal =
    getPlayerProperty(player, "skill:fishCountBefore") || 0;
  const beforeInventoryMap = playerInventorySnapshots.get(player.id);

  if (!beforeInventoryMap) {
    console.warn(
      `[Fishing] Không tìm thấy snapshot inventory cho ${player.name}.`
    );
    return;
  }

  system.runTimeout(() => {
    const inv = player.getComponent("minecraft:inventory")?.container;
    if (!inv) return;

    const afterInventoryMap = getInventoryContentMap(player);

    let xpGain = 0;

    const fishingLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
    const xpBonusFromInt =
      getPlayerStat(player, "intelligence") *
      STATS_CONFIG.intelligence.xpMultiplier;

    for (const fishConfig of fishTypes) {
      const itemTypeId = fishConfig.item;
      const prevAmount = beforeInventoryMap.get(itemTypeId) || 0;
      const currentAmount = afterInventoryMap.get(itemTypeId) || 0;
      const gainedAmountOfType = currentAmount - prevAmount;

      if (gainedAmountOfType > 0) {
        xpGain += fishConfig.xp * (1 + fishingLevel * 0.1);
        xpGain += xpGain * xpBonusFromInt;

        const skill2Level = getPlayerProperty(
          player,
          `skill:${SKILL_ID}Skill2`
        );
        const luckLevel = getPlayerStat(player, "luck");
        const dropChanceBonus =
          luckLevel * STATS_CONFIG.luck.dropChanceMultiplier;

        if (
          skill2Level > 0 &&
          Math.random() * 100 <
            ((5 + skill2Level) / 100) * 100 + dropChanceBonus
        ) {
          const bonusFishAmount = skill2Level;
          const fishItemStack = new ItemStack(
            ItemTypes.get(itemTypeId),
            bonusFishAmount
          );
          tryAddItemToPlayerInventory(player, fishItemStack);
          player.sendMessage(
            `§a${getTranslatedText(
              "fishing_fishing_net_activated",
              locale,
              itemTypeId.replace("minecraft:", "")
            )} (+${bonusFishAmount})`
          );
        }

        const skill1Level = getPlayerProperty(
          player,
          `skill:${SKILL_ID}Skill1`
        );

        if (
          skill1Level > 0 &&
          Math.random() * 100 <
            ((2 + skill1Level) / 100) * 100 + dropChanceBonus
        ) {
          const randomTreasure =
            treasureFish[Math.floor(Math.random() * treasureFish.length)];
          const treasureItemStack = new ItemStack(
            ItemTypes.get(randomTreasure.item),
            randomTreasure.amount
          );
          tryAddItemToPlayerInventory(player, treasureItemStack);
          player.sendMessage(
            `§e${getTranslatedText(
              "fishing_golden_lure_activated",
              locale,
              randomTreasure.item.replace("minecraft:", "")
            )}`
          );
        }
      }
    }

    if (xpGain > 0) {
      setPlayerProperty(
        player,
        `skill:xpFishing`,
        getPlayerProperty(player, `skill:xpFishing`) + xpGain
      );
      fishingLevelUp(player);
    }

    playerInventorySnapshots.delete(player.id);
  }, 20);
});
