// skills/woodcutting.js
import {
  world,
  system,
  Player,
  ItemStack,
  ItemTypes,
  BlockVolume,
} from "@minecraft/server";
import * as Utils from "../enchantment_utils/treeUitls.js";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import {
  getPlayerProperty,
  setPlayerProperty,
  isInventoryFull,
} from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { logs, axe } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "woodcutting";
const config = skillConfig[SKILL_ID];

const woodcuttingSkill3Cooldown = new CooldownManager("woodcuttingSkill3");

/**
 * Hàm lên cấp cho kỹ năng Woodcutting (Tiều phu).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function woodcutterLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Woodcutting (Tiều phu).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function woodcutterPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpLogs, woodcutterSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Woodcutting (Tiều phu).
 * @param {import("@minecraft/server").Player} player
 */
export async function woodcutterSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "woodcutting_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((5 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "woodcutting_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((10 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Giả sử STATS_CONFIG.intelligence.cooldownReduction là một giá trị thập phân (ví dụ: 0.001 cho 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Tính toán cooldown sau khi giảm theo cấp độ kỹ năng
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Đảm bảo tối thiểu 1 giây
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Tính tổng phần trăm giảm từ chỉ số thông minh
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Giảm tối đa 95% để tránh cooldown bằng 0 hoặc âm
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Áp dụng giảm từ thông minh
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );

      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      ); // Đảm bảo tối thiểu 1 giây trong UI
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "woodcutting_skill3_active_desc",
        locale,
        finalCooldownSeconds,
        finalDurationSeconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(totalIntelligenceReductionPercentage * 100)}%`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    woodcutterPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Woodcutting (Tiều phu).
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpLogs(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_wood", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = logs.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence"); // Lấy chỉ số Intelligence
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const logConfig = logs[i];
    // Standardized XP calculation: base_log_xp * (1 + currentSkillLevel * 0.1)
    const baseLogXp = logConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseLogXp + baseLogXp * xpBonusFromInt; // Cộng thêm XP từ Intelligence
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${logConfig.xpType}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${logConfig.xpType}`],
      `${logConfig.blockID}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpLogs(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpLogs(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

// Xử lý sự kiện khi người chơi phá hủy block gỗ để tăng XP Woodcutting
world.afterEvents.playerBreakBlock.subscribe(async (eventData) => {
  const player = eventData.player;
  const block = eventData.block;
  const brokenBlockTypeId = eventData.brokenBlockPermutation.type.id;
  const item = player
    .getComponent("minecraft:inventory")
    .container.getItem(player.selectedSlotIndex);

  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0 || !item) return;

  // Lấy chỉ số Intelligence và Luck
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  // Kiểm tra xem người chơi có cầm rìu không
  if (!axe.includes(item.typeId)) return;

  // Kiểm tra xem block có phải là gỗ (log) hoặc lá (leaves) không
  const logConfig = logs.find((l) => l.blockID === brokenBlockTypeId);
  if (logConfig) {
    const currentWoodcuttingLevel = getPlayerProperty(
      player,
      `skill:${SKILL_ID}`
    );
    // Standardized XP calculation: base_log_xp * (1 + currentSkillLevel * 0.1)
    let xpGain = logConfig.xp * (1 + currentWoodcuttingLevel * 0.1);
    xpGain += xpGain * xpBonusFromInt; // Cộng thêm XP từ Intelligence

    setPlayerProperty(
      player,
      `skill:xpWoodcutting`,
      getPlayerProperty(player, `skill:xpWoodcutting`) + xpGain
    );
    woodcutterLevelUp(player);
    const luckLevel = getPlayerStat(player, "luck");
    const dropChanceBonus = luckLevel * STATS_CONFIG.luck.dropChanceMultiplier;

    // Skill 1: Log plus (thêm gỗ) - Tỷ lệ kích hoạt bị ảnh hưởng bởi Luck
    const skill1Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
    if (
      skill1Level > 0 &&
      Math.random() * 100 < ((5 + skill1Level) / 100) * 100 + dropChanceBonus
    ) {
      player.runCommand(`give @s ${brokenBlockTypeId} 1`);
    }
  }
});

// Xử lý sự kiện khi người chơi giết mob bằng rìu cho skill 2: Bổ đầu (Woodcutting)
world.afterEvents.entityDie.subscribe(async (eventData) => {
  const killer = eventData.damageSource.damagingEntity;
  const diedEntity = eventData.deadEntity;

  if (killer && killer instanceof Player) {
    const locale = getPlayerLocale(killer);
    const hasSetup = getPlayerProperty(killer, "skill:setUpStartLevel", 0);
    if (hasSetup === 0) return;

    const itemInHand = killer
      .getComponent("minecraft:inventory")
      .container.getItem(killer.selectedSlotIndex);
    if (!itemInHand || !axe.includes(itemInHand.typeId)) return;

    const skill2Level = getPlayerProperty(killer, `skill:${SKILL_ID}Skill2`);
    const luckLevel = getPlayerStat(killer, "luck");
    const dropChanceBonus = luckLevel * STATS_CONFIG.luck.dropChanceMultiplier;

    if (
      skill2Level > 0 &&
      Math.random() * 100 < ((10 + skill2Level) / 100) * 100 + dropChanceBonus
    ) {
      const skullItem = new ItemStack(
        ItemTypes.get("minecraft:skeleton_skull"),
        1
      );

      // 👤 Name of the entity that died
      const deadName = diedEntity.name ?? "Unknown";

      // 🕓 Get current date
      const now = new Date();
      const dateString = now.toLocaleDateString("en-GB");

      // 🏷️ Set name and lore
      skullItem.nameTag = `§r§e${deadName}'s Skull`;
      skullItem.setLore([`§r§7Date: ${dateString}`]);

      const inventoryComp = killer.getComponent("minecraft:inventory");
      const container = inventoryComp?.container;

      if (container) {
        if (isInventoryFull(container, skullItem)) {
          // Inventory full, don't add or drop
          killer.sendMessage(`${getTranslatedText("full_inventory", locale)}`);
        } else {
          container.addItem(skullItem);
          killer.sendMessage(
            `${getTranslatedText("get_head", locale, deadName)}`
          );
        }
      } else {
        console.warn(
          `[WARNING] Player ${killer.name} has no inventory component.`
        );
      }
    }
  }
});

// ========================= SKILL 3 ========================

export function activateWoodcuttingSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  // Đọc từ config.skillLevels.skill3, sử dụng 'baseCooldown'
  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20; // Đọc `baseCooldown`
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Tính toán cooldown sau khi giảm theo cấp độ kỹ năng
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Đảm bảo tối thiểu 1 giây
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Tính tổng phần trăm giảm từ chỉ số thông minh
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Giảm tối đa 95% để tránh cooldown bằng 0 hoặc âm
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Áp dụng giảm từ thông minh
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown =
    woodcuttingSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }

    return;
  }

  // Kích hoạt skill
  player.sendMessage(
    `§a${getTranslatedText("woodcutting_skill3_active", locale)}`
  ); // Đã đổi key thông báo
  player.playSound("random.orb", player.location);

  player.addTag("skill:treeCapitatorActive");

  // Đặt cooldown
  woodcuttingSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(
      `§e${getTranslatedText("woodcutting_skill3_ended", locale)}`
    ); // Đã đổi key thông báo
    player.removeTag("skill:treeCapitatorActive");
  }, finalDurationSeconds * 20);
}

// =============================================================================================

let locations = [];

/**
 *
 * @param { import("@minecraft/server").Player } player
 * @param { import("@minecraft/server").Block } block
 * @param { import("@minecraft/server").Dimension } dimension
 * @param { import("@minecraft/server").BlockType } blockType
 * @param { import("@minecraft/server").Vector3 } start
 * @param { number } run
 */
const breakBlocks = (player, block, dimension, blockType, start, run) => {
  let locs = locations.find(({ run: r }) => r == run);
  if (locs == undefined) {
    locations.push({ run, locations: [] });
    locs = locations.find(({ run: r }) => r == run);
  }

  const { x, y, z } = block.location;
  const alreadyVisited =
    locs.locations.find((l) => l.x == x && l.y == y && l.z == z) != undefined;
  const drops = Utils.allowedBlocksWood.find(
    (b) => b.id == blockType.id
  )?.drops;
  //const tag = Utils.allowedTags.find((t) => t.id == blockType.id)?.tag;
  if (
    alreadyVisited ||
    (locs.locations.length != 0 &&
      (drops == undefined || block.type.id != blockType.id)) ||
    locs.locations.length == Utils.maxBlocks
  )
    return;

  block.setType("air");
  if (locs.locations.length != 0) {
    /*** @type { import("@minecraft/server").Container } */
    const inventory = player.getComponent("minecraft:inventory").container;
    const item = inventory.getItem(player.selectedSlotIndex);
    /*** @type { import("@minecraft/server").EnchantmentList } */
    const enchantments = item
      .getComponent("minecraft:enchantable")
      .getEnchantments()
      .map((e) => e.type);
    if (enchantments.includes("silk_touch")) {
      dimension.spawnItem(new ItemStack(blockType.id), start);
    } else {
      const level = enchantments.includes("fortune")?.level ?? 0;
      const drop = drops.drops[level];
      const amount = Math.random() * (drop.max - drop.min) + drop.min;
      dimension.spawnItem(new ItemStack(drops.id, amount), start);
    }
  }

  locs.locations.push({ x, y, z });
  const blocks = new BlockVolume(
    { x: x + 1, y: y + 1, z: z + 1 },
    { x: x - 1, y: y - 1, z: z - 1 }
  ).getBlockLocationIterator();

  for (const b of blocks) {
    const block = dimension.getBlock(b);

    breakBlocks(player, block, dimension, blockType, start, run);
  }
  const inventory = player.getComponent("minecraft:inventory").container;
  const item = inventory.getItem(player.selectedSlotIndex);
  //.damage)

  item.getComponent("durability").damage = item.getComponent(
    "durability"
  ).damage += 1;
  inventory.setItem(player.selectedSlotIndex, item);
};

world.afterEvents.playerBreakBlock.subscribe(
  ({ player, block, dimension, brokenBlockPermutation }) => {
    const inventory = player.getComponent("minecraft:inventory").container;
    const item = inventory.getItem(player.selectedSlotIndex);
    const durability = item?.getComponent("durability");
    if (!item) return;
    if (
      player.hasTag("skill:treeCapitatorActive") &&
      durability.maxDurability - durability.damage != 0
    ) {
      if (!item.hasTag("minecraft:is_axe")) return;

      breakBlocks(
        player,
        block,
        dimension,
        brokenBlockPermutation.type,
        block.location,
        Date.now()
      );
    }
  }
);
