// stamina.js
import { world, system, Player } from "@minecraft/server";
import { getPlayerProperty, setPlayerProperty } from "./utils.js"; // Import các hàm tiện ích mới
import { getTranslatedText, getPlayerLocale } from "./lang.js"; // Import cho đa ngôn ngữ
import { agilityLevelUp } from "./skills/agility.js"; // Import hàm lên cấp Agility
import { getPlayerStat, STATS_CONFIG } from "./playerStats.js"; // Import để lấy chỉ số Intelligence

/**
 * Hàm chính xử lý stamina cho người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi.
 */
export function staminaMain(player) {
  const locale = getPlayerLocale(player);

  let stamina = getPlayerProperty(player, "skill:stamina");
  let agility = getPlayerProperty(player, "skill:agility");
  let agilitySkill1 = getPlayerProperty(player, "skill:agilitySkill1");
  // Tính toán maxStamina dựa trên agility và agilitySkill1
  let maxStamina = Math.round((1000 + agility) * (agilitySkill1 / 10 + 1));

  let mode = getPlayerProperty(player, "skill:modeShowBar");
  let healthMax = player.getComponent("health").effectiveMax;
  let playerHealth = player.getComponent("minecraft:health").currentValue;

  // Lấy chỉ số Intelligence
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  // Hiển thị thanh stamina/máu trên actionbar
  if (mode === 1) {
    player.runCommand(
      `title @s actionbar  §r${Math.floor(
        playerHealth
      )}/${healthMax} §7(${Math.floor(
        (playerHealth / healthMax) * 100
      )}%)      §bStamina§r: ${stamina}`
    );
  } else if (mode === 2) {
    player.runCommand(
      `title @s actionbar  §r${Math.floor(
        playerHealth
      )}/${healthMax} §7(${Math.floor(
        (playerHealth / healthMax) * 100
      )}%)\n§bStamina§r: ${stamina}`
    );
  } else if (mode === 3) {
    player.runCommand(
      `title @s actionbar  §r${Math.floor(
        playerHealth
      )}/${healthMax} §7(${Math.floor((playerHealth / healthMax) * 100)}%)`
    );
  } else if (mode === 4) {
    player.runCommand(`title @s actionbar  §r§bStamina§r: ${stamina}`);
  } else if (mode === 0) {
    // Chế độ tắt thanh
    player.runCommand(`title @s actionbar `);
  }

  // Đảm bảo stamina không vượt quá MaxStamina và không âm
  if (stamina > maxStamina) {
    stamina = maxStamina;
    setPlayerProperty(player, "skill:stamina", maxStamina);
  }
  if (stamina < 0) {
    stamina = 0;
    setPlayerProperty(player, "skill:stamina", 0);
  }

  // Logic trừ stamina khi chạy và nhảy, cộng XP Agility
  if (player.isSprinting && !player.isGliding) {
    if (stamina > 0) {
      // XP khi chạy
      const baseAgilityXpRun = 0.05; // Base XP khi chạy
      let xpRun = baseAgilityXpRun * (1 + agility * 0.1); // XP dựa trên cấp Agility
      xpRun += xpRun * xpBonusFromInt; // Cộng thêm XP từ Intelligence

      system.runTimeout(() => {
        setPlayerProperty(
          player,
          "skill:stamina",
          getPlayerProperty(player, "skill:stamina") - 5
        );
        setPlayerProperty(
          player,
          "skill:xpAgility",
          getPlayerProperty(player, "skill:xpAgility") + xpRun
        );
        agilityLevelUp(player); // Cố gắng lên cấp Agility
      }, 5);

      // Vừa chạy vừa nhảy - trừ thêm stamina và cộng thêm XP Agility
      if (player.isJumping) {
        const baseAgilityXpRunJump = 0.1; // Base XP khi chạy và nhảy
        let xpRunJump = baseAgilityXpRunJump * (1 + agility * 0.1); // XP dựa trên cấp Agility
        xpRunJump += xpRunJump * xpBonusFromInt; // Cộng thêm XP từ Intelligence

        system.runTimeout(() => {
          setPlayerProperty(
            player,
            "skill:xpAgility",
            getPlayerProperty(player, "skill:xpAgility") + xpRunJump
          );
          setPlayerProperty(
            player,
            "skill:stamina",
            getPlayerProperty(player, "skill:stamina") - 5
          );
          agilityLevelUp(player); // Cố gắng lên cấp Agility
        }, 5);
      }
    } else if (stamina <= 0) {
      // Nếu hết stamina, áp dụng hiệu ứng chậm
      player.addEffect("slowness", 60, { showParticles: false, amplifier: 0 }); // Slowness I trong 3 giây (60 ticks)
    }
  }
  // Logic hồi phục stamina khi không chạy
  else if (stamina < maxStamina && !player.isSprinting) {
    const isMoving =
      MathRound(player.getVelocity().x) != 0 ||
      MathRound(player.getVelocity().y) != 0 ||
      MathRound(player.getVelocity().z) != 0;

    // XP khi di chuyển (đi bộ, lén lút) hoặc đứng yên
    let xpGainFromPassive = 0;

    // Hồi stamina khi lén lút (sneaking)
    if (player.isSneaking) {
      staminaGain(player, 2);
      xpGainFromPassive = 0.02; // XP nhỏ khi lén lút
    }
    // Hồi stamina khi đi bộ (walking)
    else if (isMoving) {
      staminaGain(player, 1);
      xpGainFromPassive = 0.01; // XP nhỏ khi đi bộ
      // Thêm hiệu ứng hạt nếu có skill DiggingSkill2
      if (Number(getPlayerProperty(player, "skill:diggingSkill2")) >= 1) {
        player.runCommand(`particle minecraft:endrod ~~-.5~`);
      }
    }
    // Hồi stamina khi đứng yên
    else {
      staminaGain(player, 3);
      xpGainFromPassive = 0.005; // XP rất nhỏ khi đứng yên
    }

    // Áp dụng XP Agility từ các hoạt động thụ động
    if (xpGainFromPassive > 0) {
      let finalPassiveXp = xpGainFromPassive * (1 + agility * 0.1);
      finalPassiveXp += finalPassiveXp * xpBonusFromInt;
      setPlayerProperty(
        player,
        "skill:xpAgility",
        getPlayerProperty(player, "skill:xpAgility") + finalPassiveXp
      );
      agilityLevelUp(player); // Cố gắng lên cấp Agility
    }
  }
}

/**
 * Hàm tăng stamina cho người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {number} amount Lượng stamina muốn tăng.
 */
function staminaGain(player, amount) {
  setPlayerProperty(
    player,
    "skill:stamina",
    getPlayerProperty(player, "skill:stamina") + amount
  );
}

/**
 * Hàm làm tròn số thực để kiểm tra chuyển động.
 * @param {number} x Giá trị tọa độ.
 * @returns {number} Giá trị đã làm tròn.
 */
function MathRound(x) {
  return Math.round(x * 15) / 1000;
}
