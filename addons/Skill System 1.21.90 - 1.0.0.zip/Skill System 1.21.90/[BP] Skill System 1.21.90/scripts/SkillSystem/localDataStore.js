// BP/scripts/localDataStore.js
import { world, system } from "@minecraft/server";

const DATA_STORAGE_ENTITY_TYPE = "dienkon:db_ld";
const DATA_STORAGE_TAG = "skill_data_storage_tag";
const DATA_PROPERTY_KEY = "all_player_skill_data";

let dataStorageEntity = null;

/**
 * Tìm hoặc tạo entity lưu trữ dữ liệu.
 */
function getOrCreateDataStorageEntity() {
  //   if (dataStorageEntity && dataStorageEntity.isValid())
  //     return dataStorageEntity;

  let overworld;
  try {
    overworld = world.getDimension("overworld");
  } catch (e) {
    console.error("[Local Data Store] Lỗi truy cập overworld:", e);
    return null;
  }

  const entities = overworld.getEntities({
    type: DATA_STORAGE_ENTITY_TYPE,
    tags: [DATA_STORAGE_TAG],
  });

  if (entities.length > 0) {
    dataStorageEntity = entities[0];
    // console.warn("[Skill System] Found existing data storage entity.");
    return dataStorageEntity;
  }

  // Spawn mới
  try {
    const spawnLocation = { x: 0, y: 60, z: 0 }; // Sửa y: -60 => y: 1 để đảm bảo hợp lệ
    // world.runCommand(
    //   `setblock ${spawnLocation.x} ${spawnLocation.y - 1} ${
    //     spawnLocation.z
    //   } barrier`
    // );
    dataStorageEntity = overworld.spawnEntity(
      DATA_STORAGE_ENTITY_TYPE,
      spawnLocation
    );

    dataStorageEntity.nameTag = "§cDO NOT BREAK: Skill Data Storage";
    dataStorageEntity.addTag(DATA_STORAGE_TAG);

    // Init dữ liệu rỗng nếu chưa có
    if (!dataStorageEntity.getDynamicProperty(DATA_PROPERTY_KEY)) {
      dataStorageEntity.setDynamicProperty(
        DATA_PROPERTY_KEY,
        JSON.stringify({})
      );
    }

    console.warn("[Skill System] Created new skill data storage entity.");
    return dataStorageEntity;
  } catch (e) {
    console.error("[Skill System] Failed to spawn entity:", e);
    return null;
  }
}

// Thử tạo liên tục mỗi 1 giây cho đến khi thành công
const intervalId = system.runInterval(() => {
  const entity = getOrCreateDataStorageEntity();
  if (entity) {
    console.warn("[Skill System] Entity ready. Stopping retry loop.");
    system.clearRun(intervalId);
  }
}, 20); // 20 tick = 1 giây

/**
 * Đọc toàn bộ dữ liệu kỹ năng người chơi.
 */
export function getAllPlayerSkillDataLocal() {
  const entity = getOrCreateDataStorageEntity();
  if (!entity) return {};

  const rawData = entity.getDynamicProperty(DATA_PROPERTY_KEY);
  if (typeof rawData === "string" && rawData.length > 0) {
    try {
      return JSON.parse(rawData);
    } catch (e) {
      console.error("[Local Data Store] Parse lỗi:", e);
      return {};
    }
  }
  return {};
}

/**
 * Cập nhật dữ liệu kỹ năng của một người chơi cụ thể.
 * @param {string} playerId
 * @param {string} playerName
 * @param {Object} skillSpecificData
 */
export function updatePlayerSkillDataLocal(
  playerId,
  playerName,
  skillSpecificData
) {
  const entity = getOrCreateDataStorageEntity();
  if (!entity) {
    console.error("[Local Data Store] Không tìm thấy entity để cập nhật.");
    return;
  }

  const allData = getAllPlayerSkillDataLocal();
  allData[playerId] = {
    ...skillSpecificData,
    playerName: playerName,
  };

  try {
    const jsonData = JSON.stringify(allData);
    entity.setDynamicProperty(DATA_PROPERTY_KEY, jsonData);
    // console.warn(`[Local Data Store] Updated ${playerName}. Size: ${jsonData.length} chars`);
  } catch (e) {
    console.error(
      `[Local Data Store] Ghi dữ liệu thất bại (${playerName}):`,
      e
    );
    if (e.message?.includes("exceeds the maximum size")) {
      console.error(
        "[Local Data Store] Dữ liệu quá lớn! Cân nhắc giảm hoặc lưu ngoài."
      );
    }
  }
}
