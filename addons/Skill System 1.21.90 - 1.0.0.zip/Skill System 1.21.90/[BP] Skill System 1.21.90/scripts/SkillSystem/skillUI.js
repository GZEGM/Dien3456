// skillUI.js
import { world } from "@minecraft/server"; // Thêm system để dùng system.currentTick (nếu cần)
import ChestFormData from "../Modules/ChestForms.js"; // Đảm bảo đường dẫn đúng
import { ForceOpen } from "../Modules/Forms.js"; // Đảm bảo đường dẫn đúng
import { getTranslatedText, getPlayerLocale } from "./lang.js";
import { getPlayerProperty, setPlayerProperty } from "./utils.js"; // Giả định đây là hàm bạn dùng để lấy property từ player
import { metricNumbers } from "./moneyUtils.js";
import { skillConfig } from "./skillConfig.js";

// IMPORT MỚI: localDataStore.js (Để lấy dữ liệu người chơi offline)
import { getAllPlayerSkillDataLocal } from "./localDataStore.js";
import { openPlayerSkillManagerUI } from "./main.js"; // Import để quay lại UI quản lý

// ... (các hàm createSkillDetailsPage và createExclusiveSkillsPage giữ nguyên như bạn đã cung cấp) ...

/**
 * Hiển thị trang chi tiết cho một kỹ năng cụ thể.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {string} skillId ID của kỹ năng (e.g., 'mining', 'attack').
 * @param {function} xpSourceFunction Hàm để mở UI nguồn XP cụ thể của kỹ năng.
 * @param {function} exclusiveSkillsFunction Hàm để mở UI kỹ năng độc quyền.
 */
export async function createSkillDetailsPage(
  player,
  skillId,
  xpSourceFunction,
  exclusiveSkillsFunction
) {
  const locale = getPlayerLocale(player);
  const config = skillConfig[skillId];

  if (!config) {
    player.sendMessage(
      `§cError: Skill configuration not found for ID: ${skillId}`
    );
    return;
  }

  const { nameKey, objectivePrefix, skillLevels, pageBackKey } = config;

  let currentLevel = getPlayerProperty(player, `skill:${objectivePrefix}`);
  let xpCurrent = getPlayerProperty(
    player,
    `skill:xp${
      objectivePrefix.charAt(0).toUpperCase() + objectivePrefix.slice(1)
    }`
  );
  let xpNextLevel = getPlayerProperty(
    player,
    `skill:nextXp${
      objectivePrefix.charAt(0).toUpperCase() + objectivePrefix.slice(1)
    }`
  );

  let skill1Level = getPlayerProperty(
    player,
    `skill:${objectivePrefix}${skillLevels.skill1.objectiveSuffix}`
  );
  let skill2Level = getPlayerProperty(
    player,
    `skill:${objectivePrefix}${skillLevels.skill2.objectiveSuffix}`
  );
  let skill3Level = getPlayerProperty(
    player,
    `skill:${objectivePrefix}${skillLevels.skill3.objectiveSuffix}`
  );

  let page = Math.floor(currentLevel / 36); // Tính toán trang dựa trên cấp độ
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText(nameKey, locale)} - ${getTranslatedText(
      "page",
      locale
    )} ${page + 1}`
  );

  // Buttons for skill levels - Modified for Zigzag display
  // Điền vào các ô trống trước để tạo nền cho hiệu ứng zigzag
  for (let i = 9; i <= 44; i++) {
    Form.button(i, "", [], "textures/blocks/glass_black", 1, false); // Nút trống
  }

  // Vòng lặp này sẽ đặt các nút cấp độ vào vị trí zigzag
  for (
    let relativeLevelIndex = 0;
    relativeLevelIndex < 36;
    relativeLevelIndex++
  ) {
    const levelDisplayed = page * 36 + relativeLevelIndex; // Cấp độ kỹ năng thực tế

    const rowInPage = Math.floor(relativeLevelIndex / 9); // Hàng trong trang hiện tại (0-3)
    const colInRow = relativeLevelIndex % 9; // Cột trong hàng hiện tại (0-8)

    let buttonPos;
    if (rowInPage % 2 === 0) {
      // Hàng chẵn (0, 2) -> Từ trái sang phải
      buttonPos = 9 + rowInPage * 9 + colInRow;
    } else {
      // Hàng lẻ (1, 3) -> Từ phải sang trái
      buttonPos = 9 + rowInPage * 9 + (8 - colInRow);
    }

    if (levelDisplayed < currentLevel) {
      Form.button(
        buttonPos, // Sử dụng vị trí zigzag đã tính toán
        `§a${getTranslatedText("level", locale)} §r${levelDisplayed + 1}`, // Hiển thị cấp độ +1 (bắt đầu từ 1)
        [`\n§7${getTranslatedText("completed", locale)}`],
        "minecraft:lime_concrete",
        1,
        true // Cho phép click vào các cấp độ đã hoàn thành để xem thông tin? (Tùy chọn)
      );
    } else if (levelDisplayed === currentLevel) {
      Form.button(
        buttonPos, // Sử dụng vị trí zigzag đã tính toán
        `§g${getTranslatedText("in_progress", locale)}`,
        [
          `\n§e• ${getTranslatedText(
            "requirements",
            locale
          )}§r: ${metricNumbers(xpNextLevel)}§3 xp\n\n§r${getTranslatedText(
            "progress",
            locale
          )}:§7 ${metricNumbers(xpCurrent)}/${metricNumbers(xpNextLevel)}`,
        ],
        "minecraft:yellow_concrete",
        1,
        true
      );
    } else {
      Form.button(
        buttonPos, // Sử dụng vị trí zigzag đã tính toán
        `********** §c${getTranslatedText("locked", locale)}§r **********`,
        [`\n§4***** ${getTranslatedText("not_completed", locale)} *****`],
        "minecraft:red_concrete",
        1,
        false
      );
    }
  }

  // Fixed buttons (giữ nguyên vị trí)
  Form.button(
    0,
    getTranslatedText("overview", locale),
    [
      `§7${getTranslatedText(
        "current_level",
        locale
      )}${currentLevel}\n\n${getTranslatedText(
        "skills_section_title",
        locale
      )}\n§7• ${getTranslatedText(
        skillLevels.skill1.nameKey,
        locale
      )}: ${skill1Level}\n§7• ${getTranslatedText(
        skillLevels.skill2.nameKey,
        locale
      )}: ${skill2Level}\n§7• ${getTranslatedText(
        skillLevels.skill3.nameKey,
        locale
      )}: ${skill3Level}`,
    ],
    config.iconPath,
    1,
    true
  );
  Form.button(
    1,
    getTranslatedText("leaderboard", locale),
    [`§cBeta`],
    "textures/items/paper",
    1,
    true
  ); // Sẽ thay thế bằng showLeaderboard
  Form.button(
    2,
    getTranslatedText("how_to_get_xp", locale),
    [`§7${getTranslatedText("click", locale)}`],
    "textures/items/experience_bottle",
    1,
    true
  );
  Form.button(
    3,
    `§9${getTranslatedText("exclusive_skills", locale)}§4`,
    [
      `\n§7• ${getTranslatedText(
        skillLevels.skill1.nameKey,
        locale
      )}: ${skill1Level}\n§7• ${getTranslatedText(
        skillLevels.skill2.nameKey,
        locale
      )}: ${skill2Level}\n§7• ${getTranslatedText(
        skillLevels.skill3.nameKey,
        locale
      )}: ${skill3Level}`,
    ],
    "textures/items/dye_powder_light_blue",
    1,
    true
  );
  Form.button(
    45,
    getTranslatedText("previous_page", locale),
    [`§7${getTranslatedText("click_to_back_previous_page", locale)}`],
    "textures/items/arrow",
    1,
    true
  );
  for (let i = 46; i < 52; i++) {
    Form.button(i, "", [], "", 1, false);
  }
  Form.button(
    52,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );
  Form.button(
    53,
    getTranslatedText("next_page", locale),
    [`§7${getTranslatedText("click_to_back_next_page", locale)}`],
    "textures/items/arrow",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 1: // Leaderboard button
        const { showLeaderboard } = await import("./main.js"); // Import động để tránh circular dependency
        showLeaderboard(player, skillId);
        break;
      case 2:
        xpSourceFunction(player); // Gọi hàm UI nguồn XP cụ thể của kỹ năng
        break;
      case 3:
        exclusiveSkillsFunction(player); // Gọi hàm UI kỹ năng độc quyền cụ thể
        break;
      case 45: // Previous page logic (basic, can be expanded for multi-page)
        if (page > 0) {
          // Re-open page with previous page number
          createSkillDetailsPage(
            player,
            skillId,
            xpSourceFunction,
            exclusiveSkillsFunction
          ); // Tạm thời, sẽ cần truyền thêm page number
        }
        break;
      case 52:
        const { Skill } = await import("./main.js"); // Import động để tránh circular dependency
        Skill(player);
        break;
      case 53: // Next page logic (basic, can be expanded for multi-page)
        // Re-open page with next page number
        createSkillDetailsPage(
          player,
          skillId,
          xpSourceFunction,
          exclusiveSkillsFunction
        ); // Tạm thời, sẽ cần truyền thêm page number
        break;
    }
  }
}

/**
 * Hiển thị trang kỹ năng độc quyền cho một kỹ năng cụ thể.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {string} skillId ID của kỹ năng (e.g., 'mining', 'attack').
 * @param {function} backFunction Hàm để quay lại trang chi tiết kỹ năng.
 * @param {object} skillSpecificDescriptions Các mô tả cụ thể cho từng skill con.
 */
export async function createExclusiveSkillsPage(
  player,
  skillId,
  backFunction,
  skillSpecificDescriptions
) {
  const locale = getPlayerLocale(player);
  const config = skillConfig[skillId];

  if (!config) {
    player.sendMessage(
      `§cError: Skill configuration not found for ID: ${skillId}`
    );
    return;
  }

  const { objectivePrefix, skillLevels } = config;
  let currentLevel = getPlayerProperty(player, `skill:${objectivePrefix}`);

  const newForm = new ChestFormData();
  newForm.title(`§r§9${getTranslatedText("exclusive_skills", locale)}§4`);
  for (let i = 0; i < 27; i++) {
    newForm.button(i, "", [], "textures/blocks/glass_black", 1, false);
  }

  const skillButtonPositions = [10, 13, 16]; // Vị trí các nút kỹ năng con

  // Tạo các nút kỹ năng con
  Object.keys(skillLevels).forEach((key, index) => {
    const skillInfo = skillLevels[key];
    const skillLevel = getPlayerProperty(
      player,
      `skill:${objectivePrefix}${skillInfo.objectiveSuffix}`
    );
    const buttonPos = skillButtonPositions[index];

    if (currentLevel >= skillInfo.unlockLevel) {
      newForm.button(
        buttonPos,
        `${getTranslatedText(skillInfo.nameKey, locale)
          .replace("(a): ", " ")
          .replace(": ", " ")
          .trim()} §a${skillLevel}`,
        [skillSpecificDescriptions[key](skillLevel)], // Sử dụng hàm mô tả từ skillSpecificDescriptions
        skillInfo.icon,
        1,
        false
      );
    } else {
      newForm.button(
        buttonPos,
        `§4${getTranslatedText("unlocked", locale)}\n\n§e${getTranslatedText(
          "requires_level",
          locale
        )} ${skillInfo.unlockLevel}§e ${getTranslatedText(
          "to_unlock",
          locale
        )}!`,
        [],
        "textures/blocks/barrier",
        1,
        false
      );
    }
  });

  newForm.button(
    18,
    getTranslatedText(config.pageBackKey, locale), // Sử dụng config.pageBackKey
    [`§7${getTranslatedText("click_to_back_skill", locale)}`],
    "textures/items/arrow",
    1,
    true
  );
  newForm.button(
    26,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, newForm);
  if (!res.canceled) {
    switch (res.selection) {
      case 18:
        backFunction(player); // Quay lại trang chi tiết kỹ năng
        break;
      case 26:
        const { Skill } = await import("./main.js"); // Import động
        Skill(player);
        break;
    }
  }
}

// Định nghĩa vị trí các nút cho bố cục kim tự tháp
const PYRAMID_POSITIONS = [
  // Hàng 1 (1 ô giữa)
  4,
  // Hàng 2 (2 ô, cách đều)
  12, 14,
  // Hàng 3 (3 ô, cách đều)
  20, 22, 24,
  // Hàng 4 (4 ô, cách đều)
  28, 30, 32, 34,
  // Hàng 5 (5 ô, cách đều)
  36, 38, 40, 42, 44,
];
const PLAYERS_PER_PAGE = PYRAMID_POSITIONS.length; // Số người chơi tối đa trên một trang kim tự tháp (1 + 2 + 3 + 4 + 5 = 15)

/**
 * Hiển thị bảng xếp hạng kỹ năng.
 * Bây giờ sẽ lấy dữ liệu từ entity trong thế giới để bao gồm cả người chơi offline.
 * @param {import("@minecraft/server").Player} player Người chơi yêu cầu bảng xếp hạng.
 * @param {string} [skillId] ID của kỹ năng cụ thể để hiển thị, nếu không có sẽ hiển thị tổng điểm.
 * @param {function} [backToPageFunction] Hàm để quay lại trang trước (nếu có).
 * @param {number} [currentPage=0] Trang hiện tại (bắt đầu từ 0).
 */
export async function showLeaderboard(
  player,
  skillId = null,
  backToPageFunction = null,
  currentPage = 0
) {
  const locale = getPlayerLocale(player);
  const Form = new ChestFormData("large");

  // Thiết lập tiêu đề bảng xếp hạng
  let titleText = "";
  if (skillId) {
    const skillInfo = skillConfig[skillId];
    titleText = `§r${getTranslatedText(
      "leaderboard",
      locale
    )} - ${getTranslatedText(skillInfo.nameKey, locale)}`;
  } else {
    titleText = `§r${getTranslatedText(
      "leaderboard",
      locale
    )} - ${getTranslatedText("total_skill_point", locale)}`;
  }
  Form.title(titleText);

  let playersData = [];
  try {
    const rawPlayersData = getAllPlayerSkillDataLocal(); // Lấy tất cả dữ liệu từ entity lưu trữ

    // Chuyển đổi dữ liệu từ object (key là player ID) sang array để sắp xếp
    playersData = Object.keys(rawPlayersData).map((playerId) => {
      const data = rawPlayersData[playerId];
      return { playerId: playerId, ...data }; // Thêm playerId vào object để tiện sử dụng
    });
    // console.warn(
    //   `[Leaderboard] Fetched ${playersData.length} entries from local storage.`
    // );
  } catch (e) {
    player.sendMessage(
      `§c[Leaderboard] Lỗi khi đọc dữ liệu cục bộ: ${e.message}`
    );
    console.error(`[Leaderboard] Error fetching local data:`, e);
    return;
  }

  // Lọc bỏ các mục không có dữ liệu kỹ năng liên quan hoặc không có tên người chơi (dữ liệu lỗi)
  playersData = playersData.filter((data) => {
    const hasName = data.playerName && data.playerName.length > 0;
    let hasSkillData = false;
    if (skillId) {
      hasSkillData = data[skillId] !== undefined; // Sử dụng skillId trực tiếp nếu đã lưu đúng
    } else {
      hasSkillData = data["totalSkillPoint"] !== undefined;
    }
    return hasName && hasSkillData;
  });

  // Sắp xếp dữ liệu: giảm dần theo cấp độ skill hoặc tổng điểm
  if (skillId) {
    playersData.sort((a, b) => (b[skillId] || 0) - (a[skillId] || 0));
  } else {
    playersData.sort(
      (a, b) => (b["totalSkillPoint"] || 0) - (a["totalSkillPoint"] || 0)
    );
  }

  // Tính toán số trang và dữ liệu cho trang hiện tại
  const totalPages = Math.ceil(playersData.length / PLAYERS_PER_PAGE);
  const startIndex = currentPage * PLAYERS_PER_PAGE;
  const endIndex = Math.min(startIndex + PLAYERS_PER_PAGE, playersData.length);
  const playersOnPage = playersData.slice(startIndex, endIndex);

  // Thêm nút và thông tin vào form theo bố cục kim tự tháp
  for (let i = 0; i < playersOnPage.length; i++) {
    const data = playersOnPage[i];
    const buttonPos = PYRAMID_POSITIONS[i];

    let desc = [];
    if (skillId) {
      desc.push(
        `§e${getTranslatedText("level", locale)}: ${data[skillId] || 0}`
      );
    } else {
      desc.push(
        `§e${getTranslatedText("total_skill_point", locale)}: ${
          data["totalSkillPoint"] || 0
        }`
      );
    }

    const displayName = data.playerName || "§8[Unknown Player]";
    // Kiểm tra xem người chơi có online không để thay đổi icon
    const isOnline = world.getPlayers().some((p) => p.id === data.playerId);
    const icon = isOnline ? "textures/ui/head" : "textures/ui/head"; // Ví dụ: Icon khác nhau cho online/offline

    Form.button(
      buttonPos,
      `§b${startIndex + i + 1}. ${displayName}`, // Rank thực tế
      desc,
      icon,
      1,
      false
    );
  }

  // Điền các ô trống còn lại
  for (const pos of PYRAMID_POSITIONS) {
    const isUsed = playersOnPage.some(
      (_, index) => PYRAMID_POSITIONS[index] === pos
    );
    if (!isUsed) {
      Form.button(pos, "", [], "textures/blocks/glass_black", 1, false);
    }
  }

  // Nút điều hướng và quay lại (giữ nguyên logic)
  // Previous Page (Slot 45)
  Form.button(
    45,
    getTranslatedText("previous_page", locale),
    [`§7${getTranslatedText("click_to_back_previous_page", locale)}`],
    currentPage > 0 ? "textures/items/arrow" : "textures/blocks/barrier",
    1,
    currentPage > 0
  );

  // Back Button (Slot 52)
  if (backToPageFunction) {
    Form.button(
      52,
      getTranslatedText("click_to_close", locale),
      [`§7${getTranslatedText("click_to_close", locale)}`],
      "minecraft:barrier",
      1,
      true
    );
  } else {
    Form.button(
      52,
      getTranslatedText("back_to_skill_list", locale),
      [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
      "minecraft:barrier",
      1,
      true
    );
  }

  // Next Page (Slot 53)
  Form.button(
    53,
    getTranslatedText("next_page", locale),
    [`§7${getTranslatedText("click_to_back_next_page", locale)}`],
    currentPage < totalPages - 1
      ? "textures/items/arrow"
      : "textures/blocks/barrier",
    1,
    currentPage < totalPages - 1
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    if (res.selection === 45 && currentPage > 0) {
      showLeaderboard(player, skillId, backToPageFunction, currentPage - 1);
    } else if (res.selection === 53 && currentPage < totalPages - 1) {
      showLeaderboard(player, skillId, backToPageFunction, currentPage + 1);
    } else if (res.selection === 52) {
      if (backToPageFunction) {
        backToPageFunction(player);
      } else {
        const { Skill } = await import("./main.js");
        Skill(player);
      }
    }
  }
}

/**
 * Hiển thị giao diện quản lý XP của một kỹ năng cho người chơi mục tiêu.
 * @param {import("@minecraft/server").Player} adminPlayer Người chơi admin.
 * @param {import("@minecraft/server").Player} targetPlayer Người chơi mục tiêu.
 * @param {string} skillId ID của kỹ năng.
 */
export async function createManagerSkillDetailsPage(
  adminPlayer,
  targetPlayer,
  skillId
) {
  const locale = getPlayerLocale(adminPlayer);
  const config = skillConfig[skillId];

  if (!config) {
    adminPlayer.sendMessage(
      `§cError: Skill configuration not found for ID: ${skillId}`
    );
    return;
  }

  const { nameKey, xpObjectivePrefix } = config;

  let currentXp = getPlayerProperty(
    targetPlayer,
    `skill:${xpObjectivePrefix}`,
    0
  );

  const Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("manage_xp_for", locale)} ${
      targetPlayer.name
    } - ${getTranslatedText(nameKey, locale)}`
  );

  // Hiển thị XP hiện tại
  Form.button(
    4, // Vị trí trung tâm hàng đầu
    `§b${getTranslatedText("current_xp", locale)}: ${metricNumbers(currentXp)}`,
    [],
    config.iconPath,
    1,
    false
  );

  // Các nút điều chỉnh XP (hàng 2)
  const xpAmounts = [
    -100000, -10000, -1000, -100, -10, -1, 1, 10, 100, 1000, 10000, 100000,
  ];
  const buttonPositions = [18, 19, 20, 9, 10, 11, 15, 16, 17, 24, 25, 26]; // Các vị trí nút từ trái sang phải, sau đó hàng dưới

  xpAmounts.forEach((amount, index) => {
    const buttonPos = buttonPositions[index];
    const isNegative = amount < 0;
    const absAmount = Math.abs(amount);
    const color = isNegative ? "§c" : "§a";
    const prefix = isNegative ? "-" : "+";
    const isEnabled = !isNegative || currentXp >= absAmount; // Không cho phép XP âm

    Form.button(
      buttonPos,
      `${color}${prefix}${metricNumbers(absAmount)} XP`,
      [
        `§7${getTranslatedText(
          "click_to_adjust_xp",
          locale,
          prefix,
          metricNumbers(absAmount)
        )}`,
      ],
      isNegative ? "textures/blocks/glass_red" : "textures/ui/plus",
      1,
      isEnabled
    );
  });

  // Nút Quay lại
  Form.button(
    49, // Vị trí dưới cùng giữa
    getTranslatedText("back_to_main_menu", locale),
    [],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(adminPlayer, Form);

  if (!result.canceled) {
    let newXp = currentXp;
    let xpChange = 0;

    switch (result.selection) {
      case 18:
        xpChange = -100000;
        break;
      case 19:
        xpChange = -10000;
        break;
      case 20:
        xpChange = -1000;
        break;
      case 9:
        xpChange = -100;
        break;
      case 10:
        xpChange = -10;
        break;
      case 11:
        xpChange = -1;
        break;
      case 15:
        xpChange = 1;
        break;
      case 16:
        xpChange = 10;
        break;
      case 17:
        xpChange = 100;
        break;
      case 24:
        xpChange = 1000;
        break; // Corrected button position for +1000
      case 25:
        xpChange = 10000;
        break; // Corrected button position for +10000
      case 26:
        xpChange = 100000;
        break; // Corrected button position for +100000
      case 49: // Back button
        openPlayerSkillManagerUI(adminPlayer, targetPlayer);
        return;
    }

    if (xpChange !== 0) {
      newXp = Math.max(0, currentXp + xpChange);
      setPlayerProperty(targetPlayer, `skill:${xpObjectivePrefix}`, newXp);
      adminPlayer.sendMessage(
        `§aĐã điều chỉnh XP của ${getTranslatedText(nameKey, locale)} cho ${
          targetPlayer.name
        } thành ${metricNumbers(newXp)}.`
      );

      // Tải lại UI điều chỉnh XP
      await createManagerSkillDetailsPage(adminPlayer, targetPlayer, skillId);
    }
  } else {
    // Nếu admin đóng form, quay lại UI quản lý chính
    openPlayerSkillManagerUI(adminPlayer, targetPlayer);
  }
}
