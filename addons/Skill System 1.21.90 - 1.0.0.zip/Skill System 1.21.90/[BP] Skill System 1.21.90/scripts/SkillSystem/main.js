// main.js
import { world, system, Player } from "@minecraft/server";
import { MessageFormData } from "@minecraft/server-ui";
import ChestFormData from "../Modules/ChestForms.js"; // Đảm bảo đường dẫn đúng
import { ForceOpen } from "../Modules/Forms.js"; // Đảm bảo đường dẫn đúng

import {
  getPlayerProperty,
  setPlayerProperty,
  resetPlayerSkills,
} from "./utils.js";
import { getMoney, metricNumbers } from "./moneyUtils.js";
import { getTranslatedText, getPlayerLocale } from "./lang.js";
import { skillConfig } from "./skillConfig.js";
import {
  showLeaderboard,
  createManagerSkillDetailsPage, // Import hàm mới
} from "./skillUI.js";

import {
  showPlayerStatsUI,
  showManagerStatAdjustmentUI, // Import hàm mới
} from "./statsUI.js"; // IMPORT MỚI: Chỉ số
import { applyAllStatEffects } from "./playerStats.js"; // IMPORT MỚI: Apply stats khi spawn

// Import tất cả các hàm UI chính của từng kỹ năng (ví dụ: minerPage, swordPage)
import { minerPage, minerLevelUp } from "./skills/mining.js";
import { woodcutterPage, woodcutterLevelUp } from "./skills/woodcutting.js";
import { swordPage, attackLevelUp } from "./skills/attack.js";
import { farmerPage, farmerLevelUp } from "./skills/farming.js";
import { diggingPage, diggingLevelUp } from "./skills/digging.js";
import { agilityPage, agilityLevelUp } from "./skills/agility.js";
import { defensePage, defenseLevelUp } from "./skills/defense.js";
import { rangedPage, rangedLevelUp } from "./skills/ranged.js";
import { fishingPage, fishingLevelUp } from "./skills/fishing.js";
import { staminaMain } from "./stamina.js"; // Import staminaMain

// Import các file skill để các sự kiện của chúng được đăng ký
// Việc import này đảm bảo rằng các event listeners được định nghĩa trong mỗi file skill sẽ được đăng ký khi addon khởi động.
// Các hàm levelUp sẽ được gọi trong system.runInterval chung.
import "./skills/mining.js";
import "./skills/woodcutting.js";
import "./skills/attack.js";
import "./skills/farming.js";
import "./skills/digging.js";
import "./skills/agility.js";
import "./skills/defense.js";
import "./skills/ranged.js";
import "./skills/fishing.js";

// --- Cấu hình Ban đầu cho Người chơi Mới ---
world.afterEvents.playerSpawn.subscribe((eventData) => {
  const player = eventData.player;
  const locale = getPlayerLocale(player);

  // Kiểm tra xem người chơi đã được thiết lập chưa
  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);

  if (hasSetup === 0) {
    // Thiết lập Dynamic Properties ban đầu cho người chơi mới
    setPlayerProperty(player, "skill:totalSkillPoint", 0);
    setPlayerProperty(player, "skill:modeShowBar", 1); // Chế độ hiển thị thanh mặc định
    setPlayerProperty(player, "skill:stamina", 1000); // Stamina ban đầu
    setPlayerProperty(player, "skill:cooldownNotification", 1); // Thông báo hồi chiêu mặc định BẬT
    setPlayerProperty(player, "money", 0); // Khởi tạo tiền nếu chưa có
    setPlayerProperty(player, "skill:playerLocale", "en_US"); // Thiết lập ngôn ngữ mặc định là tiếng Anh

    // Thiết lập các kỹ năng ban đầu
    for (const skillId in skillConfig) {
      const skill = skillConfig[skillId];
      setPlayerProperty(player, `skill:${skill.objectivePrefix}`, 0); // Level của skill chính

      // SỬA LỖI QUAN TRỌNG: Đảm bảo tên Dynamic Property của XP và Next XP là đúng
      // Sử dụng trực tiếp xpObjectivePrefix và nextXpObjectivePrefix từ skillConfig
      setPlayerProperty(player, `skill:${skill.xpObjectivePrefix}`, 0); // XP hiện tại
      // Sử dụng baseXp từ config.js hoặc từ skillConfig nếu được định nghĩa riêng cho từng skill
      setPlayerProperty(
        player,
        `skill:${skill.nextXpObjectivePrefix}`,
        skill.baseXp || 1000
      ); // XP cần thiết cho cấp độ tiếp theo

      // Thiết lập các kỹ năng con
      for (const subSkillKey in skill.skillLevels) {
        const subSkill = skill.skillLevels[subSkillKey];
        setPlayerProperty(
          player,
          `skill:${skill.objectivePrefix}${subSkill.objectiveSuffix}`,
          0
        );
      }
      // Khởi tạo cooldown cho skill 3 (nếu có)
      if (skill.skillLevels.skill3) {
        setPlayerProperty(
          player,
          `skill:${skill.objectivePrefix}${skill.skillLevels.skill3.objectiveSuffix}Cooldown`,
          0
        );
      }
    }

    // Setup chỉ số ban đầu (đảm bảo playerStats.js đã chạy applyAllStatEffects)
    // applyAllStatEffects(player); // Gọi hàm này sau khi setup để apply hiệu ứng HP ban đầu

    // Đặt cờ đã thiết lập
    setPlayerProperty(player, "skill:setUpStartLevel", 1);
    player.sendMessage(`§a${getTranslatedText("setup_complete", locale)}`);
  } else {
    // Nếu người chơi đã setup, đảm bảo các hiệu ứng chỉ số được áp dụng khi spawn/join lại

    applyAllStatEffects(player);
  }
});

// --- Vòng lặp chính của hệ thống (Tick Event) ---
system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);

    if (hasSetup === 1) {
      // Chỉ chạy cho người chơi đã được setup
      // Xử lý Stamina
      staminaMain(player);

      // Kiểm tra và xử lý lên cấp cho tất cả các kỹ năng
      minerLevelUp(player);
      woodcutterLevelUp(player);
      attackLevelUp(player);
      farmerLevelUp(player);
      diggingLevelUp(player);
      agilityLevelUp(player);
      defenseLevelUp(player);
      rangedLevelUp(player);
      fishingLevelUp(player);

      let hudHealth = getPlayerProperty(player, "skill:hideHealth", 0);
      let hudArmor = getPlayerProperty(player, "skill:hideArmor", 0);
      if (hudHealth == 0) {
        player.runCommand(`hud @s hide health`);
      } else {
        player.runCommand(`hud @s reset health`);
      }

      if (hudArmor == 0) {
        player.runCommand(`hud @s hide armor`);
      } else {
        player.runCommand(`hud @s reset armor`);
      }

      player.runCommand("tp @e[type=dienkon:db_ld] 0 60 0");
    }
  }
}, 5); // Chạy mỗi 5 tick (0.25 giây)

// --- Hàm hiển thị UI chính của hệ thống kỹ năng ---

/**
 * Hiển thị giao diện người dùng chính cho hệ thống kỹ năng.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {import("@minecraft/server").Player} [targetPlayer=player] Người chơi mục tiêu để quản lý (mặc định là người dùng lệnh).
 * @param {boolean} [isManagerMode=false] Chế độ quản lý (true) hay chế độ thông thường (false).
 */
export async function Skill(
  player,
  targetPlayer = player,
  isManagerMode = false
) {
  const locale = getPlayerLocale(player);
  const Form = new ChestFormData("large");

  // Nếu ở chế độ quản lý, thêm tên người chơi mục tiêu vào tiêu đề
  if (isManagerMode) {
    Form.title(
      `§r${getTranslatedText("manage_skill_for", locale)} ${targetPlayer.name}`
    );
  } else {
    Form.title("§r" + getTranslatedText("general_overview_title", locale));
  }

  // Định nghĩa vị trí cho từng nút kỹ năng và chức năng
  const buttonMap = {
    mining: { pos: 11, pageFunc: minerPage },
    woodcutting: { pos: 12, pageFunc: woodcutterPage },
    attack: { pos: 13, pageFunc: swordPage },
    farming: { pos: 14, pageFunc: farmerPage },
    digging: { pos: 15, pageFunc: diggingPage },
    agility: { pos: 21, pageFunc: agilityPage },
    defense: { pos: 22, pageFunc: defensePage },
    ranged: { pos: 23, pageFunc: rangedPage },
    trading: { pos: 20, pageFunc: null }, // Thay thế null bằng tradingPage nếu có
    fishing: { pos: 24, pageFunc: fishingPage }, // Thay thế null bằng fishingPage nếu có
  };

  for (let i = 0; i < 54; i++) {
    Form.button(i, "", [], "textures/blocks/glass_black");
  }
  for (let i = 29; i < 34; i++) {
    Form.button(i, "", [], "textures/blocks/glass_red");
  }

  // Thêm các nút kỹ năng theo bố cục gốc
  for (const skillId in buttonMap) {
    const { pos, pageFunc } = buttonMap[skillId];
    const config = skillConfig[skillId];

    if (config) {
      const currentLevel = getPlayerProperty(
        targetPlayer,
        `skill:${config.objectivePrefix}`
      );
      // SỬA LỖI HIỂN THỊ UI: Đảm bảo đọc đúng Dynamic Property
      const xpCurrent = getPlayerProperty(
        targetPlayer,
        `skill:${config.xpObjectivePrefix}`
      );
      const xpNextLevel = getPlayerProperty(
        targetPlayer,
        `skill:${config.nextXpObjectivePrefix}`
      );

      const skill1Level = getPlayerProperty(
        targetPlayer,
        `skill:${config.objectivePrefix}${config.skillLevels.skill1.objectiveSuffix}`
      );
      const skill2Level = getPlayerProperty(
        targetPlayer,
        `skill:${config.objectivePrefix}${config.skillLevels.skill2.objectiveSuffix}`
      );
      const skill3Level = getPlayerProperty(
        targetPlayer,
        `skill:${config.objectivePrefix}${config.skillLevels.skill3.objectiveSuffix}`
      );

      Form.button(
        pos,
        `§f${getTranslatedText(config.nameKey, locale)
          .replace("§b", "")
          .replace("§3", "")}\n§a${getTranslatedText(
          "current_level",
          locale
        )}§r${currentLevel}`,
        [
          `§7${getTranslatedText(config.descKey, locale)}\n\n` +
            `§7${getTranslatedText(
              "next_level_progress",
              locale
            )}${metricNumbers(xpCurrent.toFixed(1))}/${metricNumbers(
              xpNextLevel
            )}\n\n` +
            `§r${getTranslatedText("skills_section_title", locale)}§r\n` +
            `§7• ${getTranslatedText(
              config.skillLevels.skill1.nameKey,
              locale
            )}: ${skill1Level}\n` +
            `§7• ${getTranslatedText(
              config.skillLevels.skill2.nameKey,
              locale
            )}: ${skill2Level}\n` +
            `§7• ${getTranslatedText(config.skillLevels.skill3.nameKey, locale)
              .replace("(a): ", "")
              .trim()} (a): ${skill3Level}`,
        ],
        config.iconPath,
        1,
        true
      );
    }
  }

  const totalSkillPoints = getPlayerProperty(
    targetPlayer,
    "skill:totalSkillPoint"
  );
  const attackLevel = getPlayerProperty(targetPlayer, "skill:attackLevel");
  const healthMax = targetPlayer.getComponent("minecraft:health").effectiveMax;
  const defenseLevel = getPlayerProperty(targetPlayer, "skill:denfenseLevel");
  const stamina = getPlayerProperty(targetPlayer, "skill:stamina");

  Form.button(
    8,
    getTranslatedText("general_overview_title", locale),
    [
      `\§7${getTranslatedText(
        "total_skill_point",
        locale
      )} ${totalSkillPoints}\n\n${getTranslatedText(
        "attack_level",
        locale
      )} ${attackLevel}\n${getTranslatedText(
        "health_max",
        locale
      )} ${healthMax}\n${getTranslatedText(
        "defense_level",
        locale
      )} ${defenseLevel}\n${getTranslatedText(
        "stamina_current",
        locale
      )} ${stamina}\n${getTranslatedText("money", locale)} ${getMoney(
        targetPlayer
      )}\n${getTranslatedText(
        "stamina_mechanics_title",
        locale
      )}\n${getTranslatedText(
        "stamina_cost_mine_attack",
        locale
      )}\n${getTranslatedText("stamina_cost_run", locale)}\n${getTranslatedText(
        "stamina_cost_run_jump",
        locale
      )}\n${getTranslatedText(
        "stamina_regen_walk",
        locale
      )}\n${getTranslatedText(
        "stamina_regen_sneak",
        locale
      )}\n${getTranslatedText("stamina_regen_idle", locale)}\n`,
    ],
    "textures/ui/cube_icon",
    1,
    true
  );

  Form.button(
    17,
    getTranslatedText("your_stats_title", locale),
    [`§7${getTranslatedText("click_to_view_stats", locale)}`],
    "minecraft:anvil",
    1,
    true
  );

  // Hide settings and leaderboard in manager mode
  if (!isManagerMode) {
    Form.button(
      45,
      getTranslatedText("setting_title", locale),
      [`§7${getTranslatedText("click_to_setting", locale)}`],
      "textures/ui/gear",
      1,
      true
    );

    Form.button(
      49,
      getTranslatedText("leaderboard", locale),
      [`§7${getTranslatedText("click", locale)}`],
      "textures/ui/icon_map",
      1,
      true
    );
  } else {
    // Thêm nút "Reset Skills" trong chế độ quản lý
    Form.button(
      49,
      `§c${getTranslatedText("reset_all_skills", locale)}`,
      [
        `§7${getTranslatedText(
          "confirm_reset_skills",
          locale,
          targetPlayer.name
        )}`,
      ],
      "textures/ui/trash",
      1,
      true
    );
  }

  Form.button(
    53,
    getTranslatedText("click_to_close", locale),
    [`§7${getTranslatedText("click_to_close", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(player, Form);

  if (!result.canceled) {
    let selectedSkillId = null;
    for (const id in buttonMap) {
      if (buttonMap[id].pos === result.selection) {
        selectedSkillId = id;
        break;
      }
    }

    if (selectedSkillId) {
      if (isManagerMode) {
        // Mở UI điều chỉnh XP kỹ năng cho người chơi mục tiêu
        await createManagerSkillDetailsPage(
          player,
          targetPlayer,
          selectedSkillId
        );
      } else {
        const { pageFunc } = buttonMap[selectedSkillId];
        if (pageFunc) {
          await pageFunc(player); // Gọi trang chi tiết kỹ năng tương ứng
        } else {
          player.sendMessage(`§c${getTranslatedText("not_done_yet", locale)}`); // Thông báo nếu chưa có trang
        }
      }
    } else if (result.selection === 49) {
      if (isManagerMode) {
        // Xử lý Reset Skills trong chế độ quản lý
        const confirmForm = new MessageFormData()
          .title(getTranslatedText("reset_confirmation_title", locale))
          .body(
            getTranslatedText("confirm_reset_skills", locale, targetPlayer.name)
          )
          .button1(getTranslatedText("yes_reset", locale))
          .button2(getTranslatedText("no", locale));

        const response = await confirmForm.show(player);

        if (response.selection === 0) {
          resetPlayerSkills(targetPlayer);
          player.sendMessage(
            `§a${getTranslatedText(
              "skills_reset_success",
              locale,
              targetPlayer.name
            )}`
          );
        } else {
          player.sendMessage(
            `§7${getTranslatedText(
              "skills_reset_cancelled",
              locale,
              targetPlayer.name
            )}`
          );
        }
        openPlayerSkillManagerUI(player, targetPlayer); // Tải lại UI quản lý
      } else {
        // Bảng xếp hạng
        showLeaderboard(player);
      }
    } else if (result.selection === 17) {
      // Chỉ số của bạn hoặc của người chơi mục tiêu
      if (isManagerMode) {
        showManagerStatAdjustmentUI(player, targetPlayer); // Mở UI quản lý chỉ số cho người chơi mục tiêu
      } else {
        showPlayerStatsUI(player);
      }
    } else if (result.selection === 45) {
      // Cài đặt (chỉ trong chế độ thường)
      if (!isManagerMode) {
        settingPage(player);
      }
    } else if (result.selection === 53) {
      // Đóng
      // Hành động đóng form, không cần làm gì thêm vì ForceOpen đã đóng
    }
  }
}

/**
 * Mở giao diện quản lý kỹ năng cho một người chơi cụ thể.
 * Chỉ dành cho admin.
 * @param {import("@minecraft/server").Player} adminPlayer Người chơi admin.
 * @param {import("@minecraft/server").Player} targetPlayer Người chơi mục tiêu để quản lý.
 */
export async function openPlayerSkillManagerUI(adminPlayer, targetPlayer) {
  await Skill(adminPlayer, targetPlayer, true);
}

// --- Các hàm UI phụ trợ (Cài đặt) ---
async function settingPage(player) {
  const locale = getPlayerLocale(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification",
    1
  );
  let hideHealth = getPlayerProperty(player, "skill:hideHealth", 0);
  let hideArmor = getPlayerProperty(player, "skill:hideArmor", 0);

  const Form = new ChestFormData("small");
  Form.title(`§r${getTranslatedText("setting_title", locale)}`);

  // Fill empty slots with black glass for the first 27 slots
  for (let i = 0; i < 27; i++) {
    Form.button(i, "", [], "textures/blocks/glass_black", 1, false);
  }

  // Health/Stamina Bar Settings button
  // This button will now open the new settingBarPage
  Form.button(
    9,
    hideHealth === 1
      ? getTranslatedText("hide_health_on", locale)
      : getTranslatedText("hide_health_off", locale),
    [
      hideHealth === 1
        ? getTranslatedText("click_to_turn_off", locale)
        : getTranslatedText("click_to_turn_on", locale),
    ],
    "minecraft:gold_block",
    1,
    true
  );

  Form.button(
    11,
    getTranslatedText("health_stamina_bar", locale),
    [`§7${getTranslatedText("click_to_change_mode", locale)}`],
    "textures/items/diamond_chestplate",
    1,
    true
  );

  // Language Selection button (NEW)
  const currentLocale = getPlayerLocale(player);
  const isEnglish = currentLocale === "en_US";
  Form.button(
    13, // Position in the middle
    getTranslatedText("language_button", locale),
    [
      getTranslatedText(
        "language_current",
        locale,
        getTranslatedText(
          isEnglish ? "english_name" : "vietnamese_name",
          locale
        )
      ) +
        "\n" +
        getTranslatedText(
          "click_to_switch_to",
          locale,
          getTranslatedText(
            isEnglish ? "vietnamese_name" : "english_name",
            locale
          )
        ),
    ],
    "minecraft:writable_book", // Icon for language
    1,
    true
  );

  // Cooldown Notification Setting
  Form.button(
    15,
    cooldownNotification === 1
      ? getTranslatedText("cooldown_notification_on", locale)
      : getTranslatedText("cooldown_notification_off", locale),
    [
      cooldownNotification === 1
        ? getTranslatedText("click_to_turn_off", locale)
        : getTranslatedText("click_to_turn_on", locale),
    ],
    "textures/items/experience_bottle",
    1,
    true
  );

  Form.button(
    17,
    hideArmor === 1
      ? getTranslatedText("hide_armor_on", locale)
      : getTranslatedText("hide_armor_off", locale),
    [
      hideArmor === 1
        ? getTranslatedText("click_to_turn_off", locale)
        : getTranslatedText("click_to_turn_on", locale),
    ],
    "minecraft:iron_block",
    1,
    true
  );

  // Back button
  Form.button(
    26,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(player, Form);

  if (!result.canceled) {
    if (result.selection === 9) {
      setPlayerProperty(player, "skill:hideHealth", hideHealth === 1 ? 0 : 1);
      settingPage(player); // Reload the settings page to show the updated status
    } else if (result.selection === 11) {
      // Health and Stamina bar button
      await settingBarPage(player); // Open the separate mode selection page
    } else if (result.selection === 13) {
      // Language button
      const newLocale = isEnglish ? "vi_VN" : "en_US";
      setPlayerProperty(player, "skill:playerLocale", newLocale);
      player.sendMessage(
        `§a${getTranslatedText(
          "language_switched_to",
          newLocale,
          getTranslatedText(
            newLocale === "en_US" ? "english_name" : "vietnamese_name",
            newLocale
          )
        )}`
      );
      settingPage(player); // Reload the settings page to show the updated language
    } else if (result.selection === 15) {
      // Cooldown Notification button
      setPlayerProperty(
        player,
        "skill:cooldownNotification",
        cooldownNotification === 1 ? 0 : 1
      );
      settingPage(player); // Reload the settings page to show the updated status
    } else if (result.selection === 17) {
      setPlayerProperty(player, "skill:hideArmor", hideArmor === 1 ? 0 : 1);
      settingPage(player); // Reload the settings page to show the updated status
    } else if (result.selection === 26) {
      // Back to skill list
      Skill(player);
    }
  }
}

/**
 * Hiển thị giao diện chọn chế độ hiển thị thanh máu/stamina.
 * @param {import("@minecraft/server").Player} player Người chơi.
 */
async function settingBarPage(player) {
  const locale = getPlayerLocale(player);
  const Form = new ChestFormData("small");
  Form.title(`§r${getTranslatedText("setting_title", locale)}`); // Still using "SETTINGS" title

  for (let i = 0; i < 27; i++) {
    Form.button(i, "", [], "textures/blocks/glass_black", 1, false);
  }

  // Buttons for each mode
  Form.button(
    9,
    getTranslatedText("mode1_title", locale),
    [`${getTranslatedText("mode1_desc", locale)}`],
    "minecraft:coal_block",
    1,
    true
  );
  Form.button(
    11,
    getTranslatedText("mode2_title", locale),
    [`${getTranslatedText("mode2_desc", locale)}`],
    "minecraft:iron_block",
    1,
    true
  );
  Form.button(
    13,
    getTranslatedText("mode3_title", locale),
    [`${getTranslatedText("mode3_desc", locale)}`],
    "minecraft:gold_block",
    1,
    true
  );
  Form.button(
    15,
    getTranslatedText("mode4_title", locale),
    [`${getTranslatedText("mode4_desc", locale)}`],
    "minecraft:diamond_block",
    1,
    true
  );
  Form.button(
    17,
    getTranslatedText("mode0_title", locale),
    [`${getTranslatedText("mode0_desc", locale)}`],
    "minecraft:emerald_block",
    1,
    true
  );

  // Back to general settings button
  Form.button(
    18,
    getTranslatedText("back_to_general_settings", locale),
    [`§7${getTranslatedText("click_to_back_setting", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  // Back to main skill list button (same as before)
  Form.button(
    26,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(player, Form);

  if (!result.canceled) {
    let newMode = -1;
    switch (result.selection) {
      case 9:
        newMode = 1;
        break;
      case 11:
        newMode = 2;
        break;
      case 13:
        newMode = 3;
        break;
      case 15:
        newMode = 4;
        break;
      case 17:
        newMode = 0;
        break;
      case 18: // Back to general settings
        settingPage(player);
        return; // Exit function after going back
      case 26: // Back to main skill list
        Skill(player);
        return; // Exit function after going back
    }

    if (newMode !== -1) {
      setPlayerProperty(player, "skill:modeShowBar", newMode);
      player.sendMessage(
        `§a${getTranslatedText("mode_set_success", locale, newMode)}`
      ); // Confirmation message
      settingBarPage(player); // Reload the bar settings page to reflect the change
    }
  }
}

// --- Xuất các hàm cần thiết để các tệp khác có thể truy cập ---
export { showLeaderboard }; // showLeaderboard vẫn cần được import và định nghĩa ở skillUI.js
