// config.js

let xp = 50; // Base XP for leveling up (used in skillCore for initial nextXp)

export const resetCost = 1000; // Chi phí đặt lại

// STATS SYSTEM CONFIG
export const STAT_POINT_PER_SKILL_LEVEL = 1; // Vẫn giữ nguyên, ví dụ cứ 5 cấp skill chính sẽ có cơ hội nhận điểm
export const CHANCE_TO_GET_UNSPENT_STAT_POINT = 0.1; // Tỉ lệ 50% nhận điểm, bạn có thể điều chỉnh

class blocks {
  constructor(blockID, xp, xpType) {
    this.blockID = blockID;
    this.xp = xp;
    this.xpType = xpType;
  }
}
class entities {
  constructor(id, xp, name, texture, damage) {
    this.id = id;
    this.xp = xp;
    this.name = name;
    this.texture = texture;
    this.damage = damage;
  }
}
// Treasures (sorted by general value/rarity, then alphabetically)
const treasures = [
  // Common/Utility
  "minecraft:arrow",
  "minecraft:bone",
  "minecraft:book",
  "minecraft:bowl", // Added from fishTypes junk
  "minecraft:bamboo", // Added from fishTypes junk
  "minecraft:cocoa_beans", // Added from fishTypes junk
  "minecraft:coal",
  "minecraft:feather",
  "minecraft:flint",
  "minecraft:gunpowder",
  "minecraft:ink_sac", // Added from fishTypes junk
  "minecraft:leather", // Added from fishTypes junk
  "minecraft:rotten_flesh", // Added from fishTypes junk
  "minecraft:stick",
  "minecraft:string",
  "minecraft:sugar",
  "minecraft:tripwire_hook",
  "minecraft:water_bottle", // Added from fishTypes junk
  // Uncommon/Equipment
  "minecraft:bow",
  "minecraft:compass",
  "minecraft:fishing_rod", // Damaged/Enchanted fishing rod
  "minecraft:leather_boots", // Added from fishTypes junk
  "minecraft:leather_leggings", // Added from fishTypes junk
  "minecraft:name_tag",
  "minecraft:saddle",
  // Rare/Valuable
  "minecraft:amethyst_shard",
  "minecraft:blaze_rod",
  "minecraft:brick", // Clay/Brick, useful for building
  "minecraft:diamond",
  "minecraft:emerald",
  "minecraft:enchanted_book",
  "minecraft:enchanted_bow", // Enchanted bow
  "minecraft:ender_pearl",
  "minecraft:ghast_tear",
  "minecraft:glow_ink_sac", // Added from fishTypes junk
  "minecraft:glowstone_dust",
  "minecraft:gold_block",
  "minecraft:gold_ingot",
  "minecraft:iron_ingot",
  "minecraft:lapis_lazuli",
  "minecraft:nautilus_shell",
  "minecraft:nether_star",
  "minecraft:redstone",
  "minecraft:slime_ball",
  "minecraft:spider_eye",
  "minecraft:totem_of_undying",
  "minecraft:wither_skeleton_skull",
];

// Ores and Stone-like blocks (grouped by type/progression, then alphabetically)
const m = [
  // Basic Stone & Variants
  new blocks("minecraft:stone", 0.1, "Stone"),
  new blocks("minecraft:cobblestone", 0.1, "Cobblestone"),
  new blocks("minecraft:andesite", 0.1, "Andesite"),
  new blocks("minecraft:diorite", 0.1, "Diorite"),
  new blocks("minecraft:granite", 0.1, "Granite"),
  new blocks("minecraft:deepslate", 0.1, "Deepslate"),
  new blocks("minecraft:tuff", 0.1, "Tuff"),
  new blocks("minecraft:dripstone_block", 0.1, "Dripstone Block"),
  new blocks("minecraft:basalt", 0.1, "Basalt"),
  new blocks("minecraft:blackstone", 0.1, "Blackstone"),
  // Coal & Redstone
  new blocks("minecraft:coal_ore", 0.2, "Coal Ore"),
  new blocks("minecraft:deepslate_coal_ore", 0.2, "Deepslate Coal Ore"),
  new blocks("minecraft:redstone_ore", 0.2, "Redstone Ore"),
  new blocks("minecraft:lit_redstone_ore", 0.2, "Lit Redstone Ore"), // Lit version
  new blocks("minecraft:deepslate_redstone_ore", 0.2, "Deepslate Redstone Ore"),
  new blocks("minecraft:lapis_ore", 0.2, "Lapis Ore"),
  new blocks("minecraft:deepslate_lapis_ore", 0.2, "Deepslate Lapis Ore"),
  new blocks("minecraft:glowstone", 0.2, "Glowstone"),
  new blocks("minecraft:amethyst_block", 0.3, "Amethyst Block"),
  new blocks("minecraft:budding_amethyst", 0.5, "Budding Amethyst"),
  // Metals
  new blocks("minecraft:copper_ore", 0.2, "Copper Ore"),
  new blocks("minecraft:deepslate_copper_ore", 0.2, "Deepslate Copper Ore"),
  new blocks("minecraft:iron_ore", 0.3, "Iron Ore"),
  new blocks("minecraft:deepslate_iron_ore", 0.3, "Deepslate Iron Ore"),
  new blocks("minecraft:raw_iron_block", 0.3, "Raw Iron Block"),
  new blocks("minecraft:gold_ore", 0.4, "Gold Ore"),
  new blocks("minecraft:deepslate_gold_ore", 0.4, "Deepslate Gold Ore"),
  new blocks("minecraft:raw_gold_block", 0.4, "Raw Gold Block"),
  // Valuable Ores
  new blocks("minecraft:emerald_ore", 0.5, "Emerald Ore"),
  new blocks("minecraft:deepslate_emerald_ore", 0.5, "Deepslate Emerald Ore"),
  new blocks("minecraft:diamond_ore", 0.5, "Diamond Ore"),
  new blocks("minecraft:deepslate_diamond_ore", 0.5, "Deepslate Diamond Ore"),
  // Nether & End
  new blocks("minecraft:netherrack", 0.05, "Netherrack"),
  new blocks("minecraft:nether_gold_ore", 0.5, "Nether Gold Ore"),
  new blocks("minecraft:quartz_ore", 0.3, "Quartz Ore"),
  new blocks("minecraft:ancient_debris", 1.0, "Ancient Debris"),
  new blocks("minecraft:obsidian", 0.8, "Obsidian"),
  new blocks("minecraft:end_stone", 0.1, "End Stone"),
];

// Logs and Wood (grouped by wood type, then by block variation)
const logs = [
  // Oak
  new blocks("minecraft:oak_log", 0.1, "Oak Log"),
  new blocks("minecraft:stripped_oak_log", 0.1, "Stripped Oak Log"),
  new blocks("minecraft:oak_wood", 0.1, "Oak Wood"),
  new blocks("minecraft:stripped_oak_wood", 0.1, "Stripped Oak Wood"),
  new blocks("minecraft:oak_leaves", 0.05, "Oak Leaves"),
  // Birch
  new blocks("minecraft:birch_log", 0.1, "Birch Log"),
  new blocks("minecraft:stripped_birch_log", 0.1, "Stripped Birch Log"),
  new blocks("minecraft:birch_wood", 0.1, "Birch Wood"),
  new blocks("minecraft:stripped_birch_wood", 0.1, "Stripped Birch Wood"),
  new blocks("minecraft:birch_leaves", 0.05, "Birch Leaves"),
  // Spruce
  new blocks("minecraft:spruce_log", 0.1, "Spruce Log"),
  new blocks("minecraft:stripped_spruce_log", 0.1, "Stripped Spruce Log"),
  new blocks("minecraft:spruce_wood", 0.1, "Spruce Wood"),
  new blocks("minecraft:stripped_spruce_wood", 0.1, "Stripped Spruce Wood"),
  new blocks("minecraft:spruce_leaves", 0.05, "Spruce Leaves"),
  // Jungle
  new blocks("minecraft:jungle_log", 0.1, "Jungle Log"),
  new blocks("minecraft:stripped_jungle_log", 0.1, "Stripped Jungle Log"),
  new blocks("minecraft:jungle_wood", 0.1, "Jungle Wood"),
  new blocks("minecraft:stripped_jungle_wood", 0.1, "Stripped Jungle Wood"),
  new blocks("minecraft:jungle_leaves", 0.05, "Jungle Leaves"),
  // Acacia
  new blocks("minecraft:acacia_log", 0.1, "Acacia Log"),
  new blocks("minecraft:stripped_acacia_log", 0.1, "Stripped Acacia Log"),
  new blocks("minecraft:acacia_wood", 0.1, "Acacia Wood"),
  new blocks("minecraft:stripped_acacia_wood", 0.1, "Stripped Acacia Wood"),
  new blocks("minecraft:acacia_leaves", 0.05, "Acacia Leaves"),
  // Dark Oak
  new blocks("minecraft:dark_oak_log", 0.1, "Dark Oak Log"),
  new blocks("minecraft:stripped_dark_oak_log", 0.1, "Stripped Dark Oak Log"),
  new blocks("minecraft:dark_oak_wood", 0.1, "Dark Oak Wood"),
  new blocks("minecraft:stripped_dark_oak_wood", 0.1, "Stripped Dark Oak Wood"),
  new blocks("minecraft:dark_oak_leaves", 0.05, "Dark Oak Leaves"),
  // Mangrove
  new blocks("minecraft:mangrove_log", 0.1, "Mangrove Log"),
  new blocks("minecraft:stripped_mangrove_log", 0.1, "Stripped Mangrove Log"),
  new blocks("minecraft:mangrove_wood", 0.1, "Mangrove Wood"),
  new blocks("minecraft:stripped_mangrove_wood", 0.1, "Stripped Mangrove Wood"),
  new blocks("minecraft:mangrove_leaves", 0.05, "Mangrove Leaves"),
  new blocks("minecraft:mangrove_roots", 0.05, "Mangrove Roots"),
  // Cherry
  new blocks("minecraft:cherry_log", 0.1, "Cherry Log"),
  new blocks("minecraft:stripped_cherry_log", 0.1, "Stripped Cherry Log"),
  new blocks("minecraft:cherry_wood", 0.1, "Cherry Wood"),
  new blocks("minecraft:stripped_cherry_wood", 0.1, "Stripped Cherry Wood"),
  new blocks("minecraft:cherry_leaves", 0.05, "Cherry Leaves"),
  // Crimson (Nether)
  new blocks("minecraft:crimson_stem", 0.1, "Crimson Stem"),
  new blocks("minecraft:stripped_crimson_stem", 0.1, "Stripped Crimson Stem"),
  new blocks("minecraft:crimson_hyphae", 0.1, "Crimson Hyphae"),
  new blocks(
    "minecraft:stripped_crimson_hyphae",
    0.1,
    "Stripped Crimson Hyphae"
  ),
  new blocks("minecraft:crimson_nylium", 0.05, "Crimson Nylium"),
  // Warped (Nether)
  new blocks("minecraft:warped_stem", 0.1, "Warped Stem"),
  new blocks("minecraft:stripped_warped_stem", 0.1, "Stripped Warped Stem"),
  new blocks("minecraft:warped_hyphae", 0.1, "Warped Hyphae"),
  new blocks("minecraft:stripped_warped_hyphae", 0.1, "Stripped Warped Hyphae"),
  new blocks("minecraft:warped_nylium", 0.05, "Warped Nylium"),
];

// Mobs (grouped by behavior: Passive, Neutral, Hostile, Boss; then alphabetically)
const mobs = [
  // Passive Mobs
  new entities("minecraft:allay", 0.5, "Allay", "minecraft:allay_spawn_egg", 0),
  new entities(
    "minecraft:armadillo",
    0.5,
    "Armadillo",
    "minecraft:armadillo_spawn_egg",
    0
  ),
  new entities("minecraft:bat", 0.3, "Bat", "minecraft:bat_spawn_egg", 1),
  new entities("minecraft:camel", 0.6, "Camel", "minecraft:camel_spawn_egg", 4),
  new entities("minecraft:cat", 0.4, "Cat", "minecraft:cat_spawn_egg", 3),
  new entities(
    "minecraft:chicken",
    0.2,
    "Chicken",
    "minecraft:chicken_spawn_egg",
    2
  ),
  new entities("minecraft:cod", 0.2, "Cod", "minecraft:cod_spawn_egg", 2),
  new entities("minecraft:cow", 0.4, "Cow", "minecraft:cow_spawn_egg", 2),
  new entities(
    "minecraft:dolphin",
    0.4,
    "Dolphin",
    "minecraft:dolphin_spawn_egg",
    3
  ),
  new entities(
    "minecraft:donkey",
    0.5,
    "Donkey",
    "minecraft:donkey_spawn_egg",
    4
  ),
  new entities("minecraft:frog", 0.4, "Frog", "minecraft:frog_spawn_egg", 2),
  new entities(
    "minecraft:glow_squid",
    0.5,
    "Glow Squid",
    "minecraft:glow_squid_spawn_egg",
    4
  ),
  new entities("minecraft:horse", 0.6, "Horse", "minecraft:horse_spawn_egg", 4),
  new entities("minecraft:llama", 0.6, "Llama", "minecraft:llama_spawn_egg", 5),
  new entities(
    "minecraft:mooshroom",
    0.4,
    "Mooshroom",
    "minecraft:mooshroom_spawn_egg",
    2
  ),
  new entities("minecraft:mule", 0.5, "Mule", "minecraft:mule_spawn_egg", 4),
  new entities(
    "minecraft:ocelot",
    0.5,
    "Ocelot",
    "minecraft:ocelot_spawn_egg",
    4
  ),
  new entities("minecraft:panda", 0.6, "Panda", "minecraft:panda_spawn_egg", 4),
  new entities(
    "minecraft:parrot",
    0.3,
    "Parrot",
    "minecraft:parrot_spawn_egg",
    1
  ),
  new entities("minecraft:pig", 0.3, "Pig", "minecraft:pig_spawn_egg", 2),
  new entities(
    "minecraft:pufferfish",
    0.2,
    "Pufferfish",
    "minecraft:pufferfish_spawn_egg",
    2
  ),
  new entities(
    "minecraft:rabbit",
    0.2,
    "Rabbit",
    "minecraft:rabbit_spawn_egg",
    1
  ),
  new entities(
    "minecraft:salmon",
    0.2,
    "Salmon",
    "minecraft:salmon_spawn_egg",
    2
  ),
  new entities("minecraft:sheep", 0.3, "Sheep", "minecraft:sheep_spawn_egg", 2),
  new entities(
    "minecraft:sniffer",
    0.4,
    "Sniffer",
    "minecraft:sniffer_spawn_egg",
    3
  ),
  new entities("minecraft:squid", 0.3, "Squid", "minecraft:squid_spawn_egg", 2),
  new entities(
    "minecraft:strider",
    0.5,
    "Strider",
    "minecraft:strider_spawn_egg",
    0
  ),
  new entities(
    "minecraft:tropical_fish",
    0.2,
    "Tropical Fish",
    "minecraft:tropical_fish_spawn_egg",
    2
  ),
  new entities(
    "minecraft:turtle",
    0.4,
    "Turtle",
    "minecraft:turtle_spawn_egg",
    3
  ),
  new entities(
    "minecraft:villager",
    0.3,
    "Villager",
    "minecraft:villager_spawn_egg",
    0
  ),
  // Neutral Mobs
  new entities(
    "minecraft:axolotl",
    0.5,
    "Axolotl",
    "minecraft:axolotl_spawn_egg",
    4
  ),
  new entities("minecraft:bee", 0.3, "Bee", "minecraft:bee_spawn_egg", 3),
  new entities(
    "minecraft:enderman",
    2.0,
    "Enderman",
    "minecraft:enderman_spawn_egg",
    7
  ),
  new entities("minecraft:fox", 0.5, "Fox", "minecraft:fox_spawn_egg", 4),
  new entities("minecraft:goat", 0.6, "Goat", "minecraft:goat_spawn_egg", 4),
  new entities(
    "minecraft:hoglin",
    1.8,
    "Hoglin",
    "minecraft:hoglin_spawn_egg",
    6
  ),
  new entities(
    "minecraft:iron_golem",
    5.0,
    "Iron Golem",
    "minecraft:iron_golem_spawn_egg",
    15
  ),
  new entities(
    "minecraft:piglin",
    1.5,
    "Piglin",
    "minecraft:piglin_spawn_egg",
    5
  ),
  new entities(
    "minecraft:polar_bear",
    0.8,
    "Polar Bear",
    "minecraft:polar_bear_spawn_egg",
    6
  ),
  new entities(
    "minecraft:snow_golem",
    0.5,
    "Snow Golem",
    "minecraft:snow_golem_spawn_egg",
    0
  ),
  new entities("minecraft:wolf", 0.5, "Wolf", "minecraft:wolf_spawn_egg", 5),
  new entities(
    "minecraft:zombified_piglin",
    1.5,
    "Zombified Piglin",
    "minecraft:zombified_piglin_spawn_egg",
    5
  ), // Renamed from piglin to zombified_piglin
  // Hostile Mobs
  new entities("minecraft:blaze", 2.5, "Blaze", "minecraft:blaze_spawn_egg", 6),
  new entities(
    "minecraft:cave_spider",
    1.0,
    "Cave Spider",
    "minecraft:cave_spider_spawn_egg",
    2
  ),
  new entities(
    "minecraft:creeper",
    1.5,
    "Creeper",
    "minecraft:creeper_spawn_egg",
    0
  ),
  new entities(
    "minecraft:drowned",
    1.1,
    "Drowned",
    "minecraft:drowned_spawn_egg",
    2
  ),
  new entities(
    "minecraft:elder_guardian",
    10.0,
    "Elder Guardian",
    "minecraft:elder_guardian_spawn_egg",
    8
  ),
  new entities(
    "minecraft:endermite",
    0.7,
    "Endermite",
    "minecraft:endermite_spawn_egg",
    2
  ),
  new entities(
    "minecraft:evoker",
    3.0,
    "Evoker",
    "minecraft:evoker_spawn_egg",
    9
  ),
  new entities("minecraft:ghast", 3.0, "Ghast", "minecraft:ghast_spawn_egg", 8),
  new entities(
    "minecraft:guardian",
    2.8,
    "Guardian",
    "minecraft:guardian_spawn_egg",
    6
  ),
  new entities("minecraft:husk", 1.0, "Husk", "minecraft:husk_spawn_egg", 2),
  new entities(
    "minecraft:magma_cube",
    1.0,
    "Magma Cube",
    "minecraft:magma_cube_spawn_egg",
    3
  ),
  new entities(
    "minecraft:phantom",
    2.2,
    "Phantom",
    "minecraft:phantom_spawn_egg",
    5
  ),
  new entities(
    "minecraft:piglin_brute",
    2.5,
    "Piglin Brute",
    "minecraft:piglin_brute_spawn_egg",
    8
  ),
  new entities(
    "minecraft:pillager",
    1.6,
    "Pillager",
    "minecraft:pillager_spawn_egg",
    4
  ),
  new entities(
    "minecraft:shulker",
    4.0,
    "Shulker",
    "minecraft:shulker_spawn_egg",
    0
  ),
  new entities(
    "minecraft:silverfish",
    0.6,
    "Silverfish",
    "minecraft:silverfish_spawn_egg",
    1
  ),
  new entities(
    "minecraft:skeleton",
    1.2,
    "Skeleton",
    "minecraft:skeleton_spawn_egg",
    3
  ),
  new entities("minecraft:slime", 0.8, "Slime", "minecraft:slime_spawn_egg", 2),
  new entities(
    "minecraft:spider",
    0.8,
    "Spider",
    "minecraft:spider_spawn_egg",
    2
  ),
  new entities("minecraft:stray", 1.3, "Stray", "minecraft:stray_spawn_egg", 3),
  new entities("minecraft:vex", 1.5, "Vex", "minecraft:vex_spawn_egg", 5),
  new entities(
    "minecraft:vindicator",
    2.0,
    "Vindicator",
    "minecraft:vindicator_spawn_egg",
    7
  ),
  new entities(
    "minecraft:warden",
    8.0,
    "Warden",
    "minecraft:warden_spawn_egg",
    15
  ),
  new entities("minecraft:witch", 1.8, "Witch", "minecraft:witch_spawn_egg", 0),
  new entities(
    "minecraft:wither_skeleton",
    3.5,
    "Wither Skeleton",
    "minecraft:wither_skeleton_spawn_egg",
    4
  ),
  new entities(
    "minecraft:zoglin",
    1.8,
    "Zoglin",
    "minecraft:zoglin_spawn_egg",
    7
  ),
  new entities(
    "minecraft:zombie",
    1.0,
    "Zombie",
    "minecraft:zombie_spawn_egg",
    2
  ),
  new entities(
    "minecraft:zombie_villager",
    1.0,
    "Zombie Villager",
    "minecraft:zombie_villager_spawn_egg",
    2
  ),
  // Boss Mobs
  new entities(
    "minecraft:ender_dragon",
    100.0,
    "Ender Dragon",
    "minecraft:ender_dragon_spawn_egg",
    25
  ),
  new entities(
    "minecraft:wither",
    50.0,
    "Wither",
    "minecraft:wither_spawn_egg",
    20
  ),
];

// Crops (grouped by type, then alphabetically)
const crops = [
  // Vegetables & Grains
  new blocks("minecraft:beetroots", 0.1, "Beetroot"),
  new blocks("minecraft:carrots", 0.1, "Carrot"),
  new blocks("minecraft:nether_wart", 0.15, "Nether Wart"),
  new blocks("minecraft:potatoes", 0.1, "Potato"),
  new blocks("minecraft:wheat", 0.1, "Wheat"),
  // Fruits & Melons
  new blocks("minecraft:cocoa_pod", 0.12, "Cocoa Beans"),
  new blocks("minecraft:melon_block", 0.2, "Melon"),
  new blocks("minecraft:pumpkin", 0.2, "Pumpkin"),
  new blocks("minecraft:sweet_berry_bush", 0.1, "Sweet Berry Bush"),
  // Other Plants
  new blocks("minecraft:bamboo", 0.05, "Bamboo"),
  new blocks("minecraft:brown_mushroom", 0.05, "Brown Mushroom"),
  new blocks("minecraft:cactus", 0.05, "Cactus"),
  new blocks("minecraft:cave_vines", 0.1, "Cave Vines"), // For Glow Berries
  new blocks("minecraft:chorus_flower", 0.2, "Chorus Flower"),
  new blocks("minecraft:chorus_plant", 0.15, "Chorus Plant"),
  new blocks("minecraft:kelp", 0.05, "Kelp"),
  new blocks("minecraft:red_mushroom", 0.05, "Red Mushroom"),
  new blocks("minecraft:reeds", 0.05, "Sugar Cane"),
];

// Max growth stage for crops
const cropsGrowth = {
  "minecraft:beetroots": 3,
  "minecraft:carrots": 7,
  "minecraft:cocoa_pod": 2,
  "minecraft:melon_block": 7, // Stalk growth
  "minecraft:nether_wart": 3,
  "minecraft:potatoes": 7,
  "minecraft:pumpkin": 7, // Stalk growth
  "minecraft:sweet_berry_bush": 3,
  "minecraft:wheat": 7,
  "minecraft:bamboo": null, // No growth state property
  "minecraft:brown_mushroom": null, // No growth state property
  "minecraft:cactus": null, // No growth state property
  "minecraft:cave_vines": 2, // Cave vines with glow berries
  "minecraft:chorus_flower": null, // No growth state property
  "minecraft:chorus_plant": null, // No growth state property
  "minecraft:kelp": null, // No growth state property
  "minecraft:red_mushroom": null, // No growth state property
  "minecraft:reeds": null, // No growth state property
};

// Soils (grouped by type, then alphabetically)
const soils = [
  // Dirt & Variants
  new blocks("minecraft:dirt", 0.5, "Dirt"),
  new blocks("minecraft:coarse_dirt", 0.5, "Coarse Dirt"),
  new blocks("minecraft:farmland", 0.5, "Farmland"),
  new blocks("minecraft:grass", 0.5, "Grass"),
  new blocks("minecraft:grass_block", 0.5, "Grass Block"),
  new blocks("minecraft:mud", 0.5, "Mud"),
  new blocks("minecraft:muddy_mangrove_roots", 0.5, "Muddy Mangrove Roots"),
  new blocks("minecraft:mycelium", 0.5, "Mycelium"),
  new blocks("minecraft:podzol", 0.5, "Podzol"),
  new blocks("minecraft:rooted_dirt", 0.5, "Rooted Dirt"),
  new blocks("minecraft:soul_soil", 0.5, "Soul Soil"),
  // Sand & Variants
  new blocks("minecraft:sand", 0.5, "Sand"),
  new blocks("minecraft:red_sand", 0.5, "Red Sand"),
  new blocks("minecraft:soul_sand", 0.5, "Soul Sand"),
  // Other
  new blocks("minecraft:clay", 0.5, "Clay"),
  new blocks("minecraft:gravel", 0.5, "Gravel"),
  new blocks("minecraft:powder_snow", 0.5, "Powder Snow"),
  new blocks("minecraft:snow", 0.5, "Snow"),
];

// Prefix tool
const pickaxe = [
  "minecraft:wooden_pickaxe",
  "minecraft:stone_pickaxe",
  "minecraft:iron_pickaxe",
  "minecraft:golden_pickaxe",
  "minecraft:diamond_pickaxe",
  "minecraft:netherite_pickaxe",
];
const axe = [
  "minecraft:wooden_axe",
  "minecraft:stone_axe",
  "minecraft:iron_axe",
  "minecraft:golden_axe",
  "minecraft:diamond_axe",
  "minecraft:netherite_axe",
];
const sword = [
  "minecraft:wooden_sword",
  "minecraft:stone_sword",
  "minecraft:iron_sword",
  "minecraft:golden_sword",
  "minecraft:diamond_sword",
  "minecraft:netherite_sword",
];
const hoe = [
  "minecraft:wooden_hoe",
  "minecraft:stone_hoe",
  "minecraft:iron_hoe",
  "minecraft:golden_hoe",
  "minecraft:diamond_hoe",
  "minecraft:netherite_hoe",
];
const shovel = [
  "minecraft:wooden_shovel",
  "minecraft:stone_shovel",
  "minecraft:iron_shovel",
  "minecraft:golden_shovel",
  "minecraft:diamond_shovel",
  "minecraft:netherite_shovel",
];
const bow = ["minecraft:bow", "minecraft:crossbow"];

const particles = {
  regen: "minecraft:villager_happy", // Placeholder
  strength: "minecraft:basic_flame_particle", // Placeholder
  lucky_block: "minecraft:basic_redstone_particle", // Placeholder
};

export const fishTypes = [
  // Fish (sorted alphabetically)
  { item: "minecraft:clownfish", name: "Clownfish", xp: 1.2 },
  { item: "minecraft:cod", name: "Raw Cod", xp: 0.5 },
  { item: "minecraft:pufferfish", name: "Pufferfish", xp: 1.5 },
  { item: "minecraft:salmon", name: "Raw Salmon", xp: 0.8 },
  { item: "minecraft:tropical_fish", name: "Tropical Fish", xp: 2.0 },

  // Junk (sorted alphabetically)
  { item: "minecraft:bamboo", name: "Bamboo", xp: 0.1 },
  { item: "minecraft:bone", name: "Bone", xp: 0.1 },
  { item: "minecraft:bowl", name: "Bowl", xp: 0.1 },
  { item: "minecraft:cocoa_beans", name: "Cocoa Beans", xp: 0.1 },
  { item: "minecraft:fishing_rod", name: "Damaged Fishing Rod", xp: 0.2 },
  { item: "minecraft:glow_ink_sac", name: "Glow Ink Sac", xp: 0.2 },
  { item: "minecraft:ink_sac", name: "Ink Sac", xp: 0.1 },
  { item: "minecraft:leather", name: "Leather", xp: 0.1 },
  { item: "minecraft:leather_boots", name: "Leather Boots", xp: 0.2 },
  { item: "minecraft:leather_leggings", name: "Leather Leggings", xp: 0.2 },
  { item: "minecraft:rotten_flesh", name: "Rotten Flesh", xp: 0.1 },
  { item: "minecraft:stick", name: "Stick", xp: 0.1 },
  { item: "minecraft:string", name: "String", xp: 0.1 },
  { item: "minecraft:tripwire_hook", name: "Tripwire Hook", xp: 0.1 },
  { item: "minecraft:water_bottle", name: "Water Bottle", xp: 0.1 },

  // Treasure (sorted alphabetically)
  { item: "minecraft:bow", name: "Bow", xp: 1.0 },
  { item: "minecraft:enchanted_book", name: "Enchanted Book", xp: 2.0 },
  { item: "minecraft:enchanted_bow", name: "Enchanted Bow", xp: 1.5 },
  { item: "minecraft:fishing_rod", name: "Enchanted Fishing Rod", xp: 1.5 },
  { item: "minecraft:name_tag", name: "Name Tag", xp: 1.0 },
  { item: "minecraft:nautilus_shell", name: "Nautilus Shell", xp: 1.5 },
  { item: "minecraft:saddle", name: "Saddle", xp: 1.0 },
];

export const treasureFish = [
  { item: "minecraft:name_tag", amount: 1 },
  { item: "minecraft:nautilus_shell", amount: 1 },
  { item: "minecraft:enchanted_book", amount: 1 }, // Random enchanted book, cần logic phức tạp hơn
];

export {
  xp,
  blocks,
  entities,
  treasures,
  m,
  logs,
  mobs,
  crops,
  cropsGrowth,
  soils,
  pickaxe,
  axe,
  sword,
  hoe,
  shovel,
  bow,
  particles,
};
