// BP/scripts/modules/CooldownManager.js

import { system } from "@minecraft/server";
import { getPlayerProperty, setPlayerProperty } from "../SkillSystem/utils.js";

/**
 * Quản lý thời gian hồi chiêu cho các skill hoặc khả năng của người chơi.
 * Dữ liệu cooldown được lưu trong Dynamic Properties của người chơi.
 */
export class CooldownManager {
  /**
   * @param {string} cooldownId ID duy nhất cho cooldown này (ví dụ: "miningSkill3Cooldown")
   */
  constructor(cooldownId) {
    this.cooldownProperty = `cooldown:${cooldownId}`;
  }

  /**
   * Đặt thời gian hồi chiêu cho người chơi.
   * @param {import("@minecraft/server").Player} player Người chơi.
   * @param {number} durationTicks Thời gian hồi chiêu tính bằng ticks (20 ticks = 1 giây).
   */
  setCooldown(player, durationTicks) {
    const endTime = system.currentTick + durationTicks;
    setPlayerProperty(player, this.cooldownProperty, endTime);
  }

  /**
   * Lấy thời gian hồi chiêu còn lại cho người chơi.
   * @param {import("@minecraft/server").Player} player Người chơi.
   * @returns {number} Thời gian còn lại tính bằng ticks. Trả về 0 nếu không có cooldown hoặc đã hết.
   */
  getRemainingCooldown(player) {
    const endTime = getPlayerProperty(player, this.cooldownProperty, 0);
    const now = system.currentTick;

    if (typeof endTime !== "number" || endTime <= now) {
      this.clearCooldown(player);
      return 0;
    }

    return endTime - now;
  }

  /**
   * Kiểm tra xem skill có đang trong thời gian hồi chiêu không.
   * @param {import("@minecraft/server").Player} player Người chơi.
   * @returns {boolean} True nếu đang trong cooldown, False nếu không.
   */
  isOnCooldown(player) {
    return this.getRemainingCooldown(player) > 0;
  }

  /**
   * Xóa cooldown cho người chơi.
   * @param {import("@minecraft/server").Player} player Người chơi.
   */
  clearCooldown(player) {
    setPlayerProperty(player, this.cooldownProperty, 0);
  }
}
