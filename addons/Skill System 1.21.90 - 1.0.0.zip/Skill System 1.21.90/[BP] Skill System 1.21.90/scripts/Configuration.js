const Config = {};

Config.NumberOf_1_16_100_Items = 1;

export default { Config };
