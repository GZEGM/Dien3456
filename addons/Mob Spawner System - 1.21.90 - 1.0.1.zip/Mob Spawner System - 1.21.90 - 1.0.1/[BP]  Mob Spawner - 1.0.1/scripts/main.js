import { world, system } from "@minecraft/server";
import {
  ModalFormData,
  ActionFormData,
  MessageFormData,
} from "@minecraft/server-ui";

const areaSelectMap = new Map();
const spawnerIntervals = new Map();
const debugLogs = [];
const playerToolCooldowns = new Map(); // Map to track player cooldowns for tool interaction
const COOLDOWN_TICKS = 10; // Cooldown duration in game ticks (20 ticks = 1 second)

// New Maps for managing floating text and particles
// Now maps intervalKey (spawnerKey_mobType) to text display entity ID
const spawnerTextEntities = new Map();
// Now maps intervalKey (spawnerKey_mobType) to floating text update interval ID
const floatingTextUpdateIntervals = new Map();
const spawnerParticleIntervals = new Map(); // Maps spawnerKey to particle interval ID (still position-based)

// Global ID for floating text entity type
const FloatingTextID = "dienkon:floating_text";

// Config
let mobConfig = {
  chunkLoadRadius: 2, // Radius in chunks around spawner to check for existing mobs
  playerNearbyDistance: 48, // Distance player needs to be nearby for spawner to be active
  toolType: "minecraft:golden_shovel", // Item ID used to select positions
};

/**
 * Loads the mob configuration from world dynamic properties.
 */
function loadMobConfig() {
  try {
    const raw = world.getDynamicProperty("mob_config");
    if (raw) {
      const data = JSON.parse(raw);
      mobConfig = Object.assign(mobConfig, data);
    }
  } catch (err) {
    console.warn("Failed to load mob_config:", err);
  }
}

/**
 * Saves the mob configuration to world dynamic properties.
 */
function saveMobConfig() {
  world.setDynamicProperty("mob_config", JSON.stringify(mobConfig));
}

/**
 * Opens the main spawner configuration UI for a player.
 * @param {import("@minecraft/server").Player} player - The player to show the UI to.
 */
function openSpawnerConfigUI(player) {
  const form = new ModalFormData()
    .title("Spawner Settings")
    .textField("Chunk Load Radius (blocks)", "", {
      defaultValue: mobConfig.chunkLoadRadius.toString(),
    })
    .textField("Player Nearby Distance (blocks)", "", {
      defaultValue: mobConfig.playerNearbyDistance.toString(),
    })
    .textField("Tool Type (item ID)", "", {
      defaultValue: mobConfig.toolType,
    });

  form.show(player).then((res) => {
    if (res.canceled) return;

    const [chunkRadiusStr, playerDistStr, toolType] = res.formValues;

    const radius = parseInt(chunkRadiusStr);
    const playerDist = parseInt(playerDistStr);

    if (isNaN(radius) || radius < 0 || radius > 10) {
      return player.sendMessage("§cInvalid chunk radius (0-10).");
    }
    if (isNaN(playerDist) || playerDist < 1 || playerDist > 128) {
      return player.sendMessage("§cInvalid player distance (1-128).");
    }

    mobConfig.chunkLoadRadius = radius;
    mobConfig.playerNearbyDistance = playerDist;
    mobConfig.toolType = toolType.trim() || "minecraft:golden_shovel";

    saveMobConfig();
    player.sendMessage("§a[Spawner] Settings updated.");
  });
}

// Reload all spawners when the world loads
system.runTimeout(() => {
  loadMobConfig();
  saveMobConfig(); // Save initial config if none exists

  const raw = world.getDynamicProperty("mob_spawns");
  if (!raw) return;

  try {
    const all = JSON.parse(raw);
    for (const key in all) {
      const [_, x, y, z] = key
        .split("_")
        .map((s, i) => (i === 0 ? s : parseInt(s)));
      const pos = { x, y, z };
      const configs = all[key];

      if (Array.isArray(configs)) {
        startSpawnerListAt(pos, configs); // Handle list of configs at a position
      } else {
        startSpawnerAt(pos, configs); // Backward compatibility for old single config structure
      }
    }
    DebugLog(`[Server] §aScript has been loaded and spawners re-initialized.`);
  } catch (err) {
    DebugLog(`§c[Server Error] Failed to load mob spawns: ${err}`, true);
    console.error("[Script Error] Failed to load mob spawns:", err);
  }
}, 40); // Run after a short delay to ensure world is ready

// === MAIN MENU ITEM USE ===
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  // Check for the specific item ID for the menu opener
  if (!item || item.typeId !== "item:mob_spawn") return;

  const form = new ActionFormData()
    .title("Mob Spawner Menu")
    .body("Select an action:")
    .button("Create mob spawn (point)")
    .button("Create mob spawn (area)")
    .button("Manage Spawners")
    .button("Debug Log")
    .button("Config");

  form.show(player).then((res) => {
    if (res.canceled) return;

    switch (res.selection) {
      case 0:
        askForPointPosition(player);
        break;
      case 1:
        askForAreaPositions(player);
        break;
      case 2:
        openSpawnerManagerUI(player);
        break;
      case 3:
        openDebugLogForm(player);
        break;
      case 4:
        openSpawnerConfigUI(player);
        break;
    }
  });
});

/**
 * Parses a single coordinate string (e.g., "~", "~10", "-50") relative to a current value.
 * @param {string} val - The coordinate string.
 * @param {number} cur - The current coordinate value (e.g., player.location.x).
 * @returns {number} The parsed absolute coordinate.
 */
const parseCoord = (val, cur) => {
  if (val.startsWith("~")) {
    const offsetStr = val.substring(1);
    if (offsetStr === "") {
      return Math.floor(cur); // Just "~"
    } else {
      const offset = parseInt(offsetStr);
      if (!isNaN(offset)) {
        return Math.floor(cur) + offset; // "~10", "~-5"
      }
    }
  }
  return parseInt(val); // "100", "-20"
};

/**
 * Parses a coordinate input string (e.g., "100 64 -20", "~ ~ ~", "~10 ~-5 ~", or "~~10~")
 * and returns absolute coordinates.
 * @param {string} inputStr - The raw input string from the form.
 * @param {import("@minecraft/server").Vector3} currentLoc - The player's current location for relative coordinates.
 * @returns {import("@minecraft/server").Vector3 | null} Parsed coordinates or null if invalid.
 */
function parseCoordsInput(inputStr, currentLoc) {
  const parts = inputStr.trim().split(/\s+/); // Try splitting by space first

  if (parts.length === 3) {
    // Handles "100 64 -20", "~ ~ ~", "~10 ~-5 ~"
    const x = parseCoord(parts[0], currentLoc.x);
    const y = parseCoord(parts[1], currentLoc.y);
    const z = parseCoord(parts[2], currentLoc.z);
    if (![x, y, z].some(isNaN)) {
      return { x, y, z };
    }
  }

  // If not 3 space-separated parts, try parsing as a contiguous string like "~1~10~"
  const contiguousRegex = /^~(-?\d*)?~(-?\d*)?~(-?\d*)?$/;
  const match = inputStr.trim().match(contiguousRegex);

  if (match) {
    const xOffsetStr = match[1] || "0"; // Default to 0 if empty (e.g., just "~")
    const yOffsetStr = match[2] || "0";
    const zOffsetStr = match[3] || "0";

    const x = Math.floor(currentLoc.x) + parseInt(xOffsetStr);
    const y = Math.floor(currentLoc.y) + parseInt(yOffsetStr);
    const z = Math.floor(currentLoc.z) + parseInt(zOffsetStr);

    if (![x, y, z].some(isNaN)) {
      return { x, y, z };
    }
  }

  return null; // Invalid format
}

/**
 * Prompts the player for a single point spawn position.
 * @param {import("@minecraft/server").Player} player - The player requesting the position.
 */
function askForPointPosition(player) {
  const form = new ModalFormData()
    .title("Point Spawn Position")
    .textField("Enter coordinates (x y z)", "~ ~ ~", {
      placeholder: "e.g., 100 64 -20 or ~ ~ ~ or ~10 ~-5 ~ or ~1~10~", // Updated placeholder
    });

  form.show(player).then((res) => {
    if (res.canceled) return;

    const input = res.formValues[0];
    const current = player.location;
    const parsedPos = parseCoordsInput(input, current);

    if (!parsedPos) {
      return player.sendMessage(
        "§cInvalid format. Use: x y z (e.g. 100 64 -20 or ~ ~ ~ or ~10 ~-5 ~ or ~1~10~)"
      );
    }

    player.sendMessage(
      `§a[Spawner] Creating point spawner at ${parsedPos.x} ${parsedPos.y} ${parsedPos.z}`
    );
    openAreaMobSettingsUI(player, parsedPos, null); // Single point spawn
  });
}

/**
 * Prompts the player for two positions to define a spawn area.
 * @param {import("@minecraft/server").Player} player - The player requesting the positions.
 */
function askForAreaPositions(player) {
  const form = new ModalFormData()
    .title("Area Spawn Positions")
    .textField("Start pos (x y z)", "~ ~ ~", {
      placeholder: "e.g., 100 64 -20 or ~ ~ ~ or ~10 ~-5 ~ or ~1~10~", // Updated placeholder
    })
    .textField("End pos (x y z)", "~ ~ ~", {
      placeholder: "e.g., 110 70 -10 or ~ ~ ~ or ~10 ~-5 ~ or ~1~10~", // Updated placeholder
    });

  form.show(player).then((res) => {
    if (res.canceled) return;

    const input1 = res.formValues[0];
    const input2 = res.formValues[1];

    const current = player.location;
    const parsedStart = parseCoordsInput(input1, current);
    const parsedEnd = parseCoordsInput(input2, current);

    if (!parsedStart || !parsedEnd) {
      return player.sendMessage(
        "§cInvalid format. Use: x y z (e.g. 100 64 -20 or ~ ~ ~ or ~10 ~-5 ~ or ~1~10~)"
      );
    }

    player.sendMessage(
      `§a[Spawner] Creating area spawner from (${parsedStart.x} ${parsedStart.y} ${parsedStart.z}) to (${parsedEnd.x} ${parsedEnd.y} ${parsedEnd.z})`
    );
    openAreaMobSettingsUI(player, parsedStart, parsedEnd); // Area spawn
  });
}

/**
 * Handles actions (remove, edit) for a selected spawner.
 * @param {import("@minecraft/server").Player} player - The player performing the action.
 * @param {"remove"|"edit"} mode - The action mode.
 * @param {string} key - The spawner's unique key (e.g., "spawner_100_64_-20").
 * @param {number} index - The index of the specific config within the list at that key.
 */
function handleSpawnerAction(player, mode, key, index) {
  const allData = JSON.parse(world.getDynamicProperty("mob_spawns") ?? "{}");
  if (!allData[key]) {
    player.sendMessage("§cSpawner not found.");
    return;
  }

  const configList = Array.isArray(allData[key])
    ? allData[key]
    : [allData[key]]; // Ensure it's always a list
  const selectedConfig = configList[index];
  if (!selectedConfig) {
    player.sendMessage("§cInvalid spawner index.");
    return;
  }

  const [_, x, y, z] = key
    .split("_")
    .map((s, i) => (i === 0 ? s : parseInt(s)));

  const mobType = selectedConfig.mobType;
  const intervalKey = `${key}_${mobType}`; // Specific interval key for this mobType at this position

  if (mode === "remove") {
    const confirm = new MessageFormData()
      .title("Confirm Removal")
      .body(
        `Are you sure you want to remove:\n§c[${mobType}] at (${x}, ${y}, ${z})`
      )
      .button1("§cYes, delete")
      .button2("Cancel");

    confirm.show(player).then((res) => {
      if (res.selection !== 0) return; // If not "Yes, delete"

      // Get the intervalKey of the config being removed
      const removedIntervalKey = `${key}_${mobType}`;

      // Remove the specific config from the list
      configList.splice(index, 1);

      // If the list is empty after removal, delete the whole key from allData
      if (configList.length === 0) {
        delete allData[key];
        world.setDynamicProperty("mob_spawns", JSON.stringify(allData));
        clearAllVisualsAtPosition(key); // Clear all visuals at this position
      } else {
        allData[key] = configList; // Otherwise, update the list
        world.setDynamicProperty("mob_spawns", JSON.stringify(allData));
        // Only clear the specific floating text for the removed config
        clearSpecificFloatingText(removedIntervalKey);
      }

      // Clear the corresponding spawner interval (main spawn loop)
      if (spawnerIntervals.has(removedIntervalKey)) {
        system.clearRun(spawnerIntervals.get(removedIntervalKey));
        spawnerIntervals.delete(removedIntervalKey);
      }

      player.sendMessage(
        `§aRemoved spawner [${mobType}] at (${x}, ${y}, ${z})`
      );
    });
  } else if (mode === "edit") {
    openAreaMobSettingsUI(
      player,
      selectedConfig.isArea ? selectedConfig.areaStart : { x, y, z },
      selectedConfig.isArea ? selectedConfig.areaEnd : null,
      (newPos, newConfig) => {
        // This is the callback, now receiving newConfig
        const oldPosKey = getPosKey({ x, y, z }); // x, y, z from the key of the selected spawner
        const oldIntervalKey = `${oldPosKey}_${selectedConfig.mobType}`; // selectedConfig is the OLD config

        const newPosKey = getPosKey(newPos);
        const newIntervalKey = `${newPosKey}_${newConfig.mobType}`; // newConfig is the result from the form

        // 1. Clear the old spawner's main interval
        if (spawnerIntervals.has(oldIntervalKey)) {
          system.clearRun(spawnerIntervals.get(oldIntervalKey));
          spawnerIntervals.delete(oldIntervalKey);
        }

        // 2. Clear the old spawner's floating text if it was enabled or if its intervalKey changed
        if (
          selectedConfig.showFloatingText ||
          oldIntervalKey !== newIntervalKey
        ) {
          clearSpecificFloatingText(oldIntervalKey);
        }

        // 3. Clear old particle visualization only if the position changes or particles are toggled off
        // Particle visualization is tied to spawnerKey (position), not intervalKey.
        // If the position changes, we need to clear the old particle visualization.
        // If particles were enabled and are now disabled, clear them.
        if (
          selectedConfig.showParticles &&
          (oldPosKey !== newPosKey || !newConfig.showParticles)
        ) {
          clearParticlesForPosition(oldPosKey);
        }

        // 4. Clear old teleportation interval only if the position changes or autoTeleport is toggled off
        // Teleportation is tied to spawnerKey (position).
        if (
          selectedConfig.autoTeleportMobs &&
          (oldPosKey !== newPosKey || !newConfig.autoTeleportMobs)
        ) {
          clearTeleportationForPosition(oldPosKey);
        }

        // Remove the old config from the list (this part remains the same)
        configList.splice(index, 1);
        if (configList.length === 0) {
          delete allData[key];
        } else {
          allData[key] = configList;
        }
        world.setDynamicProperty("mob_spawns", JSON.stringify(allData));
        player.sendMessage(
          `§e[Edit] Old spawner config removed. Enter new settings.`
        );
      },
      selectedConfig // Pass the old config to pre-fill the form
    );
  }
}

/**
 * Opens the UI to manage existing spawners.
 * @param {import("@minecraft/server").Player} player - The player to show the UI to.
 */
function openSpawnerManagerUI(player) {
  const allData = JSON.parse(world.getDynamicProperty("mob_spawns") ?? "{}");
  const keys = Object.keys(allData);
  if (keys.length === 0) return player.sendMessage("§cNo spawners found.");

  const form = new ActionFormData()
    .title("Spawner Manager")
    .body("§aSelect a spawner to manage:");

  const indexMap = []; // To map form selection index back to key and config index

  for (const key of keys) {
    const configList = Array.isArray(allData[key])
      ? allData[key]
      : [allData[key]]; // Ensure it's always a list
    configList.forEach((config, idx) => {
      const label = `§r[${config.name || "Unnamed"}§r]\n§2${key.replace(
        "spawner_",
        ""
      )} §r- §r${config.mobType}`;
      form.button(label);
      indexMap.push({ key, index: idx, config });
    });
  }

  form.show(player).then((res) => {
    if (res.canceled) return;

    const { key, index, config } = indexMap[res.selection];
    const [x, y, z] = key
      .replace("spawner_", "")
      .split("_")
      .map((n) => parseInt(n));
    const mobType = config.mobType;
    const pos = { x, y, z };
    const tagKey = key; // Tag used to identify mobs from this spawner

    let currentCount = 0;
    try {
      // Get mobs of the specified type within the spawner's effective radius that have its tag
      const mobs = world
        .getDimension("overworld")
        .getEntities({
          type: mobType, // Use raw mobType for custom IDs
          location: pos,
          maxDistance: mobConfig.chunkLoadRadius * 16,
        })
        .filter((e) => e.hasTag(tagKey));

      currentCount = mobs.length;
    } catch (err) {
      DebugLog(
        `[Manager] Error while counting mobs for ${mobType} at ${key}: ${err}`,
        true
      );
    }

    const maxCount = config.count ?? "N/A";

    const subForm = new ActionFormData()
      .title(`Spawner Info`)
      .body(
        `§bSpawner ID:§r ${key}
§bMob Type:§r ${mobType}
§bDisplay Name:§r ${config.name ?? "None"}
§bCount:§r ${currentCount}/${maxCount}
§bPosition:§r (§a${Math.floor(pos.x)} §c${Math.floor(pos.y)} §d${Math.floor(
          pos.z
        )}§r)`
      )
      .button("§9Teleport to Spawner")
      .button("§eEdit Spawner")
      .button("§cRemove Spawner")
      .button("§lBack to List");

    subForm.show(player).then((subRes) => {
      if (subRes.canceled) return;

      if (subRes.selection === 0) {
        // Teleport
        player.teleport(
          { x: pos.x + 0.5, y: pos.y + 1, z: pos.z + 0.5 },
          { facingLocation: pos }
        );
        player.sendMessage("§aTeleported to spawner.");
      } else if (subRes.selection === 1) {
        // Edit
        handleSpawnerAction(player, "edit", key, index);
      } else if (subRes.selection === 2) {
        // Remove
        handleSpawnerAction(player, "remove", key, index);
      } else if (subRes.selection === 3) {
        // Back
        openSpawnerManagerUI(player); // Reload the manager UI
      }
    });
  });
}

// === TOOL BLOCK INTERACTION ===
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const player = event.player;
  const item = event.itemStack;
  const block = event.block;

  // Only allow OPs to use this functionality
  if (!player.hasTag("admin") || !item || !block) return;
  // Check if the item used is the configured tool type
  if (item.typeId !== mobConfig.toolType) return;

  const playerId = player.id;
  const now = system.currentTick;

  // Check cooldown
  if (
    playerToolCooldowns.has(playerId) &&
    now - playerToolCooldowns.get(playerId) < COOLDOWN_TICKS
  ) {
    // Player is on cooldown, ignore this interaction
    event.cancel = true; // Cancel even if on cooldown to prevent default block interaction
    return;
  }

  // Set cooldown
  playerToolCooldowns.set(playerId, now);

  system.run(() => {
    // IMPORTANT: Placing event.cancel = true inside system.run() introduces a 1-tick delay.
    // This means the default block interaction might still occur for one tick before being cancelled.
    // The cooldown mechanism helps mitigate spamming the UI, but this delay for the block interaction itself remains.
    event.cancel = true; // Cancel the event to prevent default block interaction

    const loc = block.location; // Location of the interacted block

    if (!player.isSneaking) {
      // Single point mode (not sneaking)
      player.sendMessage("§a[Spawner] Configuring single-point spawner...");
      openAreaMobSettingsUI(player, loc, null);
    } else {
      // Area mode (sneaking)
      // Adjust Y-coordinate to be slightly above the block for spawning
      const adjustedLoc = { ...loc, y: loc.y + 1 };

      if (!areaSelectMap.has(playerId)) {
        // First click in area mode: set start position
        areaSelectMap.set(playerId, adjustedLoc);
        player.sendMessage(
          "§a[Spawner] Start position set. Select the end position."
        );
      } else {
        // Second click in area mode: set end position and define area
        const start = areaSelectMap.get(playerId);
        const end = adjustedLoc;
        areaSelectMap.delete(playerId); // Clear the stored start position
        player.sendMessage(
          "§a[Spawner] Area defined. Now configuring mob settings..."
        );
        openAreaMobSettingsUI(player, start, end);
      }
    }
  });
});

/**
 * Formats a position object into a readable string.
 * @param {import("@minecraft/server").Vector3} pos - The position object.
 * @returns {string} The formatted position string.
 */
const formatPos = (pos) => `${pos.x} ${pos.y} ${pos.z}`;

/**
 * Opens the main UI for configuring mob spawn settings (for point or area).
 * @param {import("@minecraft/server").Player} player - The player to show the UI to.
 * @param {import("@minecraft/server").Vector3} start - The start position of the spawn area (or single point).
 * @param {import("@minecraft/server").Vector3 | null} end - The end position of the spawn area, or null for single point.
 * @param {function(import("@minecraft/server").Vector3, object)} [onBeforeSave] - Callback executed before saving the new config (e.g., for editing). Passes the calculated savePos and the new config.
 * @param {object} [oldConfig] - Existing config data to pre-fill the form during editing.
 */
function openAreaMobSettingsUI(
  player,
  start,
  end,
  onBeforeSave = (newPos, newConfig) => {}, // Added newConfig parameter
  oldConfig = null
) {
  const getVal = (val, fallback = "") => (val != null ? String(val) : fallback);
  let areaText = "Single-point spawn mode";
  let areaHeader = "";
  if (end) {
    // Calculate area dimensions and volume for display
    const sizeX = Math.abs(end.x - start.x) + 1;
    const sizeY = Math.abs(end.y - start.y) + 1;
    const sizeZ = Math.abs(end.z - start.z) + 1;
    const volume = sizeX * sizeY * sizeZ;
    areaText = `§7Spawn Area: ${sizeX}×${sizeY}×${sizeZ} = §a${volume} blocks`;
    areaHeader = `§7From ${formatPos(start)} To ${formatPos(end)}`;
  }

  const form = new ModalFormData()
    .title(end ? "Area Mob Settings" : "Single Mob Settings")
    .textField(
      `${areaHeader}\n${areaText}\n\n§c* Mob Type (e.g. zombie, custom:my_mob)`,
      getVal(oldConfig?.mobType),
      {
        defaultValue: getVal(oldConfig?.mobType),
        placeholder: "zombie or custom:my_mob",
      }
    )
    .textField("§c* Max Mob Count", getVal(oldConfig?.count), {
      defaultValue: getVal(oldConfig?.count),
      placeholder: "1",
    })
    .textField("Mob Display Name (Optional)", getVal(oldConfig?.name), {
      defaultValue: getVal(oldConfig?.name),
      placeholder: "My Spawner Mob",
    })
    .textField("§c* Spawn Delay (seconds)", getVal(oldConfig?.delay), {
      defaultValue: getVal(oldConfig?.delay),
      placeholder: "10",
    })
    .toggle("Add Effects?", {
      defaultValue: !!oldConfig?.effects?.length,
    })
    .toggle("Add Equipment?", {
      defaultValue:
        !!oldConfig?.equipment?.mainhand ||
        !!oldConfig?.equipment?.offhand ||
        !!oldConfig?.equipment?.helmet ||
        !!oldConfig?.equipment?.chestplate ||
        !!oldConfig?.equipment?.leggings ||
        !!oldConfig?.equipment?.boots,
    })
    .toggle("Show Mob Count Floating Text", {
      defaultValue: oldConfig?.showFloatingText ?? false,
    })
    .toggle("Show Spawn Area Particles", {
      defaultValue: oldConfig?.showParticles ?? false,
    })
    .toggle("Auto-teleport Mobs to spawn area", {
      // New toggle for mob teleport
      defaultValue: oldConfig?.autoTeleportMobs ?? false,
    })
    .textField(
      "Mob Teleport Radius (blocks)",
      getVal(oldConfig?.teleportRadius),
      {
        // New text field for teleport radius
        defaultValue: getVal(oldConfig?.teleportRadius ?? 32), // Default to 32 blocks
        placeholder: "32",
      }
    );

  form.show(player).then((res) => {
    if (res.canceled) return;

    const [
      mobTypeRaw,
      countRaw,
      name,
      delayRaw,
      useEffect,
      useEquipment, // New toggle for equipment
      showFloatingText,
      showParticles,
      autoTeleportMobs, // New
      teleportRadiusRaw, // New
    ] = res.formValues;

    const mobType = mobTypeRaw.trim();
    const count = parseInt(countRaw);
    const delay = parseInt(delayRaw);
    const teleportRadius = parseInt(teleportRadiusRaw); // New

    if (!mobType) return player.sendMessage("§c[Error] Mob type is required.");
    if (isNaN(count) || count <= 0)
      return player.sendMessage("§c[Error] Max mob count must be > 0.");
    if (isNaN(delay) || delay <= 0)
      return player.sendMessage("§c[Error] Spawn delay must be > 0.");
    if (autoTeleportMobs && (isNaN(teleportRadius) || teleportRadius <= 0))
      // New validation
      return player.sendMessage(
        "§c[Error] Mob teleport radius must be > 0 if auto-teleport is enabled."
      );

    const baseConfig = {
      mobType,
      count,
      name: name?.trim() || "",
      delay,
      equipment: oldConfig?.equipment || { enchantments: {} }, // Keep old equipment if not using new form
      effects: oldConfig?.effects || [], // Keep old effects if not using new form
      isArea: !!end,
      areaStart: end ? start : undefined,
      areaEnd: end ? end : undefined,
      showFloatingText,
      floatingTextFormat:
        oldConfig?.floatingTextFormat ??
        "§l§b{name} Spawner\n§r§fCount: {count}/{maxCount}\n§r§7Time: {time}",
      floatingTextOffset: oldConfig?.floatingTextOffset ?? {
        x: 0.5,
        y: 1,
        z: 0.5,
      },
      showParticles,
      autoTeleportMobs, // New
      teleportRadius: autoTeleportMobs ? teleportRadius : undefined, // New
    };

    /**
     * Final saving logic.
     */
    const handleFinalSave = () => {
      const savePos = end ? getMiddlePos(start, end) : start;
      // Pass newConfig to onBeforeSave so it can compare old and new states for cleanup
      onBeforeSave(savePos, baseConfig);

      // Save the new config
      saveSpawnConfig(savePos, baseConfig);

      // Start the spawner with the new config
      startSpawnerAt(savePos, baseConfig);

      // If floating text is now disabled, ensure it's cleared for THIS specific config
      const newSpawnerPosKey = getPosKey(savePos);
      const newIntervalKey = `${newSpawnerPosKey}_${baseConfig.mobType}`;
      if (!baseConfig.showFloatingText) {
        clearSpecificFloatingText(newIntervalKey);
      }

      player.sendMessage(
        `§a[Spawner] Spawner created/updated for '${mobType}' at (${Math.floor(
          savePos.x
        )}, ${Math.floor(savePos.y)}, ${Math.floor(savePos.z)})`
      );
    };

    /**
     * Handles the floating text input forms.
     */
    const handleFloatingText = () => {
      if (!showFloatingText) {
        handleFinalSave(); // Skip floating text, proceed to final save
        return;
      }

      const floatingTextForm = new ModalFormData()
        .title("Floating Text Settings")
        .textField(
          "Floating Text Format (e.g.: {name}\\nCount: {count}/{maxCount}\\nTime: {time})",
          getVal(
            oldConfig?.floatingTextFormat ??
              "§l§b{name} Spawner\n§r§fCount: {count}/{maxCount}\n§r§7Time: {time}"
          ),
          {
            defaultValue: getVal(
              oldConfig?.floatingTextFormat ??
                "§l§b{name} Spawner\n§r§fCount: {count}/{maxCount}\n§r§7Time: {time}"
            ),
            placeholder:
              "Default: {name}\\nCount: {count}/{maxCount}\\nTime: {time}",
          }
        )
        .textField(
          "Floating Text Offset X (from spawner block center)",
          getVal(oldConfig?.floatingTextOffset?.x ?? 0.5),
          {
            defaultValue: getVal(oldConfig?.floatingTextOffset?.x ?? 0.5),
            placeholder: "0.5 (center)",
          }
        )
        .textField(
          "Floating Text Offset Y (from spawner block bottom)",
          getVal(oldConfig?.floatingTextOffset?.y ?? 1),
          {
            defaultValue: getVal(oldConfig?.floatingTextOffset?.y ?? 1),
            placeholder: "1 (above block)",
          }
        )
        .textField(
          "Floating Text Offset Z (from spawner block center)",
          getVal(oldConfig?.floatingTextOffset?.z ?? 0.5),
          {
            defaultValue: getVal(oldConfig?.floatingTextOffset?.z ?? 0.5),
            placeholder: "0.5 (center)",
          }
        );

      floatingTextForm.show(player).then((ftRes) => {
        if (ftRes.canceled) {
          handleFinalSave(); // If canceled, proceed to final save
          return;
        }

        const [
          floatingTextFormat,
          floatingTextOffsetXRaw,
          floatingTextOffsetYRaw,
          floatingTextOffsetZRaw,
        ] = ftRes.formValues;

        baseConfig.floatingTextFormat = floatingTextFormat?.trim();
        baseConfig.floatingTextOffset = {
          x: parseFloat(floatingTextOffsetXRaw) || 0.5,
          y: parseFloat(floatingTextOffsetYRaw) || 1,
          z: parseFloat(floatingTextOffsetZRaw) || 0.5,
        };
        handleFinalSave(); // After floating text, proceed to final save
      });
    };

    /**
     * Handles the equipment input forms.
     */
    const handleEquipment = () => {
      if (!useEquipment) {
        baseConfig.equipment = { enchantments: {} }; // Clear equipment if toggle is off
        handleFloatingText(); // Skip equipment, proceed to floating text
        return;
      }

      const equipmentForm = new ModalFormData()
        .title("Equipment Details")
        .textField(
          "Mainhand Item ID (Optional, e.g., diamond_sword)",
          getVal(oldConfig?.equipment?.mainhand),
          {
            defaultValue: getVal(oldConfig?.equipment?.mainhand),
            placeholder: "diamond_sword",
          }
        )
        .textField(
          "Offhand Item ID (Optional, e.g., shield)",
          getVal(oldConfig?.equipment?.offhand),
          {
            defaultValue: getVal(oldConfig?.equipment?.offhand),
            placeholder: "shield",
          }
        )
        .textField(
          "Helmet Item ID (Optional, e.g., diamond_helmet)",
          getVal(oldConfig?.equipment?.helmet),
          {
            defaultValue: getVal(oldConfig?.equipment?.helmet),
            placeholder: "diamond_helmet",
          }
        )
        .textField(
          "Chestplate Item ID (Optional)",
          getVal(oldConfig?.equipment?.chestplate),
          {
            defaultValue: getVal(oldConfig?.equipment?.chestplate),
            placeholder: "diamond_chestplate",
          }
        )
        .textField(
          "Leggings Item ID (Optional)",
          getVal(oldConfig?.equipment?.leggings),
          {
            defaultValue: getVal(oldConfig?.equipment?.leggings),
            placeholder: "diamond_leggings",
          }
        )
        .textField(
          "Boots Item ID (Optional)",
          getVal(oldConfig?.equipment?.boots),
          {
            defaultValue: getVal(oldConfig?.equipment?.boots),
            placeholder: "diamond_boots",
          }
        );

      equipmentForm.show(player).then((eqRes) => {
        if (eqRes.canceled) {
          handleFloatingText(); // If canceled, proceed to floating text
          return;
        }

        const [mainhand, offhand, helmet, chestplate, leggings, boots] =
          eqRes.formValues;

        baseConfig.equipment = {
          mainhand: mainhand?.trim() || "",
          offhand: offhand?.trim() || "",
          helmet: helmet?.trim() || "",
          chestplate: chestplate?.trim() || "",
          leggings: leggings?.trim() || "",
          boots: boots?.trim() || "",
          enchantments: {}, // Enchantment feature is removed
        };
        handleFloatingText(); // After equipment, proceed to floating text
      });
    };

    /**
     * Handles the effect input forms.
     */
    const handleEffects = () => {
      if (!useEffect) {
        baseConfig.effects = []; // Clear effects if toggle is off
        handleEquipment(); // Skip effects, proceed to equipment
        return;
      }

      const effCountForm = new ModalFormData()
        .title("Effects")
        .textField(
          "Number of Effects (max 64)",
          getVal(oldConfig?.effects?.length || "1"),
          {
            defaultValue: getVal(oldConfig?.effects?.length || "1"),
            placeholder: "1-5",
          }
        );

      effCountForm.show(player).then((effRes) => {
        if (effRes.canceled) {
          handleEquipment(); // If effects count form canceled, proceed to equipment
          return;
        }
        const n = parseInt(effRes.formValues[0]);
        if (isNaN(n) || n < 0 || n > 64) {
          player.sendMessage(
            "§c[Error] Effect count must be between 0 and 64."
          );
          handleEquipment(); // Invalid count, proceed to equipment
          return;
        }
        if (n === 0) {
          baseConfig.effects = []; // No effects requested
          handleEquipment();
          return;
        }

        const effForm = new ModalFormData().title("Effect Details");

        for (let i = 0; i < n; i++) {
          const eff = oldConfig?.effects?.[i];
          effForm.textField(
            `Effect ID #${i + 1} (e.g. minecraft:speed)`,
            getVal(eff?.name),
            {
              defaultValue: getVal(eff?.name),
              placeholder: "minecraft:speed",
            }
          );
          effForm.textField(`Level #${i + 1} (e.g. 1)`, getVal(eff?.level), {
            defaultValue: getVal(eff?.level),
            placeholder: "1",
          });
        }

        effForm.show(player).then((listRes) => {
          if (listRes.canceled) {
            handleEquipment(); // If effect details form canceled, proceed to equipment
            return;
          }
          const effects = [];
          for (let i = 0; i < listRes.formValues.length; i += 2) {
            const effectName = listRes.formValues[i]?.trim();
            const level = parseInt(listRes.formValues[i + 1]) || 1; // Default level to 1 if not parsed
            if (effectName) {
              effects.push({ name: effectName, level });
            }
          }
          baseConfig.effects = effects;
          handleEquipment(); // After effects, proceed to equipment
        });
      });
    };

    handleEffects(); // Start the flow with effects, which will then call equipment, then floating text, then final save
  });
}

/**
 * Calculates the middle position between two points.
 * Used for storing area spawners at a single coordinate.
 * @param {import("@minecraft/server").Vector3} pos1 - First position.
 * @param {import("@minecraft/server").Vector3} pos2 - Second position.
 * @returns {import("@minecraft/server").Vector3} The middle position.
 */
function getMiddlePos(pos1, pos2) {
  return {
    x: Math.floor((pos1.x + pos2.x) / 2),
    y: Math.floor((pos1.y + pos2.y) / 2),
    z: Math.floor((pos1.z + pos2.z) / 2),
  };
}

/**
 * Generates a random integer between two numbers (inclusive).
 * @param {number} a - First number.
 * @param {number} b - Second number.
 * @returns {number} A random integer.
 */
function getRand(a, b) {
  const min = Math.min(a, b);
  const max = Math.max(a, b);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Finds a random air block position within a given area for spawning.
 * Tries up to 50 times to find a suitable spot (air block with air block above it).
 * @param {import("@minecraft/server").Vector3} start - The start corner of the area.
 * @param {import("@minecraft/server").Vector3} end - The end corner of the area.
 * @returns {import("@minecraft/server").Vector3 | null} A suitable spawn position or null if none found.
 */
function getRandomAirPositionInArea(start, end) {
  const dim = world.getDimension("overworld");

  for (let i = 0; i < 50; i++) {
    const x = getRand(start.x, end.x);
    const y = getRand(start.y, end.y);
    const z = getRand(start.z, end.z);

    try {
      const block = dim.getBlock({ x, y, z });
      const above = dim.getBlock({ x, y: y + 1, z });

      // If block or above is null, it means the chunk is not loaded or the block does not exist
      // within the currently loaded range. Log and continue to the next random position.
      if (!block || !above) {
        DebugLog(
          `§c[Debug] Block data at (${x}, ${y}, ${z}) or (${x}, ${
            y + 1
          }, ${z}) unavailable. Possibly unloaded chunk.`,
          true
        );
        continue; // Try next random position
      }

      if (
        block.typeId === "minecraft:air" &&
        above.typeId === "minecraft:air"
      ) {
        return { x: x + 0.5, y: y, z: z + 0.5 }; // Return center of block
      }
    } catch (e) {
      // This catch block handles ArgumentOutOfBoundsError thrown directly by getBlock
      // It means the coordinates are genuinely out of bounds for access (e.g., edge of an unloaded chunk).
      DebugLog(
        `§c[Debug] Error accessing block at (${x}, ${y}, ${z}): ${e.message}`,
        true
      );
      // The loop will continue to the next iteration to find another random spot.
    }
  }
  DebugLog(
    `§c[Debug] No valid air block found in area after 50 attempts or all attempts hit unloaded chunks.`,
    true
  );
  return null;
}

/**
 * Generates a unique key for a position to store spawner data.
 * @param {import("@minecraft/server").Vector3} pos - The position.
 * @returns {string} The unique key.
 */
function getPosKey(pos) {
  return `spawner_${Math.floor(pos.x)}_${Math.floor(pos.y)}_${Math.floor(
    pos.z
  )}`;
}

/**
 * Saves a new mob spawner configuration to world dynamic properties.
 * It stores configurations as a list at each position, allowing multiple spawners per block.
 * @param {import("@minecraft/server").Vector3} pos - The central position for the spawner.
 * @param {object} data - The spawner configuration data.
 */
function saveSpawnConfig(pos, data) {
  const key = getPosKey(pos);
  const allData = JSON.parse(world.getDynamicProperty("mob_spawns") ?? "{}");

  // Ensure it's an array before pushing
  if (!allData[key]) {
    allData[key] = [];
  } else if (!Array.isArray(allData[key])) {
    // Convert old single object to array for backward compatibility
    allData[key] = [allData[key]];
  }
  allData[key].push(data); // Add the new config to the list
  world.setDynamicProperty("mob_spawns", JSON.stringify(allData));
}

/**
 * Starts all spawners defined in a list for a specific position.
 * @param {import("@minecraft/server").Vector3} pos - The central position for the spawners.
 * @param {Array<object>} configList - A list of spawner configurations.
 */
function startSpawnerListAt(pos, configList) {
  for (const config of configList) {
    startSpawnerAt(pos, config);
  }
}

/**
 * Starts an individual mob spawner based on its configuration.
 * @param {import("@minecraft/server").Vector3} pos - The central position of the spawner.
 * @param {object} config - The spawner configuration.
 */
function startSpawnerAt(pos, config) {
  const {
    mobType,
    count,
    name,
    delay,
    effects,
    equipment,
    isArea,
    areaStart,
    areaEnd,
    showFloatingText, // New
    showParticles, // New
    floatingTextOffset, // New
    floatingTextFormat = "§l§b{name} Spawner\n§r§fCount: {count}/{maxCount}\n§r§7Time: {time}", // Added default here
    autoTeleportMobs, // New
    teleportRadius, // New
  } = config;
  const spawnerPosKey = getPosKey(pos); // Tag to identify mobs from this spawner
  const intervalKey = `${spawnerPosKey}_${mobType}`; // Unique key for this specific spawner's interval

  // Clear any existing interval for this spawner before starting a new one
  if (spawnerIntervals.has(intervalKey)) {
    system.clearRun(spawnerIntervals.get(intervalKey));
    spawnerIntervals.delete(intervalKey);
  }

  // Start particle visualization if enabled and it's an area spawner
  // Particle visualization is position-based, not specific config-based
  if (isArea && showParticles) {
    startParticleVisualization(
      spawnerPosKey, // Use spawnerPosKey here
      world.getDimension("overworld"),
      areaStart,
      areaEnd
    );
  } else if (!isArea && showParticles) {
    // For point spawners, if particles are enabled
    // You might want a different particle visualization for point spawners
    // For now, it will just not show particles if not an area.
    // If you want point particles, you'd add a separate function for that.
  }

  // Start mob teleportation if enabled
  // Mob teleportation is position-based, not specific config-based
  if (autoTeleportMobs && teleportRadius !== undefined) {
    startMobTeleportation(
      spawnerPosKey,
      pos,
      mobType,
      isArea,
      areaStart,
      areaEnd,
      teleportRadius
    );
  }

  // Set up the recurring interval for spawning
  const intervalId = system.runInterval(() => {
    const playersNearby = world.getPlayers().some((player) => {
      // Calculate squared distance for efficiency
      const dx = player.location.x - pos.x;
      const dy = player.location.y - pos.y;
      const dz = player.location.z - pos.z;
      return dx * dx + dy * dy + dz * dz <= mobConfig.playerNearbyDistance ** 2;
    });

    // Only spawn if a player is within the configured nearby distance
    if (!playersNearby) return;

    const dimension = world.getDimension("overworld");
    // Count existing mobs of this type originating from this spawner
    const nearby = dimension
      .getEntities({
        type: mobType, // Use the raw mobType for custom IDs
        location: pos,
        maxDistance: mobConfig.chunkLoadRadius * 16, // Use chunkLoadRadius for entity proximity check
      })
      .filter((e) => e.hasTag(spawnerPosKey)); // Filter by spawner's unique tag

    const currentMobCount = nearby.length; // Get current count before potential spawn

    // If current mob count meets or exceeds the max count, do not spawn
    if (currentMobCount >= count) return;

    // Determine spawn position based on whether it's an area or single point
    const spawnPos = isArea
      ? getRandomAirPositionInArea(areaStart, areaEnd)
      : { x: pos.x + 0.5, y: pos.y + 1, z: pos.z + 0.5 };
    if (!spawnPos) {
      DebugLog(
        `§c[Spawner Error] Could not find valid spawn position for ${mobType} at ${spawnerPosKey}`,
        true
      );
      return;
    }

    let mob;
    try {
      // Spawn the entity using the provided mobType (supports custom IDs)
      mob = dimension.spawnEntity(mobType, spawnPos);
      if (name) {
        mob.nameTag = name; // Set custom nameTag if provided
      }
      mob.addTag(spawnerPosKey); // Add the unique spawner tag to the mob

      // Log successful spawn
      DebugLog(
        `§7[Spawner] §aSpawned §7[§b${mobType}§7]§r ${
          name || "null"
        }§r at §c(${Math.floor(spawnPos.x)}, ${Math.floor(
          spawnPos.y
        )}, ${Math.floor(spawnPos.z)}) §r- §d${currentMobCount + 1}/${count}` // Updated count
      );
    } catch (err) {
      // Log errors during mob spawning
      DebugLog(
        `§c[Spawner Error] Failed to spawn mob with ID: ${mobType} at (${Math.floor(
          spawnPos.x
        )}, ${Math.floor(spawnPos.y)}, ${Math.floor(spawnPos.z)}): ${
          err.message
        }`,
        true
      );
      // Notify OPs in-game about the spawning error, with a tickingarea suggestion
      for (const player of world.getPlayers()) {
        if (player.hasTag("admin")) {
          // Changed to 'admin' tag
          player.sendMessage(
            `§c[Spawner Error] Failed to spawn mob with ID: ${mobType}. Error: ${err.message}. §eThis may be due to unloaded chunks. Please try using '/tickingarea add circle ~~~ 4' at the spawner location to keep chunks active.`
          );
        }
      }
      return; // Stop if mob creation failed
    }

    try {
      const { mainhand, offhand, helmet, chestplate, leggings, boots } =
        equipment;

      // Apply equipment if item ID is provided and not empty
      const replaceItem = (slot, item) => {
        if (item) {
          mob.runCommand(`replaceitem entity @s ${slot} 0 ${item}`);
          DebugLog(
            `§7[Spawner] Equipped ${item} in ${slot} for ${mob.nameTag}`
          );
        }
      };

      replaceItem("slot.weapon.mainhand", mainhand);
      replaceItem("slot.weapon.offhand", offhand);
      replaceItem("slot.armor.head", helmet);
      replaceItem("slot.armor.chest", chestplate);
      replaceItem("slot.armor.legs", leggings);
      replaceItem("slot.armor.feet", boots);

      // Apply effects
      for (const eff of effects || []) {
        // Ensure effects is an array
        mob.runCommand(`effect @s ${eff.name} 999999 ${eff.level - 1} true`);
        DebugLog(
          `§7[Spawner] Applied effect ${eff.name}:${eff.level} to ${mob.nameTag}`
        );
      }

      // New: Set mob to its maximum health AFTER effects have been applied
      if (mob.hasComponent("health")) {
        const healthComp = mob.getComponent("health");
        healthComp.setCurrentValue(healthComp.effectiveMax); // Set current health to max health
        DebugLog(
          `§7[Spawner] Set ${mobType} (${mob.nameTag}) to full health (${healthComp.effectiveMax}) after effects.`
        );
      }
    } catch (e) {
      DebugLog(
        `§c[Spawner Error] Error while applying effects/equipment to ${mob.name}: ${e.message}`,
        true
      );
    }
  }, delay * 20); // Delay in game ticks (20 ticks = 1 second)

  spawnerIntervals.set(intervalKey, intervalId); // Store interval ID to clear later

  // Start floating text update interval
  if (showFloatingText) {
    startFloatingTextUpdate(
      intervalKey, // Pass intervalKey here
      pos,
      mobType,
      count,
      floatingTextOffset,
      name,
      floatingTextFormat,
      delay
    );
  } else {
    // If showFloatingText is false, ensure the floating text is despawned
    clearSpecificFloatingText(intervalKey); // Clear specific floating text
  }
}

/**
 * Starts an interval to update the floating text for a spawner.
 * @param {string} intervalKey - The unique key of the spawner configuration (spawnerKey_mobType).
 * @param {import("@minecraft/server").Vector3} pos - The central position of the spawner.
 * @param {string} mobType - The type of mob.
 * @param {number} maxCount - Max allowed mob count.
 * @param {object} floatingTextOffset - {x, y, z} offsets for the text entity.
 * @param {string} spawnerName - The display name of the spawner.
 * @param {string} floatingTextFormat - The custom format string for the floating text.
 * @param {number} spawnDelay - The spawn delay in seconds.
 */
function startFloatingTextUpdate(
  intervalKey, // Changed from spawnerKey
  pos,
  mobType,
  maxCount,
  floatingTextOffset,
  spawnerName,
  floatingTextFormat,
  spawnDelay
) {
  // Clear any existing interval for this spawner's floating text
  if (floatingTextUpdateIntervals.has(intervalKey)) {
    system.clearRun(floatingTextUpdateIntervals.get(intervalKey));
    floatingTextUpdateIntervals.delete(intervalKey);
  }

  // Store the last tick a spawn occurred for this spawner
  let lastSpawnTick = system.currentTick;

  const intervalId = system.runInterval(() => {
    let textEntity = null;
    let foundInDimension = false;

    // Iterate through all dimensions to find the entity
    for (const dimensionName of ["overworld", "nether", "the_end"]) {
      try {
        const dimension = world.getDimension(dimensionName);
        if (!dimension) {
          DebugLog(
            `§c[Floating Text] Warning: Dimension '${dimensionName}' not found or not loaded for spawner ${intervalKey}. Skipping this dimension.`,
            true
          );
          continue;
        }

        // Use getEntities to find the armor stand by its dynamic property and type
        const entitiesInDimension = dimension.getEntities({
          type: FloatingTextID,
          // You can add a location filter here if you want to limit the search radius
          // location: pos,
          // maxDistance: 64, // Example: search within 64 blocks
        });

        for (const entity of entitiesInDimension) {
          // Check for the specific intervalKey
          if (
            entity.getDynamicProperty("spawner_interval_key") === intervalKey &&
            entity.isValid
          ) {
            textEntity = entity;
            foundInDimension = true;
            break; // Found it, exit inner loop
          }
        }
      } catch (e) {
        DebugLog(
          `§c[Floating Text] Error searching dimension '${dimensionName}' for spawner ${intervalKey}: ${e.message}`,
          true
        );
      }
      if (foundInDimension) break; // Found it, exit outer loop
    }

    if (!textEntity) {
      // If entity doesn't exist or was invalid, create a new one
      textEntity = createFloatingTextEntity(
        intervalKey, // Pass intervalKey here
        pos,
        floatingTextOffset
      );
      // IMPORTANT: Do NOT stop the interval if creation fails due to chunk unload.
      // Let it continue to retry on the next tick.
      if (!textEntity) {
        return; // Just return, interval continues
      }
    } else {
      // If entity exists, teleport it to the correct position in case spawner was moved
      const targetLoc = {
        x: pos.x + floatingTextOffset.x,
        y: pos.y + floatingTextOffset.y,
        z: pos.z + floatingTextOffset.z,
      };
      if (
        textEntity.location.x !== targetLoc.x ||
        textEntity.location.y !== targetLoc.y ||
        textEntity.location.z !== targetLoc.z
      ) {
        try {
          textEntity.teleport(targetLoc, { dimension: textEntity.dimension });
          DebugLog(
            `§a[Floating Text] Teleported text display for ${intervalKey} to new position.`
          );
        } catch (e) {
          DebugLog(
            `§c[Floating Text] Failed to teleport text entity for ${intervalKey}: ${e.message}`,
            true
          );
        }
      }
    }

    // After ensuring textEntity exists (either found or newly created), update its nameTag
    if (textEntity && textEntity.isValid) {
      // Get dimension from the entity itself to ensure it's valid for counting mobs
      const dimension = textEntity.dimension;
      if (!dimension) {
        DebugLog(
          `§c[Floating Text] Warning: Dimension of textEntity for ${intervalKey} became invalid during update. Skipping nameTag update. Will retry next tick.`,
          true
        );
        spawnerTextEntities.delete(intervalKey); // Force re-creation next tick
        return;
      }

      // Count existing mobs of this type originating from this spawner
      const currentMobCount = dimension
        .getEntities({
          type: mobType,
          location: pos,
          maxDistance: mobConfig.chunkLoadRadius * 16,
        })
        .filter((e) => e.hasTag(getPosKey(pos))).length; // Use spawnerPosKey for mob tagging

      let timeRemainingSeconds;

      // Calculate time remaining based on the spawn delay and current tick
      const spawnerIntervalTicks = spawnDelay * 20;
      const ticksSinceLastSpawn =
        (system.currentTick - lastSpawnTick) % spawnerIntervalTicks;
      timeRemainingSeconds = Math.max(
        0,
        spawnDelay - Math.floor(ticksSinceLastSpawn / 20)
      );

      // If current mob count is at or above maxCount, override time to 0
      if (currentMobCount >= maxCount) {
        timeRemainingSeconds = 0;
      } else if (ticksSinceLastSpawn === 0 && system.currentTick !== 0) {
        // If it's exactly the start of a new cycle (and not initial load), reset lastSpawnTick
        lastSpawnTick = system.currentTick;
        timeRemainingSeconds = spawnDelay;
      }

      // Format the text using the custom format string
      let formattedText = floatingTextFormat;
      formattedText = formattedText.replace(
        /{name}/g,
        spawnerName || "Unnamed Spawner"
      );
      formattedText = formattedText.replace(/{id}/g, mobType);
      formattedText = formattedText.replace(
        /{count}/g,
        currentMobCount.toString()
      );
      formattedText = formattedText.replace(/{maxCount}/g, maxCount.toString());
      formattedText = formattedText.replace(
        /{time}/g,
        timeRemainingSeconds.toString()
      );
      formattedText = formattedText.replace(/\\n/g, "\n"); // Replace literal \n with newline character

      textEntity.nameTag = formattedText;
    } else {
      DebugLog(
        `§c[Floating Text] Warning: textEntity for ${intervalKey} became invalid before nameTag update. Will attempt re-creation next tick.`,
        true
      );
      // Force re-creation on next tick by deleting the stored ID
      spawnerTextEntities.delete(intervalKey);
    }
  }, 20); // Update every 1 second (20 ticks)

  floatingTextUpdateIntervals.set(intervalKey, intervalId);
  DebugLog(`§a[Floating Text] Started update interval for ${intervalKey}`);
}

/**
 * Creates a floating text armor stand entity.
 * @param {string} intervalKey - The unique key of the spawner configuration.
 * @param {import("@minecraft/server").Vector3} pos - The central position of the spawner.
 * @param {object} floatingTextOffset - {x, y, z} offsets for the text entity.
 * @returns {import("@minecraft/server").Entity | null} The armor stand entity, or null if creation failed.
 */
function createFloatingTextEntity(
  intervalKey, // Changed from spawnerKey
  pos,
  floatingTextOffset
) {
  const dimension = world.getDimension("overworld");
  if (!dimension) {
    DebugLog(
      `§c[Floating Text] Error: Dimension 'overworld' not found or not loaded. Cannot create text entity for ${intervalKey}.`,
      true
    );
    return null;
  }

  let textEntity = null;

  try {
    const spawnLoc = {
      x: pos.x + floatingTextOffset.x,
      y: pos.y + floatingTextOffset.y,
      z: pos.z + floatingTextOffset.z,
    };
    textEntity = dimension.spawnEntity(FloatingTextID, spawnLoc); // Use FloatingTextID here
    textEntity.setDynamicProperty("spawner_interval_key", intervalKey); // Store the intervalKey
    spawnerTextEntities.set(intervalKey, textEntity.id);

    // Commented out invisibility and data merge commands as requested
    // textEntity.runCommand("effect @s invisibility 999999 0 true"); // Make it invisible
    // system.run(() => { // Run in next tick to ensure entity is fully initialized for data merge
    //     if (textEntity && textEntity.isValid) {
    //         textEntity.runCommand("data merge entity @s {NoGravity:1b,Small:1b}"); // Set no gravity and small
    //         DebugLog(`§a[Floating Text] Applied NBT data (NoGravity, Small) to new armor_stand for ${intervalKey}`);
    //     } else {
    //         DebugLog(`§c[Floating Text] Failed to apply NBT data: new armor_stand for ${intervalKey} is invalid.`, true);
    //     }
    // });

    textEntity.runCommand("tag @s add spawner_floating_text"); // Add a tag for easier identification

    DebugLog(
      `§a[Floating Text] Created new armor_stand text display for ${intervalKey} with ID: ${textEntity.id}`
    );
    return textEntity; // Return the newly created entity
  } catch (e) {
    DebugLog(
      `§c[Floating Text] Failed to create armor_stand text display for ${intervalKey}: ${e.message}`,
      false
    );
    return null; // Return null on failure
  }
}

/**
 * Starts particle visualization for an area spawner.
 * @param {string} spawnerKey - The unique key of the spawner (position).
 * @param {import("@minecraft/server").Dimension} dimension - The dimension.
 * @param {import("@minecraft/server").Vector3} areaStart - The start corner of the area.
 * @param {import("@minecraft/server").Vector3} areaEnd - The end corner of the area.
 */
function startParticleVisualization(spawnerKey, dimension, areaStart, areaEnd) {
  // Clear any existing particle interval for this spawner (position-based)
  if (spawnerParticleIntervals.has(spawnerKey)) {
    system.clearRun(spawnerParticleIntervals.get(spawnerKey));
    spawnerParticleIntervals.delete(spawnerKey);
  }

  const particleIntervalId = system.runInterval(() => {
    const minX = Math.min(areaStart.x, areaEnd.x);
    const minY = Math.min(areaStart.y, areaEnd.y);
    const minZ = Math.min(areaStart.z, areaEnd.z);
    const maxX = Math.max(areaStart.x, areaEnd.x);
    const maxY = Math.max(areaStart.y, areaEnd.y);
    const maxZ = Math.max(areaStart.z, areaEnd.z);

    const particleId = "minecraft:endrod";
    const particleOffset = 0.5; // Center particles on block edge

    // Draw edges of the bounding box
    // Edges parallel to X-axis
    for (let x = minX; x <= maxX; x++) {
      // Chunk check is a best-effort; direct API limitations mean it might still fail if chunk unloads mid-loop.
      // The try-catch around getBlock is the primary way to handle unloaded chunks.
      try {
        dimension.getBlock({ x, y: minY, z: minZ }); // Attempt to get a block in the chunk to check if loaded
        dimension.spawnParticle(particleId, {
          x: x + particleOffset,
          y: minY + particleOffset,
          z: minZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: x + particleOffset,
          y: minY + particleOffset,
          z: maxZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: x + particleOffset,
          y: maxY + particleOffset,
          z: minZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: x + particleOffset,
          y: maxY + particleOffset,
          z: maxZ + particleOffset,
        });
      } catch (e) {
        // Chunk likely unloaded, particles won't show anyway. Log for debug.
        // DebugLog(`§e[Particles] Skipping particle spawn due to unloaded chunk at X:${x}, Y:${minY}, Z:${minZ}`);
      }
    }
    // Edges parallel to Y-axis
    for (let y = minY; y <= maxY; y++) {
      try {
        dimension.getBlock({ x: minX, y, z: minZ });
        dimension.spawnParticle(particleId, {
          x: minX + particleOffset,
          y: y + particleOffset,
          z: minZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: minX + particleOffset,
          y: y + particleOffset,
          z: maxZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: maxX + particleOffset,
          y: y + particleOffset,
          z: minZ + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: maxX + particleOffset,
          y: y + particleOffset,
          z: maxZ + particleOffset,
        });
      } catch (e) {
        /* silent fail */
      }
    }
    // Edges parallel to Z-axis
    for (let z = minZ; z <= maxZ; z++) {
      try {
        dimension.getBlock({ x: minX, y: minY, z });
        dimension.spawnParticle(particleId, {
          x: minX + particleOffset,
          y: minY + particleOffset,
          z: z + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: minX + particleOffset,
          y: maxY + particleOffset,
          z: z + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: maxX + particleOffset,
          y: minY + particleOffset,
          z: z + particleOffset,
        });
        dimension.spawnParticle(particleId, {
          x: maxX + particleOffset,
          y: maxY + particleOffset,
          z: z + particleOffset,
        });
      } catch (e) {
        /* silent fail */
      }
    }
  }, 10); // Spawn particles every 0.5 seconds (10 ticks)

  spawnerParticleIntervals.set(spawnerKey, particleIntervalId);
  DebugLog(`§a[Particles] Started particle visualization for ${spawnerKey}`);
}

/**
 * Starts automatic mob teleportation back to the spawn area.
 * @param {string} spawnerKey - The unique key of the spawner (position).
 * @param {import("@minecraft/server").Vector3} spawnerPos - The central position of the spawner.
 * @param {string} mobType - The type of mob (used for filtering mobs, but teleportation is position-based).
 * @param {boolean} isArea - True if it's an area spawner, false if single point.
 * @param {import("@minecraft/server").Vector3 | undefined} areaStart - The start position of the area (if area spawner).
 * @param {import("@minecraft/server").Vector3 | undefined} areaEnd - The end position of the area (if area spawner).
 * @param {number} teleportRadius - The radius for teleportation.
 */
function startMobTeleportation(
  spawnerKey,
  spawnerPos,
  mobType,
  isArea,
  areaStart,
  areaEnd,
  teleportRadius
) {
  const dimension = world.getDimension("overworld"); // Mobs will be teleported in this dimension

  // Clear any existing mob teleportation interval for this spawner (position-based)
  const teleportIntervalKey = `teleport_${spawnerKey}`;
  if (spawnerIntervals.has(teleportIntervalKey)) {
    system.clearRun(spawnerIntervals.get(teleportIntervalKey));
    spawnerIntervals.delete(teleportIntervalKey);
  }

  const intervalId = system.runInterval(() => {
    const mobs = dimension
      .getEntities({
        type: mobType, // Filter by mob type
        location: spawnerPos,
        maxDistance: teleportRadius + 100, // Search a bit further than the teleport radius
      })
      .filter((e) => e.hasTag(spawnerKey)); // Only mobs from this spawner position

    for (const mob of mobs) {
      const mobLoc = mob.location;
      let shouldTeleport = false;

      if (isArea) {
        // For area spawner, check if the mob is outside the radius from the area perimeter
        const minX = Math.min(areaStart.x, areaEnd.x);
        const minY = Math.min(areaStart.y, areaEnd.y);
        const minZ = Math.min(areaStart.z, areaEnd.z);
        const maxX = Math.max(areaStart.x, areaEnd.x);
        const maxY = Math.max(areaStart.y, areaEnd.y);
        const maxZ = Math.max(areaStart.z, areaEnd.z);

        // Check if the mob is outside the bounding box + teleportRadius
        if (
          mobLoc.x < minX - teleportRadius ||
          mobLoc.x > maxX + teleportRadius ||
          mobLoc.y < minY - teleportRadius ||
          mobLoc.y > maxY + teleportRadius ||
          mobLoc.z < minZ - teleportRadius ||
          mobLoc.z > maxZ + teleportRadius
        ) {
          shouldTeleport = true;
        }
      } else {
        // For point spawner, check if the mob is outside the radius from the spawn point
        const dx = mobLoc.x - spawnerPos.x;
        const dy = mobLoc.y - spawnerPos.y;
        const dz = mobLoc.z - spawnerPos.z;
        const distanceSquared = dx * dx + dy * dy + dz * dz;
        if (distanceSquared > teleportRadius * teleportRadius) {
          shouldTeleport = true;
        }
      }

      if (shouldTeleport) {
        // Teleport the mob to a random position within the spawn area or near the spawn point
        let targetTeleportPos;
        if (isArea) {
          targetTeleportPos = getRandomAirPositionInArea(areaStart, areaEnd);
        } else {
          // For point spawn, teleport to a random position near the spawn point
          targetTeleportPos = {
            x: spawnerPos.x + (Math.random() - 0.5) * 2, // +/- 1 block
            y: spawnerPos.y + 1,
            z: spawnerPos.z + (Math.random() - 0.5) * 2,
          };
        }

        if (targetTeleportPos) {
          try {
            mob.teleport(targetTeleportPos, { dimension: dimension });
            DebugLog(
              `§a[Mob Teleportation] Teleported mob ${mob.nameTag} back to spawner area of ${spawnerKey}.`
            );
          } catch (e) {
            DebugLog(
              `§c[Mob Teleportation] Failed to teleport mob ${mob.nameTag}: ${e.message}`,
              true
            );
          }
        } else {
          DebugLog(
            `§c[Mob Teleportation] Could not find valid teleport position for mob ${mob.nameTag} from spawner ${spawnerKey}.`,
            true
          );
        }
      }
    }
  }, 20 * 5); // Check every 5 seconds (100 ticks)

  spawnerIntervals.set(teleportIntervalKey, intervalId);
  DebugLog(
    `§a[Mob Teleportation] Started mob teleportation interval for ${spawnerKey}`
  );
}

/**
 * Clears the floating text and its update interval for a specific spawner configuration.
 * @param {string} intervalKey - The unique key of the spawner configuration (spawnerKey_mobType).
 */
function clearSpecificFloatingText(intervalKey) {
  // Clear floating text update interval
  if (floatingTextUpdateIntervals.has(intervalKey)) {
    system.clearRun(floatingTextUpdateIntervals.get(intervalKey));
    floatingTextUpdateIntervals.delete(intervalKey);
    DebugLog(`§a[Floating Text] Stopped update interval for ${intervalKey}`);
  }

  // Clear floating text entity
  if (spawnerTextEntities.has(intervalKey)) {
    let despawned = false;
    const textEntityId = spawnerTextEntities.get(intervalKey);
    for (const dimensionName of ["overworld", "nether", "the_end"]) {
      try {
        const dimension = world.getDimension(dimensionName);
        if (!dimension) continue;
        const entitiesInDimension = dimension.getEntities({
          type: FloatingTextID,
          // Consider adding a location filter here if performance is an issue
        });
        for (const entity of entitiesInDimension) {
          if (
            entity &&
            entity.getDynamicProperty("spawner_interval_key") === intervalKey
          ) {
            entity.runCommand(`event entity @s despawn`);
            DebugLog(
              `§a[Floating Text] Despawned text display for ${intervalKey} in ${dimensionName}.`
            );
            despawned = true;
            break;
          }
        }
      } catch (e) {
        DebugLog(
          `§c[Floating Text] Error despawning text entity for ${intervalKey} in ${dimensionName}: ${e.message}`,
          true
        );
      }
      if (despawned) break;
    }

    if (!despawned) {
      DebugLog(
        `§e[Floating Text] Text entity for ${intervalKey} not found or mismatched ID/type during despawn attempt.`,
        true
      );
    }

    spawnerTextEntities.delete(intervalKey);
  }
}

/**
 * Clears the particle visualization interval for a given spawner position key.
 * @param {string} spawnerKey - The unique key of the spawner (position).
 */
function clearParticlesForPosition(spawnerKey) {
  if (spawnerParticleIntervals.has(spawnerKey)) {
    system.clearRun(spawnerParticleIntervals.get(spawnerKey));
    spawnerParticleIntervals.delete(spawnerKey);
    DebugLog(`§a[Particles] Stopped particle visualization for ${spawnerKey}`);
  }
}

/**
 * Clears the mob teleportation interval for a given spawner position key.
 * @param {string} spawnerKey - The unique key of the spawner (position).
 */
function clearTeleportationForPosition(spawnerKey) {
  const teleportIntervalKey = `teleport_${spawnerKey}`;
  if (spawnerIntervals.has(teleportIntervalKey)) {
    system.clearRun(spawnerIntervals.get(teleportIntervalKey));
    spawnerIntervals.delete(teleportIntervalKey);
    DebugLog(
      `§a[Mob Teleportation] Stopped teleportation interval for ${spawnerKey}`
    );
  }
}

/**
 * Clears all visuals (floating texts, particles, teleportation) associated with a spawner position.
 * This is typically called when a spawner position is entirely removed.
 * @param {string} spawnerKey - The unique key of the spawner position.
 */
function clearAllVisualsAtPosition(spawnerKey) {
  // Clear all floating texts associated with this spawner position
  const allData = JSON.parse(world.getDynamicProperty("mob_spawns") ?? "{}");
  const configsAtPos = Array.isArray(allData[spawnerKey])
    ? allData[spawnerKey]
    : allData[spawnerKey]
    ? [allData[spawnerKey]]
    : [];

  // Iterate through all configs that *were* at this position (even if they've just been removed from data)
  // We need to try to clear any floating text entities that might still exist for them.
  for (const config of configsAtPos) {
    // Construct the intervalKey based on the config's mobType
    const intervalKey = `${spawnerKey}_${config.mobType}`;
    clearSpecificFloatingText(intervalKey);
  }

  // Clear particle visualization for this position
  clearParticlesForPosition(spawnerKey);

  // Clear mob teleportation for this position
  clearTeleportationForPosition(spawnerKey);
}

/**
 * Adds a message to the debug log.
 * @param {string} message - The message to log.
 * @param {boolean} isError - True if this is an error message, to also log to console.warn.
 */
function DebugLog(message, isError = false) {
  const time = new Date().toLocaleTimeString();
  const formatted = `§r[${time}] ${message}\n`;
  debugLogs.push(formatted);

  if (isError) {
    console.warn(formatted); // Also log errors to console.warn
  }

  // Keep log size manageable
  if (debugLogs.length > 10000) {
    debugLogs.shift(); // Remove oldest log entry
  }
}

/**
 * Opens the debug log UI for a player.
 * @param {import("@minecraft/server").Player} player - The player to show the UI to.
 */
function openDebugLogForm(player) {
  const form = new ActionFormData().title("Debug Logs");

  if (debugLogs.length === 0) {
    form.body("§7(No logs available)");
  } else {
    // Display only the last 10 log entries for readability
    const logText = debugLogs.slice(-10).join("\n");
    form.body("§bRecent Logs:\n§f" + logText);
  }

  form.button("Clear Log");
  form.button("Refresh Log");
  form.button("Close");

  form.show(player).then((res) => {
    if (res.selection == 0) {
      debugLogs.length = 0; // Clear the array
      player.sendMessage("§a[Debug] Logs cleared.");
    }
    if (res.selection == 1) {
      openDebugLogForm(player); // Refresh the form
    }
    // No action needed for "Close" or canceled form
  });
}
