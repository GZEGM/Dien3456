// main.js
import {
  world,
  system,
  Player,
  EntityInventoryComponent,
} from "@minecraft/server";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";
import { ForceOpen } from "./function/ForceOpen.js"; // Adjust path if needed
import { questManager } from "./lib/DynamicPropertyQuestManager.js"; // Import the QuestManager instance
import "./lib/Command.js";

// --- Utility for Displaying Quest Details ---
function getQuestDetailsText(quest) {
  let details = `§l§fQuest Name:§r §a${quest.name}\n`;
  details += `§l§fLevel:§r §e${quest.level}\n`;
  details += `§l§fMax Completions:§r §6${
    quest.maxCompletions === 0 ? "Infinite" : quest.maxCompletions
  }\n`;
  details += `§l§fLocks Other Quests:§r §d${
    quest.locksOtherQuests ? "Yes" : "No"
  }\n`;
  details += `§l§fDescription:§r §b${quest.description}\n`;
  details += `§l§fCompletion Msg:§r §9${quest.completionMessage}\n`;

  // ===== Requirements =====
  details += "\n§l§fRequirements:§r\n";
  if (quest.requirements.length === 0) {
    details += "  §7(None)\n";
  } else {
    quest.requirements.forEach((req, i) => {
      let reqText = `  §f${i + 1}. `;
      const qty = req.quantity;
      const nameOrId = req.displayName
        ? `§a${req.displayName}`
        : `§e${req.targetId.split(":")[1]}`;
      const formatted = `§6x${qty} ${nameOrId}`;
      switch (req.type) {
        case "has_item":
          reqText += `You need to have ${formatted}.`;
          break;
        case "break_block":
          reqText += `You need to break ${formatted}.`;
          break;
        case "place_block":
          reqText += `You need to place ${formatted}.`;
          break;
        case "kill_mob":
          reqText += `You must kill ${formatted}.`;
          break;
        default:
          reqText += `Type: §b${req.type.replace(
            /_/g,
            " "
          )}, Target: ${formatted}`;
          break;
      }
      details += reqText + "\n";
    });
  }

  // ===== Rewards =====
  details += "\n§l§fRewards:§r\n";
  if (quest.rewards.length === 0) {
    details += "  §7(None)\n";
  } else {
    quest.rewards.forEach((reward, i) => {
      let rewardText = `  §f${i + 1}. `;
      const qty = reward.itemQuantity || 1;
      const nameOrId = reward.displayName
        ? `§a${reward.displayName}`
        : reward.itemTypeId
        ? `§e${reward.itemTypeId}`
        : "§7(Unknown)";
      const formatted = `§6x${qty} ${nameOrId}`;
      switch (reward.type) {
        case "give_item":
          rewardText += `You will receive ${formatted}`;
          if (reward.itemEnchants?.length > 0)
            rewardText += ` §rwith enchantments: §d${reward.itemEnchants
              .map((e) => `${e.id}:${e.level}`)
              .join(", ")}`;
          if (reward.itemLore?.length > 0)
            rewardText += ` §rand lore: §7'${reward.itemLore.join("', '")}'`;
          rewardText += ".";
          break;
        case "scoreboard":
          rewardText += `You will gain §e${reward.scoreboardScore} §a${reward.scoreboardObjective}.`;
          break;
        case "structure":
          rewardText += `You will unlock x§6${reward.structureCount} §e${
            reward.displayName || reward.structureId
          }.`;
          break;
        default:
          rewardText += `You will receive: Type §b${reward.type.replace(
            /_/g,
            " "
          )} ${formatted}`;
          break;
      }
      details += rewardText + "\n";
    });
  }

  return details;
}

// --- Watchdog Termination Handler ---
system.beforeEvents.watchdogTerminate.subscribe((event) => {
  event.cancel = true;
  console.warn(
    `[Watchdog] Canceled critical exception of type '${event.cancelationReason}'`
  );
});

// --- Quest Progress Checking and Reward Granting ---

// Main loop to check for quest completion every X ticks (e.g., 20 ticks = 1 second)
system.runInterval(() => {
  if (!questManager._isInitialized) return;

  for (const player of world.getAllPlayers()) {
    if (!player.isValid) continue; // Ensure player is valid

    const allStoredQuests = questManager.getAllQuests(); // Get all currently loaded quests
    const activeQuests = allStoredQuests.filter((q) => {
      // Kiểm tra xem quest có thực sự tồn tại trong manager trước khi lọc theo status
      const questInManager = questManager.getQuest(q.id);
      if (!questInManager) {
        // Nếu quest không tồn tại, có nghĩa là nó đã bị xóa.
        // Reset trạng thái của player đối với quest này nếu nó vẫn được ghi nhận là 'in_progress'
        // Điều này giúp dọn dẹp dữ liệu cũ.
        const playerProgress = questManager.getPlayerProgress(player);
        if (playerProgress[q.id]?.status === "in_progress") {
          questManager.resetPlayerQuestProgress(player, q.id);
          console.warn(
            `[Main WARNING] Cleaned up in_progress status for deleted quest ${q.id} for player ${player.name}.`
          );
        }
        return false; // Loại bỏ quest đã bị xóa khỏi danh sách activeQuests
      }
      return questManager.getQuestStatus(player, q.id) === "in_progress";
    });

    for (const quest of activeQuests) {
      if (!player.isValid) continue; // Kiểm tra lại sau khi lọc
      questManager.attemptQuestCompletion(player, quest.id);
    }
  }
}, 20); // Check every 20 ticks (1 second)

// Event listener for player joining/respawning to check quests (e.g., has_item)
world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  system.runTimeout(() => {
    if (questManager._isInitialized && player.isValid) {
      const allStoredQuests = questManager.getAllQuests();
      const activeQuests = allStoredQuests.filter((q) => {
        const questInManager = questManager.getQuest(q.id);
        if (!questInManager) {
          const playerProgress = questManager.getPlayerProgress(player);
          if (playerProgress[q.id]?.status === "in_progress") {
            questManager.resetPlayerQuestProgress(player, q.id);
            // console.warn(
            //   `[Main WARNING] Cleaned up in_progress status for deleted quest ${q.id} for player ${player.name} on spawn.`
            // );
          }
          return false;
        }
        return questManager.getQuestStatus(player, q.id) === "in_progress";
      });
      for (const quest of activeQuests) {
        if (!player.isValid) continue; // Kiểm tra lại sau khi lọc
        questManager.attemptQuestCompletion(player, quest.id);
      }
    }
  }, 40); // Delay by 2 seconds (40 ticks)
});

// Event listener for player leaving to save progress (optional, but good practice)
world.beforeEvents.playerLeave.subscribe((event) => {
  const player = event.player;
  if (!player.isValid) {
    // Thêm kiểm tra player.isValid
    console.warn(
      "[QuestSystem WARNING] PlayerLeave event for invalid player. Skipping save."
    );
    return;
  }
  if (questManager._isInitialized) {
    const progress = questManager.getPlayerProgress(player);
    questManager.savePlayerProgress(player, progress);
    questManager._playerProgressCache.delete(player.id);
    console.log(
      `[QuestSystem] Saved progress and cleared cache for player ${player.name} on leave.`
    );
  }
});

// --- Specific Requirement Event Listeners ---
// These listeners update the progress for specific quest types.

world.afterEvents.playerBreakBlock.subscribe((event) => {
  const player = event.player.isValid ? event.player : null; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Thêm kiểm tra player.isValid
  const brokenBlockId = event.brokenBlockPermutation.type.id;
  // console.warn(
  //   `[Main DEBUG] Player ${player.name} broke block: ${brokenBlockId}`
  // );

  const allStoredQuests = questManager.getAllQuests();
  const activeQuests = allStoredQuests.filter((q) => {
    const questInManager = questManager.getQuest(q.id);
    if (!questInManager) {
      const playerProgress = questManager.getPlayerProgress(player);
      if (playerProgress[q.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, q.id);
      }
      return false;
    }
    return questManager.getQuestStatus(player, q.id) === "in_progress";
  });

  for (const quest of activeQuests) {
    if (!player.isValid) continue; // Kiểm tra lại sau khi lọc
    quest.requirements.forEach((req, index) => {
      if (req.type === "break_block" && req.targetId === brokenBlockId) {
        // console.warn(
        //   `[Main DEBUG] Matched break_block requirement for quest "${quest.name}" (index ${index}).`
        // );
        questManager.updateQuestProgress(player, quest.id, index, 1);
      }
    });
    questManager.attemptQuestCompletion(player, quest.id);
  }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const player = event.player.isValid ? event.player : null; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Thêm kiểm tra player.isValid
  const placedBlockId = event.block.typeId;
  // console.warn(
  //   `[Main DEBUG] Player ${player.name} placed block: ${placedBlockId}`
  // );

  const allStoredQuests = questManager.getAllQuests();
  const activeQuests = allStoredQuests.filter((q) => {
    const questInManager = questManager.getQuest(q.id);
    if (!questInManager) {
      const playerProgress = questManager.getPlayerProgress(player);
      if (playerProgress[q.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, q.id);
      }
      return false;
    }
    return questManager.getQuestStatus(player, q.id) === "in_progress";
  });

  for (const quest of activeQuests) {
    if (!player.isValid) continue; // Kiểm tra lại sau khi lọc
    quest.requirements.forEach((req, index) => {
      if (req.type === "place_block" && req.targetId === placedBlockId) {
        // console.warn(
        //   `[Main DEBUG] Matched place_block requirement for quest "${quest.name}" (index ${index}).`
        // );
        questManager.updateQuestProgress(player, quest.id, index, 1);
      }
    });
    questManager.attemptQuestCompletion(player, quest.id);
  }
});

world.afterEvents.entityDie.subscribe((event) => {
  const killer = event.damageSource.damagingEntity;

  if (killer && killer instanceof Player) {
    const player = killer.isValid ? killer : null; // Ensure killer is valid or set to null
    if (!player || !player.isValid) return; // Thêm kiểm tra player.isValid
    const mobId = event.deadEntity.typeId;
    // console.warn(`[Main DEBUG] Player ${player.name} killed entity: ${mobId}`);

    const allStoredQuests = questManager.getAllQuests();
    const activeQuests = allStoredQuests.filter((q) => {
      const questInManager = questManager.getQuest(q.id);
      if (!questInManager) {
        const playerProgress = questManager.getPlayerProgress(player);
        if (playerProgress[q.id]?.status === "in_progress") {
          questManager.resetPlayerQuestProgress(player, q.id);
        }
        return false;
      }
      return questManager.getQuestStatus(player, q.id) === "in_progress";
    });

    for (const quest of activeQuests) {
      if (!player.isValid) continue; // Kiểm tra lại sau khi lọc
      quest.requirements.forEach((req, index) => {
        if (req.type === "kill_mob" && req.targetId === mobId) {
          // console.warn(
          //   `[Main DEBUG] Matched kill_mob requirement for quest "${quest.name}" (index ${index}).`
          // );
          questManager.updateQuestProgress(player, quest.id, index, 1);
        }
      });
      questManager.attemptQuestCompletion(player, quest.id);
    }
  }
});

// --- ActionBar Display Loop ---
system.runInterval(() => {
  if (!questManager._isInitialized) return;

  for (const player of world.getAllPlayers()) {
    if (!player.isValid) {
      // Kiểm tra player validity ngay lập tức
      player.onScreenDisplay.setActionBar(""); // Xóa action bar nếu player không hợp lệ
      // Không cần setPlayerActionBarDisplayEnabled(player, false) ở đây vì player đã invalid,
      // việc set lại sẽ gây lỗi TypeError.
      continue;
    }

    if (questManager.isPlayerActionBarDisplayEnabled(player)) {
      const allStoredQuests = questManager.getAllQuests();
      const activeQuests = allStoredQuests.filter((q) => {
        // Kiểm tra quest có tồn tại trước khi lấy trạng thái
        const questInManager = questManager.getQuest(q.id);
        if (!questInManager) {
          // Nếu quest không tồn tại, log warning và không đưa vào danh sách activeQuests
          console.warn(
            `[Main WARNING] Quest ${q.id} not found during ActionBar filter. Likely deleted.`
          );
          // Đồng thời, tắt ActionBar cho quest này trong dữ liệu của người chơi.
          const playerProgress = questManager.getPlayerProgress(player);
          if (playerProgress[q.id]?.status === "in_progress") {
            questManager.resetPlayerQuestProgress(player, q.id);
          }
          return false;
        }
        return questManager.getQuestStatus(player, q.id) === "in_progress";
      });

      if (activeQuests.length > 0) {
        const quest = activeQuests[0]; // Display progress for the first active quest

        // Vẫn kiểm tra lại một lần nữa để chắc chắn quest vẫn tồn tại
        const currentQuestInManager = questManager.getQuest(quest.id);
        if (!currentQuestInManager) {
          player.onScreenDisplay.setActionBar(""); // Clear action bar
          // Vẫn gọi setPlayerActionBarDisplayEnabled, nhưng đã xử lý player.isValid trong hàm đó
          questManager.setPlayerActionBarDisplayEnabled(player, false);
          console.warn(
            `[Main WARNING] Quest ${quest.id} not found for ActionBar display. Disabling display for ${player.name}.`
          );
          continue; // Skip to next player
        }

        let actionBarText = `§bQuest: §f${quest.name}§r\n§aProgress:§r`;

        if (currentQuestInManager.requirements.length === 0) {
          actionBarText += " §7(No requirements)";
        } else {
          const inventory = player.getComponent(
            EntityInventoryComponent.componentId
          )?.container;

          currentQuestInManager.requirements.forEach((req, i) => {
            let current = 0;
            if (req.type === "has_item" && inventory) {
              for (let slot = 0; slot < inventory.size; slot++) {
                const item = inventory.getItem(slot);
                if (item && item.typeId === req.targetId) {
                  current += item.amount;
                }
              }
            } else {
              current = questManager.getRequirementProgress(
                player,
                quest.id,
                i
              );
            }
            actionBarText += ` §e${
              req.displayName || req.targetId.replace("minecraft:", "")
            }: §6${current}/${req.quantity}`;
          });
        }
        player.onScreenDisplay.setActionBar(actionBarText);
      } else {
        // If no active quests, clear action bar
        player.onScreenDisplay.setActionBar("");
      }
    } else {
      // If action bar display is disabled, ensure it's clear
      player.onScreenDisplay.setActionBar("");
    }
  }
}); // Update action bar every 2 ticks (0.1 seconds)

// --- Item Use Event Listener for Main Menu ---
world.beforeEvents.itemUse.subscribe((eventData) => {
  const item = eventData.itemStack;
  const player = eventData.source.isValid ? eventData.source : null; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Thêm kiểm tra player.isValid

  // Trigger main menu with a compass
  if (item.typeId === "gui:quest") {
    system.run(async () => {
      // Ensure QuestManager is initialized before showing UI that relies on it
      if (!questManager._isInitialized) {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cQuest system is still loading. Please wait a moment."
        );
        player.playSound("note.bass");
        return;
      }
      if (!player.hasTag("admin")) {
        FuncOpenQuestList(player);
        return;
      }
      FuncMainMenu(player); // Directly call main menu
    });
  }
});

// --- Main Menu UI ---

/**
 * Displays the main quest system menu using ActionFormData.
 * @param {import("@minecraft/server").Player} player The player viewing the menu.
 */
export async function FuncMainMenu(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const UI = new ActionFormData()
    .title("§l§bQuest System Main Menu")
    .body("§fSelect an option:")
    .button("§l§aCreate New Quest", "textures/ui/icon_new")
    .button("§l§eManage Quests", "textures/ui/gear")
    .button("§l§cOpen Quest List", "textures/ui/icon_book_writable"); // Player-facing quest list

  const result = await ForceOpen(player, UI);

  if (result.canceled) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §fYou closed the main menu."
    );
    return; // Exit function if canceled
  }

  if (result.selection === 0) {
    FuncCreateQuest(player);
  } else if (result.selection === 1) {
    FuncManageQuests(player);
  } else if (result.selection === 2) {
    FuncOpenQuestList(player);
  }
  // No re-call of FuncMainMenu here to prevent double-closing
}

// --- Create Quest UI Flow ---

/**
 * Guides the player through creating a new quest.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncCreateQuest(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const UI = new ModalFormData()
    .title("§l§aCreate New Quest")
    .textField("§cQuest Name:", "Enter quest name (e.g., 'First Steps')", {
      maxLength: 50,
    })
    .textField("§cQuest Level/Rarity:", "e.g., 'Common', 'Uncommon', 'Rare'", {
      maxLength: 20,
    })
    .textField("§cMax Completions (0 for Infinite):", "Enter number or 'inf'", {
      defaultValue: "0",
      maxLength: 5,
    })
    .toggle("Locks Other Quests (Prevent other new quests):")
    .textField("§cQuest Description:", "What the player needs to do?", {
      maxLength: 200,
    })
    .textField(
      "§cCompletion Message:",
      "Message upon completion (e.g., 'Well done!')",
      { maxLength: 100 }
    )
    .textField(
      "Texture Path (Optional):",
      "e.g., 'textures/ui/icon_book_writable.png'",
      { defaultValue: "textures/ui/icon_book_writable.png", maxLength: 100 }
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §fQuest creation canceled."
    );
    FuncMainMenu(player); // Return to main menu
    return;
  }

  const [
    name,
    level,
    maxCompletionsStr,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  ] = result.formValues;

  let maxCompletions = 0; // Default to infinite
  if (maxCompletionsStr) {
    if (maxCompletionsStr.toLowerCase() === "inf") {
      maxCompletions = 0;
    } else {
      const parsed = parseInt(maxCompletionsStr);
      if (!isNaN(parsed) && parsed >= 0) {
        maxCompletions = parsed; // Fix: use maxCompletions, not newMaxCompletions here
      } else {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Max Completions value. Must be a non-negative number or 'inf'."
        );
        FuncCreateQuest(player); // Allow retry
        return;
      }
    }
  }

  if (!name || !level || !description || !completionMessage) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cName, Level, Description, and Completion Message are required!"
    );
    FuncCreateQuest(player); // Allow retry
    return;
  }

  const newQuest = questManager.createQuest({
    name,
    level,
    maxCompletions,
    locksOtherQuests,
    description,
    completionMessage,
    texture: texture || "textures/ui/icon_book_writable.png",
  });

  player.sendMessage(
    `§7[§bQuest §eSystem§7]§r §7>> §aQuest "${newQuest.name}" created! Now add Requirements and Rewards.`
  );
  FuncEditQuestDetails(player, newQuest.id); // Go directly to edit details
}

// --- Edit Quest Details (Requirements & Rewards) ---

/**
 * Allows editing requirements and rewards for a specific quest.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditQuestDetails(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    FuncManageQuests(player);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§eEdit Quest: ${quest.name}`)
    .body(getQuestDetailsText(quest))
    .button("§aAdd Requirement", "textures/ui/plus")
    .button("§aAdd Reward", "textures/ui/promo_gift_small_pink")
    .button("§eEdit Basic Info", "textures/ui/editIcon.png")
    .button("§cManage Requirements", "textures/ui/icon_best3")
    .button("§cManage Rewards", "textures/items/emerald")
    .button("§9Back to Manage Quests", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncManageQuests(player); // Go back to manage quests
    return;
  }

  if (result.selection === 0) {
    FuncAddRequirement(player, questId);
  } else if (result.selection === 1) {
    FuncAddReward(player, questId);
  } else if (result.selection === 2) {
    FuncEditQuestBasicInfo(player, questId);
  } else if (result.selection === 3) {
    FuncManageRequirements(player, questId);
  } else if (result.selection === 4) {
    FuncManageRewards(player, questId);
  } else if (result.selection === 5) {
    FuncManageQuests(player);
  }
}

/**
 * Edit basic quest info (name, level, description, completion message, texture, maxCompletions, locksOtherQuests)
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditQuestBasicInfo(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    FuncManageQuests(player);
    return;
  }

  const maxCompletionsDisplay =
    quest.maxCompletions === 0 ? "inf" : String(quest.maxCompletions);

  const UI = new ModalFormData()
    .title("§l§eEdit Basic Quest Info")
    .textField("§cQuest Name:", "Enter quest name", {
      maxLength: 50,
      defaultValue: quest.name,
    })
    .textField("§cQuest Level/Rarity:", "e.g., 'Common', 'Uncommon', 'Rare'", {
      maxLength: 20,
      defaultValue: quest.level,
    })
    .textField("§cMax Completions (0 for Infinite):", "Enter number or 'inf'", {
      defaultValue: maxCompletionsDisplay,
      maxLength: 5,
    })
    .toggle("Locks Other Quests (Prevent other new quests):", {
      defaultValue: quest.locksOtherQuests,
    })
    .textField("§cQuest Description:", "What the player needs to do?", {
      maxLength: 200,
      defaultValue: quest.description,
    })
    .textField("§cCompletion Message:", "Message upon completion", {
      maxLength: 100,
      defaultValue: quest.completionMessage,
    })
    .textField(
      "§6Texture Path:",
      "e.g., 'textures/ui/icon_book_writable.png'",
      { defaultValue: quest.texture, maxLength: 100 }
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const [
    name,
    level,
    maxCompletionsStr,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  ] = result.formValues;

  let newMaxCompletions = 0;
  if (maxCompletionsStr) {
    if (maxCompletionsStr.toLowerCase() === "inf") {
      newMaxCompletions = 0;
    } else {
      const parsed = parseInt(maxCompletionsStr);
      if (!isNaN(parsed) && parsed >= 0) {
        newMaxCompletions = parsed;
      } else {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Max Completions value. Must be a non-negative number or 'inf'."
        );
        FuncEditQuestBasicInfo(player, questId);
        return;
      }
    }
  }

  if (!name || !level || !description || !completionMessage) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cAll fields are required!"
    );
    FuncEditQuestBasicInfo(player, questId);
    return;
  }

  questManager.updateQuest(questId, {
    name,
    level,
    maxCompletions: newMaxCompletions,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  });
  player.sendMessage(
    "§7[§bQuest §eSystem§7]§r §7>> §aQuest basic info updated!"
  );
  FuncEditQuestDetails(player, questId);
}

/**
 * Allows adding a new requirement to a quest.
 * Now uses a dropdown for requirement type.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncAddRequirement(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    FuncManageQuests(player);
    return;
  }

  const requirementTypes = [
    "Has Item",
    "Break Block",
    "Place Block",
    "Kill Mob",
  ];
  const requirementTypeValues = [
    "has_item",
    "break_block",
    "place_block",
    "kill_mob",
  ];

  const UI = new ModalFormData()
    .title("§l§aAdd Quest Requirement")
    .dropdown("§6Select Requirement Type:", requirementTypes)
    .textField(
      "§cTarget ID:",
      `e.g., 'minecraft:diamond_ore', 'minecraft:zombie'`
    )
    .textField("§cQuantity:", "Enter required amount (number)", {
      defaultValue: "1",
    })
    .textField("Display Name (Optional):", "e.g., 'Diamonds', 'Zombies'");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const [selectedTypeIndex, targetId, quantityStr, displayName] =
    result.formValues;
  const reqType = requirementTypeValues[selectedTypeIndex];
  const quantity = parseInt(quantityStr);

  if (!reqType || !targetId || isNaN(quantity) || quantity <= 0) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cInvalid input. Please fill all required fields correctly!"
    );
    FuncAddRequirement(player, questId);
    return;
  }

  questManager.addRequirement(questId, {
    type: reqType,
    targetId,
    quantity,
    displayName: displayName || undefined,
  });

  player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §aRequirement added!");
  FuncEditQuestDetails(player, questId);
}

/**
 * Manages existing requirements (edit/remove).
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncManageRequirements(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest || quest.requirements.length === 0) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cNo requirements to manage for this quest."
    );
    FuncEditQuestDetails(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§cManage Requirements for ${quest.name}`)
    .body("§fSelect a requirement to edit or remove:");

  quest.requirements.forEach((req, i) => {
    let display = `§f${i + 1}. ${req.type.replace(/_/g, " ")}: §e${
      req.displayName || req.targetId
    } (x${req.quantity})`;
    UI.button(display);
  });
  UI.button("§9Back to Quest Details", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === quest.requirements.length) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const selectedIndex = result.selection;
  FuncEditRemoveRequirement(player, questId, selectedIndex);
}

/**
 * Edits or removes a specific requirement.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {number} index
 */
async function FuncEditRemoveRequirement(player, questId, index) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  const req = quest?.requirements[index];
  if (!quest || !req) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cRequirement not found!"
    );
    FuncManageRequirements(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§cEdit/Remove Requirement ${index + 1}`)
    .body(
      `§fType: §b${req.type.replace(/_/g, " ")}\nTarget: §e${
        req.targetId
      }\nQuantity: §6${req.quantity}`
    )
    .button("§aEdit Requirement", "textures/ui/editIcon.png")
    .button("§cRemove Requirement", "textures/ui/trash")
    .button("§9Back", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === 2) {
    FuncManageRequirements(player, questId);
    return;
  }

  if (result.selection === 0) {
    // Edit
    const editUI = new ModalFormData()
      .title(`§l§aEdit Requirement ${index + 1}`)
      .textField(
        "§cTarget ID:",
        `e.g., 'minecraft:diamond_ore', 'minecraft:zombie'`,
        { defaultValue: req.targetId }
      )
      .textField("§cQuantity:", "Enter required amount (number)", {
        defaultValue: String(req.quantity),
      })
      .textField("Display Name (Optional):", "e.g., 'Diamonds', 'Zombies'", {
        defaultValue: req.displayName || "",
      });

    const editResult = await ForceOpen(player, editUI);
    if (editResult.canceled) {
      FuncEditRemoveRequirement(player, questId, index);
      return;
    }

    const [newTargetId, newQuantityStr, newDisplayName] = editResult.formValues;
    const newQuantity = parseInt(newQuantityStr);

    if (!newTargetId || isNaN(newQuantity) || newQuantity <= 0) {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Target ID or Quantity!"
      );
      FuncEditRemoveRequirement(player, questId, index);
      return;
    }

    questManager.updateRequirement(questId, index, {
      targetId: newTargetId,
      quantity: newQuantity,
      displayName: newDisplayName || undefined,
    });
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §aRequirement updated!");
    FuncManageRequirements(player, questId);
  } else if (result.selection === 1) {
    // Remove
    const confirmUI = new MessageFormData()
      .title("§cConfirm Removal")
      .body(
        `§fAre you sure you want to remove this requirement?\n§e${req.type}: ${req.targetId} x${req.quantity}`
      )
      .button1("§aYes")
      .button2("§cNo");
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.removeRequirement(questId, index);
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §aRequirement removed!"
      );
    } else {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §fRequirement removal canceled."
      );
    }
    FuncManageRequirements(player, questId);
  }
}

/**
 * Allows adding a new reward to a quest.
 * Now uses a dropdown for reward type.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncAddReward(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    FuncManageQuests(player);
    return;
  }

  const rewardTypes = ["Give Item", "Scoreboard", "Structure"];
  const rewardTypeValues = ["give_item", "scoreboard", "structure"];

  const UI = new ModalFormData()
    .title("§l§aAdd Quest Reward")
    .dropdown("§6Select Reward Type:", rewardTypes);

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const [selectedTypeIndex] = result.formValues;
  const rewardType = rewardTypeValues[selectedTypeIndex];

  let rewardDetailsUI;
  if (rewardType === "give_item") {
    rewardDetailsUI = new ModalFormData()
      .title("§l§aGive Item Reward")
      .textField("§cItem Type ID:", `e.g., 'minecraft:diamond_sword'`)
      .textField("§cQuantity:", "Enter amount (number)", { defaultValue: "1" })
      .textField(
        "Lore (comma separated):",
        "e.g., 'Special Item, For Heroes Only'",
        { defaultValue: "" }
      )
      .textField(
        "Enchantments (id:level, comma separated):",
        "e.g., 'sharpness:5,unbreaking:3'",
        { defaultValue: "" }
      )
      .textField("Display Name (Optional):", "e.g., 'Legendary Sword'");
  } else if (rewardType === "scoreboard") {
    rewardDetailsUI = new ModalFormData()
      .title("§l§aScoreboard Reward")
      .textField("§cObjective Name:", "e.g., 'money', 'kills'")
      .textField("§cScore Amount:", "Score to add/set (number)", {
        defaultValue: "1",
      })
      .textField("Display Name (Optional):", "e.g., 'Money Boost'");
  } else if (rewardType === "structure") {
    rewardDetailsUI = new ModalFormData()
      .title("§l§aStructure Reward")
      .textField("§cStructure ID:", "e.g., 'my_structures:house1'")
      .textField("§cCount (to spawn at player):", "Number of structures", {
        defaultValue: "1",
      })
      .textField("Display Name (Optional):", "e.g., 'Small House'");
  } else {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cUnknown reward type selected."
    );
    FuncAddReward(player, questId);
    return;
  }

  const rewardResult = await ForceOpen(player, rewardDetailsUI);
  if (rewardResult.canceled) {
    FuncAddReward(player, questId);
    return;
  }

  let newReward = { type: rewardType };
  if (rewardType === "give_item") {
    const [itemTypeId, quantityStr, loreStr, enchantsStr, displayName] =
      rewardResult.formValues;
    const itemQuantity = parseInt(quantityStr);
    const itemLore = loreStr
      ? loreStr.split(",").map((s) => s.trim())
      : undefined;
    const itemEnchants = enchantsStr
      ? enchantsStr
          .split(",")
          .map((s) => {
            const parts = s.trim().split(":");
            return parts.length === 2
              ? { id: parts[0], level: parseInt(parts[1]) || 1 }
              : null;
          })
          .filter((e) => e)
      : undefined;

    if (!itemTypeId || isNaN(itemQuantity) || itemQuantity <= 0) {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Item Type ID or Quantity!"
      );
      FuncAddReward(player, questId);
      return;
    }
    Object.assign(newReward, {
      itemTypeId,
      itemQuantity,
      itemLore,
      itemEnchants,
      displayName: displayName || undefined,
    });
  } else if (rewardType === "scoreboard") {
    const [objectiveName, scoreAmountStr, displayName] =
      rewardResult.formValues;
    const scoreAmount = parseInt(scoreAmountStr);
    if (!objectiveName || isNaN(scoreAmount)) {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Objective Name or Score Amount!"
      );
      FuncAddReward(player, questId);
      return;
    }
    Object.assign(newReward, {
      scoreboardObjective: objectiveName,
      scoreboardScore: scoreAmount,
      displayName: displayName || undefined,
    });
  } else if (rewardType === "structure") {
    const [structureId, countStr, displayName] = rewardResult.formValues;
    const structureCount = parseInt(countStr);
    if (!structureId || isNaN(structureCount) || structureCount <= 0) {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Structure ID or Count!"
      );
      FuncAddReward(player, questId);
      return;
    }
    Object.assign(newReward, {
      structureId,
      structureCount,
      displayName: displayName || undefined,
    });
  }

  questManager.addReward(questId, newReward);
  player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §aReward added!");
  FuncEditQuestDetails(player, questId);
}

/**
 * Manages existing rewards (edit/remove).
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncManageRewards(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest || quest.rewards.length === 0) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cNo rewards to manage for this quest."
    );
    FuncEditQuestDetails(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§cManage Rewards for ${quest.name}`)
    .body("§fSelect a reward to edit or remove:");

  quest.rewards.forEach((reward, i) => {
    let display = `§f${i + 1}. ${reward.type.replace(/_/g, " ")}: ${
      reward.displayName || ""
    }`;
    if (reward.itemTypeId)
      display += ` x${reward.itemQuantity} ${reward.itemTypeId}`;
    if (reward.scoreboardObjective)
      display += ` ${reward.scoreboardScore} ${reward.scoreboardObjective}`;
    if (reward.structureId)
      display += ` x${reward.structureCount} ${reward.structureId}`;
    UI.button(display);
  });
  UI.button("§9Back to Quest Details", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === quest.rewards.length) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const selectedIndex = result.selection;
  FuncEditRemoveReward(player, questId, selectedIndex);
}

/**
 * Edits or removes a specific reward.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {number} index
 */
async function FuncEditRemoveReward(player, questId, index) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  const reward = quest?.rewards[index];
  if (!quest || !reward) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cReward not found!");
    FuncManageRewards(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§cEdit/Remove Reward ${index + 1}`)
    .body(
      `§fType: §b${reward.type.replace(/_/g, " ")}\nDisplay Name: §e${
        reward.displayName || "N/A"
      }`
    )
    .button("§aEdit Reward", "textures/ui/editIcon")
    .button("§cRemove Reward", "textures/ui/trash")
    .button("§9Back", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === 2) {
    FuncManageRewards(player, questId);
    return;
  }

  if (result.selection === 0) {
    // Edit
    let editUI;
    if (reward.type === "give_item") {
      editUI = new ModalFormData()
        .title("§l§aEdit Give Item Reward")
        .textField("§cItem Type ID:", `e.g., 'minecraft:diamond_sword'`, {
          defaultValue: reward.itemTypeId || "",
        })
        .textField("§cQuantity:", "Enter amount (number)", {
          defaultValue: String(reward.itemQuantity || 1),
        })
        .textField(
          "Lore (comma separated):",
          "e.g., 'Special Item, For Heroes Only'",
          { defaultValue: reward.itemLore?.join(",") || "" }
        )
        .textField(
          "Enchantments (id:level, comma separated):",
          "e.g., 'sharpness:5,unbreaking:3'",
          {
            defaultValue:
              reward.itemEnchants?.map((e) => `${e.id}:${e.level}`).join(",") ||
              "",
          }
        )
        .textField("Display Name (Optional):", "e.g., 'Legendary Sword'", {
          defaultValue: reward.displayName || "",
        });
    } else if (reward.type === "scoreboard") {
      editUI = new ModalFormData()
        .title("§l§aEdit Scoreboard Reward")
        .textField("§cObjective Name:", "e.g., 'money', 'kills'", {
          defaultValue: reward.scoreboardObjective || "",
        })
        .textField("§cScore Amount:", "Score to add/set (number)", {
          defaultValue: String(reward.scoreboardScore || 1),
        })
        .textField("Display Name (Optional):", "e.g., 'Money Boost'", {
          defaultValue: reward.displayName || "",
        });
    } else if (reward.type === "structure") {
      editUI = new ModalFormData()
        .title("§l§aEdit Structure Reward")
        .textField("§cStructure ID:", "e.g., 'my_structures:house1'", {
          defaultValue: reward.structureId || "",
        })
        .textField("§cCount (to spawn at player):", "Number of structures", {
          defaultValue: String(reward.structureCount || 1),
        })
        .textField("Display Name (Optional):", "e.g., 'Small House'", {
          defaultValue: reward.displayName || "",
        });
    } else {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cUnknown reward type."
      );
      FuncManageRewards(player, questId);
      return;
    }

    const editResult = await ForceOpen(player, editUI);
    if (editResult.canceled) {
      FuncEditRemoveReward(player, questId, index);
      return;
    }

    let updatedReward = { ...reward };
    if (reward.type === "give_item") {
      const [itemTypeId, quantityStr, loreStr, enchantsStr, displayName] =
        editResult.formValues;
      const itemQuantity = parseInt(quantityStr);
      const itemLore = loreStr
        ? loreStr.split(",").map((s) => s.trim())
        : undefined;
      const itemEnchants = enchantsStr
        ? enchantsStr
            .split(",")
            .map((s) => {
              const parts = s.trim().split(":");
              return parts.length === 2
                ? { id: parts[0], level: parseInt(parts[1]) || 1 }
                : null;
            })
            .filter((e) => e)
        : undefined;

      if (!itemTypeId || isNaN(itemQuantity) || itemQuantity <= 0) {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Item Type ID or Quantity!"
        );
        FuncEditRemoveReward(player, questId, index);
        return;
      }
      Object.assign(updatedReward, {
        itemTypeId,
        itemQuantity,
        itemLore,
        itemEnchants,
        displayName: displayName || undefined,
      });
    } else if (reward.type === "scoreboard") {
      const [objectiveName, scoreAmountStr, displayName] =
        editResult.formValues;
      const scoreAmount = parseInt(scoreAmountStr);
      if (!objectiveName || isNaN(scoreAmount)) {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Objective Name or Score Amount!"
        );
        FuncEditRemoveReward(player, questId, index);
        return;
      }
      Object.assign(updatedReward, {
        scoreboardObjective: objectiveName,
        scoreboardScore: scoreAmount,
        displayName: displayName || undefined,
      });
    } else if (reward.type === "structure") {
      const [structureId, countStr, displayName] = editResult.formValues;
      const structureCount = parseInt(countStr);
      if (!structureId || isNaN(structureCount) || structureCount <= 0) {
        player.sendMessage(
          "§7[§bQuest §eSystem§7]§r §7>> §cInvalid Structure ID or Count!"
        );
        FuncEditRemoveReward(player, questId, index);
        return;
      }
      Object.assign(updatedReward, {
        structureId,
        structureCount,
        displayName: displayName || undefined,
      });
    }
    questManager.updateReward(questId, index, updatedReward);
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §aReward updated!");
    FuncManageRewards(player, questId);
  } else if (result.selection === 1) {
    // Remove
    const confirmUI = new MessageFormData()
      .title("§cConfirm Removal")
      .body(
        `§fAre you sure you want to remove this reward?\n§e${reward.type}: ${
          reward.displayName ||
          reward.itemTypeId ||
          reward.scoreboardObjective ||
          reward.structureId
        }`
      )
      .button1("§aYes")
      .button2("§cNo");
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.removeReward(questId, index);
      player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §aReward removed!");
    } else {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §fReward removal canceled."
      );
    }
    FuncManageRewards(player, questId);
  }
}

// --- Manage Quests UI Flow ---

/**
 * Displays a list of all quests for management (edit/delete).
 * @param {import("@minecraft/server").Player} player
 */
async function FuncManageQuests(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const allQuests = questManager.getAllQuests();
  if (allQuests.length === 0) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cNo quests created yet. Create one first!"
    );
    FuncMainMenu(player);
    return;
  }

  const UI = new ActionFormData()
    .title("§l§eManage Quests")
    .body("§fSelect a quest to manage or manage the system:");

  allQuests.forEach((quest) => {
    UI.button(`${quest.name} §r- Level: ${quest.level}`, quest.texture);
  });
  UI.button(
    "§l§cReset System (Delete All Quests & Progress)",
    "textures/ui/trash"
  ); // New button for reset
  UI.button("§9Back to Main Menu", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === allQuests.length + 1) {
    // Index adjusted for new button
    FuncMainMenu(player);
    return;
  }

  if (result.selection === allQuests.length) {
    // New button's index
    FuncResetSystem(player);
  } else {
    const selectedQuest = allQuests[result.selection];
    FuncEditDeleteQuest(player, selectedQuest.id);
  }
}

/**
 * Allows editing or deleting a specific quest.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditDeleteQuest(player, questId) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    FuncManageQuests(player);
    return;
  }

  const UI = new ActionFormData()
    .title(`§l§eManage: ${quest.name}`)
    .body(getQuestDetailsText(quest))
    .button("§aEdit Quest Details", "textures/ui/editIcon")
    .button("§cDelete Quest", "textures/ui/trash")
    .button("§9Back to Manage Quests", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === 2) {
    FuncManageQuests(player);
    return;
  }

  if (result.selection === 0) {
    FuncEditQuestDetails(player, questId);
  } else if (result.selection === 1) {
    const confirmUI = new MessageFormData()
      .title("§cConfirm Quest Deletion")
      .body(
        `§fAre you sure you want to delete quest:\n§e"${quest.name}"?\n§cTHIS CANNOT BE UNDONE!`
      )
      .button1("§aYes, Delete")
      .button2("§cNo");
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.deleteQuest(questId);
      player.sendMessage(
        `§7[§bQuest §eSystem§7]§r §7>> §aQuest "${quest.name}" deleted.`
      );
    } else {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §fQuest deletion canceled."
      );
    }
    FuncManageQuests(player);
  }
}

/**
 * Resets the entire quest system (deletes all quests and player progress).
 * @param {import("@minecraft/server").Player} player
 */
async function FuncResetSystem(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const confirmUI = new MessageFormData()
    .title("§cCONFIRM SYSTEM RESET")
    .body(
      "§l§cWARNING: THIS WILL DELETE ALL CREATED QUESTS AND ALL PLAYER PROGRESS!\n§r§fAre you absolutely sure you want to do this?\n§eTHIS ACTION CANNOT BE UNDONE!"
    )
    .button1("§4YES, RESET EVERYTHING")
    .button2("§aNo, Go Back");

  const result = await ForceOpen(player, confirmUI);

  if (!result.canceled && result.selection === 0) {
    // Confirmed Yes
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §eResetting quest system..."
    );
    try {
      questManager.deleteAllQuests();
      questManager.clearAllPlayerProgress();
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §aQuest system reset complete!"
      );
    } catch (e) {
      player.sendMessage(
        "§7[§bQuest §eSystem§7]§r §7>> §cError during system reset. Check console."
      );
      console.error("[SYSTEM RESET ERROR]", e);
    }
  } else {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §fSystem reset canceled."
    );
  }
  FuncManageQuests(player); // Return to manage quests menu
}

// --- Player-Facing Quest List UI ---

/**
 * Opens the main quest list selection menu (All, Unfinished, Completed, By Level).
 * @param {import("@minecraft/server").Player} player
 */
export async function FuncOpenQuestList(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const actionBarStatus = questManager.isPlayerActionBarDisplayEnabled(player)
    ? "§aON"
    : "§cOFF";
  const UI = new ActionFormData()
    .title("§l§cPlayer Quest List")
    .body("§fSelect a category to view quests:")
    .button("§l§fAll Quests", "textures/ui/icon_book_writable")
    .button("§l§eUnfinished Quests", "textures/ui/icon_unlocked")
    .button("§l§aCompleted Quests", "textures/ui/confirm")
    .button("§lInfinity Quests", "textures/items/coal")
    .button("§l§bQuests by Level", "textures/items/diamond")
    .button(
      `§l§9Toggle ActionBar Display (${actionBarStatus})`,
      "textures/ui/refresh_hover"
    )
    .button("§9Back to Main Menu", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === 6) {
    if (!player.hasTag("admin")) return;
    FuncMainMenu(player);
    return;
  }

  if (result.selection === 0) {
    FuncViewAllQuests(player);
  } else if (result.selection === 1) {
    FuncViewUnfinishedQuests(player);
  } else if (result.selection === 2) {
    FuncViewCompletedQuests(player);
  } else if (result.selection == 3) {
    FuncViewInfinityQuests(player);
  } else if (result.selection === 4) {
    FuncViewQuestsByLevel(player);
  } else if (result.selection === 5) {
    const newStatus = !questManager.isPlayerActionBarDisplayEnabled(player);
    questManager.setPlayerActionBarDisplayEnabled(player, newStatus);
    player.sendMessage(
      `§7[§bQuest §eSystem§7]§r §7>> §aActionBar display for quests is now: §b${
        newStatus ? "ON" : "OFF"
      }`
    );
    FuncOpenQuestList(player);
  }
}

/**
 * Displays a list of quests based on a filter.
 * @param {import("@minecraft/server").Player} player
 * @param {string} title The title for the quest list UI.
 * @param {function(Quest, PlayerQuestProgressEntry?): boolean} filterFn A function to filter quests.
 * @param {string} [backFunction='FuncOpenQuestList'] The name of the function to return to.
 * @param {string} [specificLevel=null] For "Quests by Level", the specific level to filter by.
 */
async function FuncViewFilteredQuests(
  player,
  title,
  filterFn,
  backFunction = "FuncOpenQuestList",
  specificLevel = null
) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  let quests = questManager.getAllQuests();
  const playerProgress = questManager.getPlayerProgress(player);

  if (specificLevel) {
    quests = quests.filter(
      (q) => q.level.toLowerCase() === specificLevel.toLowerCase()
    );
  }

  const filteredQuests = quests.filter((quest) => {
    // Cũng kiểm tra sự tồn tại của quest ở đây trước khi gọi filterFn
    const questInManager = questManager.getQuest(quest.id);
    if (!questInManager) {
      // Nếu quest không tồn tại, reset trạng thái của player đối với quest này
      if (playerProgress[quest.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, quest.id);
      }
      return false; // Loại bỏ quest đã bị xóa
    }
    return filterFn(quest, playerProgress[quest.id]);
  });

  if (filteredQuests.length === 0) {
    player.sendMessage(
      `§7[§bQuest §eSystem§7]§r §7>> §cNo quests found in this category.`
    );
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel")
      FuncViewQuestsByLevel(player);
    return;
  }

  const UI = new ActionFormData()
    .title(title)
    .body("§fSelect a quest for details:");
  filteredQuests.forEach((quest) => {
    const status = questManager.getQuestStatus(player, quest.id);
    const timesCompleted = questManager.getTimesCompleted(player, quest.id);
    const completionInfo =
      quest.maxCompletions === 0
        ? ""
        : ` (${timesCompleted}/${quest.maxCompletions})`;
    UI.button(
      `${quest.name} §r(${status.replace(/_/g, " ")}${completionInfo})§r`,
      quest.texture
    );
  });
  UI.button("§9Back", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === filteredQuests.length) {
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel")
      FuncViewQuestsByLevel(player);
    return;
  }

  const selectedQuest = filteredQuests[result.selection];
  FuncViewQuestDetailsPlayer(
    player,
    selectedQuest.id,
    backFunction,
    specificLevel
  );
}

/**
 * Displays all quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewAllQuests(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  await FuncViewFilteredQuests(
    player,
    "§l§fAll Quests",
    () => true,
    "FuncOpenQuestList"
  );
}

/**
 * Displays unfinished quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewUnfinishedQuests(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  await FuncViewFilteredQuests(
    player,
    "§l§eUnfinished Quests",
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return timesCompleted < quest.maxCompletions;
    },
    "FuncOpenQuestList"
  );
}

/**
 * Displays completed quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewCompletedQuests(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  await FuncViewFilteredQuests(
    player,
    "§l§aCompleted Quests",
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      // player.sendMessage(status);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return quest.maxCompletions > 0 && timesCompleted >= quest.maxCompletions;
    },
    "FuncOpenQuestList"
  );
}

async function FuncViewInfinityQuests(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  await FuncViewFilteredQuests(
    player,
    "§lInfinity Quests",
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      // player.sendMessage(status);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return quest.maxCompletions == 0;
    },
    "FuncOpenQuestList"
  );
}

/**
 * Displays quests categorized by level.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewQuestsByLevel(player) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const allQuests = questManager.getAllQuests();
  const uniqueLevels = [...new Set(allQuests.map((q) => q.level))];

  if (uniqueLevels.length === 0) {
    player.sendMessage(
      "§7[§bQuest §eSystem§7]§r §7>> §cNo quests with defined levels found."
    );
    FuncOpenQuestList(player);
    return;
  }

  const UI = new ActionFormData()
    .title("§l§bQuests by Level")
    .body("§fSelect a quest level:");

  uniqueLevels.forEach((level) => {
    UI.button(`§r${level} §rQuests`);
  });
  UI.button("§9Back to Quest List", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === uniqueLevels.length) {
    FuncOpenQuestList(player);
    return;
  }

  const selectedLevel = uniqueLevels[result.selection];
  await FuncViewFilteredQuests(
    player,
    `§l§b${selectedLevel} Quests`,
    (quest) => true,
    "FuncViewQuestsByLevel",
    selectedLevel
  );
}

/**
 * Displays full details of a single quest for a player, with options like 'Start' or 'Reset Progress'.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {string} [backFunction='FuncOpenQuestList'] The name of the function to return to.
 * @param {string} [specificLevel=null] Used when returning from "Quests by Level"
 */
async function FuncViewQuestDetailsPlayer(
  player,
  questId,
  backFunction = "FuncOpenQuestList",
  specificLevel = null
) {
  if (!player.isValid) return; // Thêm kiểm tra player.isValid
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §cQuest not found!");
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel" && specificLevel)
      FuncViewFilteredQuests(
        player,
        `§l§b${specificLevel} Quests`,
        (q) => true,
        "FuncViewQuestsByLevel",
        specificLevel
      );
    else FuncOpenQuestList(player);
    return;
  }

  const playerStatus = questManager.getQuestStatus(player, questId);
  const timesCompleted = questManager.getTimesCompleted(player, questId);
  const maxCompletions = quest.maxCompletions;
  const hasLockingQuest = questManager.hasLockingQuestInProgress(player); // Check for locking quests

  let actionButtonText = "";
  let canStartQuest = false;
  let canResetProgress = false;
  let cannotStartReason = "";

  // Determine button text and actions based on quest status and completions
  if (playerStatus === "not_started") {
    if (maxCompletions === 0 || timesCompleted < maxCompletions) {
      if (hasLockingQuest && !quest.locksOtherQuests) {
        actionButtonText = "§c(Cannot Start - Other Quest Locks)";
        cannotStartReason =
          "You have another quest in progress that prevents starting new quests.";
      } else {
        actionButtonText = "§aStart Quest";
        canStartQuest = true;
      }
    } else {
      actionButtonText = "§cMax Completions Reached)";
    }
  } else if (playerStatus === "in_progress") {
    actionButtonText = "§eReset Progress";
    canResetProgress = true;
  } else if (playerStatus === "completed") {
    if (maxCompletions === 0 || timesCompleted < maxCompletions) {
      actionButtonText = "§aRe-start Quest";
      canStartQuest = true;
    } else {
      actionButtonText = "§cReset Progress (Maxed)";
      canResetProgress = true;
    }
  }

  // Display current progress for requirements if in_progress
  let progressDetails = "";
  if (playerStatus === "in_progress" && quest.requirements.length > 0) {
    progressDetails += "\n§l§fCurrent Progress:§r\n";
    const inventory = player.getComponent(
      EntityInventoryComponent.componentId
    )?.container;

    quest.requirements.forEach((req, i) => {
      let current = 0;
      if (req.type === "has_item" && inventory) {
        // For has_item, directly count items in inventory
        for (let slot = 0; slot < inventory.size; slot++) {
          const item = inventory.getItem(slot);
          if (item && item.typeId === req.targetId) {
            current += item.amount;
          }
        }
      } else {
        // For other types, use stored progress
        current = questManager.getRequirementProgress(player, questId, i);
      }
      progressDetails += `  §r- ${
        req.displayName || req.targetId.replace("minecraft:", "")
      }: §6${current}/${req.quantity}\n`;
    });
  }

  const UI = new ActionFormData()
    .title(`§l§fQuest: ${quest.name}`)
    .body(
      `§fCurrent Status: §7${playerStatus.replace(/_/g, " ")}\n` +
        `§fCompleted: §7${timesCompleted}${
          maxCompletions === 0 ? "" : `/${maxCompletions}`
        }\n\n` +
        getQuestDetailsText(quest) +
        progressDetails
    )
    .button(actionButtonText, "textures/ui/gear")
    .button("§9Back", "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled || result.selection === 1) {
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel" && specificLevel)
      FuncViewFilteredQuests(
        player,
        `§l§b${specificLevel} Quests`,
        (q) => true,
        "FuncViewQuestsByLevel",
        specificLevel
      );
    else FuncOpenQuestList(player);
    return;
  }

  if (result.selection === 0) {
    // Action Button
    if (canStartQuest) {
      if (hasLockingQuest && !quest.locksOtherQuests) {
        player.sendMessage(
          `§7[§bQuest §eSystem§7]§r §7>> §c${cannotStartReason}`
        );
        FuncViewQuestDetailsPlayer(
          player,
          questId,
          backFunction,
          specificLevel
        );
        return;
      }
      questManager.setQuestStatus(player, questId, "in_progress");
      player.sendMessage(
        `§7[§bQuest §eSystem§7]§r §7>> §aQuest "${quest.name}" started!`
      );
    } else if (canResetProgress) {
      const confirmUI = new MessageFormData()
        .title("§cConfirm Reset")
        .body(
          `§fAre you sure you want to reset your progress for:\n§e"${quest.name}"?`
        )
        .button1("§aYes, Reset")
        .button2("§cNo");
      const confirmResult = await ForceOpen(player, confirmUI);

      if (!confirmResult.canceled && confirmResult.selection === 0) {
        questManager.resetPlayerQuestProgress(player, questId);
        player.sendMessage(
          `§7[§bQuest §eSystem§7]§r §7>> §aProgress for "${quest.name}" reset.`
        );
      } else {
        player.sendMessage("§7[§bQuest §eSystem§7]§r §7>> §fReset canceled.");
      }
    }
    FuncViewQuestDetailsPlayer(player, questId, backFunction, specificLevel);
  }
}
