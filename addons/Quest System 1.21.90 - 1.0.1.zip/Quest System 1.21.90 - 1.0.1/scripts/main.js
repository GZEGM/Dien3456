// main.js
import {
  world,
  system,
  Player,
  EntityInventoryComponent,
} from "@minecraft/server";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";
import { ForceOpen } from "./function/ForceOpen.js"; // Adjust path if needed
import { questManager } from "./lib/DynamicPropertyQuestManager.js"; // Import the QuestManager instance
import "./lib/Command.js";
import { languages, getLocalizedText, getLanguageName } from "./lang.js"; // Import language utilities

// --- Utility for Displaying Quest Details ---
/**
 * Gets the formatted quest details text for detailed view (used in admin panels).
 * @param {Quest} quest - The quest object.
 * @param {import("@minecraft/server").Player} player - The player viewing the menu.
 * @returns {string} The quest details text.
 */
function getQuestDetailsText(quest, player) {
  let details = `${getLocalizedText(player, "quest_name_label")} §a${
    quest.name
  }\n`;
  details += `${getLocalizedText(player, "quest_level_prefix")} §r${
    quest.level
  }\n`;
  details += `${getLocalizedText(player, "quest_max_completions_prefix")} §6${
    quest.maxCompletions === 0
      ? getLocalizedText(player, "infinity_quests")
      : quest.maxCompletions
  }\n`;
  details += `${getLocalizedText(
    player,
    "quest_locks_other_quests_prefix"
  )} §d${
    quest.locksOtherQuests
      ? getLocalizedText(player, "yes")
      : getLocalizedText(player, "no")
  }\n`;
  details += `${getLocalizedText(player, "quest_description_prefix")} §b${
    quest.description
  }\n`;
  details += `${getLocalizedText(
    player,
    "quest_completion_message_prefix"
  )} §9${quest.completionMessage}\n`;

  // ===== Requirements =====
  details +=
    "\n§l§r" + getLocalizedText(player, "quest_requirements_prefix") + "§r\n";
  if (quest.requirements.length === 0) {
    details +=
      "  §7" + getLocalizedText(player, "quest_no_requirements") + "\n";
  } else {
    quest.requirements.forEach((req, i) => {
      let reqText = `  §r${i + 1}. `;
      const qty = req.quantity;
      // Display raw targetId if displayName is not provided
      const nameOrId = req.displayName
        ? `§a${req.displayName}`
        : req.targetId
        ? `§e${req.targetId}`
        : req.scoreboardObjective
        ? `§a${req.scoreboardObjective}`
        : req.playerTag
        ? `§e${req.playerTag}`
        : req.propertyName
        ? `§a${req.propertyName}`
        : `§7(${getLocalizedText(player, "unknown_requirement")})`;

      // Use custom description if available, otherwise use default
      if (req.description) {
        reqText += req.description
          .replace(/\{amount\}/g, `§6${qty}§r`)
          .replace(/\{name\}/g, `§a${nameOrId}§r`)
          .replace(/\{x\}/g, `§b${req.x || 0}§r`)
          .replace(/\{y\}/g, `§b${req.y || 0}§r`)
          .replace(/\{z\}/g, `§b${req.z || 0}§r`)
          .replace(/\{radius\}/g, `§e${req.radius || 0}§r`)
          .replace(/\{objective\}/g, `§a${req.scoreboardObjective || "N/A"}§r`)
          .replace(/\{tag\}/g, `§e${req.playerTag || "N/A"}§r`)
          .replace(/\{property\}/g, `§a${req.propertyName || "N/A"}§r`)
          .replace(
            /\{value\}/g,
            `§e${req.propertyValue !== undefined ? req.propertyValue : "N/A"}§r`
          )
          .replace(/\{operator\}/g, `§e${req.operator || "N/A"}§r`);
      } else {
        const formatted = `§6x${qty} ${nameOrId}`;
        switch (req.type) {
          case "has_item":
            reqText += getLocalizedText(player, "quest_req_has_item", {
              formatted,
            });
            break;
          case "break_block":
            reqText += getLocalizedText(player, "quest_req_break_block", {
              formatted,
            });
            break;
          case "place_block":
            reqText += getLocalizedText(player, "quest_req_place_block", {
              formatted,
            });
            break;
          case "kill_mob":
            reqText += getLocalizedText(player, "quest_req_kill_mob", {
              formatted,
            });
            break;
          case "location":
            reqText += getLocalizedText(player, "quest_req_location", {
              x: Math.floor(req.x),
              y: Math.floor(req.y),
              z: Math.floor(req.z),
              radius: req.radius,
            });
            break;
          case "scoreboard":
            reqText += getLocalizedText(player, "quest_req_scoreboard", {
              objective: req.scoreboardObjective,
              operator: req.operator,
              amount: req.quantity,
            });
            break;
          case "tag":
            reqText += getLocalizedText(player, "quest_req_tag", {
              tag: req.playerTag,
            });
            break;
          case "property":
            reqText += getLocalizedText(player, "quest_req_property", {
              property: req.propertyName,
              operator: req.operator,
              value: req.propertyValue,
            });
            break;
          default:
            reqText += getLocalizedText(player, "quest_req_unknown_type", {
              type: req.type.replace(/_/g, " "),
              formatted,
            });
            break;
        }
      }
      details +=
        reqText +
        (req.isHidden
          ? " §7(" + getLocalizedText(player, "hidden") + ")"
          : "") +
        "\n";
    });
  }

  // ===== Rewards =====
  details +=
    "\n§l§r" + getLocalizedText(player, "quest_rewards_prefix") + "§r\n";
  if (quest.rewards.length === 0) {
    details += "  §7" + getLocalizedText(player, "quest_no_rewards") + "\n";
  } else {
    quest.rewards.forEach((reward, i) => {
      let rewardText = `  §r${i + 1}. `;
      const qty = reward.itemQuantity || 1;
      // Display raw itemTypeId if displayName is not provided
      const nameOrId = reward.displayName
        ? `§a${reward.displayName}`
        : reward.itemTypeId
        ? `§e${reward.itemTypeId}`
        : `§7(${getLocalizedText(player, "unknown_reward")})`;

      // Use custom description if available, otherwise use default
      if (reward.description) {
        rewardText += reward.description
          .replace(/\{amount\}/g, `§6${qty}§r`)
          .replace(/\{name\}/g, `§a${nameOrId}§r`)
          .replace(/\{command\}/g, `§e${reward.commandString || "N/A"}§r`)
          .replace(
            /\{value\}/g,
            `§e${
              reward.propertyValue !== undefined ? reward.propertyValue : "N/A"
            }§r`
          );
      } else {
        const formatted = `§6x${qty} ${nameOrId}`;
        switch (reward.type) {
          case "give_item":
            rewardText += getLocalizedText(player, "quest_reward_get_item", {
              formatted,
            });
            if (reward.itemEnchants?.length > 0) {
              const enchants = reward.itemEnchants
                .map((e) => `${e.id}:${e.level}`)
                .join(", ");
              if (reward.itemLore?.length > 0) {
                const lore = reward.itemLore.join("', '");
                rewardText += getLocalizedText(
                  player,
                  "quest_item_with_enchants_lore",
                  { enchants: `§d${enchants}`, lore: `§7'${lore}'` }
                );
              } else {
                rewardText += getLocalizedText(
                  player,
                  "quest_item_with_enchants",
                  { enchants: `§d${enchants}` }
                );
              }
            } else if (reward.itemLore?.length > 0) {
              const lore = reward.itemLore.join("', '");
              rewardText += getLocalizedText(player, "quest_item_with_lore", {
                lore: `§7'${lore}'`,
              });
            }
            rewardText += ".";
            break;
          case "scoreboard":
            rewardText += getLocalizedText(player, "quest_reward_get_score", {
              score: `§e${reward.scoreboardScore}`,
              objective: `§a${reward.scoreboardObjective}`,
            });
            break;
          case "structure":
            rewardText += getLocalizedText(
              player,
              "quest_reward_unlock_structure",
              {
                count: `§6${reward.structureCount}`,
                name: `§e${reward.displayName || reward.structureId}`,
              }
            );
            break;
          case "command":
            rewardText += getLocalizedText(player, "quest_reward_run_command", {
              command: `§e'/${reward.commandString}'`,
            });
            break;
          case "script":
            rewardText += getLocalizedText(
              player,
              "quest_reward_execute_script",
              {
                script_snippet: `§e'${reward.scriptString.substring(
                  0,
                  50
                )}...'`,
              }
            ); // Display code snippet
            break;
          case "property":
            rewardText += getLocalizedText(
              player,
              "quest_reward_set_property",
              {
                property: `§a'${reward.propertyName}'`,
                operator: reward.operator || "=", // Display operator for property
                value: `§e'${reward.propertyValue}'`,
              }
            );
            break;
          default:
            reqText += getLocalizedText(player, "quest_reward_unknown_type", {
              type: req.type.replace(/_/g, " "),
              formatted,
            });
            break;
        }
      }
      details +=
        rewardText +
        (reward.isHidden
          ? " §7(" + getLocalizedText(player, "hidden") + ")"
          : "") +
        "\n";
    });
  }

  return details;
}

// --- Watchdog Termination Handler ---
system.beforeEvents.watchdogTerminate.subscribe((event) => {
  event.cancel = true;
  console.warn(
    `[Watchdog] Cancelled critical exception of type '${event.cancelationReason}'`
  );
});

// --- Helper Functions for Requirements ---
/**
 * Parses coordinate string (e.g., "~ ~ ~", "100 ~ 200") into {x, y, z}.
 * Supports '~' for player's current coordinate.
 * @param {import("@minecraft/server").Player} player
 * @param {string} coordString
 * @returns {{x: number, y: number, z: number} | null} Parsed coordinates or null if invalid.
 */
function parseCoordinates(player, coordString) {
  const parts = coordString.split(/\s+/);
  if (parts.length !== 3) return null;

  const playerLoc = player.location;
  let x, y, z;

  const parsePart = (part, playerCoord) => {
    if (part === "~") {
      return playerCoord;
    } else if (part.startsWith("~")) {
      return playerCoord + parseFloat(part.substring(1));
    } else {
      return parseFloat(part);
    }
  };

  x = Math.floor(parsePart(parts[0], playerLoc.x));
  y = Math.floor(parsePart(parts[1], playerLoc.y));
  z = Math.floor(parsePart(parts[2], playerLoc.z));

  if (isNaN(x) || isNaN(y) || isNaN(z)) return null;

  return { x, y, z };
}

/**
 * Checks if the player is near a specific location within a given radius.
 * @param {import("@minecraft/server").Player} player - The player.
 * @param {number} x - Target X coordinate.
 * @param {number} y - Target Y coordinate.
 * @param {number} z - Target Z coordinate.
 * @param {number} radius - Radius in blocks.
 * @returns {boolean} True if the player is within the radius, false otherwise.
 */
function isPlayerNearLocation(player, x, y, z, radius) {
  const playerLoc = player.location;
  const dx = playerLoc.x - x;
  const dy = playerLoc.y - y;
  const dz = playerLoc.z - z;
  const distanceSquared = dx * dx + dy * dy + dz * dz;
  return distanceSquared <= radius * radius;
}

/**
 * Gets a player's score from a scoreboard objective.
 * @param {import("@minecraft/server").Player} player - The player.
 * @param {string} objectiveId - The ID of the scoreboard objective.
 * @returns {number} The player's score, or 0 if not found.
 */
function getPlayerScore(player, objectiveId) {
  try {
    const objective = world.scoreboard.getObjective(objectiveId);
    if (objective) {
      const score = objective.getScore(player.scoreboardIdentity);
      return score !== undefined ? score : 0;
    }
  } catch (e) {
    console.warn(
      `[QuestSystem ERROR] Could not get scoreboard for ${player.name}, objective ${objectiveId}: ${e}`
    );
  }
  return 0;
}

/**
 * Evaluates a comparison between two values based on an operator.
 * @param {any} value1 The first value.
 * @param {string} operator The comparison operator (e.g., ">", "<", "=", ">=", "<=", "!=").
 * @param {any} value2 The second value.
 * @returns {boolean} True if the comparison is true, false otherwise.
 */
function evaluateComparison(value1, operator, value2) {
  // Attempt to convert to number for numerical comparisons if both are numbers or numeric strings
  let num1 = parseFloat(value1);
  let num2 = parseFloat(value2);

  const isNumericComparison = !isNaN(num1) && !isNaN(num2);

  switch (operator) {
    case ">":
      return isNumericComparison ? num1 > num2 : value1 > value2;
    case "<":
      return isNumericComparison ? num1 < num2 : value1 < value2;
    case "=":
      // Use loose equality for flexibility, especially with property values
      return value1 == value2;
    case ">=":
      return isNumericComparison ? num1 >= num2 : value1 >= value2;
    case "<=":
      return isNumericComparison ? num1 <= num2 : value1 <= value2;
    case "!=":
      return value1 != value2;
    default:
      console.warn(`[QuestSystem WARNING] Unknown operator: ${operator}`);
      return false;
  }
}

// --- Quest Progress and Reward Checking ---

// Main loop to check for quest completion every X ticks (e.g., 20 ticks = 1 second)
system.runInterval(() => {
  if (!questManager._isInitialized) return;

  for (const player of world.getAllPlayers()) {
    if (!player.isValid) continue; // Ensure player is valid

    const allStoredQuests = questManager.getAllQuests(); // Get all currently loaded quests
    const activeQuests = allStoredQuests.filter((q) => {
      // Check if the quest actually exists in the manager before filtering by status
      const questInManager = questManager.getQuest(q.id);
      if (!questInManager) {
        // If the quest doesn't exist, it means it was deleted.
        // Reset player's status for this quest if it's still recorded as 'in_progress'
        // This helps clean up stale data.
        const playerProgress = questManager.getPlayerProgress(player);
        if (playerProgress[q.id]?.status === "in_progress") {
          questManager.resetPlayerQuestProgress(player, q.id);
          console.warn(
            `[Main WARNING] Cleaned up in_progress status for deleted quest ${q.id} for player ${player.name}.`
          );
        }
        return false; // Exclude deleted quests from activeQuests list
      }
      return questManager.getQuestStatus(player, q.id) === "in_progress";
    });

    for (const quest of activeQuests) {
      if (!player.isValid) continue; // Re-check after filtering

      let hasProgressUpdate = false;
      quest.requirements.forEach((req, index) => {
        const currentProgress = questManager.getRequirementProgress(
          player,
          quest.id,
          index
        );

        switch (req.type) {
          case "has_item": // NEW CASE FOR HAS_ITEM
            const inventory = player.getComponent(
              EntityInventoryComponent.componentId
            )?.container;
            let itemCount = 0;
            if (inventory) {
              for (let slot = 0; slot < inventory.size; slot++) {
                const item = inventory.getItem(slot);
                if (item && item.typeId === req.targetId) {
                  itemCount += item.amount;
                }
              }
            }
            // Update stored progress only if it's different from the live count
            if (currentProgress !== itemCount) {
              questManager.setRequirementProgress(
                player,
                quest.id,
                index,
                itemCount
              );
              hasProgressUpdate = true;
            }
            break;
          case "location":
            if (
              currentProgress === 0 && // Only update if not yet met
              isPlayerNearLocation(player, req.x, req.y, req.z, req.radius)
            ) {
              questManager.setRequirementProgress(player, quest.id, index, 1); // Mark as complete (1 for boolean-like completion)
              hasProgressUpdate = true;
            }
            break;
          case "scoreboard":
            const playerScore = getPlayerScore(player, req.scoreboardObjective);
            if (req.checkType === "one_time") {
              if (
                currentProgress === 0 && // Only update if not yet met
                evaluateComparison(playerScore, req.operator, req.quantity)
              ) {
                questManager.setRequirementProgress(player, quest.id, index, 1); // Mark as complete (1 for boolean-like completion)
                hasProgressUpdate = true;
              }
            } else {
              // 'continuous' or undefined (default)
              // For continuous, update with the actual score if it changes
              if (playerScore !== currentProgress) {
                questManager.setRequirementProgress(
                  player,
                  quest.id,
                  index,
                  playerScore
                );
                hasProgressUpdate = true;
              }
            }
            break;
          case "tag":
            if (player.hasTag(req.playerTag) && currentProgress === 0) {
              questManager.setRequirementProgress(player, quest.id, index, 1); // Mark as complete
              hasProgressUpdate = true;
            }
            break;
          case "property":
            const playerPropValue = player.getDynamicProperty(req.propertyName);
            const actualPropValue =
              playerPropValue !== undefined ? playerPropValue : 0;

            if (req.checkType === "one_time") {
              if (
                currentProgress === 0 && // Only update if not yet met
                evaluateComparison(
                  actualPropValue,
                  req.operator,
                  req.propertyValue
                )
              ) {
                questManager.setRequirementProgress(player, quest.id, index, 1); // Mark as complete
                hasProgressUpdate = true;
              }
            } else {
              // 'continuous' or undefined (default)
              // For continuous, update with the actual property value if it changes
              if (actualPropValue !== currentProgress) {
                questManager.setRequirementProgress(
                  player,
                  quest.id,
                  index,
                  actualPropValue
                );
                hasProgressUpdate = true;
              }
            }
            break;
        }
      });

      if (hasProgressUpdate) {
        questManager.attemptQuestCompletion(player, quest.id);
      }
    }
  }
}, 20); // Check every 20 ticks (1 second)

// Event listener for player spawn/respawn to check quests (e.g., has_item)
world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  system.runTimeout(() => {
    if (questManager._isInitialized && player.isValid) {
      const allStoredQuests = questManager.getAllQuests();
      const activeQuests = allStoredQuests.filter((q) => {
        const questInManager = questManager.getQuest(q.id);
        if (!questInManager) {
          const playerProgress = questManager.getPlayerProgress(player);
          if (playerProgress[q.id]?.status === "in_progress") {
            questManager.resetPlayerQuestProgress(player, q.id);
          }
          return false;
        }
        return questManager.getQuestStatus(player, q.id) === "in_progress";
      });
      for (const quest of activeQuests) {
        if (!player.isValid) continue; // Re-check after filtering
        questManager.attemptQuestCompletion(player, quest.id);
      }
    }
  }, 40); // Delay 2 seconds (40 ticks)
});

// Event listener for player leave to save progress (optional, but good practice)
world.beforeEvents.playerLeave.subscribe((event) => {
  const player = event.player;
  if (!player.isValid) {
    // Add player.isValid check
    console.warn(
      "[QuestSystem WARNING] PlayerLeave event for invalid player object. Skipping save."
    );
    return;
  }
  if (questManager._isInitialized) {
    const progress = questManager.getPlayerProgress(player);
    questManager.savePlayerProgress(player, progress);
    questManager._playerProgressCache.delete(player.id);
    console.log(
      `[QuestSystem] Saved progress and cleared cache for player ${player.name} on leave.`
    );
  }
});

// --- Specific Requirement Event Listeners ---
// These listeners update progress for specific quest types.

world.afterEvents.playerBreakBlock.subscribe((event) => {
  const player = event.player.isValid ? event.player : null; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Add player.isValid check
  const brokenBlockId = event.brokenBlockPermutation.type.id;
  // console.warn(
  //   `[Main DEBUG] Player ${player.name} broke block: ${brokenBlockId}`
  // );

  const allStoredQuests = questManager.getAllQuests();
  const activeQuests = allStoredQuests.filter((q) => {
    const questInManager = questManager.getQuest(q.id);
    if (!questInManager) {
      const playerProgress = questManager.getPlayerProgress(player);
      if (playerProgress[q.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, q.id);
      }
      return false;
    }
    return questManager.getQuestStatus(player, q.id) === "in_progress";
  });

  for (const quest of activeQuests) {
    if (!player.isValid) continue; // Re-check after filtering
    quest.requirements.forEach((req, index) => {
      if (req.type === "break_block" && req.targetId === brokenBlockId) {
        const currentProgress = questManager.getRequirementProgress(
          player,
          quest.id,
          index
        );
        if (currentProgress < req.quantity) {
          // Only increment if not yet reached required quantity
          questManager.updateQuestProgress(player, quest.id, index, 1);
        }
      }
    });
    questManager.attemptQuestCompletion(player, quest.id);
  }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const player = event.player; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Add player.isValid check
  const placedBlockId = event.block.typeId;
  // console.warn(
  //   `[Main DEBUG] Player ${player.name} placed block: ${placedBlockId}`
  // );

  const allStoredQuests = questManager.getAllQuests();
  const activeQuests = allStoredQuests.filter((q) => {
    const questInManager = questManager.getQuest(q.id);
    if (!questInManager) {
      const playerProgress = questManager.getPlayerProgress(player);
      if (playerProgress[q.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, q.id);
      }
      return false;
    }
    return questManager.getQuestStatus(player, q.id) === "in_progress";
  });

  for (const quest of activeQuests) {
    if (!player.isValid) continue; // Re-check after filtering
    quest.requirements.forEach((req, index) => {
      if (req.type === "place_block" && req.targetId === placedBlockId) {
        const currentProgress = questManager.getRequirementProgress(
          player,
          quest.id,
          index
        );
        if (currentProgress < req.quantity) {
          // Only increment if not yet reached required quantity
          questManager.updateQuestProgress(player, quest.id, index, 1);
        }
      }
    });
    questManager.attemptQuestCompletion(player, quest.id);
  }
});

world.afterEvents.entityDie.subscribe((event) => {
  const killer = event.damageSource.damagingEntity;

  if (killer && killer instanceof Player) {
    const player = killer.isValid ? killer : null; // Ensure killer is valid or set to null
    if (!player || !player.isValid) return; // Add player.isValid check
    const mobId = event.deadEntity.typeId;
    // console.warn(`[Main DEBUG] Player ${player.name} killed entity: ${mobId}`);

    const allStoredQuests = questManager.getAllQuests();
    const activeQuests = allStoredQuests.filter((q) => {
      const questInManager = questManager.getQuest(q.id);
      if (!questInManager) {
        const playerProgress = questManager.getPlayerProgress(player);
        if (playerProgress[q.id]?.status === "in_progress") {
          questManager.resetPlayerQuestProgress(player, q.id);
        }
        return false;
      }
      return questManager.getQuestStatus(player, q.id) === "in_progress";
    });

    for (const quest of activeQuests) {
      if (!player.isValid) continue; // Re-check after filtering
      quest.requirements.forEach((req, index) => {
        if (req.type === "kill_mob" && req.targetId === mobId) {
          const currentProgress = questManager.getRequirementProgress(
            player,
            quest.id,
            index
          );
          if (currentProgress < req.quantity) {
            // Only increment if not yet reached required quantity
            questManager.updateQuestProgress(player, quest.id, index, 1);
          }
        }
      });
      questManager.attemptQuestCompletion(player, quest.id);
    }
  }
});

// --- Action Bar Display Loop ---
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    if (!player.isValid) {
      // Check player validity immediately
      // Do not attempt to clear action bar if player is invalid, as it will throw an error.
      // player.onScreenDisplay.setActionBar("");
      continue;
    }

    if (questManager.isPlayerActionBarDisplayEnabled(player)) {
      const allStoredQuests = questManager.getAllQuests();
      const activeQuests = allStoredQuests.filter((q) => {
        // Check if the quest exists before getting status
        const questInManager = questManager.getQuest(q.id);
        if (!questInManager) {
          // If the quest doesn't exist, log a warning and don't include it in activeQuests
          console.warn(
            `[Main WARNING] Quest ${q.id} not found for ActionBar filter. Possibly deleted.`
          );
          // Also, disable ActionBar for this quest in player's data.
          const playerProgress = questManager.getPlayerProgress(player);
          if (playerProgress[q.id]?.status === "in_progress") {
            questManager.resetPlayerQuestProgress(player, q.id);
          }
          return false;
        }
        return questManager.getQuestStatus(player, q.id) === "in_progress";
      });

      if (activeQuests.length > 0) {
        const quest = activeQuests[0]; // Display progress for the first active quest

        // Re-check one more time to ensure the quest still exists
        const currentQuestInManager = questManager.getQuest(quest.id);
        if (!currentQuestInManager) {
          player.onScreenDisplay.setActionBar(""); // Clear action bar
          // Still call setPlayerActionBarDisplayEnabled, but player.isValid is already handled within that function
          questManager.setPlayerActionBarDisplayEnabled(player, false);
          console.warn(
            `[Main WARNING] Quest ${quest.id} not found for ActionBar display. Disabling display for ${player.name}.`
          );
          continue; // Skip to next player
        }

        let totalCurrentProgress = 0;
        let totalTargetQuantity = 0;
        let allBooleanRequirementsMet = true; // For quests with only boolean requirements

        const inventory = player.getComponent(
          EntityInventoryComponent.componentId
        )?.container;

        // Find the first uncompleted, visible requirement to display on the action bar
        let firstUncompletedVisibleRequirement = null;
        let firstUncompletedVisibleRequirementIndex = -1;

        currentQuestInManager.requirements.forEach((req, i) => {
          if (req.isHidden) return; // Don't count hidden requirements for overall progress or display

          let current = questManager.getRequirementProgress(
            player,
            quest.id,
            i
          ); // Get current stored progress
          let targetQty = req.quantity || 1; // Default to 1 for non-quantity types

          // Special handling for 'one_time' scoreboard/property types for overall progress calculation
          if (
            (req.type === "scoreboard" || req.type === "property") &&
            req.checkType === "one_time"
          ) {
            // If it's one_time and already marked as met (current >= 1), treat as targetQty for overall progress
            current = current >= 1 ? targetQty : 0;
          }
          // For 'continuous' scoreboard/property, 'current' is already the live value.
          // For other types (has_item, break_block, etc.), 'current' is the accumulated progress.

          totalCurrentProgress += Math.min(current, targetQty);
          totalTargetQuantity += targetQty;

          // Logic for firstUncompletedVisibleRequirement needs to consider the actual requirement state
          // (not just stored progress if it's a continuous type that might have dropped below target)
          let isRequirementMetLive = false;
          switch (req.type) {
            case "has_item":
              let itemCount = 0;
              if (inventory) {
                for (let slot = 0; slot < inventory.size; slot++) {
                  const item = inventory.getItem(slot);
                  if (item && item.typeId === req.targetId) {
                    itemCount += item.amount;
                  }
                }
              }
              isRequirementMetLive = itemCount >= req.quantity;
              break;
            case "break_block":
            case "place_block":
            case "kill_mob":
              isRequirementMetLive = current >= req.quantity; // current is already updated by event listeners
              break;
            case "location":
            case "tag":
              isRequirementMetLive = current >= 1; // current is 0 or 1 for these
              break;
            case "scoreboard":
            case "property":
              if (req.checkType === "one_time") {
                isRequirementMetLive = current >= 1; // If one_time, once met, it stays met
              } else {
                // continuous
                const liveValue =
                  req.type === "scoreboard"
                    ? getPlayerScore(player, req.scoreboardObjective)
                    : player.getDynamicProperty(req.propertyName) ?? 0;
                isRequirementMetLive = evaluateComparison(
                  liveValue,
                  req.operator,
                  req.quantity
                );
              }
              break;
          }

          if (
            firstUncompletedVisibleRequirement === null &&
            !isRequirementMetLive // Use live check for determining "uncompleted" for display
          ) {
            firstUncompletedVisibleRequirement = req;
            firstUncompletedVisibleRequirementIndex = i;
          }
        });

        let overallPercentage;
        if (totalTargetQuantity === 0) {
          // If there are no quantity-based requirements, check if all boolean requirements are met
          overallPercentage = allBooleanRequirementsMet ? 100 : 0;
        } else {
          overallPercentage = Math.floor(
            (totalCurrentProgress / totalTargetQuantity) * 100
          );
        }

        let actionBarText = `§b${getLocalizedText(
          player,
          "quest_name_display",
          { questName: quest.name }
        )}§r - §a${overallPercentage}%§r`; // Display overall percentage

        if (firstUncompletedVisibleRequirement) {
          const req = firstUncompletedVisibleRequirement;
          const reqIndex = firstUncompletedVisibleRequirementIndex;
          let currentReqProgress = 0; // Re-initialize for individual requirement
          let targetReqQty = req.quantity || 1;

          // Calculate currentReqProgress based on requirement type
          switch (req.type) {
            case "has_item":
              if (inventory) {
                for (let slot = 0; slot < inventory.size; slot++) {
                  const item = inventory.getItem(slot);
                  if (item && item.typeId === req.targetId) {
                    currentReqProgress += item.amount;
                  }
                }
              }
              break;
            case "break_block":
            case "place_block":
            case "kill_mob":
              currentReqProgress = questManager.getRequirementProgress(
                player,
                quest.id,
                reqIndex
              );
              break;
            case "location":
            case "tag":
              currentReqProgress = questManager.getRequirementProgress(
                player,
                quest.id,
                reqIndex
              );
              break;
            case "scoreboard":
              if (req.checkType === "one_time") {
                currentReqProgress = questManager.getRequirementProgress(
                  player,
                  quest.id,
                  reqIndex
                );
              } else {
                // continuous
                currentReqProgress = getPlayerScore(
                  player,
                  req.scoreboardObjective
                );
              }
              break;
            case "property":
              if (req.checkType === "one_time") {
                currentReqProgress = questManager.getRequirementProgress(
                  player,
                  quest.id,
                  reqIndex
                );
              } else {
                // continuous
                currentReqProgress =
                  player.getDynamicProperty(req.propertyName) ?? 0;
              }
              break;
          }

          let reqDisplayString = "";
          // Prioritize description > displayName > id for Action Bar
          if (req.description) {
            reqDisplayString = req.description
              .replace(/\{amount\}/g, `§6${req.quantity}§r`)
              .replace(
                /\{name\}/g,
                `§a${
                  req.displayName ||
                  req.targetId ||
                  req.scoreboardObjective ||
                  req.playerTag ||
                  req.propertyName
                }§r`
              )
              .replace(/\{x\}/g, `§b${Math.floor(req.x || 0)}§r`)
              .replace(/\{y\}/g, `§b${Math.floor(req.y || 0)}§r`)
              .replace(/\{z\}/g, `§b${Math.floor(req.z || 0)}§r`)
              .replace(/\{radius\}/g, `§e${req.radius || 0}§r`)
              .replace(
                /\{objective\}/g,
                `§a${req.scoreboardObjective || "N/A"}§r`
              )
              .replace(/\{tag\}/g, `§e${req.playerTag || "N/A"}§r`)
              .replace(/\{property\}/g, `§a${req.propertyName || "N/A"}§r`)
              .replace(
                /\{value\}/g,
                `§e${
                  req.propertyValue !== undefined ? req.propertyValue : "N/A"
                }§r`
              )
              .replace(/\{operator\}/g, `§e${req.operator || "N/A"}§r`);
          } else if (req.displayName) {
            reqDisplayString = `§r${req.displayName}`;
          } else {
            switch (req.type) {
              case "has_item":
              case "break_block":
              case "place_block":
              case "kill_mob":
                reqDisplayString = `§e${req.targetId}`;
                break;
              case "location":
                reqDisplayString = getLocalizedText(
                  player,
                  "location_display",
                  {
                    x: Math.floor(req.x),
                    y: Math.floor(req.y),
                    z: Math.floor(req.z),
                    radius: req.radius,
                  }
                );
                break;
              case "scoreboard":
                reqDisplayString = `§a${req.scoreboardObjective}`;
                break;
              case "tag":
                reqDisplayString = `§e${req.playerTag}`;
                break;
              case "property":
                reqDisplayString = `§a${req.propertyName}`;
                break;
              default:
                reqDisplayString = `§7(${getLocalizedText(
                  player,
                  "unknown_requirement"
                )})`; // Fallback
                break;
            }
          }

          let displayProgress = "";
          let isReqCurrentlyMet = false;

          // Determine if the requirement is currently met for display
          if (
            ["has_item", "break_block", "place_block", "kill_mob"].includes(
              req.type
            )
          ) {
            isReqCurrentlyMet = currentReqProgress >= targetReqQty;
            // Cap the displayed current progress at the target quantity
            displayProgress = ` §7(${Math.min(
              currentReqProgress,
              targetReqQty
            )}/${targetReqQty})§r`;
          } else if (req.type === "location" || req.type === "tag") {
            isReqCurrentlyMet = currentReqProgress > 0;
            displayProgress =
              currentReqProgress > 0
                ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                : ` §c(${getLocalizedText(
                    player,
                    "req_status_not_completed"
                  )})§r`;
          } else if (req.type === "scoreboard" || req.type === "property") {
            if (req.checkType === "one_time") {
              isReqCurrentlyMet = currentReqProgress > 0; // If one_time, check stored progress
              displayProgress =
                currentReqProgress > 0
                  ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                  : ` §c(${getLocalizedText(
                      player,
                      "req_status_not_completed"
                    )})§r`;
            } else {
              // continuous
              const liveValue =
                req.type === "scoreboard"
                  ? getPlayerScore(player, req.scoreboardObjective)
                  : player.getDynamicProperty(req.propertyName) ?? 0;
              isReqCurrentlyMet = evaluateComparison(
                liveValue,
                req.operator,
                req.quantity
              );
              displayProgress = isReqCurrentlyMet
                ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                : ` §c(${getLocalizedText(
                    player,
                    "req_status_not_completed"
                  )})§r`;
              // Also show current value for continuous scoreboard/property if relevant, capped at target
              if (
                typeof liveValue === "number" &&
                typeof req.quantity === "number"
              ) {
                displayProgress += ` §7(${Math.min(liveValue, req.quantity)}/${
                  req.quantity
                })§r`;
              }
            }
          }
          actionBarText += `\n${reqDisplayString}${displayProgress}`;
        } else {
          // If all visible requirements are completed, show a "Quest completed" message or similar
          actionBarText += `\n§a${getLocalizedText(
            player,
            "all_requirements_met"
          )}§r`;
        }

        player.onScreenDisplay.setActionBar(actionBarText);
      } else {
        // If no active quests, clear action bar
        player.onScreenDisplay.setActionBar("");
      }
    } else {
      // If action bar display is disabled, ensure it's empty
      player.onScreenDisplay.setActionBar("");
    }
  }
}, 2); // Update action bar every 2 ticks (0.1 seconds)

// --- Item Use Event Listener for Main Menu ---
world.beforeEvents.itemUse.subscribe((eventData) => {
  const item = eventData.itemStack;
  const player = eventData.source.isValid ? eventData.source : null; // Ensure player is valid or set to null
  if (!player || !player.isValid) return; // Add player.isValid check

  // Activate main menu with compass
  if (item.typeId === "gui:quest") {
    system.run(async () => {
      // Ensure QuestManager is initialized before showing UI based on it
      if (!questManager._isInitialized) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "loading_system")
        );
        player.playSound("note.bass");
        return;
      }
      if (!player.hasTag("admin")) {
        FuncOpenQuestList(player);
        return;
      }
      FuncMainMenu(player); // Call main menu directly
    });
  }
});

// --- Main Menu UI ---

/**
 * Displays the main quest system menu using ActionFormData.
 * @param {import("@minecraft/server").Player} player The player viewing the menu.
 */
export async function FuncMainMenu(player) {
  if (!player.isValid) return; // Add player.isValid check
  const UI = new ActionFormData()
    .title(getLocalizedText(player, "main_menu_title"))
    .body(getLocalizedText(player, "main_menu_body"))
    .button(
      getLocalizedText(player, "create_quest_button"),
      "textures/ui/icon_new"
    )
    .button(
      getLocalizedText(player, "manage_quests_button"),
      "textures/ui/gear"
    )
    .button(
      getLocalizedText(player, "open_player_quest_list_button"),
      "textures/ui/icon_book_writable"
    ); // Player-facing quest list

  const result = await ForceOpen(player, UI);

  // If UI is cancelled (e.g., by pressing 'X'), return to previous state (no specific menu)
  if (result.canceled) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "closed_main_menu")
    );
    return;
  }

  if (result.selection === 0) {
    FuncCreateQuest(player);
  } else if (result.selection === 1) {
    FuncManageQuests(player);
  } else if (result.selection === 2) {
    FuncOpenQuestList(player);
  }
}

// --- Create Quest UI Flow ---

/**
 * Guides the player through creating a new quest.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncCreateQuest(player) {
  if (!player.isValid) return; // Add player.isValid check
  const UI = new ModalFormData()
    .title(getLocalizedText(player, "create_quest_button"))
    .textField(
      getLocalizedText(player, "quest_name_label"),
      getLocalizedText(player, "quest_name_placeholder"), // Refined title
      {
        maxLength: 50,
      }
    )
    .textField(
      getLocalizedText(player, "quest_level_label"),
      getLocalizedText(player, "quest_level_placeholder"), // Refined title
      {
        maxLength: 20,
      }
    )
    .textField(
      getLocalizedText(player, "max_completions_label"),
      getLocalizedText(player, "max_completions_placeholder"), // Refined title
      {
        defaultValue: "0",
        maxLength: 5,
      }
    )
    .toggle(getLocalizedText(player, "locks_other_quests_label"))
    .textField(
      getLocalizedText(player, "quest_description_label"),
      getLocalizedText(player, "quest_description_placeholder"), // Refined title
      {
        maxLength: 200,
      }
    )
    .textField(
      getLocalizedText(player, "completion_message_label"),
      getLocalizedText(player, "completion_message_placeholder"), // Refined title
      { maxLength: 100 }
    )
    .textField(
      getLocalizedText(player, "texture_path_label"),
      getLocalizedText(player, "texture_path_placeholder"), // Refined title
      { defaultValue: "textures/ui/icon_book_writable.png", maxLength: 100 }
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "create_quest_canceled")
    );
    FuncMainMenu(player); // Return to main menu
    return;
  }

  const [
    name,
    level,
    maxCompletionsStr,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  ] = result.formValues;

  let maxCompletions = 0; // Default to infinite
  if (maxCompletionsStr) {
    if (maxCompletionsStr.toLowerCase() === "inf") {
      maxCompletions = 0;
    } else {
      const parsed = parseInt(maxCompletionsStr);
      if (!isNaN(parsed) && parsed >= 0) {
        maxCompletions = parsed;
      } else {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_max_completions")
        );
        FuncCreateQuest(player); // Allow retry
        return;
      }
    }
  }

  if (!name || !level) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "required_fields_missing")
    );
    FuncCreateQuest(player); // Allow retry
    return;
  }

  const newQuest = questManager.createQuest({
    name,
    level,
    maxCompletions,
    locksOtherQuests,
    description,
    completionMessage,
    texture: texture || "textures/ui/icon_book_writable.png",
  });

  player.sendMessage(
    getLocalizedText(player, "system_prefix") +
      getLocalizedText(player, "quest_created_success", {
        questName: newQuest.name,
      })
  );
  FuncEditQuestDetails(player, newQuest.id); // Go straight to editing details
}

// --- Edit Quest Details (Requirements & Rewards) ---

/**
 * Allows editing requirements and rewards for a specific quest.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditQuestDetails(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    FuncManageQuests(player);
    return;
  }

  const UI = new ActionFormData()
    .title(
      getLocalizedText(player, "edit_delete_quest_title", {
        questName: quest.name,
      })
    )
    .body(getQuestDetailsText(quest, player)) // Still use full details for admin view
    .button(getLocalizedText(player, "add_requirement"), "textures/ui/plus")
    .button(
      getLocalizedText(player, "add_reward"),
      "textures/ui/promo_gift_small_pink"
    )
    .button(
      getLocalizedText(player, "edit_basic_info"),
      "textures/ui/editIcon.png"
    )
    .button(
      getLocalizedText(player, "manage_requirements"),
      "textures/ui/icon_best3"
    )
    .button(
      getLocalizedText(player, "manage_rewards"),
      "textures/items/emerald"
    )
    .button(
      getLocalizedText(player, "back_to_quest_management"),
      "textures/ui/arrow_left"
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncManageQuests(player); // Return to quest management
    return;
  }

  if (result.selection === 0) {
    FuncAddRequirement(player, questId);
  } else if (result.selection === 1) {
    FuncAddReward(player, questId);
  } else if (result.selection === 2) {
    FuncEditQuestBasicInfo(player, questId);
  } else if (result.selection === 3) {
    FuncManageRequirements(player, questId);
  } else if (result.selection === 4) {
    FuncManageRewards(player, questId);
  } else if (result.selection === 5) {
    FuncManageQuests(player);
  }
}

/**
 * Edits a quest's basic information (name, level, description, completion message, texture, maxCompletions, locksOtherQuests)
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditQuestBasicInfo(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    FuncManageQuests(player);
    return;
  }

  const maxCompletionsDisplay =
    quest.maxCompletions === 0 ? "inf" : String(quest.maxCompletions);

  const UI = new ModalFormData()
    .title(getLocalizedText(player, "edit_basic_info"))
    .textField(
      getLocalizedText(player, "quest_name_label"),
      getLocalizedText(player, "quest_name_placeholder"), // Refined title
      {
        maxLength: 50,
        defaultValue: quest.name,
      }
    )
    .textField(
      getLocalizedText(player, "quest_level_label"),
      getLocalizedText(player, "quest_level_placeholder"), // Refined title
      {
        maxLength: 20,
        defaultValue: quest.level,
      }
    )
    .textField(
      getLocalizedText(player, "max_completions_label"),
      getLocalizedText(player, "max_completions_placeholder"), // Refined title
      {
        defaultValue: "0",
        maxLength: 5,
      }
    )
    .toggle(getLocalizedText(player, "locks_other_quests_label"))
    .textField(
      getLocalizedText(player, "quest_description_label"),
      getLocalizedText(player, "quest_description_placeholder"), // Refined title
      {
        maxLength: 200,
        defaultValue: quest.description,
      }
    )
    .textField(
      getLocalizedText(player, "completion_message_label"),
      getLocalizedText(player, "completion_message_placeholder"), // Refined title
      {
        maxLength: 100,
        defaultValue: quest.completionMessage,
      }
    )
    .textField(
      getLocalizedText(player, "texture_path_label"),
      getLocalizedText(player, "texture_path_placeholder"), // Refined title
      { defaultValue: quest.texture, maxLength: 100 }
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId);
    return;
  }

  const [
    name,
    level,
    maxCompletionsStr,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  ] = result.formValues;

  let newMaxCompletions = 0;
  if (maxCompletionsStr) {
    if (maxCompletionsStr.toLowerCase() === "inf") {
      newMaxCompletions = 0;
    } else {
      const parsed = parseInt(maxCompletionsStr);
      if (!isNaN(parsed) && parsed >= 0) {
        newMaxCompletions = parsed;
      } else {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_max_completions")
        );
        FuncEditQuestBasicInfo(player, questId);
        return;
      }
    }
  }

  if (!name || !level || !description || !completionMessage) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "all_fields_required")
    );
    FuncEditQuestBasicInfo(player, questId);
    return;
  }

  questManager.updateQuest(questId, {
    name,
    level,
    maxCompletions: newMaxCompletions,
    locksOtherQuests,
    description,
    completionMessage,
    texture,
  });
  player.sendMessage(
    getLocalizedText(player, "system_prefix") +
      getLocalizedText(player, "basic_info_updated")
  );
  FuncEditQuestDetails(player, questId);
}

/**
 * Allows adding a new requirement to a quest.
 * Now uses a dropdown for requirement type.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncAddRequirement(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    FuncManageQuests(player);
    return;
  }

  const requirementTypes = [
    getLocalizedText(player, "req_type_has_item"),
    getLocalizedText(player, "req_type_break_block"),
    getLocalizedText(player, "req_type_place_block"),
    getLocalizedText(player, "req_type_kill_mob"),
    getLocalizedText(player, "req_type_location"),
    getLocalizedText(player, "req_type_scoreboard"),
    getLocalizedText(player, "req_type_tag"),
    getLocalizedText(player, "req_type_property"),
  ];
  const requirementTypeValues = [
    "has_item",
    "break_block",
    "place_block",
    "kill_mob",
    "location",
    "scoreboard",
    "tag",
    "property",
  ];

  const typeSelectionUI = new ModalFormData()
    .title(getLocalizedText(player, "add_requirement"))
    .dropdown(getLocalizedText(player, "select_req_type"), requirementTypes);

  const typeResult = await ForceOpen(player, typeSelectionUI);
  if (typeResult.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }

  const [selectedTypeIndex] = typeResult.formValues;
  const reqType = requirementTypeValues[selectedTypeIndex];

  let UI;
  let newRequirement;
  const operators = [">", "<", "=", ">=", "<=", "!="]; // Define operators here
  const checkTypes = [
    getLocalizedText(player, "check_type_continuous"),
    getLocalizedText(player, "check_type_one_time"),
  ]; // Define check types

  switch (reqType) {
    case "has_item":
    case "break_block":
    case "place_block":
    case "kill_mob":
      UI = new ModalFormData()
        .title(
          `${getLocalizedText(player, "add_requirement")} ${getLocalizedText(
            player,
            `req_type_${reqType}`
          ).toUpperCase()}`
        )
        .textField(
          getLocalizedText(player, "target_id"),
          getLocalizedText(player, "target_id_placeholder")
        )
        .textField(
          getLocalizedText(player, "quantity"),
          getLocalizedText(player, "quantity_placeholder"),
          {
            defaultValue: "1",
          }
        )
        .textField(
          getLocalizedText(player, "display_name"),
          getLocalizedText(player, "display_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "location":
      UI = new ModalFormData()
        .title(
          getLocalizedText(player, "add_requirement") +
            " " +
            getLocalizedText(player, "req_type_location")
        )
        .textField(
          getLocalizedText(player, "location"), // Refined title
          getLocalizedText(player, "coords_placeholder"),
          { maxLength: 50 }
        ) // Single text field for coordinates
        .textField(
          getLocalizedText(player, "radius"),
          getLocalizedText(player, "radius_placeholder"),
          { defaultValue: "1" }
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_loc_placeholder"),
          { maxLength: 100 }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "scoreboard":
      UI = new ModalFormData()
        .title(
          getLocalizedText(player, "add_requirement") +
            " " +
            getLocalizedText(player, "req_type_scoreboard")
        )
        .textField(
          getLocalizedText(player, "objective"),
          getLocalizedText(player, "objective_name_placeholder")
        )
        .dropdown(getLocalizedText(player, "operator_label"), operators) // Dropdown for operator
        .textField(
          getLocalizedText(player, "score_amount"), // Refined title
          getLocalizedText(player, "score_amount_placeholder"),
          {
            defaultValue: "1",
          }
        )
        .textField(
          getLocalizedText(player, "display_name"),
          getLocalizedText(player, "display_name_placeholder")
        ) // Display name for scoreboard objective
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_sb_placeholder"),
          { maxLength: 100 }
        )
        .dropdown(getLocalizedText(player, "check_type_label"), checkTypes) // New dropdown for check type
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "tag":
      UI = new ModalFormData()
        .title(
          getLocalizedText(player, "add_requirement") +
            " " +
            getLocalizedText(player, "req_type_tag")
        )
        .textField(
          getLocalizedText(player, "player_tag"),
          getLocalizedText(player, "tag_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_tag_placeholder"),
          { maxLength: 100 }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "property":
      UI = new ModalFormData()
        .title(
          getLocalizedText(player, "add_requirement") +
            " " +
            getLocalizedText(player, "req_type_property")
        )
        .textField(
          getLocalizedText(player, "property_name"),
          getLocalizedText(player, "property_name_placeholder")
        )
        .dropdown(getLocalizedText(player, "operator_label"), operators) // Dropdown for operator
        .textField(
          getLocalizedText(player, "property_value"),
          getLocalizedText(player, "property_value_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_prop_placeholder"),
          { maxLength: 100 }
        )
        .dropdown(getLocalizedText(player, "check_type_label"), checkTypes) // New dropdown for check type
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    default:
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "unknown_req_type_selected")
      );
      FuncEditQuestDetails(player, questId);
      return;
  }

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }

  switch (reqType) {
    case "has_item":
    case "break_block":
    case "place_block":
    case "kill_mob":
      const [targetId, quantityStr, displayName, description, isHiddenItem] =
        result.formValues;
      const quantity = parseInt(quantityStr);
      if (!targetId || isNaN(quantity) || quantity <= 0) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_input_fill_all_fields")
        );
        FuncAddRequirement(player, questId);
        return;
      }
      newRequirement = {
        type: reqType,
        targetId,
        quantity,
        displayName: displayName || undefined,
        description: description || undefined,
        isHidden: isHiddenItem,
      };
      break;
    case "location":
      const [coordsString, radiusStr, descriptionLoc, isHiddenLoc] =
        result.formValues;
      const parsedCoords = parseCoordinates(player, coordsString);
      const radius = parseFloat(radiusStr);
      if (!parsedCoords || isNaN(radius) || radius < 0) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_coords_radius")
        );
        FuncAddRequirement(player, questId);
        return;
      }
      newRequirement = {
        type: reqType,
        x: parsedCoords.x,
        y: parsedCoords.y,
        z: parsedCoords.z,
        radius,
        description: descriptionLoc || undefined,
        quantity: 1, // Quantity 1 for boolean-like completion
        isHidden: isHiddenLoc,
      };
      break;
    case "scoreboard":
      const [
        objectiveName,
        operatorIndex,
        scoreAmountStr,
        displayNameSb,
        descriptionSb,
        checkTypeIndexSb, // New: check type index
        isHiddenSb,
      ] = result.formValues;
      const scoreAmount = parseInt(scoreAmountStr);
      const operator = operators[operatorIndex];
      const checkTypeSb = checkTypes[checkTypeIndexSb]; // New: check type value
      if (!objectiveName || isNaN(scoreAmount) || !operator) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_objective_operator_score")
        );
        FuncAddRequirement(player, questId);
        return;
      }
      newRequirement = {
        type: reqType,
        scoreboardObjective: objectiveName,
        operator: operator, // Save selected operator
        quantity: scoreAmount,
        displayName: displayNameSb || undefined,
        description: descriptionSb || undefined,
        checkType:
          checkTypeSb === getLocalizedText(player, "check_type_one_time")
            ? "one_time"
            : "continuous", // New: save check type
        isHidden: isHiddenSb,
      };
      break;
    case "tag":
      const [tagName, descriptionTag, isHiddenTag] = result.formValues;
      if (!tagName) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "tag_name_required")
        );
        FuncAddRequirement(player, questId);
        return;
      }
      newRequirement = {
        type: reqType,
        playerTag: tagName,
        quantity: 1,
        description: descriptionTag || undefined,
        isHidden: isHiddenTag,
      }; // Quantity 1 for boolean-like completion
      break;
    case "property":
      const [
        propertyName,
        operatorPropIndex,
        propertyValueStr,
        descriptionProp,
        checkTypeIndexProp, // New: check type index
        isHiddenProp,
      ] = result.formValues;
      let propertyValue;
      try {
        propertyValue = JSON.parse(propertyValueStr); // Attempt to parse as JSON (number, boolean, string)
      } catch {
        propertyValue = propertyValueStr; // Treat as string if parsing fails
      }
      const propertyOperator = operators[operatorPropIndex];
      const checkTypeProp = checkTypes[checkTypeIndexProp]; // New: check type value
      if (
        !propertyName ||
        propertyValueStr === undefined ||
        propertyValueStr === null ||
        !propertyOperator
      ) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "property_name_value_operator_required")
        );
        FuncAddRequirement(player, questId);
        return;
      }
      newRequirement = {
        type: reqType,
        propertyName: propertyName,
        propertyValue: propertyValue,
        operator: propertyOperator, // Save selected operator for property
        quantity: 1, // Quantity 1 for boolean-like completion
        description: descriptionProp || undefined,
        checkType:
          checkTypeProp === getLocalizedText(player, "check_type_one_time")
            ? "one_time"
            : "continuous", // New: save check type
        isHidden: isHiddenProp,
      };
      break;
  }

  questManager.addRequirement(questId, newRequirement);

  player.sendMessage(
    getLocalizedText(player, "system_prefix") +
      getLocalizedText(player, "requirement_added")
  );
  FuncEditQuestDetails(player, questId);
}

/**
 * Manages existing requirements (edit/remove).
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncManageRequirements(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest || quest.requirements.length === 0) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "no_requirements_to_manage")
    );
    FuncEditQuestDetails(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "manage_requirements") + " " + quest.name)
    .body(getLocalizedText(player, "select_quest_to_view"));

  quest.requirements.forEach((req, i) => {
    let display = `§r${i + 1}. ${getLocalizedText(
      player,
      `req_type_${req.type.replace(" ", "_")}`
    )}: `;
    // Prioritize description > displayName > id for display in management list
    if (req.description) {
      display += req.description;
    } else {
      switch (req.type) {
        case "has_item":
        case "break_block":
        case "place_block":
        case "kill_mob":
          display += `§r${req.displayName || req.targetId} (x${req.quantity})`;
          break;
        case "location":
          display += `§rX:${Math.floor(req.x)}, Y:${Math.floor(
            req.y
          )}, Z:${Math.floor(req.z)} (${getLocalizedText(player, "radius")}: ${
            req.radius
          })`;
          break;
        case "scoreboard":
          display += `§r${req.scoreboardObjective} (${req.operator} ${
            req.quantity
          }) [${getLocalizedText(
            player,
            `check_type_${req.checkType || "continuous"}`
          )}]`;
          break;
        case "tag":
          display += `§r${req.playerTag}`;
          break;
        case "property":
          display += `§r${req.propertyName} (${req.operator} ${
            req.propertyValue
          }) [${getLocalizedText(
            player,
            `check_type_${req.checkType || "continuous"}`
          )}]`;
          break;
        default:
          display += `§7(${getLocalizedText(player, "unknown_requirement")})`;
          break;
      }
    }
    UI.button(
      display +
        (req.isHidden ? " §7(" + getLocalizedText(player, "hidden") + ")" : "")
    );
  });
  UI.button(
    getLocalizedText(player, "back_to_quest_management"),
    "textures/ui/arrow_left"
  );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }
  if (result.selection === quest.requirements.length) {
    // "Back" button
    FuncEditQuestDetails(player, questId);
    return;
  }

  const selectedIndex = result.selection;
  FuncEditRemoveRequirement(player, questId, selectedIndex);
}

/**
 * Edits or removes a specific requirement.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {number} index
 */
async function FuncEditRemoveRequirement(player, questId, index) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  const req = quest?.requirements[index];
  if (!quest || !req) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "req_not_found")
    );
    FuncManageRequirements(player, questId);
    return;
  }

  const checkTypeDisplay =
    req.type === "scoreboard" || req.type === "property"
      ? `\n${getLocalizedText(
          player,
          "check_type_label"
        )}: §b${getLocalizedText(
          player,
          `check_type_${req.checkType || "continuous"}`
        )}`
      : "";

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "edit_req_title", { index: index + 1 }))
    .body(
      `§r${getLocalizedText(player, "req_type")}: §b${getLocalizedText(
        player,
        `req_type_${req.type.replace(" ", "_")}`
      )}\n` +
        (req.targetId
          ? `${getLocalizedText(player, "target_id")}: §e${req.targetId}\n`
          : "") +
        (req.quantity !== undefined
          ? `${getLocalizedText(player, "quantity")}: §6${req.quantity}\n`
          : "") +
        (req.x !== undefined
          ? `${getLocalizedText(player, "location")}: X:${Math.floor(
              req.x
            )}, Y:${Math.floor(req.y)}, Z:${Math.floor(
              req.z
            )} (${getLocalizedText(player, "radius")}: ${req.radius})\n`
          : "") +
        (req.scoreboardObjective
          ? `${getLocalizedText(player, "objective")}: §e${
              req.scoreboardObjective
            } ${req.operator || ""} ${req.quantity}\n`
          : "") +
        (req.playerTag
          ? `${getLocalizedText(player, "player_tag")}: §e${req.playerTag}\n`
          : "") +
        (req.propertyName
          ? `${getLocalizedText(player, "property_name")}: §e${
              req.propertyName
            } (${getLocalizedText(player, "property_value")}: ${
              req.propertyValue
            }) (${getLocalizedText(player, "operator")}: ${req.operator})\n`
          : "") +
        (req.displayName
          ? `${getLocalizedText(player, "display_name")}: §a${
              req.displayName
            }\n`
          : "") +
        (req.description
          ? `${getLocalizedText(player, "description")}: §7${req.description}\n`
          : "") +
        `${getLocalizedText(player, "hidden")}: §d${
          req.isHidden
            ? getLocalizedText(player, "yes")
            : getLocalizedText(player, "no")
        }\n` +
        checkTypeDisplay // Add check type display
    )
    .button(
      getLocalizedText(player, "edit_requirement"),
      "textures/ui/editIcon.png"
    )
    .button(getLocalizedText(player, "delete_requirement"), "textures/ui/trash")
    .button(getLocalizedText(player, "back"), "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncManageRequirements(player, questId); // Return to manage requirements
    return;
  }
  if (result.selection === 2) {
    // "Back" button
    FuncManageRequirements(player, questId);
    return;
  }

  if (result.selection === 0) {
    // Edit
    let editUI;
    const operators = [">", "<", "=", ">=", "<=", "!="];
    const currentOperatorIndex = operators.indexOf(req.operator || "=");
    const checkTypes = [
      getLocalizedText(player, "check_type_continuous"),
      getLocalizedText(player, "check_type_one_time"),
    ];
    const currentCheckTypeIndex = checkTypes.indexOf(
      getLocalizedText(player, `check_type_${req.checkType || "continuous"}`)
    );

    switch (req.type) {
      case "has_item":
      case "break_block":
      case "place_block":
      case "kill_mob":
        editUI = new ModalFormData()
          .title(
            `${getLocalizedText(player, "edit_requirement")} ${getLocalizedText(
              player,
              `req_type_${req.type.replace(" ", "_")}`
            ).toUpperCase()}`
          )
          .textField(
            getLocalizedText(player, "target_id"),
            getLocalizedText(player, "target_id_placeholder"),
            { defaultValue: req.targetId }
          )
          .textField(
            getLocalizedText(player, "quantity"),
            getLocalizedText(player, "quantity_placeholder"),
            {
              defaultValue: String(req.quantity),
            }
          )
          .textField(
            getLocalizedText(player, "display_name"),
            getLocalizedText(player, "display_name_placeholder"),
            { defaultValue: req.displayName || "" }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: req.description || "" }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: req.isHidden || false,
          });
        break;
      case "location":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_requirement") +
              " " +
              getLocalizedText(player, "req_type_location")
          )
          .textField(
            getLocalizedText(player, "location_coordinates"), // Refined title
            getLocalizedText(player, "coords_placeholder"),
            { defaultValue: `${req.x} ${req.y} ${req.z}` }
          ) // Single text field for coordinates
          .textField(
            getLocalizedText(player, "radius"),
            getLocalizedText(player, "radius_placeholder"),
            {
              defaultValue: String(req.radius),
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_loc_placeholder"),
            { defaultValue: req.description || "" }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: req.isHidden || false,
          });
        break;
      case "scoreboard":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_requirement") +
              " " +
              getLocalizedText(player, "req_type_scoreboard")
          )
          .textField(
            getLocalizedText(player, "objective"),
            getLocalizedText(player, "objective_name_placeholder"),
            {
              defaultValue: req.scoreboardObjective,
            }
          )
          .dropdown(getLocalizedText(player, "operator_label"), operators, {
            defaultValue: currentOperatorIndex,
          }) // Dropdown for operator
          .textField(
            getLocalizedText(player, "score_amount"), // Refined title
            getLocalizedText(player, "score_amount_placeholder"),
            {
              defaultValue: String(req.quantity),
            }
          )
          .textField(
            getLocalizedText(player, "display_name"),
            getLocalizedText(player, "display_name_placeholder"),
            {
              defaultValue: req.displayName || "",
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_sb_placeholder"),
            { defaultValue: req.description || "" }
          )
          .dropdown(getLocalizedText(player, "check_type_label"), checkTypes, {
            defaultValue: currentCheckTypeIndex,
          }) // New dropdown for check type
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: req.isHidden || false,
          });
        break;
      case "tag":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_requirement") +
              " " +
              getLocalizedText(player, "req_type_tag")
          )
          .textField(
            getLocalizedText(player, "player_tag"),
            getLocalizedText(player, "tag_name_placeholder"),
            {
              defaultValue: req.playerTag,
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_tag_placeholder"),
            {
              defaultValue: req.description || "",
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: req.isHidden || false,
          });
        break;
      case "property":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_requirement") +
              " " +
              getLocalizedText(player, "req_type_property")
          )
          .textField(
            getLocalizedText(player, "property_name"),
            getLocalizedText(player, "property_name_placeholder"),
            {
              defaultValue: req.propertyName,
            }
          )
          .dropdown(getLocalizedText(player, "operator_label"), operators, {
            defaultValue: currentOperatorIndex,
          })
          .textField(
            getLocalizedText(player, "property_value"),
            getLocalizedText(player, "property_value_placeholder"),
            {
              defaultValue: String(req.propertyValue),
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: req.description || "" }
          )
          .dropdown(getLocalizedText(player, "check_type_label"), checkTypes, {
            defaultValue: currentCheckTypeIndex,
          }) // New dropdown for check type
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: req.isHidden || false,
          });
        break;
      default:
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "unknown_req_type_selected")
        );
        FuncManageRequirements(player, questId);
        return;
    }

    const editResult = await ForceOpen(player, editUI);
    if (editResult.canceled) {
      FuncEditRemoveRequirement(player, questId, index);
      return;
    }

    let updatedRequirement = { ...req };
    switch (req.type) {
      case "has_item":
      case "break_block":
      case "place_block":
      case "kill_mob":
        const [
          newTargetId,
          newQuantityStr,
          newDisplayName,
          newDescription,
          newIsHiddenItem,
        ] = editResult.formValues;
        const newQuantity = parseInt(newQuantityStr);
        if (!newTargetId || isNaN(newQuantity) || newQuantity <= 0) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_target_id_quantity")
          );
          FuncEditRemoveRequirement(player, questId, index);
          return;
        }
        Object.assign(updatedRequirement, {
          targetId: newTargetId,
          quantity: newQuantity,
          displayName: newDisplayName || undefined,
          description: newDescription || undefined,
          isHidden: newIsHiddenItem,
        });
        break;
      case "location":
        const [
          newCoordsString,
          newRadiusStr,
          newDescriptionLoc,
          newIsHiddenLoc,
        ] = editResult.formValues;
        const newParsedCoords = parseCoordinates(player, newCoordsString);
        const newRadius = parseFloat(newRadiusStr);
        if (!newParsedCoords || isNaN(newRadius) || newRadius < 0) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_coords_radius_edit")
          );
          FuncEditRemoveRequirement(player, questId, index);
          return;
        }
        Object.assign(updatedRequirement, {
          x: newParsedCoords.x,
          y: newParsedCoords.y,
          z: newParsedCoords.z,
          radius: newRadius,
          description: newDescriptionLoc || undefined,
          isHidden: newIsHiddenLoc,
        });
        break;
      case "scoreboard":
        const [
          newObjectiveName,
          newOperatorIndex,
          newScoreAmountStr,
          newDisplayNameSb,
          newDescriptionSb,
          newCheckTypeIndexSb, // New: check type index
          newIsHiddenSb,
        ] = editResult.formValues;
        const newScoreAmount = parseInt(newScoreAmountStr);
        const newOperator = operators[newOperatorIndex];
        const newCheckTypeSb = checkTypes[newCheckTypeIndexSb]; // New: check type value
        if (!newObjectiveName || isNaN(newScoreAmount) || !newOperator) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_objective_operator_score_edit")
          );
          FuncEditRemoveRequirement(player, questId, index);
          return;
        }
        Object.assign(updatedRequirement, {
          scoreboardObjective: newObjectiveName,
          operator: newOperator,
          quantity: newScoreAmount,
          displayName: newDisplayNameSb || undefined,
          description: newDescriptionSb || undefined,
          checkType:
            newCheckTypeSb === getLocalizedText(player, "check_type_one_time")
              ? "one_time"
              : "continuous", // New: update check type
          isHidden: newIsHiddenSb,
        });
        break;
      case "tag":
        const [newTagName, newDescriptionTag, newIsHiddenTag] =
          editResult.formValues;
        if (!newTagName) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "tag_name_required_edit")
          );
          FuncEditRemoveRequirement(player, questId, index);
          return;
        }
        Object.assign(updatedRequirement, {
          playerTag: newTagName,
          description: newDescriptionTag || undefined,
          isHidden: newIsHiddenTag,
        });
        break;
      case "property":
        const [
          newPropertyName,
          newOperatorPropIndex,
          newPropertyValueStr,
          newDescriptionProp,
          newCheckTypeIndexProp, // New: check type index
          newIsHiddenProp,
        ] = editResult.formValues;
        let newPropertyValue;
        try {
          newPropertyValue = JSON.parse(newPropertyValueStr);
        } catch {
          newPropertyValue = newPropertyValueStr;
        }
        const newPropertyOperator = operators[newOperatorPropIndex];
        const newCheckTypeProp = checkTypes[newCheckTypeIndexProp]; // New: check type value
        if (
          !newPropertyName ||
          newPropertyValueStr === undefined ||
          newPropertyValueStr === null ||
          !newPropertyOperator
        ) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(
                player,
                "property_name_value_operator_required_edit"
              )
          );
          FuncEditRemoveRequirement(player, questId, index);
          return;
        }
        Object.assign(updatedRequirement, {
          propertyName: newPropertyName,
          propertyValue: newPropertyValue,
          operator: newPropertyOperator,
          description: newDescriptionProp || undefined,
          checkType:
            newCheckTypeProp === getLocalizedText(player, "check_type_one_time")
              ? "one_time"
              : "continuous", // New: update check type
          isHidden: newIsHiddenProp,
        });
        break;
    }

    questManager.updateRequirement(questId, index, updatedRequirement);
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "requirement_updated")
    );
    FuncManageRequirements(player, questId);
  } else if (result.selection === 1) {
    // Delete
    const confirmUI = new MessageFormData()
      .title(getLocalizedText(player, "confirm_delete_req_title"))
      .body(
        getLocalizedText(player, "confirm_delete_req_body") +
          `\n§e${req.type}: ${
            req.displayName ||
            req.targetId ||
            req.scoreboardObjective ||
            req.playerTag ||
            req.propertyName ||
            JSON.stringify(req.propertyValue)
          }`
      )
      .button1(getLocalizedText(player, "delete_confirmed"))
      .button2(getLocalizedText(player, "delete_canceled"));
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.removeRequirement(questId, index);
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "requirement_deleted")
      );
    } else {
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "delete_req_canceled")
      );
    }
    FuncManageRequirements(player, questId);
  }
}

/**
 * Allows adding a new reward to a quest.
 * Now uses a dropdown for reward type.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncAddReward(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    FuncManageQuests(player);
    return;
  }

  const rewardTypes = [
    getLocalizedText(player, "reward_type_give_item"),
    getLocalizedText(player, "reward_type_scoreboard"),
    getLocalizedText(player, "reward_type_structure"),
    getLocalizedText(player, "reward_type_command"),
    getLocalizedText(player, "reward_type_script"),
    getLocalizedText(player, "reward_type_property"),
  ];
  const rewardTypeValues = [
    "give_item",
    "scoreboard",
    "structure",
    "command",
    "script",
    "property",
  ];

  const typeSelectionUI = new ModalFormData()
    .title(getLocalizedText(player, "add_reward_title"))
    .dropdown(getLocalizedText(player, "select_reward_type"), rewardTypes);

  const typeResult = await ForceOpen(player, typeSelectionUI);
  if (typeResult.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }

  const [selectedTypeIndex] = typeResult.formValues;
  const rewardType = rewardTypeValues[selectedTypeIndex];

  let UI;
  let newReward;
  const propertyOperators = [
    getLocalizedText(player, "property_operator_set"),
    getLocalizedText(player, "property_operator_add"),
    getLocalizedText(player, "property_operator_subtract"),
  ]; // Operators for property rewards

  switch (rewardType) {
    case "give_item":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_give_item"))
        .textField(
          getLocalizedText(player, "item_id"), // Refined title
          getLocalizedText(player, "item_id_placeholder")
        )
        .textField(
          getLocalizedText(player, "quantity"),
          getLocalizedText(player, "quantity_placeholder"),
          {
            defaultValue: "1",
          }
        )
        .textField(
          getLocalizedText(player, "item_lore"), // Refined title
          getLocalizedText(player, "item_lore_placeholder"),
          { defaultValue: "" }
        )
        .textField(
          getLocalizedText(player, "item_enchants"), // Refined title
          getLocalizedText(player, "item_enchants_placeholder"),
          { defaultValue: "" }
        )
        .textField(
          getLocalizedText(player, "display_name"),
          getLocalizedText(player, "display_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_item_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "scoreboard":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_scoreboard"))
        .textField(
          getLocalizedText(player, "objective"),
          getLocalizedText(player, "objective_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "score_to_add"), // Refined title
          getLocalizedText(player, "score_to_add_placeholder"),
          {
            defaultValue: "1",
          }
        )
        .textField(
          getLocalizedText(player, "display_name"),
          getLocalizedText(player, "display_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_scoreboard_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "structure":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_structure"))
        .textField(
          getLocalizedText(player, "structure_id"), // Refined title
          getLocalizedText(player, "structure_id_placeholder")
        )
        .textField(
          getLocalizedText(player, "structure_count"), // Refined title
          getLocalizedText(player, "structure_count_placeholder"),
          {
            defaultValue: "1",
          }
        )
        .textField(
          getLocalizedText(player, "display_name"),
          getLocalizedText(player, "display_name_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_structure_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "command":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_command"))
        .textField(
          getLocalizedText(player, "command_string"), // Refined title
          getLocalizedText(player, "command_string_placeholder"),
          {
            maxLength: 200,
          }
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_command_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "script":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_script"))
        .textField(
          getLocalizedText(player, "script_string"), // Refined title
          getLocalizedText(player, "script_string_placeholder"),
          {
            maxLength: 500,
            placeholder: getLocalizedText(
              player,
              "script_player_variable_hint"
            ),
          }
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          {
            maxLength: 100,
          }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_script_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    case "property":
      UI = new ModalFormData()
        .title(getLocalizedText(player, "reward_type_property"))
        .textField(
          getLocalizedText(player, "property_name"),
          getLocalizedText(player, "property_name_placeholder")
        )
        .dropdown(
          getLocalizedText(player, "property_operator_label"),
          propertyOperators
        ) // New dropdown for property operator
        .textField(
          getLocalizedText(player, "property_value"),
          getLocalizedText(player, "property_value_reward_placeholder")
        )
        .textField(
          getLocalizedText(player, "optional_description"), // Refined title
          getLocalizedText(player, "optional_description_placeholder"),
          { maxLength: 100 }
        )
        .textField(
          getLocalizedText(player, "reward_message"), // Refined title
          getLocalizedText(player, "reward_message_placeholder"),
          {
            maxLength: 100,
            placeholder: getLocalizedText(
              player,
              "default_property_reward_message"
            ),
          }
        )
        .toggle(getLocalizedText(player, "hide_from_player_list"), {
          defaultValue: false,
        }); // New toggle
      break;
    default:
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "unknown_reward_type_selected")
      );
      FuncAddReward(player, questId);
      return;
  }

  const rewardResult = await ForceOpen(player, UI);
  if (rewardResult.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }

  switch (rewardType) {
    case "give_item":
      const [
        itemTypeId,
        quantityStr,
        loreStr,
        enchantsStr,
        displayName,
        description,
        rewardMessageItem,
        isHiddenItem,
      ] = rewardResult.formValues;
      const itemQuantity = parseInt(quantityStr);
      const itemLore = loreStr
        ? loreStr.split(",").map((s) => s.trim())
        : undefined;
      const itemEnchants = enchantsStr
        ? enchantsStr
            .split(",")
            .map((s) => {
              const parts = s.trim().split(":");
              return parts.length === 2
                ? { id: parts[0], level: parseInt(parts[1]) || 1 }
                : null;
            })
            .filter((e) => e)
        : undefined;

      if (!itemTypeId || isNaN(itemQuantity) || itemQuantity <= 0) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_item_id_quantity")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        itemTypeId,
        itemQuantity,
        itemLore,
        itemEnchants,
        displayName: displayName || undefined,
        description: description || undefined,
        rewardMessage: rewardMessageItem || undefined,
        isHidden: isHiddenItem,
      };
      break;
    case "scoreboard":
      const [
        objectiveName,
        scoreAmountStr,
        displayNameSb,
        descriptionSb,
        rewardMessageSb,
        isHiddenSb,
      ] = rewardResult.formValues;
      const scoreAmount = parseInt(scoreAmountStr);
      if (!objectiveName || isNaN(scoreAmount)) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_objective_score")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        scoreboardObjective: objectiveName,
        scoreboardScore: scoreAmount,
        displayName: displayNameSb || undefined,
        description: descriptionSb || undefined,
        rewardMessage: rewardMessageSb || undefined,
        isHidden: isHiddenSb,
      };
      break;
    case "structure":
      const [
        structureId,
        countStr,
        displayNameStruct,
        descriptionStruct,
        rewardMessageStruct,
        isHiddenStruct,
      ] = rewardResult.formValues;
      const structureCount = parseInt(countStr);
      if (!structureId || isNaN(structureCount) || structureCount <= 0) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "invalid_structure_id_count")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        structureId,
        structureCount,
        displayName: displayNameStruct || undefined,
        description: descriptionStruct || undefined,
        rewardMessage: rewardMessageStruct || undefined,
        isHidden: isHiddenStruct,
      };
      break;
    case "command":
      const [commandString, descriptionCmd, rewardMessageCmd, isHiddenCmd] =
        rewardResult.formValues;
      if (!commandString) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "command_string_required")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        commandString,
        description: descriptionCmd || undefined,
        rewardMessage: rewardMessageCmd || undefined,
        isHidden: isHiddenCmd,
      };
      break;
    case "script":
      const [
        scriptString,
        descriptionScript,
        rewardMessageScript,
        isHiddenScript,
      ] = rewardResult.formValues;
      if (!scriptString) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "script_code_required")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        scriptString,
        description: descriptionScript || undefined,
        rewardMessage: rewardMessageScript || undefined,
        isHidden: isHiddenScript,
      };
      break;
    case "property":
      const [
        propertyName,
        operatorPropIndex, // New: operator index
        propertyValueStr,
        descriptionProp,
        rewardMessageProp,
        isHiddenProp,
      ] = rewardResult.formValues;
      let propertyValue;
      try {
        propertyValue = JSON.parse(propertyValueStr);
      } catch {
        propertyValue = propertyValueStr;
      }
      const propertyRewardOperator = propertyOperators[operatorPropIndex]; // Get operator string
      if (
        !propertyName ||
        propertyValueStr === undefined ||
        propertyValueStr === null ||
        !propertyRewardOperator // Check operator
      ) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "property_name_value_required")
        );
        FuncAddReward(player, questId);
        return;
      }
      newReward = {
        type: rewardType,
        propertyName,
        propertyValue,
        operator: propertyRewardOperator, // Save operator
        description: descriptionProp || undefined,
        rewardMessage: rewardMessageProp || undefined,
        isHidden: isHiddenProp,
      };
      break;
  }

  questManager.addReward(questId, newReward);
  player.sendMessage(
    getLocalizedText(player, "system_prefix") +
      getLocalizedText(player, "reward_added")
  );
  FuncEditQuestDetails(player, questId);
}

/**
 * Manages existing rewards (edit/remove).
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncManageRewards(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest || quest.rewards.length === 0) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "no_rewards_to_manage")
    );
    FuncEditQuestDetails(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "manage_rewards") + " " + quest.name)
    .body(getLocalizedText(player, "select_quest_to_view"));

  quest.rewards.forEach((reward, i) => {
    let display = `§r${i + 1}. ${getLocalizedText(
      player,
      `reward_type_${reward.type.replace(" ", "_")}`
    )}: ${reward.displayName || ""}`;
    if (reward.itemTypeId)
      display += ` x${reward.itemQuantity} ${reward.itemTypeId}`;
    if (reward.scoreboardObjective)
      display += ` ${reward.scoreboardScore} ${reward.scoreboardObjective}`;
    if (reward.structureId)
      display += ` x${reward.structureCount} ${reward.structureId}`;
    if (reward.commandString)
      display += ` ${getLocalizedText(
        player,
        "command"
      )}: '${reward.commandString.substring(0, 20)}...'`;
    if (reward.scriptString)
      display += ` ${getLocalizedText(
        player,
        "script"
      )}: '${reward.scriptString.substring(0, 20)}...'`;
    if (reward.propertyName)
      display += ` ${getLocalizedText(player, "property")}: '${
        reward.propertyName
      }' ${reward.operator || "="} '${reward.propertyValue}'`; // Display operator
    UI.button(
      display +
        (reward.isHidden
          ? " §7(" + getLocalizedText(player, "hidden") + ")"
          : "")
    );
  });
  UI.button(
    getLocalizedText(player, "back_to_quest_management"),
    "textures/ui/arrow_left"
  );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncEditQuestDetails(player, questId); // Return to quest details
    return;
  }
  if (result.selection === quest.rewards.length) {
    // "Back" button
    FuncEditQuestDetails(player, questId);
    return;
  }

  const selectedIndex = result.selection;
  FuncEditRemoveReward(player, questId, selectedIndex);
}

/**
 * Edits or removes a specific reward.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {number} index
 */
async function FuncEditRemoveReward(player, questId, index) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  const reward = quest?.rewards[index];
  if (!quest || !reward) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "reward_not_found")
    );
    FuncManageRewards(player, questId);
    return;
  }

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "edit_reward_title", { index: index + 1 }))
    .body(
      `§r${getLocalizedText(player, "req_type")}: §b${getLocalizedText(
        player,
        `reward_type_${reward.type.replace(" ", "_")}`
      )}\n${getLocalizedText(player, "display_name")}: §e${
        reward.displayName || "N/A"
      }\n` +
        `${getLocalizedText(player, "hidden")}: §d${
          reward.isHidden
            ? getLocalizedText(player, "yes")
            : getLocalizedText(player, "no")
        }\n`
    )
    .button(getLocalizedText(player, "edit_reward"), "textures/ui/editIcon")
    .button(getLocalizedText(player, "delete_reward"), "textures/ui/trash")
    .button(getLocalizedText(player, "back"), "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncManageRewards(player, questId); // Return to manage rewards
    return;
  }
  if (result.selection === 2) {
    // "Back" button
    FuncManageRewards(player, questId);
    return;
  }

  if (result.selection === 0) {
    // Edit
    let editUI;
    const propertyOperators = [
      getLocalizedText(player, "property_operator_set"),
      getLocalizedText(player, "property_operator_add"),
      getLocalizedText(player, "property_operator_subtract"),
    ]; // Operators for property rewards
    const currentPropertyOperatorIndex = propertyOperators.indexOf(
      reward.operator || getLocalizedText(player, "property_operator_set")
    );

    switch (reward.type) {
      case "give_item":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_give_item")
          )
          .textField(
            getLocalizedText(player, "item_id"), // Refined title
            getLocalizedText(player, "item_id_placeholder"),
            {
              defaultValue: reward.itemTypeId || "",
            }
          )
          .textField(
            getLocalizedText(player, "quantity"),
            getLocalizedText(player, "quantity_placeholder"),
            {
              defaultValue: String(reward.itemQuantity || 1),
            }
          )
          .textField(
            getLocalizedText(player, "item_lore"), // Refined title
            getLocalizedText(player, "item_lore_placeholder"),
            { defaultValue: reward.itemLore?.join(",") || "" }
          )
          .textField(
            getLocalizedText(player, "item_enchants"), // Refined title
            getLocalizedText(player, "item_enchants_placeholder"),
            {
              defaultValue:
                reward.itemEnchants
                  ?.map((e) => `${e.id}:${e.level}`)
                  .join(",") || "",
            }
          )
          .textField(
            getLocalizedText(player, "display_name"),
            getLocalizedText(player, "display_name_placeholder"),
            {
              defaultValue: reward.displayName || "",
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: reward.description || "" }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_item_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      case "scoreboard":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_scoreboard")
          )
          .textField(
            getLocalizedText(player, "objective"),
            getLocalizedText(player, "objective_name_placeholder"),
            {
              defaultValue: reward.scoreboardObjective || "",
            }
          )
          .textField(
            getLocalizedText(player, "score_to_add"), // Refined title
            getLocalizedText(player, "score_to_add_placeholder"),
            {
              defaultValue: String(reward.scoreboardScore || 1),
            }
          )
          .textField(
            getLocalizedText(player, "display_name"),
            getLocalizedText(player, "display_name_placeholder"),
            {
              defaultValue: reward.displayName || "",
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: reward.description || "" }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_scoreboard_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      case "structure":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_structure")
          )
          .textField(
            getLocalizedText(player, "structure_id"), // Refined title
            getLocalizedText(player, "structure_id_placeholder"),
            {
              defaultValue: reward.structureId || "",
            }
          )
          .textField(
            getLocalizedText(player, "structure_count"), // Refined title
            getLocalizedText(player, "structure_count_placeholder"),
            {
              defaultValue: String(reward.structureCount || 1),
            }
          )
          .textField(
            getLocalizedText(player, "display_name"),
            getLocalizedText(player, "display_name_placeholder"),
            {
              defaultValue: reward.displayName || "",
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: reward.description || "" }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_structure_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      case "command":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_command")
          )
          .textField(
            getLocalizedText(player, "command_string"), // Refined title
            getLocalizedText(player, "command_string_placeholder"),
            {
              defaultValue: reward.commandString || "",
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            {
              defaultValue: reward.description || "",
            }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_command_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      case "script":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_script")
          )
          .textField(
            getLocalizedText(player, "script_string"), // Refined title
            getLocalizedText(player, "script_string_placeholder"),
            {
              defaultValue: reward.scriptString || "",
              placeholder: getLocalizedText(
                player,
                "script_player_variable_hint"
              ),
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            {
              defaultValue: reward.description || "",
            }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_script_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      case "property":
        editUI = new ModalFormData()
          .title(
            getLocalizedText(player, "edit_reward") +
              " " +
              getLocalizedText(player, "reward_type_property")
          )
          .textField(
            getLocalizedText(player, "property_name"),
            getLocalizedText(player, "property_name_placeholder"),
            {
              defaultValue: reward.propertyName || "",
            }
          )
          .dropdown(
            getLocalizedText(player, "property_operator_label"),
            propertyOperators,
            {
              defaultValue: currentPropertyOperatorIndex,
            }
          ) // New dropdown for property operator
          .textField(
            getLocalizedText(player, "property_value"),
            getLocalizedText(player, "property_value_reward_placeholder"),
            {
              defaultValue: String(reward.propertyValue),
            }
          )
          .textField(
            getLocalizedText(player, "optional_description"), // Refined title
            getLocalizedText(player, "optional_description_placeholder"),
            { defaultValue: reward.description || "" }
          )
          .textField(
            getLocalizedText(player, "reward_message"), // Refined title
            getLocalizedText(player, "reward_message_placeholder"),
            {
              defaultValue: reward.rewardMessage || "",
              placeholder: getLocalizedText(
                player,
                "default_property_reward_message"
              ),
            }
          )
          .toggle(getLocalizedText(player, "hide_from_player_list"), {
            defaultValue: reward.isHidden || false,
          });
        break;
      default:
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "unknown_reward_type_selected")
        );
        FuncManageRewards(player, questId);
        return;
    }

    const editResult = await ForceOpen(player, editUI);
    if (editResult.canceled) {
      FuncEditRemoveReward(player, questId, index);
      return;
    }

    let updatedReward = { ...reward };
    switch (reward.type) {
      case "give_item":
        const [
          itemTypeId,
          quantityStr,
          loreStr,
          enchantsStr,
          displayName,
          description,
          rewardMessageItem,
          isHiddenItem,
        ] = editResult.formValues;
        const itemQuantity = parseInt(quantityStr);
        const itemLore = loreStr
          ? loreStr.split(",").map((s) => s.trim())
          : undefined;
        const itemEnchants = enchantsStr
          ? enchantsStr
              .split(",")
              .map((s) => {
                const parts = s.trim().split(":");
                return parts.length === 2
                  ? { id: parts[0], level: parseInt(parts[1]) || 1 }
                  : null;
              })
              .filter((e) => e)
          : undefined;

        if (!itemTypeId || isNaN(itemQuantity) || itemQuantity <= 0) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_item_id_quantity")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          itemTypeId,
          itemQuantity,
          itemLore,
          itemEnchants,
          displayName: displayName || undefined,
          description: description || undefined,
          rewardMessage: rewardMessageItem || undefined,
          isHidden: isHiddenItem,
        });
        break;
      case "scoreboard":
        const [
          objectiveName,
          scoreAmountStr,
          displayNameSb,
          descriptionSb,
          rewardMessageSb,
          isHiddenSb,
        ] = editResult.formValues;
        const scoreAmount = parseInt(scoreAmountStr);
        if (!objectiveName || isNaN(scoreAmount)) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_objective_score")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          scoreboardObjective: objectiveName,
          scoreboardScore: scoreAmount,
          displayName: displayNameSb || undefined,
          description: descriptionSb || undefined,
          rewardMessage: rewardMessageSb || undefined,
          isHidden: isHiddenSb,
        });
        break;
      case "structure":
        const [
          structureId,
          countStr,
          displayNameStruct,
          descriptionStruct,
          rewardMessageStruct,
          isHiddenStruct,
        ] = editResult.formValues;
        const structureCount = parseInt(countStr);
        if (!structureId || isNaN(structureCount) || structureCount <= 0) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "invalid_structure_id_count")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          structureId,
          structureCount,
          displayName: displayNameStruct || undefined,
          description: descriptionStruct || undefined,
          rewardMessage: rewardMessageStruct || undefined,
          isHidden: isHiddenStruct,
        });
        break;
      case "command":
        const [commandString, descriptionCmd, rewardMessageCmd, isHiddenCmd] =
          editResult.formValues;
        if (!commandString) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "command_string_required")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          commandString,
          description: descriptionCmd || undefined,
          rewardMessage: rewardMessageCmd || undefined,
          isHidden: isHiddenCmd,
        });
        break;
      case "script":
        const [
          scriptString,
          descriptionScript,
          rewardMessageScript,
          isHiddenScript,
        ] = editResult.formValues;
        if (!scriptString) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "script_code_required")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          scriptString,
          description: descriptionScript || undefined,
          rewardMessage: rewardMessageScript || undefined,
          isHidden: isHiddenScript,
        });
        break;
      case "property":
        const [
          propertyName,
          operatorPropIndex, // New: operator index
          newPropertyValueStr,
          descriptionProp,
          rewardMessageProp,
          isHiddenProp,
        ] = editResult.formValues;
        let propertyValue;
        try {
          propertyValue = JSON.parse(newPropertyValueStr);
        } catch {
          propertyValue = newPropertyValueStr;
        }
        const propertyRewardOperator = propertyOperators[operatorPropIndex]; // Get operator string
        if (
          !propertyName ||
          newPropertyValueStr === undefined ||
          newPropertyValueStr === null ||
          !propertyRewardOperator // Check operator
        ) {
          player.sendMessage(
            getLocalizedText(player, "system_prefix") +
              getLocalizedText(player, "property_name_value_required")
          );
          FuncEditRemoveReward(player, questId, index);
          return;
        }
        Object.assign(updatedReward, {
          propertyName,
          propertyValue,
          operator: propertyRewardOperator, // Save operator
          description: descriptionProp || undefined,
          rewardMessage: rewardMessageProp || undefined,
          isHidden: isHiddenProp,
        });
        break;
    }
    questManager.updateReward(questId, index, updatedReward);
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "reward_updated")
    );
    FuncManageRewards(player, questId);
  } else if (result.selection === 1) {
    // Delete
    const confirmUI = new MessageFormData()
      .title(getLocalizedText(player, "confirm_delete_req_title"))
      .body(
        getLocalizedText(player, "confirm_delete_reward_body") +
          `\n§e${reward.type}: ${
            reward.displayName ||
            reward.itemTypeId ||
            reward.scoreboardObjective ||
            reward.structureId ||
            reward.commandString ||
            reward.propertyName
          }`
      )
      .button1(getLocalizedText(player, "delete_confirmed"))
      .button2(getLocalizedText(player, "delete_canceled"));
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.removeReward(questId, index);
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "reward_deleted")
      );
    } else {
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "delete_reward_canceled")
      );
    }
    FuncManageRewards(player, questId);
  }
}

// --- Quest Management UI Flow ---

/**
 * Displays a list of all quests for management (edit/delete).
 * @param {import("@minecraft/server").Player} player
 */
async function FuncManageQuests(player) {
  if (!player.isValid) return; // Add player.isValid check
  const allQuests = questManager.getAllQuests();
  if (allQuests.length === 0) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "no_quests_created")
    );
    FuncMainMenu(player);
    return;
  }

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "manage_quests_title"))
    .body(getLocalizedText(player, "manage_quests_body"));

  allQuests.forEach((quest) => {
    UI.button(
      `${quest.name} §r- ${getLocalizedText(player, "quest_level_prefix")} ${
        quest.level
      }`,
      quest.texture
    );
  });
  UI.button(
    getLocalizedText(player, "reset_system_button"),
    "textures/ui/trash"
  ); // New button to reset
  UI.button(
    getLocalizedText(player, "back_to_main_menu"),
    "textures/ui/arrow_left"
  );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncMainMenu(player); // Return to main menu
    return;
  }
  if (result.selection === allQuests.length + 1) {
    // "Back" button
    FuncMainMenu(player);
    return;
  }

  if (result.selection === allQuests.length) {
    // Index of the new button
    FuncResetSystem(player);
  } else {
    const selectedQuest = allQuests[result.selection];
    FuncEditDeleteQuest(player, selectedQuest.id);
  }
}

/**
 * Allows editing or deleting a specific quest.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 */
async function FuncEditDeleteQuest(player, questId) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    FuncManageQuests(player);
    return;
  }

  const UI = new ActionFormData()
    .title(
      getLocalizedText(player, "edit_delete_quest_title", {
        questName: quest.name,
      })
    )
    .body(getQuestDetailsText(quest, player)) // Still use full details for admin view
    .button(
      getLocalizedText(player, "edit_quest_details_button"),
      "textures/ui/editIcon"
    )
    .button(
      getLocalizedText(player, "duplicate_quest_button"), // New button for duplication
      "textures/ui/copy" // Placeholder texture, adjust as needed
    )
    .button(
      getLocalizedText(player, "delete_quest_button"),
      "textures/ui/trash"
    )
    .button(
      getLocalizedText(player, "back_to_quest_management"),
      "textures/ui/arrow_left"
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncManageQuests(player); // Return to quest management
    return;
  }
  // Adjust selection indices due to new button
  if (result.selection === 3) {
    // "Back" button (now at index 3)
    FuncManageQuests(player);
    return;
  }

  if (result.selection === 0) {
    FuncEditQuestDetails(player, questId);
  } else if (result.selection === 1) {
    // Duplicate Quest button (now at index 1)
    const confirmUI = new MessageFormData()
      .title(getLocalizedText(player, "confirm_duplicate_quest_title"))
      .body(
        getLocalizedText(player, "confirm_duplicate_quest_body", {
          questName: quest.name,
        })
      )
      .button1(getLocalizedText(player, "confirm_duplicate"))
      .button2(getLocalizedText(player, "cancel_duplicate"));
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      const duplicatedQuest = questManager.duplicateQuest(questId);
      if (duplicatedQuest) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "quest_duplicated_success", {
              questName: duplicatedQuest.name,
            })
        );
      } else {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "quest_duplicated_error")
        );
      }
    } else {
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "duplicate_quest_canceled")
      );
    }
    FuncManageQuests(player); // Return to manage quests after duplication attempt
  } else if (result.selection === 2) {
    // Delete Quest button (now at index 2)
    const confirmUI = new MessageFormData()
      .title(getLocalizedText(player, "confirm_delete_req_title"))
      .body(
        getLocalizedText(player, "confirm_delete_quest_body", {
          questName: quest.name,
        })
      )
      .button1(getLocalizedText(player, "delete_confirmed"))
      .button2(getLocalizedText(player, "delete_canceled"));
    const confirmResult = await ForceOpen(player, confirmUI);

    if (!confirmResult.canceled && confirmResult.selection === 0) {
      questManager.deleteQuest(questId);
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "quest_deleted", { questName: quest.name })
      );
    } else {
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "delete_quest_canceled")
      );
    }
    FuncManageQuests(player);
  }
}

/**
 * Resets the entire quest system (deletes all quests and player progress).
 * @param {import("@minecraft/server").Player} player
 */
async function FuncResetSystem(player) {
  if (!player.isValid) return; // Add player.isValid check
  const confirmUI = new MessageFormData()
    .title(getLocalizedText(player, "confirm_reset_system_title"))
    .body(getLocalizedText(player, "confirm_reset_system_body"))
    .button1(getLocalizedText(player, "delete_confirmed"))
    .button2(getLocalizedText(player, "delete_canceled"));

  const result = await ForceOpen(player, confirmUI);

  if (!result.canceled && result.selection === 0) {
    // Confirm Yes
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "resetting_system")
    );
    try {
      questManager.deleteAllQuests();
      questManager.clearAllPlayerProgress();
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "reset_system_complete")
      );
    } catch (e) {
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "reset_system_error")
      );
      console.error("[SYSTEM RESET ERROR]", e);
    }
  } else {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "reset_system_canceled")
    );
  }
  FuncManageQuests(player); // Return to quest management menu
}

// --- Player-Facing Quest List UI ---

/**
 * Opens the main quest list selection menu (All, Unfinished, Completed, By Level).
 * @param {import("@minecraft/server").Player} player
 */
export async function FuncOpenQuestList(player) {
  if (!player.isValid) return; // Add player.isValid check
  const actionBarStatus = questManager.isPlayerActionBarDisplayEnabled(player)
    ? getLocalizedText(player, "actionbar_status_on")
    : getLocalizedText(player, "actionbar_status_off");

  const currentLangCode = player.getDynamicProperty("language") || "vi";
  const currentLangName = getLanguageName(currentLangCode);

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "player_quest_list_title"))
    .body(getLocalizedText(player, "player_quest_list_body"))
    .button(
      getLocalizedText(player, "all_quests_button"),
      "textures/ui/icon_book_writable"
    )
    .button(
      getLocalizedText(player, "unfinished_quests_button"),
      "textures/ui/icon_unlocked"
    )
    .button(
      getLocalizedText(player, "completed_quests_button"),
      "textures/ui/confirm"
    )
    .button(
      getLocalizedText(player, "infinity_quests_button"),
      "textures/items/coal"
    )
    .button(
      getLocalizedText(player, "quests_by_level_button"),
      "textures/items/diamond"
    )
    .button(
      getLocalizedText(player, "toggle_actionbar_display", {
        status: actionBarStatus,
      }),
      "textures/ui/refresh_hover"
    )
    .button(
      getLocalizedText(player, "change_language_button") +
        ` §r(§7${currentLangName}§r)`,
      "textures/ui/icon_setting"
    ) // New language button
    .button(
      getLocalizedText(player, "back_to_main_menu"),
      "textures/ui/arrow_left"
    );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    if (!player.hasTag("admin")) return; // If player is not admin, just close UI
    FuncMainMenu(player); // If admin, return to main menu
    return;
  }
  if (result.selection === 7) {
    // Updated index for "Back" button
    // "Back" button
    if (!player.hasTag("admin")) return;
    FuncMainMenu(player);
    return;
  }

  if (result.selection === 0) {
    FuncViewAllQuests(player);
  } else if (result.selection === 1) {
    FuncViewUnfinishedQuests(player);
  } else if (result.selection == 3) {
    FuncViewInfinityQuests(player);
  } else if (result.selection === 2) {
    FuncViewCompletedQuests(player);
  } else if (result.selection === 4) {
    FuncViewQuestsByLevel(player);
  } else if (result.selection === 5) {
    const newStatus = !questManager.isPlayerActionBarDisplayEnabled(player);
    questManager.setPlayerActionBarDisplayEnabled(player, newStatus);
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "actionbar_display_updated", {
          status: newStatus
            ? getLocalizedText(player, "actionbar_status_on")
            : getLocalizedText(player, "actionbar_status_off"),
        })
    );
    FuncOpenQuestList(player);
  } else if (result.selection === 6) {
    // Index for Change Language button
    FuncChangeLanguage(player);
  }
}

/**
 * Displays the language selection UI.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncChangeLanguage(player) {
  if (!player.isValid) return;

  const currentLangCode = player.getDynamicProperty("language") || "vi";
  const currentLangName = getLanguageName(currentLangCode);

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "change_language_button"))
    .body(
      `${getLocalizedText(player, "current_language", {
        langName: currentLangName,
      })}\n\n${getLocalizedText(player, "select_language")}`
    );

  const langCodes = Object.keys(languages);
  langCodes.forEach((code) => {
    UI.button(getLanguageName(code));
  });
  UI.button(getLocalizedText(player, "back"), "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);

  if (result.canceled || result.selection === langCodes.length) {
    FuncOpenQuestList(player); // Return to player quest list
    return;
  }

  const selectedLangCode = langCodes[result.selection];
  player.setDynamicProperty("language", selectedLangCode);
  player.sendMessage(
    getLocalizedText(player, "system_prefix") +
      getLocalizedText(player, "language_changed", {
        langName: getLanguageName(selectedLangCode),
      })
  );
  FuncOpenQuestList(player); // Refresh quest list with new language
}

/**
 * Displays a list of quests based on a filter.
 * @param {import("@minecraft/server").Player} player
 * @param {string} title Title for the quest list UI.
 * @param {function(Quest, PlayerQuestProgressEntry?): boolean} filterFn Function to filter quests.
 * @param {string} [backFunction='FuncOpenQuestList'] Name of the function to return to.
 * @param {string} [specificLevel=null] For "Quests by Level", the specific level to filter by.
 */
async function FuncViewFilteredQuests(
  player,
  title,
  filterFn,
  backFunction = "FuncOpenQuestList",
  specificLevel = null
) {
  if (!player.isValid) return; // Add player.isValid check
  let quests = questManager.getAllQuests();
  const playerProgress = questManager.getPlayerProgress(player);

  if (specificLevel) {
    quests = quests.filter(
      (q) => q.level.toLowerCase() === specificLevel.toLowerCase()
    );
  }

  const filteredQuests = quests.filter((quest) => {
    // Also check quest existence here before calling filterFn
    const questInManager = questManager.getQuest(quest.id);
    if (!questInManager) {
      // If the quest doesn't exist, reset player's status for this quest
      if (playerProgress[quest.id]?.status === "in_progress") {
        questManager.resetPlayerQuestProgress(player, quest.id);
      }
      return false; // Exclude deleted quests
    }
    return filterFn(quest, playerProgress[quest.id]);
  });

  if (filteredQuests.length === 0) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(
          player,
          specificLevel ? "no_quests_with_level" : "no_quests_in_category"
        )
    );
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel")
      FuncViewQuestsByLevel(player);
    return;
  }

  const UI = new ActionFormData()
    .title(title)
    .body(getLocalizedText(player, "select_quest_to_view"));
  filteredQuests.forEach((quest) => {
    const status = questManager.getQuestStatus(player, quest.id);
    const timesCompleted = questManager.getTimesCompleted(player, quest.id);
    const completionInfo =
      quest.maxCompletions === 0
        ? ``
        : ` (${timesCompleted}/${quest.maxCompletions})`;
    UI.button(
      `${quest.name} §r(${getLocalizedText(
        player,
        `quest_status_${status.replace(" ", "_")}`
      )}${completionInfo})§r`,
      quest.texture
    );
  });
  UI.button(getLocalizedText(player, "back"), "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel")
      FuncViewQuestsByLevel(player);
    return;
  }
  if (result.selection === filteredQuests.length) {
    // "Back" button
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel")
      FuncViewQuestsByLevel(player);
    return;
  }

  const selectedQuest = filteredQuests[result.selection];
  FuncViewQuestDetailsPlayer(
    player,
    selectedQuest.id,
    backFunction,
    specificLevel
  );
}

/**
 * Displays all quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewAllQuests(player) {
  if (!player.isValid) return; // Add player.isValid check
  await FuncViewFilteredQuests(
    player,
    getLocalizedText(player, "view_all_quests_title"),
    () => true,
    "FuncOpenQuestList"
  );
}

/**
 * Displays unfinished quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewUnfinishedQuests(player) {
  if (!player.isValid) return; // Add player.isValid check
  await FuncViewFilteredQuests(
    player,
    getLocalizedText(player, "view_unfinished_quests_title"),
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return (
        status === "in_progress" ||
        (status === "not_started" &&
          (quest.maxCompletions === 0 || timesCompleted < quest.maxCompletions))
      );
    },
    "FuncOpenQuestList"
  );
}

/**
 * Displays completed quests.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewCompletedQuests(player) {
  if (!player.isValid) return; // Add player.isValid check
  await FuncViewFilteredQuests(
    player,
    getLocalizedText(player, "view_completed_quests_title"),
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return quest.maxCompletions > 0 && timesCompleted >= quest.maxCompletions;
    },
    "FuncOpenQuestList"
  );
}

async function FuncViewInfinityQuests(player) {
  if (!player.isValid) return; // Add player.isValid check
  await FuncViewFilteredQuests(
    player,
    getLocalizedText(player, "view_infinity_quests_title"),
    (quest, progress) => {
      const status = questManager.getQuestStatus(player, quest.id);
      const timesCompleted = questManager.getTimesCompleted(player, quest.id);
      return quest.maxCompletions == 0;
    },
    "FuncOpenQuestList"
  );
}

/**
 * Displays quests categorized by level.
 * @param {import("@minecraft/server").Player} player
 */
async function FuncViewQuestsByLevel(player) {
  if (!player.isValid) return; // Add player.isValid check
  const allQuests = questManager.getAllQuests();
  const uniqueLevels = [...new Set(allQuests.map((q) => q.level))];

  if (uniqueLevels.length === 0) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "no_quests_with_level")
    );
    FuncOpenQuestList(player);
    return;
  }

  const UI = new ActionFormData()
    .title(getLocalizedText(player, "view_quests_by_level_title"))
    .body(getLocalizedText(player, "select_level_to_view"));

  uniqueLevels.forEach((level) => {
    UI.button(
      getLocalizedText(player, "level_quests_display", { level: level })
    );
  });
  UI.button(
    getLocalizedText(player, "back_to_quest_list"),
    "textures/ui/arrow_left"
  );

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    FuncOpenQuestList(player); // Return to quest list
    return;
  }
  if (result.selection === uniqueLevels.length) {
    // "Back" button
    FuncOpenQuestList(player);
    return;
  }

  const selectedLevel = uniqueLevels[result.selection];
  await FuncViewFilteredQuests(
    player,
    getLocalizedText(player, "level_quests_display", { level: selectedLevel }),
    (quest) => true,
    "FuncViewQuestsByLevel",
    selectedLevel
  );
}

/**
 * Displays full details of a single quest to the player, with options like 'Start' or 'Reset Progress'.
 * @param {import("@minecraft/server").Player} player
 * @param {string} questId
 * @param {string} [backFunction='FuncOpenQuestList'] Name of the function to return to.
 * @param {string} [specificLevel=null] Used when returning from "Quests by Level"
 */
async function FuncViewQuestDetailsPlayer(
  player,
  questId,
  backFunction = "FuncOpenQuestList",
  specificLevel = null
) {
  if (!player.isValid) return; // Add player.isValid check
  const quest = questManager.getQuest(questId);
  if (!quest) {
    player.sendMessage(
      getLocalizedText(player, "system_prefix") +
        getLocalizedText(player, "quest_not_found")
    );
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel" && specificLevel)
      FuncViewFilteredQuests(
        player,
        getLocalizedText(player, "level_quests_display", {
          level: specificLevel,
        }),
        (q) => true,
        "FuncViewQuestsByLevel",
        specificLevel
      );
    else FuncOpenQuestList(player);
    return;
  }

  const playerStatus = questManager.getQuestStatus(player, questId);
  const timesCompleted = questManager.getTimesCompleted(player, questId);
  const maxCompletions = quest.maxCompletions;

  const playerHasActiveLockingQuest =
    questManager.hasLockingQuestInProgress(player); // Check for ANY active locking quest
  const thisQuestIsLocking = quest.locksOtherQuests; // Check if THIS quest being viewed is a locking quest
  const playerHasAnyQuestActive = questManager.hasAnyQuestInProgress(player); // Check for ANY active quest (locking or non-locking)

  let actionButtonText = "";
  let canStartQuest = false;
  let canResetProgress = false;
  let cannotStartReason = "";

  // Determine button text and actions based on quest status and completion count
  if (playerStatus === "not_started" || playerStatus === "completed") {
    // This covers both starting a new quest and restarting a completed one
    if (maxCompletions === 0 || timesCompleted < maxCompletions) {
      // If repeatable or not yet maxed out
      if (playerHasActiveLockingQuest) {
        // Rule 1: If player has ANY active locking quest, cannot start ANY new quest.
        actionButtonText = getLocalizedText(
          player,
          "cannot_start_other_quest_locking"
        );
        cannotStartReason = getLocalizedText(
          player,
          "reason_other_quest_locking"
        );
      } else if (thisQuestIsLocking && playerHasAnyQuestActive) {
        // Rule 2: If THIS quest is locking, and player has ANY other quest active (even non-locking), cannot start THIS quest.
        actionButtonText = getLocalizedText(
          player,
          "cannot_start_this_quest_locking"
        );
        cannotStartReason = getLocalizedText(
          player,
          "reason_this_quest_locking"
        );
      } else {
        actionButtonText =
          playerStatus === "not_started"
            ? getLocalizedText(player, "start_quest")
            : getLocalizedText(player, "restart_quest");
        canStartQuest = true;
      }
    } else {
      // Quest has reached max completions
      actionButtonText = getLocalizedText(player, "max_completions_reached");
    }
  } else if (playerStatus === "in_progress") {
    actionButtonText = getLocalizedText(player, "reset_progress");
    canResetProgress = true;
  }

  // Calculate overall progress percentage for display
  let totalCurrentProgress = 0;
  let totalTargetQuantity = 0;
  let allBooleanRequirementsMet = true; // For quests with only boolean requirements

  const inventory = player.getComponent(
    EntityInventoryComponent.componentId
  )?.container;

  // Condense basic quest info for player
  let playerQuestInfo = getLocalizedText(player, "quest_info_header", {
    questName: quest.name,
    questLevel: quest.level,
  });
  if (quest.locksOtherQuests) {
    playerQuestInfo += getLocalizedText(player, "quest_info_locking");
  }
  playerQuestInfo += `\n${getLocalizedText(
    player,
    "quest_info_max_completions",
    {
      maxCompletions:
        quest.maxCompletions === 0
          ? getLocalizedText(player, "infinity_quests")
          : quest.maxCompletions,
    }
  )}`;
  playerQuestInfo += `\n${getLocalizedText(player, "quest_info_description", {
    description: quest.description,
  })}`;

  let progressDisplaySection = "";
  if (playerStatus === "in_progress") {
    quest.requirements.forEach((req, i) => {
      // Only count non-hidden requirements for overall progress
      if (req.isHidden) return;

      let current = questManager.getRequirementProgress(player, questId, i);
      let targetQty = req.quantity || 1; // Default to 1 for non-quantity types

      // If it's a 'one_time' check and already completed, treat as met for overall progress
      if (
        (req.type === "scoreboard" || req.type === "property") &&
        req.checkType === "one_time"
      ) {
        current = current >= 1 ? targetQty : 0; // Treat as fully met for overall progress calculation
      }
      // For 'continuous' scoreboard/property, 'current' is already the live value.
      // For other types (has_item, break_block, etc.), 'current' is the accumulated progress.

      totalCurrentProgress += Math.min(current, targetQty); // Cap current at target
      totalTargetQuantity += targetQty;

      if (targetQty === 1 && current === 0) {
        allBooleanRequirementsMet = false; // If any boolean requirement is not met, set to false
      }
    });

    let overallPercentage;
    if (totalTargetQuantity === 0) {
      // If there are no quantity-based requirements, check if all boolean requirements are met
      overallPercentage = allBooleanRequirementsMet ? 100 : 0;
    } else {
      overallPercentage = Math.floor(
        (totalCurrentProgress / totalTargetQuantity) * 100
      );
    }

    progressDisplaySection =
      `§r${getLocalizedText(player, "current_status")}: §7${getLocalizedText(
        player,
        `quest_status_${playerStatus.replace(" ", "_")}`
      )}\n` +
      `§r${getLocalizedText(player, "completed_times")}: §7${timesCompleted}${
        maxCompletions === 0 ? "" : `/${maxCompletions}`
      }\n` +
      `§r${getLocalizedText(
        player,
        "progress_display"
      )} §6${overallPercentage}%§r\n\n` +
      // Only display non-hidden requirements and rewards
      (quest.requirements.filter((r) => !r.isHidden).length > 0
        ? "\n§l§r" +
          getLocalizedText(player, "quest_requirements_prefix") +
          "§r\n"
        : "") +
      quest.requirements
        .filter((r) => !r.isHidden)
        .map((req, i) => {
          let reqText = getLocalizedText(player, "quest_detail_req_prefix", {
            index: i + 1,
          });
          let currentProgress = 0; // Re-initialize for individual requirement
          let targetQtyForDisplay = req.quantity || 1; // Default to 1 for boolean types

          // Calculate currentProgress based on requirement type
          switch (req.type) {
            case "has_item":
              if (inventory) {
                for (let slot = 0; slot < inventory.size; slot++) {
                  const item = inventory.getItem(slot);
                  if (item && item.typeId === req.targetId) {
                    currentProgress += item.amount;
                  }
                }
              }
              break;
            case "break_block":
            case "place_block":
            case "kill_mob":
              currentProgress = questManager.getRequirementProgress(
                player,
                questId,
                i
              );
              break;
            case "location":
            case "tag":
              currentProgress = questManager.getRequirementProgress(
                player,
                questId,
                i
              );
              break;
            case "scoreboard":
              if (req.checkType === "one_time") {
                currentProgress = questManager.getRequirementProgress(
                  player,
                  questId,
                  i
                );
              } else {
                currentProgress = getPlayerScore(
                  player,
                  req.scoreboardObjective
                );
              }
              break;
            case "property":
              if (req.checkType === "one_time") {
                currentProgress = questManager.getRequirementProgress(
                  player,
                  questId,
                  i
                );
              } else {
                currentProgress =
                  player.getDynamicProperty(req.propertyName) ?? 0;
              }
              break;
          }

          let displayProgress = "";
          // Determine how to display progress based on requirement type
          if (
            ["has_item", "break_block", "place_block", "kill_mob"].includes(
              req.type
            )
          ) {
            // Cap the displayed current progress at the target quantity
            displayProgress = ` §7(${Math.min(
              currentProgress,
              targetQtyForDisplay
            )}/${targetQtyForDisplay})§r`;
          } else if (req.type === "location" || req.type === "tag") {
            displayProgress =
              currentProgress > 0
                ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                : ` §c(${getLocalizedText(
                    player,
                    "req_status_not_completed"
                  )})§r`;
          } else if (req.type === "scoreboard" || req.type === "property") {
            if (req.checkType === "one_time") {
              displayProgress =
                currentProgress > 0
                  ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                  : ` §c(${getLocalizedText(
                      player,
                      "req_status_not_completed"
                    )})§r`;
            } else {
              // continuous
              const liveValue =
                req.type === "scoreboard"
                  ? getPlayerScore(player, req.scoreboardObjective)
                  : player.getDynamicProperty(req.propertyName) ?? 0;
              displayProgress = evaluateComparison(
                liveValue,
                req.operator,
                req.quantity
              )
                ? ` §a(${getLocalizedText(player, "req_status_completed")})§r`
                : ` §c(${getLocalizedText(
                    player,
                    "req_status_not_completed"
                  )})§r`;
              // Also show current value for continuous scoreboard/property if relevant, capped at target
              if (
                typeof liveValue === "number" &&
                typeof req.quantity === "number"
              ) {
                displayProgress += ` §7(${Math.min(liveValue, req.quantity)}/${
                  req.quantity
                })§r`;
              }
            }
          }

          const qty = req.quantity;
          const nameOrId = req.displayName
            ? `§a${req.displayName}`
            : req.targetId
            ? `§e${req.targetId}`
            : req.scoreboardObjective
            ? `§a${req.scoreboardObjective}`
            : req.playerTag
            ? `§e${req.playerTag}`
            : req.propertyName
            ? `§a${req.propertyName}`
            : `§7(${getLocalizedText(player, "unknown_requirement")})`;

          if (req.description) {
            reqText += req.description
              .replace(/\{amount\}/g, `§6${qty}§r`)
              .replace(/\{name\}/g, `§a${nameOrId}§r`)
              .replace(/\{x\}/g, `§b${Math.floor(req.x || 0)}§r`)
              .replace(/\{y\}/g, `§b${Math.floor(req.y || 0)}§r`)
              .replace(/\{z\}/g, `§b${Math.floor(req.z || 0)}§r`)
              .replace(/\{radius\}/g, `§e${req.radius || 0}§r`)
              .replace(
                /\{objective\}/g,
                `§a${req.scoreboardObjective || "N/A"}§r`
              )
              .replace(/\{tag\}/g, `§e${req.playerTag || "N/A"}§r`)
              .replace(/\{property\}/g, `§a${req.propertyName || "N/A"}§r`)
              .replace(
                /\{value\}/g,
                `§e${
                  req.propertyValue !== undefined ? req.propertyValue : "N/A"
                }§r`
              )
              .replace(/\{operator\}/g, `§e${req.operator || "N/A"}§r`);
          } else {
            const formatted = `§6x${qty} ${nameOrId}`;
            switch (req.type) {
              case "has_item":
                reqText += getLocalizedText(player, "quest_req_has_item", {
                  formatted,
                });
                break;
              case "break_block":
                reqText += getLocalizedText(player, "quest_req_break_block", {
                  formatted,
                });
                break;
              case "place_block":
                reqText += getLocalizedText(player, "quest_req_place_block", {
                  formatted,
                });
                break;
              case "kill_mob":
                reqText += getLocalizedText(player, "quest_req_kill_mob", {
                  formatted,
                });
                break;
              case "location":
                reqText += getLocalizedText(player, "quest_req_location", {
                  x: Math.floor(req.x),
                  y: Math.floor(req.y),
                  z: Math.floor(req.z),
                  radius: req.radius,
                });
                break;
              case "scoreboard":
                reqText += getLocalizedText(player, "quest_req_scoreboard", {
                  objective: req.scoreboardObjective,
                  operator: req.operator,
                  amount: req.quantity,
                });
                break;
              case "tag":
                reqText += getLocalizedText(player, "quest_req_tag", {
                  tag: req.playerTag,
                });
                break;
              case "property":
                reqText += getLocalizedText(player, "quest_req_property", {
                  property: req.propertyName,
                  operator: req.operator,
                  value: req.propertyValue,
                });
                break;
              default:
                reqText += getLocalizedText(player, "quest_req_unknown_type", {
                  type: req.type.replace(/_/g, " "),
                  formatted,
                });
                break;
            }
          }
          return reqText + displayProgress; // Append progress here
        })
        .join("\n");
  } else {
    // If quest is not started or completed, just show status and times completed
    progressDisplaySection =
      `§r${getLocalizedText(player, "current_status")}: §7${getLocalizedText(
        player,
        `quest_status_${playerStatus.replace(" ", "_")}`
      )}\n` +
      `§r${getLocalizedText(player, "completed_times")}: §7${timesCompleted}${
        maxCompletions === 0 ? "" : `/${maxCompletions}`
      }\n\n` +
      (quest.requirements.filter((r) => !r.isHidden).length > 0
        ? "\n§l§r" +
          getLocalizedText(player, "quest_requirements_prefix") +
          "§r\n"
        : "") +
      quest.requirements
        .filter((r) => !r.isHidden)
        .map((req, i) => {
          let reqText = getLocalizedText(player, "quest_detail_req_prefix", {
            index: i + 1,
          });
          const qty = req.quantity;
          const nameOrId = req.displayName
            ? `§a${req.displayName}`
            : req.targetId
            ? `§e${req.targetId}`
            : req.scoreboardObjective
            ? `§a${req.scoreboardObjective}`
            : req.playerTag
            ? `§e${req.playerTag}`
            : req.propertyName
            ? `§a${req.propertyName}`
            : `§7(${getLocalizedText(player, "unknown_requirement")})`;

          if (req.description) {
            reqText += req.description
              .replace(/\{amount\}/g, `§6${qty}§r`)
              .replace(/\{name\}/g, `§a${nameOrId}§r`)
              .replace(/\{x\}/g, `§b${Math.floor(req.x || 0)}§r`)
              .replace(/\{y\}/g, `§b${Math.floor(req.y || 0)}§r`)
              .replace(/\{z\}/g, `§b${Math.floor(req.z || 0)}§r`)
              .replace(/\{radius\}/g, `§e${req.radius || 0}§r`)
              .replace(
                /\{objective\}/g,
                `§a${req.scoreboardObjective || "N/A"}§r`
              )
              .replace(/\{tag\}/g, `§e${req.playerTag || "N/A"}§r`)
              .replace(/\{property\}/g, `§a${req.propertyName || "N/A"}§r`)
              .replace(
                /\{value\}/g,
                `§e${
                  req.propertyValue !== undefined ? req.propertyValue : "N/A"
                }§r`
              )
              .replace(/\{operator\}/g, `§e${req.operator || "N/A"}§r`);
          } else {
            const formatted = `§6x${qty} ${nameOrId}`;
            switch (req.type) {
              case "has_item":
                reqText += getLocalizedText(player, "quest_req_has_item", {
                  formatted,
                });
                break;
              case "break_block":
                reqText += getLocalizedText(player, "quest_req_break_block", {
                  formatted,
                });
                break;
              case "place_block":
                reqText += getLocalizedText(player, "quest_req_place_block", {
                  formatted,
                });
                break;
              case "kill_mob":
                reqText += getLocalizedText(player, "quest_req_kill_mob", {
                  formatted,
                });
                break;
              case "location":
                reqText += getLocalizedText(player, "quest_req_location", {
                  x: Math.floor(req.x),
                  y: Math.floor(req.y),
                  z: Math.floor(req.z),
                  radius: req.radius,
                });
                break;
              case "scoreboard":
                reqText += getLocalizedText(player, "quest_req_scoreboard", {
                  objective: req.scoreboardObjective,
                  operator: req.operator,
                  amount: req.quantity,
                });
                break;
              case "tag":
                reqText += getLocalizedText(player, "quest_req_tag", {
                  tag: req.playerTag,
                });
                break;
              case "property":
                reqText += getLocalizedText(player, "quest_req_property", {
                  property: req.propertyName,
                  operator: req.operator,
                  value: req.propertyValue,
                });
                break;
              default:
                reqText += getLocalizedText(player, "quest_req_unknown_type", {
                  type: req.type.replace(/_/g, " "),
                  formatted,
                });
                break;
            }
          }
          return reqText; // No progress display if not in progress
        })
        .join("\n");
  }

  const UI = new ActionFormData()
    .title(
      getLocalizedText(player, "quest_details_title", { questName: quest.name })
    )
    .body(
      playerQuestInfo +
        "\n\n" +
        progressDisplaySection + // Use conditional progress display section
        (quest.rewards.filter((r) => !r.isHidden).length > 0
          ? "\n\n§l§r" +
            getLocalizedText(player, "quest_rewards_prefix") +
            "§r\n"
          : "") +
        quest.rewards
          .filter((r) => !r.isHidden)
          .map((reward, i) => {
            let rewardText = getLocalizedText(
              player,
              "quest_detail_reward_prefix",
              { index: i + 1 }
            );
            const qty = reward.itemQuantity || 1;
            const nameOrId = reward.displayName
              ? `§a${reward.displayName}`
              : reward.itemTypeId
              ? `§e${reward.itemTypeId}`
              : `§7(${getLocalizedText(player, "unknown_reward")})`;

            if (reward.description) {
              rewardText += reward.description
                .replace(/\{amount\}/g, `§6${qty}§r`)
                .replace(/\{name\}/g, `§a${nameOrId}§r`)
                .replace(/\{command\}/g, `§e${reward.commandString || "N/A"}§r`)
                .replace(
                  /\{value\}/g,
                  `§e${
                    reward.propertyValue !== undefined
                      ? reward.propertyValue
                      : "N/A"
                  }§r`
                );
            } else {
              const formatted = `§6x${qty} ${nameOrId}`;
              switch (reward.type) {
                case "give_item":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_get_item",
                    { formatted }
                  );
                  if (reward.itemEnchants?.length > 0) {
                    const enchants = reward.itemEnchants
                      .map((e) => `${e.id}:${e.level}`)
                      .join(", ");
                    if (reward.itemLore?.length > 0) {
                      const lore = reward.itemLore.join("', '");
                      rewardText += getLocalizedText(
                        player,
                        "quest_item_with_enchants_lore",
                        { enchants: `§d${enchants}`, lore: `§7'${lore}'` }
                      );
                    } else {
                      rewardText += getLocalizedText(
                        player,
                        "quest_item_with_enchants",
                        { enchants: `§d${enchants}` }
                      );
                    }
                  } else if (reward.itemLore?.length > 0) {
                    const lore = reward.itemLore.join("', '");
                    rewardText += getLocalizedText(
                      player,
                      "quest_item_with_lore",
                      { lore: `§7'${lore}'` }
                    );
                  }
                  rewardText += ".";
                  break;
                case "scoreboard":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_get_score",
                    {
                      score: `§e${reward.scoreboardScore}`,
                      objective: `§a${reward.scoreboardObjective}`,
                    }
                  );
                  break;
                case "structure":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_unlock_structure",
                    {
                      count: `§6${reward.structureCount}`,
                      name: `§e${reward.displayName || reward.structureId}`,
                    }
                  );
                  break;
                case "command":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_run_command",
                    { command: `§e'/${reward.commandString}'` }
                  );
                  break;
                case "script":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_execute_script",
                    {
                      script_snippet: `§e'${reward.scriptString.substring(
                        0,
                        50
                      )}...'`,
                    }
                  );
                  break;
                case "property":
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_set_property",
                    {
                      property: `§a'${reward.propertyName}'`,
                      operator: reward.operator || "=", // Display operator for property
                      value: `§e'${reward.propertyValue}'`,
                    }
                  );
                  break;
                default:
                  rewardText += getLocalizedText(
                    player,
                    "quest_reward_unknown_type",
                    { type: `§b${reward.type.replace(/_/g, " ")}`, formatted }
                  );
                  break;
              }
            }
            return rewardText;
          })
          .join("\n")
    )
    .button(actionButtonText, "textures/ui/gear")
    .button(getLocalizedText(player, "back"), "textures/ui/arrow_left");

  const result = await ForceOpen(player, UI);
  if (result.canceled) {
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel" && specificLevel)
      FuncViewFilteredQuests(
        player,
        getLocalizedText(player, "level_quests_display", {
          level: specificLevel,
        }),
        (q) => true,
        "FuncViewQuestsByLevel",
        specificLevel
      );
    else FuncOpenQuestList(player);
    return;
  }
  if (result.selection === 1) {
    // "Back" button
    if (backFunction === "FuncOpenQuestList") FuncOpenQuestList(player);
    else if (backFunction === "FuncViewQuestsByLevel" && specificLevel)
      FuncViewFilteredQuests(
        player,
        getLocalizedText(player, "level_quests_display", {
          level: specificLevel,
        }),
        (q) => true,
        "FuncViewQuestsByLevel",
        specificLevel
      );
    else FuncOpenQuestList(player);
    return;
  }

  if (result.selection === 0) {
    // Action button
    if (canStartQuest) {
      // Re-check conditions at start time for safety (though UI should prevent it)
      if (playerHasActiveLockingQuest) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") + `§c${cannotStartReason}`
        );
        FuncViewQuestDetailsPlayer(
          player,
          questId,
          backFunction,
          specificLevel
        );
        return;
      }
      if (thisQuestIsLocking && playerHasAnyQuestActive) {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") + `§c${cannotStartReason}`
        );
        FuncViewQuestDetailsPlayer(
          player,
          questId,
          backFunction,
          specificLevel
        );
        return;
      }

      questManager.setQuestStatus(player, questId, "in_progress");
      player.sendMessage(
        getLocalizedText(player, "system_prefix") +
          getLocalizedText(player, "quest_started", { questName: quest.name })
      );
    } else if (canResetProgress) {
      const confirmUI = new MessageFormData()
        .title(getLocalizedText(player, "confirm_delete_req_title"))
        .body(
          getLocalizedText(player, "confirm_delete_req_body") +
            `\n§e"${quest.name}"?`
        )
        .button1(getLocalizedText(player, "delete_confirmed"))
        .button2(getLocalizedText(player, "delete_canceled"));
      const confirmResult = await ForceOpen(player, confirmUI);

      if (!confirmResult.canceled && confirmResult.selection === 0) {
        questManager.resetPlayerQuestProgress(player, questId);
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "progress_reset", {
              questName: quest.name,
            })
        );
      } else {
        player.sendMessage(
          getLocalizedText(player, "system_prefix") +
            getLocalizedText(player, "progress_reset_canceled")
        );
      }
    }
    // After any action, return to the quest details or previous list
    FuncViewQuestDetailsPlayer(player, questId, backFunction, specificLevel);
  }
}
