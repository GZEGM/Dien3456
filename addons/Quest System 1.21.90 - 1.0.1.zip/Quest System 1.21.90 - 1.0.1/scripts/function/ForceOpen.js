// function/ForceOpen.js
import { system } from "@minecraft/server";
import {
  ActionFormData,
  MessageFormData,
  ModalFormData,
} from "@minecraft/server-ui"; // Import all form types

/**
 * Opens a UI form for a player, attempting to retry if the form is immediately canceled
 * due to a common Minecraft UI API bug where forms sometimes close instantly on first open.
 *
 * @param {import("@minecraft/server").Player} player The player for whom to open the form.
 * @param {ActionFormData | MessageFormData | ModalFormData} form The UI form object to display.
 * @returns {Promise<any>} A promise that resolves with the form's result (e.g., selection, formValues)
 * or `{ canceled: true }` if the player closed the form.
 */
export const ForceOpen = async (player, form, timeout = 1200) => {
  let startTick = system.currentTick;
  while (system.currentTick - startTick < timeout) {
    const response = await form.show(player);
    if (response.cancelationReason !== "UserBusy") return response;
  }
  return undefined;
};
