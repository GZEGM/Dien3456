// THIS ADDON MADE BY DIEN456 AND GEMINI ADVANCED

// ======================= Imports =======================
import {
  world,
  system,
  ItemStack,
  Player,
  BlockPermutation,
  EnchantmentTypes, // Import EnchantmentTypes
  CommandPermissionLevel,
  CustomCommandStatus,
  CustomCommandParamType,
} from "@minecraft/server";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";

// ================== Constants & State ==================
const CHEST_CONFIG_KEY = "chestSpawnerConfig";
const ADDON_SETTINGS_KEY = "chestSpawnerSettings";
const ACTIVE_RESPAWN_INTERVALS = new Map(); // Stores interval IDs for active spawners
const DEBUG_LOGS = [];

// Default settings for the addon
const DEFAULT_ADDON_SETTINGS = {
  specialStickItemId: "minecraft:stick",
  specialStickLore: "§rChest Spawner Tool",
  debugMode: false,
};

// Default settings for each chest spawner
const DEFAULT_CHEST_SETTINGS = {
  respawnTime: 300, // seconds
  respawnType: "every_time", // "every_time" or "after_open"
  itemPositionType: "fixed", // "fixed" or "random"
  // Changed itemQuantityType to two boolean toggles
  randomizeItemSlots: false, // true: Only a random subset of original non-empty slots are filled
  randomizeItemQuantityPerSlot: false, // true: All original non-empty slots are filled, but quantity is random (0 to original max)
  lastOpenedTime: 0, // Timestamp for "after_open" type
  originalItems: [], // Stores the original items of the chest when configured
  // New property to temporarily disable respawn for editing
  isDisabled: false,
  // New property to make the chest indestructible
  isIndestructible: false,
  // NEW: Store original block type and its permutation states for restoration
  originalBlockTypeId: "minecraft:chest",
  originalBlockPermutationStates: {},
  // NEW: Properties for partner block in a double chest
  partnerBlockLocation: null,
  partnerBlockTypeId: null,
  partnerBlockPermutationStates: null,
};

// ================== Register Dynamic Properties ==================
system.run(() => {
  try {
    world.propertyRegistry.registerWorldDynamicProperty(
      CHEST_CONFIG_KEY,
      "string"
    );
    world.propertyRegistry.registerWorldDynamicProperty(
      ADDON_SETTINGS_KEY,
      "string"
    );
  } catch (e) {
    // Properties might already be registered in multi-load scenarios
    DebugLog(`§c[Init] Error registering dynamic properties: ${e.message}`);
  }
});

// ================== Utility Functions for Config ==================

/**
 * Retrieves the entire Chest Spawner configuration.
 * @returns {object} The complete Chest Spawner configuration.
 */
function getChestConfig() {
  const raw = world.getDynamicProperty(CHEST_CONFIG_KEY);
  return raw ? JSON.parse(raw) : {};
}

/**
 * Saves the entire Chest Spawner configuration.
 * @param {object} config - The complete Chest Spawner configuration to save.
 */
function setChestConfig(config) {
  world.setDynamicProperty(CHEST_CONFIG_KEY, JSON.stringify(config));
}

/**
 * Retrieves addon settings.
 * @returns {object} The addon settings.
 */
function getAddonSettings() {
  const raw = world.getDynamicProperty(ADDON_SETTINGS_KEY);
  const loadedSettings = raw ? JSON.parse(raw) : {};
  return { ...DEFAULT_ADDON_SETTINGS, ...loadedSettings };
}

/**
 * Saves addon settings.
 * @param {object} settings - The addon settings to save.
 */
function setAddonSettings(settings) {
  world.setDynamicProperty(ADDON_SETTINGS_KEY, JSON.stringify(settings));
}

/**
 * Generates a unique key for a chest based on its location.
 * For double chests, uses the location with the smallest coordinates.
 * @param {import("@minecraft/server").Vector3} location - The block's location.
 * @returns {string} The unique chest identifier key.
 */
function generateChestKey(location) {
  return `chest_${Math.floor(location.x)}_${Math.floor(
    location.y
  )}_${Math.floor(location.z)}`;
}

/**
 * Parses a chest key into a location.
 * @param {string} chestKey - The chest identifier key.
 * @returns {import("@minecraft/server").Vector3} The chest's location.
 */
function parseChestKey(chestKey) {
  const parts = chestKey.split("_");
  return {
    x: parseInt(parts[1]),
    y: parseInt(parts[2]),
    z: parseInt(parts[3]),
  };
}

/**
 * Checks if a block is a chest, trapped chest, shulker, or barrel.
 * @param {import("@minecraft/server").Block} block - The block to check.
 * @returns {boolean} True if it's a valid chest type, false otherwise.
 */
function isChestBlock(block) {
  if (!block) return false;
  const typeId = block.typeId;
  return (
    typeId === "minecraft:chest" ||
    typeId === "minecraft:trapped_chest" ||
    typeId === "minecraft:shulker_box" ||
    typeId === "minecraft:barrel"
  );
}

/**
 * Gets the canonical location for a chest. For double chests, this will be the
 * location of the "left" half of the chest (or the one with the lowest coordinates).
 * This function avoids relying on `container.location` for double chest identification
 * as per user request, instead using block states and neighbor checks.
 * @param {import("@minecraft/server").Block} block - The chest block.
 * @returns {import("@minecraft/server").Vector3 | null} The canonical location of the chest.
 */
function getChestLocation(block) {
  if (!block || !isChestBlock(block)) {
    DebugLog(
      `§c[getChestLocation] Invalid block or not a chest block: ${
        block ? block.typeId : "null"
      }`
    );
    return null;
  }

  const blockLocation = block.location;

  try {
    // Attempt to get chest_type state. Shulkers and Barrels won't have this.
    const chestType = block.permutation.getState("chest_type"); // 'left', 'right', or undefined for single chest/other containers

    if (chestType === "left") {
      // If this is the left half of a double chest, it's already the canonical one.
      return blockLocation;
    } else if (chestType === "right") {
      // If this is the right half, we need to find the left half.
      // The 'direction' state tells us how the chest is oriented.
      const direction = block.permutation.getState("direction"); // 0: South, 1: West, 2: North, 3: East (facing direction)

      let leftHalfOffset = null;
      switch (direction) {
        case 0: // Facing South: Left half is to the East (positive X relative to current block)
          leftHalfOffset = { x: 1, y: 0, z: 0 };
          break;
        case 1: // Facing West: Left half is to the South (positive Z relative to current block)
          leftHalfOffset = { x: 0, y: 0, z: 1 };
          break;
        case 2: // Facing North: Left half is to the West (negative X relative to current block)
          leftHalfOffset = { x: -1, y: 0, z: 0 };
          break;
        case 3: // Facing East: Left half is to the North (negative Z relative to current block)
          leftHalfOffset = { x: 0, y: 0, z: -1 };
          break;
        default:
          DebugLog(
            `§c[getChestLocation] Unknown direction state for right chest at ${blockLocation.x},${blockLocation.y},${blockLocation.z}: ${direction}. Falling back to block.location.`
          );
          return blockLocation; // Fallback if direction is unexpected
      }

      const leftHalfLocation = {
        x: blockLocation.x + leftHalfOffset.x,
        y: blockLocation.y + leftHalfOffset.y,
        z: blockLocation.z + leftHalfOffset.z,
      };

      const leftHalfBlock = block.dimension.getBlock(leftHalfLocation);
      // Verify the found block is indeed a chest and its left half
      if (
        leftHalfBlock &&
        isChestBlock(leftHalfBlock) &&
        leftHalfBlock.permutation.getState("chest_type") === "left"
      ) {
        return leftHalfLocation;
      } else {
        DebugLog(
          `§c[getChestLocation] Could not find matching left half for right chest at ${blockLocation.x},${blockLocation.y},${blockLocation.z}. Falling back to block.location.`
        );
        return blockLocation; // Fallback if the other half isn't found or isn't a left chest
      }
    } else {
      // It's a single chest, shulker box, or barrel (which don't have 'chest_type' state, or it's undefined)
      return blockLocation;
    }
  } catch (e) {
    DebugLog(
      `§c[getChestLocation] Critical error during location determination for block at ${blockLocation.x},${blockLocation.y},${blockLocation.z} (${block.typeId}): ${e.message}`
    );
    // If anything goes wrong with states or neighbor checks, fall back to the block's own location.
    return blockLocation;
  }
}

/**
 * Gets information about the partner block of a double chest.
 * @param {import("@minecraft/server").Block} block - One half of a double chest.
 * @returns {{location: import("@minecraft/server").Vector3, typeId: string, states: object} | null} Partner info or null if not a double chest.
 */
function getChestPartnerInfo(block) {
  if (!block || !isChestBlock(block)) return null;

  const chestType = block.permutation.getState("chest_type");
  if (chestType === "single" || chestType === undefined) return null; // Not a double chest

  const blockLocation = block.location;
  const direction = block.permutation.getState("direction");

  let partnerOffset = null;
  if (chestType === "left") {
    // If this is the left half, partner is to the right
    switch (direction) {
      case 0: // Facing South: Right half is to the West (positive X)
        partnerOffset = { x: 1, y: 0, z: 0 };
        break;
      case 1: // Facing West: Right half is to the North (positive Z)
        partnerOffset = { x: 0, y: 0, z: 1 };
        break;
      case 2: // Facing North: Right half is to the East (negative X)
        partnerOffset = { x: -1, y: 0, z: 0 };
        break;
      case 3: // Facing East: Right half is to the South (negative Z)
        partnerOffset = { x: 0, y: 0, z: -1 };
        break;
    }
  } else if (chestType === "right") {
    // If this is the right half, partner is to the left
    switch (direction) {
      case 0: // Facing South: Left half is to the East (negative X)
        partnerOffset = { x: -1, y: 0, z: 0 };
        break;
      case 1: // Facing West: Left half is to the South (negative Z)
        partnerOffset = { x: 0, y: 0, z: -1 };
        break;
      case 2: // Facing North: Left half is to the West (positive X)
        partnerOffset = { x: 1, y: 0, z: 0 };
        break;
      case 3: // Facing East: Left half is to the North (positive Z)
        partnerOffset = { x: 0, y: 0, z: 1 };
        break;
    }
  }

  if (!partnerOffset) return null;

  const partnerLocation = {
    x: blockLocation.x + partnerOffset.x,
    y: blockLocation.y + partnerOffset.y,
    z: blockLocation.z + partnerOffset.z,
  };

  const partnerBlock = block.dimension.getBlock(partnerLocation);
  if (partnerBlock && isChestBlock(partnerBlock)) {
    const partnerStates = {};
    try {
      const partnerDirection = partnerBlock.permutation.getState("direction");
      if (partnerDirection !== undefined)
        partnerStates.direction = partnerDirection;
    } catch (e) {
      /* Ignore */
    }
    try {
      const partnerChestType = partnerBlock.permutation.getState("chest_type");
      if (partnerChestType !== undefined)
        partnerStates.chest_type = partnerChestType;
    } catch (e) {
      /* Ignore */
    }

    return {
      location: partnerLocation,
      typeId: partnerBlock.typeId,
      states: partnerStates,
    };
  }
  return null;
}

/**
 * Gets the container object of a chest (supports double chests).
 * @param {import("@minecraft/server").Block} block - The chest block.
 * @returns {import("@minecraft/server").Container | null} The chest's container object.
 */
function getChestInventoryContainer(block) {
  if (!block || !isChestBlock(block)) return null;
  try {
    const inventoryComponent = block.getComponent("minecraft:inventory");
    return inventoryComponent ? inventoryComponent.container : null;
  } catch (e) {
    DebugLog(
      `§c[getChestInventoryContainer] Error accessing inventory component for block at ${block.location.x},${block.location.y},${block.location.z} (${block.typeId}): ${e.message}`
    );
    return null;
  }
}

/**
 * Converts an ItemStack to a savable JSON object, including enchantments.
 * @param {import("@minecraft/server").ItemStack} itemStack - The ItemStack.
 * @returns {object | null} JSON object of the item or null if invalid.
 */
function getItemStackData(itemStack) {
  if (!itemStack) return null;

  const enchantments = [];
  try {
    const enchantableComponent = itemStack.getComponent(
      "minecraft:enchantable"
    );
    if (enchantableComponent) {
      for (const enchantment of enchantableComponent.getEnchantments()) {
        enchantments.push({
          typeId: enchantment.type.id,
          level: enchantment.level,
        });
      }
    }
  } catch (e) {
    DebugLog(`§c[getItemStackData] Error getting enchantments: ${e.message}`);
  }

  const data = {
    itemId: itemStack.typeId,
    amount: itemStack.amount,
    nameTag: itemStack.nameTag || "",
    lore: itemStack.getLore(),
    enchantments: enchantments, // Store enchantments
  };
  return data;
}

/**
 * Converts a JSON item data object back to an ItemStack, including enchantments.
 * @param {object} itemData - The JSON item data.
 * @returns {import("@minecraft/server").ItemStack | null} The ItemStack or null if invalid.
 */
function createItemStackFromData(itemData) {
  if (!itemData || !itemData.itemId || itemData.amount === undefined)
    return null;
  try {
    const itemStack = new ItemStack(itemData.itemId, itemData.amount);
    if (itemData.nameTag) {
      itemStack.nameTag = itemData.nameTag;
    }
    if (itemData.lore && Array.isArray(itemData.lore)) {
      itemStack.setLore(itemData.lore);
    }

    // Apply enchantments
    if (itemData.enchantments && Array.isArray(itemData.enchantments)) {
      try {
        const enchantableComponent = itemStack.getComponent(
          "minecraft:enchantable"
        );
        if (enchantableComponent) {
          for (const enchData of itemData.enchantments) {
            const enchantmentType = EnchantmentTypes.get(enchData.typeId);
            if (enchantmentType) {
              enchantableComponent.addEnchantment({
                type: enchantmentType,
                level: enchData.level,
              });
            } else {
              DebugLog(
                `§c[createItemStackFromData] Unknown enchantment type: ${enchData.typeId}`
              );
            }
          }
        }
      } catch (e) {
        DebugLog(
          `§c[createItemStackFromData] Error applying enchantments: ${e.message}`
        );
      }
    }

    return itemStack;
  } catch (e) {
    DebugLog(
      `§c[Error] Failed to create ItemStack from data: ${JSON.stringify(
        itemData
      )} - ${e.message}`
    );
    return null;
  }
}

/**
 * Adds a message to the debug log.
 * @param {string} message - The message to log.
 */
function DebugLog(message) {
  const settings = getAddonSettings();
  if (!settings.debugMode) return; // Only log if debug mode is enabled

  const time = new Date().toLocaleTimeString();
  const formatted = `§7[${time}] §f${message}`;
  DEBUG_LOGS.push(formatted);
  if (DEBUG_LOGS.length > 1000) DEBUG_LOGS.shift(); // Keep log size manageable
  //console.warn(formatted); // Also log to console for easier debugging
}

/**
 * Cleans up a chest's configuration and stops its respawn interval.
 * @param {string} chestKey - The key of the chest to clean up.
 */
function cleanupChestConfig(chestKey) {
  const allConfigs = getChestConfig();
  delete allConfigs[chestKey];
  setChestConfig(allConfigs);
  if (ACTIVE_RESPAWN_INTERVALS.has(chestKey)) {
    system.clearRun(ACTIVE_RESPAWN_INTERVALS.get(chestKey));
    ACTIVE_RESPAWN_INTERVALS.delete(chestKey);
  }
}

// ================== Item Spawning and Interaction ==================

/**
 * Gives the player the special Chest Spawner tool.
 * @param {import("@minecraft/server").Player} player - The player to give the item to.
 */
function giveSpecialItem(player) {
  const settings = getAddonSettings();
  const item = new ItemStack(settings.specialStickItemId, 1);

  const inventory = player.getComponent("minecraft:inventory").container;
  if (inventory.emptySlotsCount > 0) {
    system.run(() => {
      // Apply lore and nameTag immediately after creation
      item.setLore([settings.specialStickLore]);
      item.nameTag = "§l§bChest Spawner Tool";
      inventory.addItem(item);
      player.sendMessage(`§aYou received the Chest Spawner Tool!`);
    });
  } else {
    player.sendMessage(`§cYour inventory is full!`);
    player.dimension.spawnItem(item, player.location);
  }
}

// ================== UI Forms ==================

/**
 * Opens the main configuration menu for a chest.
 * @param {import("@minecraft/server").Player} player - The player opening the menu.
 * @param {import("@minecraft/server").Block} block - The chest block interacted with.
 * @param {object | null} existingConfig - Existing configuration for the chest, if any.
 */
async function openChestConfigMenu(player, block, existingConfig = null) {
  let chestLocation;
  try {
    chestLocation = getChestLocation(block);
  } catch (e) {
    player.sendMessage(`§cError getting chest location: ${e.message}`);
    DebugLog(
      `§c[openChestConfigMenu] Error getting chest location for block at ${block.location.x},${block.location.y},${block.location.z}: ${e.message}`
    );
    return;
  }

  if (!chestLocation) {
    player.sendMessage("§cError: Could not determine chest location.");
    return;
  }

  const chestKey = generateChestKey(chestLocation);
  let container;
  try {
    container = getChestInventoryContainer(block);
  } catch (e) {
    player.sendMessage(`§cError accessing chest inventory: ${e.message}`);
    DebugLog(
      `§c[openChestConfigMenu] Error accessing chest inventory for block at ${block.location.x},${block.location.y},${block.location.z}: ${e.message}`
    );
    return;
  }

  if (!container) {
    player.sendMessage("§cError: Could not access chest inventory.");
    return;
  }

  const blockTypeId = block.typeId;
  const blockPos = `X: ${chestLocation.x}, Y: ${chestLocation.y}, Z: ${chestLocation.z}`;
  const itemCount = container.size;

  const currentSettings = {
    ...DEFAULT_CHEST_SETTINGS,
    ...(existingConfig || {}),
  };

  const form = new ModalFormData()
    .title("§l§bChest Spawner Configuration")
    .textField(
      `Chest Type: ${blockTypeId}\nPosition: ${blockPos}\nItem Slots: ${itemCount}\n\nRespawn Time (seconds):`,
      `${currentSettings.respawnTime}`,
      {
        defaultValue: currentSettings.respawnTime.toString(),
      }
    )
    .dropdown(
      "Respawn Type:",
      ["Every Time Respawn", "Respawn After First Open"],
      {
        defaultValue: currentSettings.respawnType === "after_open" ? 1 : 0,
      }
    )
    .dropdown("Item Position Type:", ["Fixed Position", "Random Position"], {
      defaultValue: currentSettings.itemPositionType === "random" ? 1 : 0,
    })
    .toggle("Randomize Item Slots (Random subset of original items):", {
      defaultValue: currentSettings.randomizeItemSlots,
    })
    .toggle("Randomize Item Quantity (0 to Original Max per slot):", {
      defaultValue: currentSettings.randomizeItemQuantityPerSlot,
    })
    .toggle("Make Chest Indestructible:", {
      defaultValue: currentSettings.isIndestructible,
    });

  const response = await form.show(player);

  if (response.canceled) {
    player.sendMessage("§eChest Spawner configuration cancelled.");
    // If cancelled, re-enable respawn if it was disabled for editing
    if (existingConfig && existingConfig.isDisabled) {
      const allConfigs = getChestConfig();
      allConfigs[chestKey].isDisabled = false;
      setChestConfig(allConfigs);
      startChestRespawn(chestKey, allConfigs[chestKey]);
      player.sendMessage("§aChest respawn re-enabled.");
    }
    return;
  }

  const [
    respawnTimeStr,
    respawnTypeIndex,
    itemPositionTypeIndex,
    randomizeItemSlots,
    randomizeItemQuantityPerSlot,
    isIndestructible,
  ] = response.formValues;

  const respawnTime = parseInt(respawnTimeStr);
  if (isNaN(respawnTime) || respawnTime <= 0) {
    player.sendMessage(
      "§cInvalid respawn time. Please enter a positive number."
    );
    openChestConfigMenu(player, block, existingConfig); // Reopen with previous data
    return;
  }

  const newSettings = {
    ...currentSettings,
    respawnTime: respawnTime,
    respawnType: respawnTypeIndex === 0 ? "every_time" : "after_open",
    itemPositionType: itemPositionTypeIndex === 0 ? "fixed" : "random",
    randomizeItemSlots: randomizeItemSlots,
    randomizeItemQuantityPerSlot: randomizeItemQuantityPerSlot,
    isIndestructible: isIndestructible,
    lastOpenedTime: currentSettings.lastOpenedTime, // Preserve last opened time
    isDisabled: false, // Ensure respawn is re-enabled after saving config
  };

  // Capture current block type and its permutation states
  newSettings.originalBlockTypeId = block.typeId;
  const capturedStates = {};
  // Only capture 'direction' and 'chest_type' if they exist for the block
  try {
    const direction = block.permutation.getState("direction");
    if (direction !== undefined) capturedStates.direction = direction;
  } catch (e) {
    /* Ignore if state doesn't exist */
  }
  try {
    const chestType = block.permutation.getState("chest_type");
    if (chestType !== undefined) capturedStates.chest_type = chestType;
  } catch (e) {
    /* Ignore if state doesn't exist */
  }
  newSettings.originalBlockPermutationStates = capturedStates;

  // NEW: Capture partner block info if it's a double chest
  const partnerInfo = getChestPartnerInfo(block);
  if (partnerInfo) {
    newSettings.partnerBlockLocation = partnerInfo.location;
    newSettings.partnerBlockTypeId = partnerInfo.typeId;
    newSettings.partnerBlockPermutationStates = partnerInfo.states;
  } else {
    newSettings.partnerBlockLocation = null;
    newSettings.partnerBlockTypeId = null;
    newSettings.partnerBlockPermutationStates = null;
  }

  // Capture current items in the chest
  const itemsInChest = [];
  for (let i = 0; i < container.size; i++) {
    const itemStack = container.getItem(i);
    if (itemStack) {
      itemsInChest.push(getItemStackData(itemStack));
    } else {
      itemsInChest.push(null); // Keep null for empty slots to preserve position
    }
  }
  newSettings.originalItems = itemsInChest;

  const allConfigs = getChestConfig();
  allConfigs[chestKey] = newSettings;
  setChestConfig(allConfigs);

  player.sendMessage(
    `§aChest Spawner configured for ${blockTypeId} at ${blockPos}.`
  );
  startChestRespawn(chestKey, newSettings);
}

/**
 * Opens the admin menu for an already configured chest.
 * @param {import("@minecraft/server").Player} player - The admin player.
 * @param {import("@minecraft/server").Block} block - The chest block.
 * @param {string} chestKey - The key of the configured chest.
 */
async function openAdminChestMenu(player, block, chestKey) {
  let chestLocation;
  try {
    chestLocation = parseChestKey(chestKey); // Parse directly from key for teleport, etc.
  } catch (e) {
    player.sendMessage(`§cError parsing chest key: ${e.message}`);
    DebugLog(
      `§c[openAdminChestMenu] Error parsing chest key ${chestKey}: ${e.message}`
    );
    return;
  }

  const blockTypeId = block.typeId;
  const blockPos = `X: ${chestLocation.x}, Y: ${chestLocation.y}, Z: ${chestLocation.z}`;

  const form = new ActionFormData()
    .title("§l§cChest Spawner Admin Menu")
    .body(`Managing Chest: ${blockTypeId}\nPosition: ${blockPos}`)
    .button("§eEdit Configuration & Save Current Items")
    .button("§aRespawn Original Chest") // This button will now force exact respawn
    .button("§cRemove Spawner")
    .button("§9Teleport to Chest");

  const response = await form.show(player);

  if (response.canceled) {
    // If cancelled, re-enable respawn if it was disabled for editing
    const allConfigs = getChestConfig();
    if (allConfigs[chestKey] && allConfigs[chestKey].isDisabled) {
      allConfigs[chestKey].isDisabled = false;
      setChestConfig(allConfigs);
      startChestRespawn(chestKey, allConfigs[chestKey]);
      player.sendMessage("§aChest respawn re-enabled.");
    }
    return;
  }

  const allConfigs = getChestConfig();
  const currentConfig = allConfigs[chestKey];

  switch (response.selection) {
    case 0: // Edit Configuration & Save Current Items
      if (currentConfig) {
        let container;
        try {
          container = getChestInventoryContainer(block);
        } catch (e) {
          player.sendMessage(`§cError accessing chest inventory: ${e.message}`);
          DebugLog(
            `§c[openAdminChestMenu] Error accessing chest inventory for block at ${block.location.x},${block.location.y},${block.location.z}: ${e.message}`
          );
          return;
        }

        if (container) {
          const itemsInChest = [];
          for (let i = 0; i < container.size; i++) {
            const itemStack = container.getItem(i);
            if (itemStack) {
              itemsInChest.push(getItemStackData(itemStack));
            } else {
              itemsInChest.push(null);
            }
          }
          currentConfig.originalItems = itemsInChest;
          setChestConfig(allConfigs);
          player.sendMessage(
            "§aCurrent chest items saved as new original items."
          );
        } else {
          player.sendMessage(
            "§cError: Could not access chest inventory to save items."
          );
        }
        openChestConfigMenu(player, block, currentConfig);
      } else {
        player.sendMessage("§cError: Chest configuration not found.");
      }
      break;
    case 1: // Respawn Original Chest - NOW FORCES EXACT RESPAWN
      if (currentConfig) {
        // Call respawnChestContents with forceExactRespawn = true
        respawnChestContents(chestKey, currentConfig, true);
        player.sendMessage(
          "§aChest contents respawned to original configuration."
        );
      } else {
        player.sendMessage("§cError: Chest configuration not found.");
      }
      break;
    case 2: // Remove Spawner
      const confirmForm = new MessageFormData()
        .title("§cConfirm Removal")
        .body(
          `Are you sure you want to remove the Chest Spawner at ${blockPos}?`
        )
        .button1("§cRemove")
        .button2("Cancel");

      const confirmResponse = await confirmForm.show(player);
      if (confirmResponse.selection === 0) {
        // Confirmed remove
        cleanupChestConfig(chestKey);
        player.sendMessage(`§cChest Spawner at ${blockPos} removed.`);
      } else {
        // If cancelled, re-enable respawn if it was disabled for editing
        if (currentConfig && currentConfig.isDisabled) {
          allConfigs[chestKey].isDisabled = false;
          setChestConfig(allConfigs);
          startChestRespawn(chestKey, allConfigs[chestKey]);
          player.sendMessage("§aChest respawn re-enabled.");
        }
      }
      break;
    case 3: // Teleport to Chest
      player.teleport(
        {
          x: chestLocation.x + 0.5,
          y: chestLocation.y + 1,
          z: chestLocation.z + 0.5,
        },
        {
          facingLocation: chestLocation,
        }
      );
      player.sendMessage(`§aTeleported to chest at ${blockPos}.`);
      break;
  }
}

/**
 * Opens the main menu triggered by right-clicking the special item.
 * @param {import("@minecraft/server").Player} player - The player.
 */
async function openMainMenu(player) {
  const form = new ActionFormData()
    .title("§l§bChest Spawner Main Menu")
    .body("Select an option:");

  form.button("§aView All Configured Chests");
  form.button("§eSettings");

  const response = await form.show(player);

  if (response.canceled) return;

  switch (response.selection) {
    case 0: // View All Configured Chests
      openAllChestsMenu(player);
      break;
    case 1: // Settings
      openAddonSettingsMenu(player);
      break;
  }
}

/**
 * Opens a menu displaying all configured chests.
 * @param {import("@minecraft/server").Player} player - The player.
 */
async function openAllChestsMenu(player) {
  const allConfigs = getChestConfig();
  const chestKeys = Object.keys(allConfigs);

  if (chestKeys.length === 0) {
    player.sendMessage("§cNo Chest Spawners configured yet.");
    return;
  }

  const form = new ActionFormData()
    .title("§l§aAll Configured Chests")
    .body("Select a chest to manage:");

  chestKeys.forEach((key) => {
    const loc = parseChestKey(key);
    form.button(`X: ${loc.x}, Y: ${loc.y}, Z: ${loc.z}`);
  });

  const response = await form.show(player);

  if (response.canceled) {
    openMainMenu(player); // Go back to main menu
    return;
  }

  const selectedKey = chestKeys[response.selection];
  const selectedLocation = parseChestKey(selectedKey);
  const block = player.dimension.getBlock(selectedLocation);

  if (block && isChestBlock(block)) {
    openAdminChestMenu(player, block, selectedKey);
  } else {
    player.sendMessage(
      "§cError: Selected chest no longer exists or is not a valid chest block."
    );
    // Optionally remove the invalid config
    cleanupChestConfig(selectedKey);
  }
}

/**
 * Opens the addon settings menu.
 * @param {import("@minecraft/server").Player} player - The player.
 */
async function openAddonSettingsMenu(player) {
  const currentSettings = getAddonSettings();

  const form = new ModalFormData()
    .title("§l§eAddon Settings")
    .textField(
      "Special Stick Item ID:",
      `${currentSettings.specialStickItemId}`,
      {
        defaultValue: currentSettings.specialStickItemId,
      }
    )
    .textField("Special Stick Lore:", `${currentSettings.specialStickLore}`, {
      defaultValue: currentSettings.specialStickLore,
    })
    .toggle("Enable Debug Mode:", {
      defaultValue: currentSettings.debugMode,
    }); // Added defaultValue for consistency

  const response = await form.show(player);

  if (response.canceled) {
    openMainMenu(player);
    return;
  }

  const [newStickId, newStickLore, newDebugMode] = response.formValues;

  const updatedSettings = {
    specialStickItemId:
      newStickId.trim() || DEFAULT_ADDON_SETTINGS.specialStickItemId,
    specialStickLore:
      newStickLore.trim() || DEFAULT_ADDON_SETTINGS.specialStickLore,
    debugMode: newDebugMode,
  };

  setAddonSettings(updatedSettings);
  player.sendMessage("§aAddon settings updated successfully!");
  openMainMenu(player); // Go back to main menu
}

/**
 * Opens the debug log UI for a player.
 * @param {import("@minecraft/server").Player} player - The player to show the UI to.
 */
function openDebugLogForm(player) {
  const form = new ActionFormData().title("§bDebug Logs");

  if (DEBUG_LOGS.length === 0) {
    form.body("§7(No logs available)");
  } else {
    const logText = DEBUG_LOGS.slice(-20).join("\n\n"); // Show last 20 logs
    form.body(`§fRecent Logs:\n${logText}`);
  }

  form.button("Clear Log");
  form.button("Refresh Log");
  form.button("Close");

  form.show(player).then((res) => {
    if (res.canceled) return;
    if (res.selection === 0) {
      DEBUG_LOGS.length = 0; // Clear the array
      player.sendMessage("§a[Debug] Log cleared.");
    }
    if (res.selection === 1) {
      openDebugLogForm(player); // Refresh the form
    }
  });
}

// ================== Chest Respawn Logic ==================

/**
 * Starts or restarts the respawn interval for a configured chest.
 * @param {string} chestKey - The key of the chest.
 * @param {object} config - The chest's configuration.
 */
function startChestRespawn(chestKey, config) {
  // Clear any existing interval for this chest
  if (ACTIVE_RESPAWN_INTERVALS.has(chestKey)) {
    system.clearRun(ACTIVE_RESPAWN_INTERVALS.get(chestKey));
    ACTIVE_RESPAWN_INTERVALS.delete(chestKey);
  }

  // If the chest is disabled, don't start the respawn interval
  if (config.isDisabled) {
    DebugLog(`Respawn for ${chestKey} is currently disabled.`);
    return;
  }

  DebugLog(
    `Starting respawn for ${chestKey} with interval ${config.respawnTime}s`
  );

  const intervalId = system.runInterval(() => {
    const allConfigs = getChestConfig();
    const currentConfig = allConfigs[chestKey];

    if (!currentConfig || currentConfig.isDisabled) {
      // Config removed or disabled, clear interval
      system.clearRun(ACTIVE_RESPAWN_INTERVALS.get(chestKey));
      ACTIVE_RESPAWN_INTERVALS.delete(chestKey);
      DebugLog(
        `Stopped respawn for ${chestKey}: config not found or is disabled.`
      );
      return;
    }

    const chestLocation = parseChestKey(chestKey);
    const block = world.getDimension("overworld").getBlock(chestLocation); // Assume overworld for now
    if (!block || !isChestBlock(block)) {
      // If the block is missing, respawnChestContents will attempt to restore it.
      // If it fails to restore, it will clean up the config.
      // So, we don't need to delete config here.
      // Just log and continue, respawnChestContents will handle it.
      DebugLog(
        `§c[Respawn Check] Chest block at ${chestKey} is missing or invalid. Attempting respawn via respawnChestContents.`
      );
      // No return here, let the shouldRespawn logic proceed.
      // The respawnChestContents function will handle the block restoration and subsequent actions.
    }

    const currentTime = Date.now(); // Milliseconds
    const timeSinceLastOpen =
      (currentTime - currentConfig.lastOpenedTime) / 1000; // Seconds

    // Check if respawn conditions are met
    let shouldRespawn = false;
    if (currentConfig.respawnType === "every_time") {
      shouldRespawn = timeSinceLastOpen >= currentConfig.respawnTime;
    } else if (currentConfig.respawnType === "after_open") {
      // Respawn only if chest was opened and enough time has passed
      shouldRespawn =
        currentConfig.lastOpenedTime > 0 &&
        timeSinceLastOpen >= currentConfig.respawnTime;
    }

    if (shouldRespawn) {
      // For automatic respawns, respect the randomization settings in the config
      respawnChestContents(chestKey, currentConfig, false);
      // Reset lastOpenedTime for "after_open" type after respawn
      if (currentConfig.respawnType === "after_open") {
        currentConfig.lastOpenedTime = 0; // Reset so it waits for next open
        setChestConfig(allConfigs); // Save updated lastOpenedTime
      }
      DebugLog(`Respawned chest at ${chestKey}`); // Log when chest respawns
    }
  }, config.respawnTime * 20); // Convert seconds to game ticks (20 ticks = 1 second)

  ACTIVE_RESPAWN_INTERVALS.set(chestKey, intervalId);
}

/**
 * Fills the chest with its original items based on configuration.
 * @param {string} chestKey - The key of the chest.
 * @param {object} config - The chest's configuration.
 * @param {boolean} [forceExactRespawn=false] - If true, ignores randomization settings and respawns items exactly as original.
 */
function respawnChestContents(chestKey, config, forceExactRespawn = false) {
  const chestLocation = parseChestKey(chestKey);
  const dimension = world.getDimension("overworld"); // Assuming overworld for now
  let block = dimension.getBlock(chestLocation); // Get block here

  // If the block is missing or not a chest, attempt to restore it
  if (!block || !isChestBlock(block)) {
    DebugLog(
      `§c[Respawn] Chest block at ${chestKey} is missing or invalid. Attempting to restore.`
    );
    try {
      const originalTypeId = config.originalBlockTypeId || "minecraft:chest"; // Fallback
      const originalStates = config.originalBlockPermutationStates || {};
      const newPermutation = BlockPermutation.resolve(
        originalTypeId,
        originalStates
      );
      dimension.setBlockPermutation(chestLocation, newPermutation);
      DebugLog(`§a[Respawn] Restored chest block at ${chestKey}.`);
      block = dimension.getBlock(chestLocation); // Re-get the block after setting it
      if (!block || !isChestBlock(block)) {
        DebugLog(
          `§c[Respawn Error] Failed to restore chest block at ${chestKey}. Deleting configuration.`
        );
        cleanupChestConfig(chestKey); // New helper to clean up
        return;
      }
    } catch (e) {
      DebugLog(
        `§c[Respawn Error] Failed to restore chest block at ${chestKey}: ${e.message}. Deleting configuration.`
      );
      cleanupChestConfig(chestKey);
      return;
    }
  }

  // NEW: Attempt to restore the partner chest block if it was a double chest
  if (config.partnerBlockLocation && config.partnerBlockTypeId) {
    const partnerBlock = dimension.getBlock(config.partnerBlockLocation);
    if (!partnerBlock || !isChestBlock(partnerBlock)) {
      DebugLog(
        `§c[Respawn] Partner chest block at ${config.partnerBlockLocation.x},${config.partnerBlockLocation.y},${config.partnerBlockLocation.z} is missing or invalid. Attempting to restore.`
      );
      try {
        const partnerPermutation = BlockPermutation.resolve(
          config.partnerBlockTypeId,
          config.partnerBlockPermutationStates || {}
        );
        dimension.setBlockPermutation(
          config.partnerBlockLocation,
          partnerPermutation
        );
        DebugLog(
          `§a[Respawn] Restored partner chest block at ${config.partnerBlockLocation.x},${config.partnerBlockLocation.y},${config.partnerBlockLocation.z}.`
        );
      } catch (e) {
        DebugLog(
          `§c[Respawn Error] Failed to restore partner chest block at ${config.partnerBlockLocation.x},${config.partnerBlockLocation.y},${config.partnerBlockLocation.z}: ${e.message}`
        );
        // Do not delete main config if partner fails, but log the error.
      }
    }
  }

  const container = getChestInventoryContainer(block);
  if (!container) {
    DebugLog(
      `§c[Respawn Error] Cannot respawn: Could not get container for chest at ${chestKey}.`
    );
    return;
  }

  // Clear existing items in the chest
  container.clearAll();

  // If forceExactRespawn is true, fill exactly as original and return
  if (forceExactRespawn) {
    for (let i = 0; i < config.originalItems.length; i++) {
      const itemData = config.originalItems[i];
      if (itemData) {
        const itemStack = createItemStackFromData(itemData);
        if (itemStack) {
          try {
            container.setItem(i, itemStack);
          } catch (e) {
            DebugLog(
              `§c[Respawn Error] Failed to set exact item in slot ${i} for ${chestKey}: ${e.message}`
            );
          }
        }
      }
    }
    return;
  }

  // --- Apply randomization logic if not forcing exact respawn ---

  let itemsToPlaceInContainer = new Array(container.size).fill(null); // This will hold the final items and their positions

  // Step 1: Determine which original items (and their original slots) are selected based on randomizeItemSlots
  let selectedOriginalItemsWithSlots = [];
  if (config.randomizeItemSlots) {
    // Only consider non-null original items for randomization
    const potentialItems = config.originalItems
      .map((item, index) => ({ itemData: item, originalSlot: index }))
      .filter(({ itemData }) => itemData !== null);

    if (potentialItems.length > 0) {
      // Randomly select a subset of these items
      // At least 1 item if available, up to all non-null items
      const numItemsToSelect =
        Math.floor(Math.random() * potentialItems.length) + 1;

      // Shuffle potentialItems to pick random ones
      for (let i = potentialItems.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [potentialItems[i], potentialItems[j]] = [
          potentialItems[j],
          potentialItems[i],
        ];
      }
      selectedOriginalItemsWithSlots = potentialItems.slice(
        0,
        numItemsToSelect
      );
    }
  } else {
    // If randomizeItemSlots is false, all original non-null items are selected
    selectedOriginalItemsWithSlots = config.originalItems
      .map((item, index) => ({ itemData: item, originalSlot: index }))
      .filter(({ itemData }) => itemData !== null);
  }

  // Step 2: Place selected items into final positions based on itemPositionType
  if (config.itemPositionType === "fixed") {
    // Place items back into their original slots
    selectedOriginalItemsWithSlots.forEach(({ itemData, originalSlot }) => {
      itemsToPlaceInContainer[originalSlot] = itemData;
    });
  } else {
    // config.itemPositionType === "random"
    // Get all available slots and shuffle them
    const availableSlots = Array.from({ length: container.size }, (_, i) => i);
    for (let i = availableSlots.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [availableSlots[i], availableSlots[j]] = [
        availableSlots[j],
        availableSlots[i],
      ];
    }

    // Place selected items into random available slots
    selectedOriginalItemsWithSlots.forEach((itemWithSlot, index) => {
      if (index < availableSlots.length) {
        // Ensure we don't go out of bounds if selectedItems > container.size (unlikely but good practice)
        itemsToPlaceInContainer[availableSlots[index]] = itemWithSlot.itemData;
      }
    });
  }

  // Step 3: Apply randomizeItemQuantityPerSlot and set items in container
  for (let i = 0; i < container.size; i++) {
    const itemData = itemsToPlaceInContainer[i];
    if (itemData) {
      let amount = itemData.amount;
      if (config.randomizeItemQuantityPerSlot) {
        // Changed: Random from 1 to original max (if original max > 0)
        amount =
          itemData.amount > 0
            ? Math.floor(Math.random() * itemData.amount) + 1
            : 0;
      }

      if (amount > 0) {
        const itemStack = createItemStackFromData({
          ...itemData,
          amount: amount,
        });
        if (itemStack) {
          try {
            container.setItem(i, itemStack);
          } catch (e) {
            DebugLog(
              `§c[Respawn Error] Failed to set item in slot ${i} for ${chestKey}: ${e.message}`
            );
          }
        }
      }
    }
  }
}

// ================== Event Listeners ==================

// Handle player using the special item (now always opens main menu)
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  const settings = getAddonSettings();

  if (
    !item ||
    item.typeId !== settings.specialStickItemId ||
    !item.getLore().includes(settings.specialStickLore)
  ) {
    return;
  }

  // This event will no longer open any menu directly.
  // The main menu is now accessed via chat command !cs menu
  player.sendMessage(
    "§eUse '!cs menu' to open the main admin menu. Interact with chests to configure them."
  );
});

// Handle player interacting with a block while holding the special item (for config/admin menus)
world.beforeEvents.playerInteractWithBlock.subscribe(async (event) => {
  const player = event.player;
  const block = event.block;
  const item = event.itemStack;
  const settings = getAddonSettings();

  // Check if the player is holding the special tool
  if (
    item &&
    item.typeId === settings.specialStickItemId &&
    item.getLore().includes(settings.specialStickLore)
  ) {
    event.cancel = true; // Cancel default block interaction

    if (!isChestBlock(block)) {
      player.sendMessage(
        "§cYou must interact with a regular chest, trapped chest, shulker box, or barrel to configure."
      );
      return;
    }

    let chestLocation;
    try {
      chestLocation = getChestLocation(block);
    } catch (e) {
      player.sendMessage(`§cError getting chest location: ${e.message}`);
      DebugLog(
        `§c[playerInteractWithBlock] Error getting chest location for block at ${block.location.x},${block.location.y},${block.location.z}: ${e.message}`
      );
      return;
    }

    if (!chestLocation) {
      player.sendMessage("§cError: Could not determine chest location.");
      return;
    }

    const chestKey = generateChestKey(chestLocation);
    const allConfigs = getChestConfig();
    const existingConfig = allConfigs[chestKey];

    if (player.isSneaking) {
      // If sneaking + interacting with special item on a chest
      if (existingConfig) {
        // Temporarily disable respawn for editing
        existingConfig.isDisabled = true;
        setChestConfig(allConfigs);
        // Clear existing interval if any
        if (ACTIVE_RESPAWN_INTERVALS.has(chestKey)) {
          system.clearRun(ACTIVE_RESPAWN_INTERVALS.get(chestKey));
          ACTIVE_RESPAWN_INTERVALS.delete(chestKey);
          player.sendMessage(`This chest was paused!`);
        }
      }
    } else {
      // Non-sneaking interaction with special item on a chest
      if (existingConfig) {
        system.run(() => {
          openAdminChestMenu(player, block, chestKey);
        });
      } else {
        system.run(() => {
          openChestConfigMenu(player, block);
        });
      }
    }
  } else {
    // This is for general player interaction with any block, specifically to track chest opens
    // Only proceed if the player is NOT holding the special tool (to avoid conflicts)
    // and is NOT sneaking (to avoid conflicts with the main menu trigger)
    if (
      !item ||
      item.typeId !== settings.specialStickItemId ||
      !item.getLore().includes(settings.specialStickLore)
    ) {
      if (!player.isSneaking && isChestBlock(block)) {
        let chestLocation;
        try {
          chestLocation = getChestLocation(block);
        } catch (e) {
          DebugLog(
            `§c[playerInteractWithBlock] Error getting chest location for block (non-tool interaction) at ${block.location.x},${block.location.y},${block.location.z}: ${e.message}`
          );
          return;
        }

        if (!chestLocation) return;

        const chestKey = generateChestKey(chestLocation);
        const allConfigs = getChestConfig();
        const config = allConfigs[chestKey];

        if (config && config.respawnType === "after_open") {
          // Check if the chest was actually opened. This is a heuristic.
          // A more robust check would involve checking the container's open state,
          // but that's not directly exposed in the current API for playerInteractWithBlock.
          // For now, we assume a non-sneaking interaction with a chest means an attempt to open.
          config.lastOpenedTime = Date.now(); // Record current time in milliseconds
          setChestConfig(allConfigs);
          DebugLog(
            `Chest at ${chestKey} was interacted with by ${player.name}. Last opened time updated.`
          );
        }
      }
    }
  }
});

// Handle block breaking to prevent config loss unless explicitly removed
world.beforeEvents.playerBreakBlock.subscribe((event) => {
  const block = event.block;
  if (!isChestBlock(block)) return; // Only care about chest-like blocks

  const chestLocation = getChestLocation(block);
  if (!chestLocation) return; // Should not happen for valid chests

  const chestKey = generateChestKey(chestLocation);
  const allConfigs = getChestConfig();
  const config = allConfigs[chestKey];

  if (config && config.isIndestructible) {
    // Check if the chest is configured as indestructible
    // If a config exists for this chest AND it's indestructible, cancel the break event
    event.cancel = true;
    event.player.sendMessage(
      "§cThis chest is a configured Chest Spawner and is indestructible. You must remove its spawner configuration via the admin menu (!cs menu -> View All Configured Chests) to destroy it."
    );
  }
  // Removed the 'else if (config)' block.
  // If config exists but isIndestructible is false, the event will NOT be cancelled,
  // allowing the chest to be broken.
  // If no config exists, the event is also not cancelled.
});

// Removed world.afterEvents.playerOpenContainer.subscribe as requested.

// ================== Initialization ==================

// Load existing configurations and start respawn intervals on world load
system.runTimeout(() => {
  const allConfigs = getChestConfig();
  for (const chestKey in allConfigs) {
    const config = allConfigs[chestKey];
    const chestLocation = parseChestKey(chestKey);
    const block = world.getDimension("overworld").getBlock(chestLocation); // Assume overworld for now

    // The block restoration logic is now handled by respawnChestContents.
    // Here, we just ensure the config is not disabled and start the respawn.
    if (config.isDisabled) {
      config.isDisabled = false;
      setChestConfig(allConfigs); // Save updated state
    }
    startChestRespawn(chestKey, config);
    DebugLog(`Re-initialized respawn for chest at ${chestKey}`);

    // Removed the else block here, as respawnChestContents will handle missing blocks.
    // If respawnChestContents fails to restore, it will clean up the config.
  }
  DebugLog("Chest Spawner Addon loaded and existing spawners initialized.");
}, 40); // Run after a short delay to ensure world is ready

system.beforeEvents.startup.subscribe((init) => {
  let actions = ["menu", "item", "debug"];
  // Register enum for actions
  init.customCommandRegistry.registerEnum("cmd:csaction", actions);
  init.customCommandRegistry.registerCommand(
    {
      name: "cmd:cs",
      description: "Chest Spawner Command",
      permissionLevel: CommandPermissionLevel.Admin,

      // Tham số không bắt buộc (có thể bỏ qua để mở UI)
      optionalParameters: [
        {
          name: "cmd:csaction",
          type: CustomCommandParamType.Enum,
        },
      ],
    },

    // Callback xử lý lệnh
    ({ sourceEntity }, action) => {
      const player = sourceEntity;

      action = action.toLowerCase();

      if (action == "menu") {
        system.run(() => {
          openMainMenu(player);
        });
      } else if (action == "debug") {
        system.run(() => {
          openDebugLogForm(player);
        });
      } else if (action == "item") {
        giveSpecialItem(player);
      }
    }
  );
});
