// Player Vault using `dienkon:inventory` entity
// Automatically saves and removes the entity when a player leaves it.

import {
  world,
  system,
  Player,
  ItemStack,
  Entity,
  CommandPermissionLevel,
  CustomCommandStatus,
  CustomCommandParamType,
  EnchantmentTypes,
} from "@minecraft/server";

import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";

// Requires a custom entity addon with `dienkon:inventory`
const VAULT_ENTITY_TYPE = "dienkon:inventory";
const VAULT_TAG = "pv";

const VAULT_STORAGE_PREFIX = "playerVault_";
const MAX_VAULTS_PER_PLAYER = 5;

system.beforeEvents.startup.subscribe((init) => {
  init.customCommandRegistry.registerCommand(
    {
      name: "cmd:pv",
      description: "Open Player Vault",
      permissionLevel: CommandPermissionLevel.Any,

      // Optional parameter (can be omitted to open the UI)
      optionalParameters: [
        {
          name: "cmd:vault_number",
          type: CustomCommandParamType.Integer,
        },
      ],
    },

    // Command processing callback
    ({ sourceEntity }, vaultNumber) => {
      const player = sourceEntity;

      if (
        isNaN(vaultNumber) ||
        vaultNumber < 1 ||
        vaultNumber > MAX_VAULTS_PER_PLAYER
      ) {
        player.sendMessage(`§cUsage: /pv 1-${MAX_VAULTS_PER_PLAYER}`);
        return;
      }

      system.run(() => openVaultEntity(player, vaultNumber));
      return {
        status: CustomCommandStatus.Success,
        message: ``,
      };
    }
  );
});

// Helper function to get item data, including components and durability
function getItemStackData(itemStack) {
  if (!itemStack) return null;

  const enchantments = [];
  try {
    const enchantableComponent = itemStack.getComponent(
      "minecraft:enchantable"
    );
    if (enchantableComponent) {
      for (const enchantment of enchantableComponent.getEnchantments()) {
        enchantments.push({
          typeId: enchantment.type.id,
          level: enchantment.level,
        });
      }
    }
  } catch (e) {
    console.error(`[Vault] Error getting enchantments: ${e}`);
  }

  // Get and serialize durability
  let durabilityData = null;
  try {
    const durabilityComponent = itemStack.getComponent("minecraft:durability");
    if (durabilityComponent) {
      durabilityData = {
        damage: durabilityComponent.damage,
        maxDurability: durabilityComponent.maxDurability,
      };
    }
  } catch (e) {
    console.error(`[Vault] Error getting durability: ${e}`);
  }

  // Get and serialize other components, e.g., item_storage for shulker box
  const components = {};
  const itemStorageComponent = itemStack.getComponent("minecraft:item_storage");
  if (itemStorageComponent) {
    const items = [];
    for (let i = 0; i < itemStorageComponent.container.size; i++) {
      const item = itemStorageComponent.container.getItem(i);
      if (item) {
        items.push(getItemStackData(item)); // Recursive call to handle nested items
      } else {
        items.push(null);
      }
    }
    components["minecraft:item_storage"] = {
      inventory: items,
    };
  }

  // Add other components here if necessary

  const data = {
    itemId: itemStack.typeId,
    amount: itemStack.amount,
    nameTag: itemStack.nameTag || "",
    lore: itemStack.getLore(),
    enchantments: enchantments,
    durability: durabilityData, // Store serialized durability
    components: components, // Store serialized components
  };
  return data;
}

// Helper function to recreate an ItemStack from data, including components and durability
function createItemStackFromData(itemData) {
  if (!itemData || !itemData.itemId || itemData.amount === undefined)
    return null;
  try {
    const itemStack = new ItemStack(itemData.itemId, itemData.amount);
    if (itemData.nameTag) {
      itemStack.nameTag = itemData.nameTag;
    }
    if (itemData.lore && Array.isArray(itemData.lore)) {
      itemStack.setLore(itemData.lore);
    }

    // Apply enchantments
    if (itemData.enchantments && Array.isArray(itemData.enchantments)) {
      try {
        const enchantableComponent = itemStack.getComponent(
          "minecraft:enchantable"
        );
        if (enchantableComponent) {
          for (const enchData of itemData.enchantments) {
            const enchantmentType = EnchantmentTypes.get(enchData.typeId);
            if (enchantmentType) {
              enchantableComponent.addEnchantment({
                type: enchantmentType,
                level: enchData.level,
              });
            }
          }
        }
      } catch (e) {
        console.error(`[Vault] Error applying enchantments: ${e}`);
      }
    }

    // Apply durability
    if (itemData.durability) {
      try {
        const durabilityComponent = itemStack.getComponent(
          "minecraft:durability"
        );
        if (durabilityComponent) {
          durabilityComponent.damage = itemData.durability.damage;
        }
      } catch (e) {
        console.error(`[Vault] Error applying durability: ${e}`);
      }
    }

    // Apply other components
    if (itemData.components) {
      const itemStorageData = itemData.components["minecraft:item_storage"];
      if (itemStorageData) {
        const itemStorageComponent = itemStack.getComponent(
          "minecraft:item_storage"
        );
        if (itemStorageComponent) {
          const inventory = itemStorageComponent.container;
          for (let i = 0; i < inventory.size; i++) {
            const nestedItemData = itemStorageData.inventory[i];
            if (nestedItemData) {
              const nestedItemStack = createItemStackFromData(nestedItemData); // Recursive call
              if (nestedItemStack) {
                inventory.setItem(i, nestedItemStack);
              }
            }
          }
        }
      }
    }

    return itemStack;
  } catch (e) {
    console.error(
      `[Vault] Could not create ItemStack from data: ${JSON.stringify(
        itemData
      )} - ${e.message}`
    );
    return null;
  }
}

// ⚒️ Spawn entity, open GUI
function openVaultEntity(player, vaultNumber) {
  const dim = player.dimension;
  const loc = player.location;
  const vaultLoc = { x: loc.x, y: loc.y, z: loc.z };

  // 🧹 Clear old entity if it exists
  const existingVaults = world
    .getDimension("overworld")
    .getEntities({ tags: [VAULT_TAG], families: ["player_vault"] });
  for (const entity of existingVaults) {
    if (entity.getDynamicProperty("playerOwnerId") === player.id) {
      entity.remove();
    }
  }

  system.run(() => {
    // Spawn entity
    const vaultEntity = dim.spawnEntity(VAULT_ENTITY_TYPE, vaultLoc);

    // Set name
    vaultEntity.nameTag = `§4Vault #${vaultNumber}`;

    if (!vaultEntity) {
      player.sendMessage("§cCould not create vault entity.");
      return;
    }
    // Set dynamic properties and tags
    vaultEntity.addTag(VAULT_TAG);
    // Sử dụng ID của người chơi làm thuộc tính động để đảm bảo mỗi vault là duy nhất cho mỗi người chơi.
    vaultEntity.setDynamicProperty("playerOwnerId", player.id);
    vaultEntity.setDynamicProperty("vaultNumber", vaultNumber);

    // Load items
    const inv = vaultEntity.getComponent("minecraft:inventory").container;
    const key = `${VAULT_STORAGE_PREFIX}${vaultNumber}`;

    loadVaultItems(inv, key, player);

    // Let the player ride the vault entity
    player.runCommand(`ride @s start_riding @e[type=${VAULT_ENTITY_TYPE},c=1]`);
    player.addTag("is_in_vault");
    player.sendMessage(`§aOpened Vault §4#${vaultNumber}`);
    system.runTimeout(() => {
      player.runCommand(
        `title @s actionbar §aPress §eE§a to open Vault\n§cPress §eSHIFT §cto exit Vault`
      );
    }, 1);
  });
}

// 💾 Save items from vault
function saveVaultItems(inventory, key, player) {
  const data = [];
  for (let i = 0; i < inventory.size; i++) {
    const item = inventory.getItem(i);
    if (item) {
      data.push(getItemStackData(item));
    } else {
      data.push(null);
    }
  }

  try {
    const json = JSON.stringify(data);
    // The player's ID is prefixed to the key to ensure each player has their own unique vaults.
    world.setDynamicProperty(`${player.id}_${key}`, json);
    // player.sendMessage(
    //   `§aSaved Vault #${key.replace(VAULT_STORAGE_PREFIX, "")}.`
    // );
  } catch (e) {
    console.error(`[Vault] Error saving items: ${e}`);
    player.sendMessage(
      `§cError saving Vault #${key.replace(VAULT_STORAGE_PREFIX, "")}.`
    );
  }
}

// 📥 Load items into vault
function loadVaultItems(inventory, key, player) {
  try {
    // The player's ID is prefixed to the key to ensure we load the correct vaults for the player.
    const json = world.getDynamicProperty(`${player.id}_${key}`);
    const data = json ? JSON.parse(json) : [];

    for (let i = 0; i < inventory.size; i++) {
      const itemData = data[i];
      if (itemData) {
        const itemStack = createItemStackFromData(itemData);
        if (itemStack) {
          inventory.setItem(i, itemStack);
        }
      }
    }
  } catch (e) {
    console.error(`[Vault] Error loading items: ${e}`);
    player.sendMessage(
      `§cError loading Vault #${key.replace(VAULT_STORAGE_PREFIX, "")}.`
    );
  }
}

// ✅ Use system.runInterval to check if the player has left the entity
system.runInterval(() => {
  const playersInVault = world
    .getPlayers()
    .filter((p) => p.hasTag("is_in_vault"));

  for (const player of playersInVault) {
    const ride = player.getComponent("minecraft:rideable");

    // 🚩FIX: Filtering entities with a dynamic property is unreliable.
    // Instead, we get all entities with the vault tag and then filter them with JavaScript.
    const allVaults = world.getDimension("overworld").getEntities({
      type: VAULT_ENTITY_TYPE,
      tags: [VAULT_TAG],
    });
    const vaultEntity = allVaults.find((entity) => {
      return entity.getDynamicProperty("playerOwnerId") === player.id;
    });

    // Check for forbidden items continuously while the player is in the vault
    if (vaultEntity) {
      const inv = vaultEntity.getComponent("minecraft:inventory").container;
      const playerInv = player.getComponent("minecraft:inventory").container;
      let forbiddenItemFound = false;
      const forbiddenItems = ["shulker_box", "bundle"];

      vaultEntity.teleport(vaultEntity.location);

      // Iterate through the vault's inventory to find forbidden items
      for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (item && forbiddenItems.some((f) => item.typeId.includes(f))) {
          // Give the forbidden item back to the player
          playerInv.addItem(item);
          player.sendMessage(
            "§cForbidden item detected! It has been returned to your inventory."
          );
          player.playSound("note.bass", player.location);

          // Clear the item from the vault's inventory
          inv.setItem(i, null);
          forbiddenItemFound = true;
        }
      }

      // Remove the vault entity if any forbidden item was found
      if (forbiddenItemFound) {
        // vaultEntity.remove();
        continue; // Move to the next player in the loop
      }
    }

    // If the player is no longer riding the entity or it's not a vault
    if (!ride || ride.typeId !== VAULT_ENTITY_TYPE || !ride.hasTag(VAULT_TAG)) {
      if (vaultEntity) {
        const inv = vaultEntity.getComponent("minecraft:inventory").container;
        const vaultNumber = vaultEntity.getDynamicProperty("vaultNumber");
        const key = `${VAULT_STORAGE_PREFIX}${vaultNumber}`;

        saveVaultItems(inv, key, player);
      }
    }
  }
}, 1);
