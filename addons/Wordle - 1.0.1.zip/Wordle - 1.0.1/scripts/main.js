import {
  world,
  system,
  Player,
  CommandPermissionLevel,
  CustomCommandParamType,
  CustomCommandStatus,
} from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// Định nghĩa các khóa cho DynamicProperties dưới dạng các biến const riêng biệt
const X_BET_KEY = "wordle:x_bet";
const MIN_BET_KEY = "wordle:min_bet";
const MAX_BET_KEY = "wordle:max_bet";
const SCOREBOARD_KEY = "wordle:scoreboard";
const PLAYER_LANGUAGES_KEY = "wordle:player_languages"; // Lưu trữ một chuỗi JSON của { playerId: languageCode }
const CHANCES_KEY = "wordle:chances"; // Khóa mới cho số lượt chơi
const WORDS_KEY = "wordle:words"; // Khóa mới để lưu trữ danh sách từ
const BETTING_ENABLED_KEY = "wordle:betting_enabled"; // Khóa mới cho tính năng bật/tắt cược

// Dữ liệu dịch thuật cho các ngôn ngữ
const translations = {
  en: {
    wordleTitle: "§bW§co§dr§ad§el§re",
    settingTitle: "Settings",
    generalSettings: "General Settings",
    wordSettings: "Word Settings",
    addWord: "Add Word",
    viewAllWords: "View All Words",
    searchWord: "Search Word",
    deleteAllWords: "Delete All Words",
    enterNewWord: "Enter new 5-character word:",
    wordAdded: (word) => `§aWord '${word}' added successfully!§r`,
    invalidWordLength: "§cWord must be exactly 5 characters long.§r",
    wordExists: (word) => `§cWord '${word}' already exists!§r`,
    noWordsFound: "§cNo words found.§r",
    wordList: "Word List",
    searchResult: "Search Result",
    editWord: "Edit Word",
    deleteWord: "Delete Word",
    confirmDeleteAll:
      "§cAre you sure you want to delete ALL words? This cannot be undone!§r",
    allWordsDeleted: "§aAll words deleted successfully!§r",
    deleteCanceled: "§cDeletion canceled.§r",
    wordDeleted: (word) => `§aWord '${word}' deleted successfully!§r`,
    wordUpdated: (oldWord, newWord) =>
      `§aWord '${oldWord}' updated to '${newWord}' successfully!§r`,
    wordNotFound: "§cWord not found.§r",
    multipleBetLabel: "Multiplier (e.g., 2 for 2x winnings):",
    minBetLabel: "Minimum Bet:",
    maxBetLabel: "Maximum Bet:",
    scoreboardLabel: "Scoreboard (e.g., money):",
    chancesLabel: "Number of Chances (default 5):",
    bettingEnabledLabel: "Enable Betting:", // Nhãn mới cho bật/tắt cược
    settingCanceled: "§cSettings canceled!§r",
    invalidMultiplier:
      "§cInvalid multiplier. Please enter a positive number.§r",
    invalidMinBet:
      "§cInvalid minimum bet. Please enter a non-negative number.§r",
    invalidMaxBet:
      "§cInvalid maximum bet. Please enter a number greater than or equal to the minimum bet.§r",
    scoreboardEmpty: "§cScoreboard cannot be empty.§r",
    invalidChances:
      "§cInvalid number of chances. Please enter a positive integer.§r",
    settingsSaved: "§aSettings saved successfully!§r",
    betTitle: "Place Your Bet",
    betInstructions: (xBet, currentScore) =>
      `§rEnter the amount you want to bet. If you §ewin, §ayou will receive §r${xBet} §atimes your bet,\n§cbut if you lose, you will lose everything.\n\n§rYour balance: ${currentScore}`,
    fillBlanks: "§cPlease fill in the blanks§r",
    enterNumbersOnly: "§cYou must only enter numbers§r",
    betTooLow: (minBet) => `§cBet must be greater than ${minBet}§r`,
    betTooHigh: (maxBet) => `§cBet must be less than ${maxBet}§r`,
    insufficientFunds:
      "§cYour current balance is less than the amount you just bet§r",
    gameInstructions: (chances, testCase) =>
      `Guess the word. §c(5 characters limit)§r\n\n${testCase}\n§rYou have ${chances} chances left`,
    gameCanceled: "§cGame canceled!§r",
    betRefunded: (bet) =>
      `§eYour bet of ${bet} has been refunded due to game cancellation.§r`,
    enterFiveChars: "§cPlease enter exactly 5 characters!§r",
    congratulations: (wordGuess, winnings) =>
      `§aCongratulations! You guessed the word: ${wordGuess}\n§eYou earned ${winnings}§r`,
    gameOver: (wordGuess, bet) =>
      `§cGame Over! The correct word was: ${wordGuess}\n§4You lost ${bet}§r`,
    scoreError: (objective) => `Error getting score for ${objective}:`,
    languageSettingLabel: "Select Language:",
    searchWordPrompt: "Enter the word to search:",
    wordSearchCanceled: "§cWord search canceled!§r",
    noWordsForGame:
      "§cNo words available to play. Please add words in settings.§r",
    playingWithoutBet: "§aPlaying without betting. Have fun!§r", // New translation
  },
  vi: {
    wordleTitle: "§bW§co§dr§ad§el§re",
    settingTitle: "Cài đặt",
    generalSettings: "Cài đặt chung",
    wordSettings: "Cài đặt từ",
    addWord: "Thêm từ",
    viewAllWords: "Tất cả từ",
    searchWord: "Tìm kiếm từ",
    deleteAllWords: "Xóa toàn bộ từ",
    enterNewWord: "Nhập từ mới (5 ký tự):",
    wordAdded: (word) => `§aĐã thêm từ '${word}' thành công!§r`,
    invalidWordLength: "§cTừ phải có đúng 5 ký tự.§r",
    wordExists: (word) => `§cTừ '${word}' đã tồn tại!§r`,
    noWordsFound: "§cKhông tìm thấy từ nào.§r",
    wordList: "Danh sách từ",
    searchResult: "Kết quả tìm kiếm",
    editWord: "Chỉnh sửa từ",
    deleteWord: "Xóa từ",
    confirmDeleteAll:
      "§cBạn có chắc chắn muốn xóa TẤT CẢ các từ không? Thao tác này không thể hoàn tác!§r",
    allWordsDeleted: "§aĐã xóa tất cả các từ thành công!§r",
    deleteCanceled: "§cĐã hủy xóa.§r",
    wordDeleted: (word) => `§aĐã xóa từ '${word}' thành công!§r`,
    wordUpdated: (oldWord, newWord) =>
      `§aĐã cập nhật từ '${oldWord}' thành '${newWord}' thành công!§r`,
    wordNotFound: "§cKhông tìm thấy từ.§r",
    multipleBetLabel: "Tỷ lệ thắng (ví dụ: 2 cho x2 tiền):",
    minBetLabel: "Cược tối thiểu:",
    maxBetLabel: "Cược tối đa:",
    scoreboardLabel: "Bảng điểm (ví dụ: money):",
    chancesLabel: "Số lượt đoán (mặc định 5):",
    bettingEnabledLabel: "Bật cược:", // Nhãn mới cho bật/tắt cược
    settingCanceled: "§cCài đặt đã bị hủy bỏ!§r",
    invalidMultiplier: "§cTỷ lệ thắng không hợp lệ. Vui lòng nhập số dương.§r",
    invalidMinBet:
      "§cCược tối thiểu không hợp lệ. Vui lòng nhập số không âm.§r",
    invalidMaxBet:
      "§cCược tối đa không hợp lệ. Vui lòng nhập số lớn hơn hoặc bằng cược tối thiểu.§r",
    scoreboardEmpty: "§cBảng điểm không được để trống.§r",
    invalidChances:
      "§cSố lượt đoán không hợp lệ. Vui lòng nhập số nguyên dương.§r",
    settingsSaved: "§aCài đặt đã được lưu thành công!§r",
    betTitle: "Đặt cược",
    betInstructions: (xBet, currentScore) =>
      `§rNhập số tiền bạn muốn đặt cược. Nếu §ethắng, §abạn sẽ nhận lại §r${xBet} §alần số tiền đã cược,\n§cnhưng nếu thua, bạn sẽ mất tất cả.\n\n§rSố dư của bạn: ${currentScore}`,
    fillBlanks: "§cVui lòng điền vào chỗ trống§r",
    enterNumbersOnly: "§cBạn chỉ được nhập số§r",
    betTooLow: (minBet) => `§cCược phải lớn hơn ${minBet}§r`,
    betTooHigh: (maxBet) => `§cCược phải nhỏ hơn ${maxBet}§r`,
    insufficientFunds:
      "§cSố tiền hiện tại của bạn ít hơn số tiền bạn vừa đặt cược§r",
    gameInstructions: (chances, testCase) =>
      `Nhập từ bạn đoán. §c(giới hạn 5 ký tự)§r\n\n${testCase}\n§rBạn còn ${chances} lượt`,
    gameCanceled: "§cBạn đã hủy trò chơi!§r",
    betRefunded: (bet) =>
      `§eSố tiền ${bet} đã được hoàn lại do hủy trò chơi.§r`,
    enterFiveChars: "§cVui lòng nhập đúng 5 ký tự!§r",
    congratulations: (wordGuess, winnings) =>
      `§aChúc mừng! Bạn đã đoán đúng từ: ${wordGuess}\n§eBạn kiếm được ${winnings}§r`,
    gameOver: (wordGuess, bet) =>
      `§cTrò chơi kết thúc! Từ đúng là: ${wordGuess}\n§4Bạn mất ${bet}§r`,
    scoreError: (objective) => `Lỗi khi lấy điểm cho ${objective}:`,
    languageSettingLabel: "Chọn ngôn ngữ:",
    searchWordPrompt: "Nhập từ cần tìm:",
    wordSearchCanceled: "§cĐã hủy tìm kiếm từ!§r",
    noWordsForGame:
      "§cKhông có từ nào để chơi. Vui lòng thêm từ trong cài đặt.§r",
    playingWithoutBet: "§aChơi không cược. Chúc vui vẻ!§r", // New translation
  },
};

// Hàm để lấy giá trị cấu hình từ DynamicProperties
function getConfig(key, defaultValue) {
  const value = world.getDynamicProperty(key);
  return value !== undefined ? value : defaultValue;
}

// Hàm để đặt giá trị cấu hình vào DynamicProperties
function setConfig(key, value) {
  world.setDynamicProperty(key, value);
}

// Hàm trợ giúp để lấy ngôn ngữ của người chơi
function getPlayerLanguage(player) {
  const playerLanguagesJson = world.getDynamicProperty(PLAYER_LANGUAGES_KEY);
  let playerLanguages = {};
  try {
    playerLanguages = playerLanguagesJson
      ? JSON.parse(playerLanguagesJson)
      : {};
  } catch (e) {
    console.error(`Lỗi khi phân tích JSON ngôn ngữ người chơi: ${e}`);
  }
  return playerLanguages[player.id] || "en"; // Mặc định là tiếng Anh
}

// Hàm trợ giúp để đặt ngôn ngữ của người chơi
function setPlayerLanguage(player, languageCode) {
  const playerLanguagesJson = world.getDynamicProperty(PLAYER_LANGUAGES_KEY);
  let playerLanguages = {};
  try {
    playerLanguages = playerLanguagesJson
      ? JSON.parse(playerLanguagesJson)
      : {};
  } catch (e) {
    console.error(`Lỗi khi phân tích JSON ngôn ngữ người chơi: ${e}`);
  }
  playerLanguages[player.id] = languageCode;
  world.setDynamicProperty(
    PLAYER_LANGUAGES_KEY,
    JSON.stringify(playerLanguages)
  );
}

// Hàm trợ giúp để lấy chuỗi đã dịch
function getTranslatedString(player, key, ...args) {
  const lang = getPlayerLanguage(player);
  // Thử ngôn ngữ của người chơi, sau đó mặc định là tiếng Anh
  const translation =
    translations[lang] && translations[lang][key]
      ? translations[lang][key]
      : translations.en[key];
  if (typeof translation === "function") {
    return translation(...args);
  }
  return translation;
}

// Hàm lấy danh sách từ từ Dynamic Property
function getWords() {
  const wordsJson = world.getDynamicProperty(WORDS_KEY);
  try {
    return wordsJson ? JSON.parse(wordsJson) : [];
  } catch (e) {
    console.error("Error parsing words from Dynamic Property:", e);
    return [];
  }
}

// Hàm lưu danh sách từ vào Dynamic Property
function setWords(wordsArray) {
  world.setDynamicProperty(WORDS_KEY, JSON.stringify(wordsArray));
}

// Danh sách các từ mặc định cho trò chơi Wordle
const defaultWords = [
  `HELLO`,
  `SUPER`,
  `HAPPY`,
  `APPLE`,
  `GRAPE`,
  `MANGO`,
  `PEACH`,
  `PLUMS`,
  `BERRY`,
  `CHILI`,
  `OLIVE`,
  `ONION`,
  `SALAD`,
  `BREAD`,
  `PASTA`,
  `CHEES`,
  `JUICE`,
  `LEMON`,
  `CANDY`,
  `TEETH`,
  `HONEY`,
  `PEARS`,
  `WATER`,
  `SUGAR`,
  `TABLE`,
  `CHAIR`,
  `COUCH`,
  `LAPEL`,
  `SHIRT`,
  `DRESS`,
  `SKIRT`,
  `PANTS`,
  `CLOAK`,
  `SWORD`,
  `SHARP`,
  `BLUNT`,
  `PAPER`,
  `BOARD`,
  `KNIFE`,
  `TOOLS`,
  `BASIC`,
  `BUILD`,
  `PLANE`,
  `TRAIN`,
  `TRUCK`,
  `HOUSE`,
  `STICK`,
  `BRICK`,
  `STONE`,
  `MOUNT`,
  `VALVE`,
  `COAST`,
  `PLATE`,
  `GLASS`,
  `STEEL`,
  `ALLOY`,
  `LAYER`,
  `FENCE`,
  `BLOCK`,
  `MARCH`,
  `CRISP`,
  `ROUND`,
  `BLOOM`,
  `SMOKE`,
  `FIERY`,
  `EARTH`,
  `MOIST`,
  `WAVES`,
  `SUNNY`,
  `NIGHT`,
  `SPACE`,
  `LIGHT`,
  `SHINE`,
  `FAITH`,
  `TRUST`,
  `PEACE`,
  `BLISS`,
  `HAPPY`,
  `ANGEL`,
  `DEVIL`,
  `MAGIC`,
  `STORM`,
  `CLOUD`,
  `POWER`,
  `CHAOS`,
  `ORDER`,
  `HEART`,
  `MINDY`,
  `SOLID`,
  `LIQID`,
  `RIVER`,
  `STREAM`,
  `WOODS`,
  `BIRTH`,
  `TIGER`,
  `HORSE`,
  `SNAKE`,
  `BISON`,
  `EAGLE`,
  `CRANE`,
  `OCEAN`,
  `HILLS`,
  `PLAIN`,
];

// Khởi tạo các giá trị cấu hình mặc định khi thế giới khởi tạo
system.run(() => {
  if (getConfig(X_BET_KEY) === undefined) {
    setConfig(X_BET_KEY, 2);
  }
  if (getConfig(MIN_BET_KEY) === undefined) {
    setConfig(MIN_BET_KEY, 100);
  }
  if (getConfig(MAX_BET_KEY) === undefined) {
    setConfig(MAX_BET_KEY, 1000000000);
  }
  if (getConfig(SCOREBOARD_KEY) === undefined) {
    setConfig(SCOREBOARD_KEY, "money");
  }
  if (getConfig(CHANCES_KEY) === undefined) {
    setConfig(CHANCES_KEY, 5); // Mặc định 5 lượt chơi
  }
  if (getConfig(BETTING_ENABLED_KEY) === undefined) {
    setConfig(BETTING_ENABLED_KEY, true); // Mặc định bật cược
  }
  // Khởi tạo thuộc tính ngôn ngữ người chơi nếu chưa tồn tại
  if (world.getDynamicProperty(PLAYER_LANGUAGES_KEY) === undefined) {
    world.setDynamicProperty(PLAYER_LANGUAGES_KEY, "{}");
  }
  // Khởi tạo danh sách từ nếu chưa tồn tại hoặc rỗng, thêm 100 từ mặc định
  if (
    world.getDynamicProperty(WORDS_KEY) === undefined ||
    getWords().length === 0
  ) {
    setWords(defaultWords);
  }
});

// Lắng nghe các sự kiện script
system.afterEvents.scriptEventReceive.subscribe((event) => {
  const { id, message, sourceEntity: player } = event;
  if (id !== "game:wordle" || !(player instanceof Player)) return;

  if (message.startsWith("play")) {
    // Kiểm tra trạng thái cược trước khi gọi Bet
    const isBettingEnabled = getConfig(BETTING_ENABLED_KEY, true);
    const initialChances = getConfig(CHANCES_KEY, 5);
    const wordGuess = getRandomWordFromDynamicProperty(player);

    if (!wordGuess) {
      player.sendMessage(getTranslatedString(player, "noWordsForGame"));
      return;
    }

    if (!isBettingEnabled) {
      player.sendMessage(getTranslatedString(player, "playingWithoutBet"));
      Start(player, wordGuess, initialChances, "", "", 0); // Bắt đầu game không cược
    } else {
      Bet(player, ""); // Gọi hàm đặt cược
    }
  }
  if (message.startsWith("config")) {
    system.run(() => {
      Setting(player);
    });
  }
});

// Hàm hiển thị form cài đặt chính (ActionFormData)
function Setting(player) {
  let form = new ActionFormData();
  form.title(getTranslatedString(player, "settingTitle"));
  form.button(getTranslatedString(player, "generalSettings"));
  form.button(getTranslatedString(player, "wordSettings"));

  form.show(player).then((res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    if (res.selection === 0) {
      GeneralSettings(player);
    } else if (res.selection === 1) {
      WordSettings(player);
    }
  });
}

// Hàm hiển thị form cài đặt chung (ModalFormData)
function GeneralSettings(player) {
  let form = new ModalFormData();
  const currentLang = getPlayerLanguage(player);

  form.title(getTranslatedString(player, "generalSettings"));

  // Lấy giá trị hiện tại từ cấu hình đã lưu
  const currentXBet = getConfig(X_BET_KEY, 2);
  const currentMinBet = getConfig(MIN_BET_KEY, 100);
  const currentMaxBet = getConfig(MAX_BET_KEY, 1000000000);
  const currentScoreboard = getConfig(SCOREBOARD_KEY, "money");
  const currentChances = getConfig(CHANCES_KEY, 5); // Lấy số lượt chơi hiện tại
  const currentBettingEnabled = getConfig(BETTING_ENABLED_KEY, true); // Lấy trạng thái bật/tắt cược

  form.textField(getTranslatedString(player, "multipleBetLabel"), ``, {
    defaultValue: String(currentXBet), // Ensure it's a string
  });
  form.textField(getTranslatedString(player, "minBetLabel"), ``, {
    defaultValue: String(currentMinBet), // Ensure it's a string
  });
  form.textField(getTranslatedString(player, "maxBetLabel"), ``, {
    defaultValue: String(currentMaxBet), // Ensure it's a string
  });
  form.textField(getTranslatedString(player, "scoreboardLabel"), ``, {
    defaultValue: String(currentScoreboard), // Ensure it's a string
  });
  form.textField(getTranslatedString(player, "chancesLabel"), ``, {
    defaultValue: String(currentChances), // Ensure it's a string
  });
  form.toggle(getTranslatedString(player, "bettingEnabledLabel"), {
    defaultValue: currentBettingEnabled,
  }); // Thêm toggle bật/tắt cược

  // Thêm lựa chọn ngôn ngữ
  const languageOptions = Object.keys(translations).map((langCode) => {
    switch (langCode) {
      case "en":
        return "English";
      case "vi":
        return "Tiếng Việt";
      default:
        return langCode; // Fallback cho các ngôn ngữ không xác định
    }
  });
  const currentLangIndex = Object.keys(translations).indexOf(currentLang);
  form.dropdown(
    getTranslatedString(player, "languageSettingLabel"),
    languageOptions,
    { defaultValue: currentLangIndex } // Set default selected option
  );

  form.show(player).then((res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    const newXBet = parseInt(res.formValues[0]);
    const newMinBet = parseInt(res.formValues[1]);
    const newMaxBet = parseInt(res.formValues[2]);
    const newScoreboard = res.formValues[3];
    const newChances = parseInt(res.formValues[4]); // Lấy số lượt chơi mới
    const newBettingEnabled = res.formValues[5]; // Lấy trạng thái bật/tắt cược mới
    const newLangIndex = res.formValues[6]; // Chỉ số của ngôn ngữ đã chọn (index tăng lên 1 do có thêm toggle)
    const newLangCode = Object.keys(translations)[newLangIndex];

    // Kiểm tra và cập nhật các giá trị
    if (isNaN(newXBet) || newXBet <= 0) {
      player.sendMessage(getTranslatedString(player, "invalidMultiplier"));
      return;
    }
    if (isNaN(newMinBet) || newMinBet < 0) {
      player.sendMessage(getTranslatedString(player, "invalidMinBet"));
      return;
    }
    if (isNaN(newMaxBet) || newMaxBet < newMinBet) {
      player.sendMessage(getTranslatedString(player, "invalidMaxBet"));
      return;
    }
    if (!newScoreboard || newScoreboard.trim() === "") {
      player.sendMessage(getTranslatedString(player, "scoreboardEmpty"));
      return;
    }
    if (isNaN(newChances) || newChances <= 0) {
      player.sendMessage(getTranslatedString(player, "invalidChances"));
      return;
    }

    setConfig(X_BET_KEY, newXBet);
    setConfig(MIN_BET_KEY, newMinBet);
    setConfig(MAX_BET_KEY, newMaxBet);
    setConfig(SCOREBOARD_KEY, newScoreboard);
    setConfig(CHANCES_KEY, newChances); // Lưu số lượt chơi mới
    setConfig(BETTING_ENABLED_KEY, newBettingEnabled); // Lưu trạng thái bật/tắt cược mới
    setPlayerLanguage(player, newLangCode); // Lưu tùy chọn ngôn ngữ của người chơi

    player.sendMessage(getTranslatedString(player, "settingsSaved"));
  });
}

// Hàm hiển thị form cài đặt từ (ActionFormData)
async function WordSettings(player) {
  let form = new ActionFormData();
  form.title(getTranslatedString(player, "wordSettings"));
  form.button(getTranslatedString(player, "addWord"));
  form.button(getTranslatedString(player, "viewAllWords"));
  form.button(getTranslatedString(player, "searchWord"));
  form.button(getTranslatedString(player, "deleteAllWords"));

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    switch (res.selection) {
      case 0:
        addWord(player);
        break;
      case 1:
        viewAllWords(player);
        break;
      case 2:
        searchWord(player);
        break;
      case 3:
        deleteAllWords(player);
        break;
    }
  });
}

// Hàm thêm từ mới vào Dynamic Property
async function addWord(player) {
  let form = new ModalFormData();
  form.title(getTranslatedString(player, "addWord"));
  form.textField(getTranslatedString(player, "enterNewWord"), "");

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    let newWord = res.formValues[0]?.toUpperCase();

    if (!newWord || newWord.length !== 5) {
      player.sendMessage(getTranslatedString(player, "invalidWordLength"));
      return;
    }

    let currentWords = getWords();
    if (currentWords.includes(newWord)) {
      player.sendMessage(getTranslatedString(player, "wordExists", newWord));
      return;
    }

    currentWords.push(newWord);
    setWords(currentWords);
    player.sendMessage(getTranslatedString(player, "wordAdded", newWord));
  });
}

// Hàm xem tất cả các từ trong Dynamic Property
async function viewAllWords(player) {
  let currentWords = getWords();

  if (currentWords.length === 0) {
    player.sendMessage(getTranslatedString(player, "noWordsFound"));
    return;
  }

  let form = new ActionFormData();
  form.title(getTranslatedString(player, "wordList"));

  currentWords.forEach((word) => {
    form.button(word);
  });

  form.show(player).then((res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }
    const selectedWord = currentWords[res.selection];
    if (selectedWord) {
      manageWord(player, selectedWord);
    }
  });
}

// Hàm tìm kiếm từ trong Dynamic Property
async function searchWord(player) {
  let form = new ModalFormData();
  form.title(getTranslatedString(player, "searchWord"));
  form.textField(getTranslatedString(player, "searchWordPrompt"), "");

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "wordSearchCanceled"));
      return;
    }

    let searchTerm = res.formValues[0]?.toUpperCase();
    if (!searchTerm) {
      player.sendMessage(getTranslatedString(player, "fillBlanks"));
      return;
    }

    let currentWords = getWords();
    let foundWords = currentWords.filter((word) => word.includes(searchTerm));

    if (foundWords.length === 0) {
      player.sendMessage(getTranslatedString(player, "noWordsFound"));
      return;
    }

    let resultForm = new ActionFormData();
    resultForm.title(getTranslatedString(player, "searchResult"));

    foundWords.forEach((word) => {
      resultForm.button(word);
    });

    resultForm.show(player).then((resSelect) => {
      if (resSelect.canceled) {
        player.sendMessage(getTranslatedString(player, "settingCanceled"));
        return;
      }
      const selectedWord = foundWords[resSelect.selection];
      if (selectedWord) {
        manageWord(player, selectedWord);
      }
    });
  });
}

// Hàm quản lý từ (chỉnh sửa/xóa)
async function manageWord(player, wordText) {
  let form = new ActionFormData();
  form.title(`Manage Word: ${wordText}`);
  form.button(getTranslatedString(player, "editWord"));
  form.button(getTranslatedString(player, "deleteWord"));

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    if (res.selection === 0) {
      editWord(player, wordText);
    } else if (res.selection === 1) {
      deleteWord(player, wordText);
    }
  });
}

// Hàm chỉnh sửa từ trong Dynamic Property
async function editWord(player, oldWordText) {
  let form = new ModalFormData();
  form.title(getTranslatedString(player, "editWord"));
  form.textField(getTranslatedString(player, "enterNewWord"), "", {
    defaultValue: oldWordText,
  });

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "settingCanceled"));
      return;
    }

    let newWord = res.formValues[0]?.toUpperCase();

    if (!newWord || newWord.length !== 5) {
      player.sendMessage(getTranslatedString(player, "invalidWordLength"));
      return;
    }

    let currentWords = getWords();
    const index = currentWords.indexOf(oldWordText);

    if (index !== -1) {
      currentWords[index] = newWord;
      setWords(currentWords);
      player.sendMessage(
        getTranslatedString(player, "wordUpdated", oldWordText, newWord)
      );
    } else {
      player.sendMessage(getTranslatedString(player, "wordNotFound"));
    }
  });
}

// Hàm xóa từ khỏi Dynamic Property
async function deleteWord(player, wordText) {
  let currentWords = getWords();
  const filteredWords = currentWords.filter((word) => word !== wordText);

  if (filteredWords.length < currentWords.length) {
    setWords(filteredWords);
    player.sendMessage(getTranslatedString(player, "wordDeleted", wordText));
  } else {
    player.sendMessage(getTranslatedString(player, "wordNotFound"));
  }
}

// Hàm xóa toàn bộ từ khỏi Dynamic Property
async function deleteAllWords(player) {
  let confirmForm = new ModalFormData();
  confirmForm.title(getTranslatedString(player, "deleteAllWords"));
  confirmForm.textField(
    getTranslatedString(player, "confirmDeleteAll"),
    "type 'CONFIRM' to delete"
  );

  confirmForm.show(player).then(async (res) => {
    if (res.canceled || res.formValues[0]?.toUpperCase() !== "CONFIRM") {
      player.sendMessage(getTranslatedString(player, "deleteCanceled"));
      return;
    }

    setWords([]); // Set to empty array
    player.sendMessage(getTranslatedString(player, "allWordsDeleted"));
  });
}

// Hàm hiển thị form đặt cược
async function Bet(player, error) {
  const xBet = getConfig(X_BET_KEY, 2);
  const minBet = getConfig(MIN_BET_KEY, 100);
  const maxBet = getConfig(MAX_BET_KEY, 1000000000);
  const scoreboard = getConfig(SCOREBOARD_KEY, "money");
  const currentScore = getScore(player, scoreboard);
  const initialChances = getConfig(CHANCES_KEY, 5); // Lấy số lượt chơi mặc định

  // Lấy một từ ngẫu nhiên từ Dynamic Property
  let wordGuess = getRandomWordFromDynamicProperty(player);
  if (!wordGuess) {
    player.sendMessage(getTranslatedString(player, "noWordsForGame"));
    return;
  }

  let form = new ModalFormData();
  form.title(getTranslatedString(player, "betTitle"));
  form.textField(
    `${error ? `${error}\n\n` : ""}${getTranslatedString(
      // Thêm \n\n sau lỗi
      player,
      "betInstructions",
      xBet,
      currentScore
    )}`,
    `2000`
  );
  form.show(player).then(async (res) => {
    if (res.canceled) return;
    let bet = res.formValues[0];
    if (!res.formValues[0])
      return Bet(player, getTranslatedString(player, "fillBlanks"));
    if (isNaN(res.formValues[0]))
      return Bet(player, getTranslatedString(player, "enterNumbersOnly"));

    bet = Number(bet); // Chuyển đổi sang số

    if (bet < minBet)
      return Bet(player, getTranslatedString(player, "betTooLow", minBet));
    if (bet > maxBet)
      return Bet(player, getTranslatedString(player, "betTooHigh", maxBet));
    if (currentScore < bet)
      return Bet(player, getTranslatedString(player, "insufficientFunds"));

    player.runCommand(`scoreboard players remove @s ${scoreboard} ${bet}`);
    Start(player, wordGuess, initialChances, "", "", bet); // Truyền số lượt chơi ban đầu
  });
}

// Hàm lấy một từ ngẫu nhiên từ Dynamic Property
function getRandomWordFromDynamicProperty(player) {
  const words = getWords();
  if (words.length > 0) {
    return words[Math.floor(Math.random() * words.length)];
  }
  return null; // Không có từ nào
}

// Hàm bắt đầu trò chơi Wordle
function Start(player, wordGuess, chances, testCase, error, bet) {
  const modal = new ModalFormData();
  modal.title(getTranslatedString(player, "wordleTitle"));
  modal.textField(
    `${error ? `${error}\n\n` : ""}${getTranslatedString(
      // Thêm \n\n sau lỗi
      player,
      "gameInstructions",
      chances,
      testCase
    )}`,
    `HELLO`
  );

  modal.show(player).then((res) => {
    if (res.canceled) {
      player.sendMessage(getTranslatedString(player, "gameCanceled"));
      // Removed bet refund logic as requested
      return;
    }

    let word = res.formValues[0].toUpperCase();

    if (word.length !== 5) {
      return Start(
        player,
        wordGuess,
        chances,
        testCase,
        getTranslatedString(player, "enterFiveChars"),
        bet
      );
    }

    if (word === wordGuess) {
      const scoreboard = getConfig(SCOREBOARD_KEY, "money");
      const xBet = getConfig(X_BET_KEY, 2);
      const winnings = bet * xBet;
      // Only add winnings if betting is enabled and bet > 0
      if (getConfig(BETTING_ENABLED_KEY, true) && bet > 0) {
        player.sendMessage(
          getTranslatedString(player, "congratulations", wordGuess, winnings)
        );
        player.runCommand(
          `scoreboard players add @s ${scoreboard} ${winnings}`
        );
      } else {
        player.sendMessage(
          getTranslatedString(player, "congratulations", wordGuess, 0)
        ); // No winnings message
      }
      player.playSound("random.orb", player.location);
      return;
    }

    const test = checkWordleGuess(word, wordGuess);
    testCase += `${word}     ${test}§r\n`;
    if (chances - 1 <= 0) {
      // Only show loss message if betting is enabled and bet > 0
      if (getConfig(BETTING_ENABLED_KEY, true) && bet > 0) {
        player.sendMessage(
          getTranslatedString(player, "gameOver", wordGuess, bet)
        );
      } else {
        player.sendMessage(
          getTranslatedString(player, "gameOver", wordGuess, 0)
        ); // No loss message
      }
      player.playSound("note.bass", player.location);
      return;
    }

    Start(player, wordGuess, chances - 1, testCase, "", bet);
  });
}

// Hàm kiểm tra từ đoán Wordle
function checkWordleGuess(target, guess) {
  const result = Array(guess.length).fill("§cX"); // Mặc định là sai hoàn toàn
  const targetChars = target.split("");
  const guessUsed = Array(guess.length).fill(false); // Theo dõi các ký tự trong guess đã xử lý
  const targetUsed = Array(target.length).fill(false); // Theo dõi các ký tự trong target đã sử dụng

  // Bước 1: Kiểm tra đúng vị trí (green - §aO)
  for (let i = 0; i < guess.length; i++) {
    if (guess[i] === targetChars[i]) {
      result[i] = "§aO"; // Đúng ký tự và đúng vị trí
      guessUsed[i] = true; // Đánh dấu đã sử dụng ký tự ở vị trí này
      targetUsed[i] = true; // Đánh dấu ký tự trong target đã khớp
    }
  }

  // Bước 2: Kiểm tra đúng ký tự nhưng sai vị trí (yellow - §eX)
  for (let i = 0; i < guess.length; i++) {
    if (guessUsed[i]) continue; // Bỏ qua các ký tự đã đúng vị trí

    for (let j = 0; j < targetChars.length; j++) {
      if (!targetUsed[j] && guess[i] === targetChars[j]) {
        result[j] = "§eX"; // Reverted to result[j] as requested
        targetUsed[j] = true; // Đánh dấu ký tự trong target đã khớp
        break;
      }
    }
  }

  return result.join(""); // Trả về chuỗi kết quả
}

// Hàm lấy điểm từ bảng điểm
function getScore(player, objective) {
  try {
    const obj = world.scoreboard.getObjective(objective);
    if (obj) {
      return obj.getScore(player) || 0;
    }
    return 0;
  } catch (error) {
    console.warn(
      getTranslatedString(player, "scoreError", objective) + ` ${error}`
    );
    return 0;
  }
}

// ================================ COMMAND ==========================================

system.beforeEvents.startup.subscribe((init) => {
  const actionsEnum = ["play", "config"];

  // Register enum for actions
  init.customCommandRegistry.registerEnum("cmd:wordle_action", actionsEnum);
  init.customCommandRegistry.registerCommand(
    {
      name: "cmd:wordle",
      description: "Start the Wordle game or configure settings",
      permissionLevel: CommandPermissionLevel.Any,
      mandatoryParameters: [
        {
          name: "cmd:wordle_action",
          type: CustomCommandParamType.Enum,
        },
      ],
    },

    // Callback: (context, param1, param2...)
    ({ sourceEntity }, action) => {
      const player = sourceEntity;

      if (action === "play") {
        system.run(() => {
          // Kiểm tra trạng thái cược trước khi gọi Bet
          const isBettingEnabled = getConfig(BETTING_ENABLED_KEY, true);
          const initialChances = getConfig(CHANCES_KEY, 5);
          const wordGuess = getRandomWordFromDynamicProperty(player);

          if (!wordGuess) {
            player.sendMessage(getTranslatedString(player, "noWordsForGame"));
            return;
          }

          if (!isBettingEnabled) {
            Start(player, wordGuess, initialChances, "", "", 0); // Bắt đầu game không cược
          } else {
            Bet(player, ""); // Gọi hàm đặt cược
          }
        });

        return {
          status: CustomCommandStatus.Success,
        };
      }

      if (action === "config") {
        if (!player.hasTag("admin")) {
          return {
            status: CustomCommandStatus.Failure,
            message: "§cOnly operators can access configuration.",
          };
        }
        system.run(() => {
          Setting(player); // Gọi menu admin
        });

        return {
          status: CustomCommandStatus.Success,
          message: "§bOpening admin configuration...",
        };
      }

      return {
        status: CustomCommandStatus.Failure,
        message: "§cUnknown action. Use: §eplay §cor §econfig",
      };
    }
  );
});
