// skillCore.js
import { getPlayerProperty, setPlayerProperty } from "./utils.js";
import { getTranslatedText, getPlayerLocale } from "./lang.js";
import {
  STAT_POINT_PER_SKILL_LEVEL,
  xp as baseXpConstant,
  CHANCE_TO_GET_UNSPENT_STAT_POINT,
} from "./config.js";
import { applyAllStatEffects } from "./playerStats.js";

/**
 * Xử lý logic lên cấp chung cho một kỹ năng.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {object} skillConfig Cấu hình của kỹ năng từ skillConfig.js.
 */
export function handleSkillLevelUp(player, skillConfig) {
  const locale = getPlayerLocale(player);

  if (!player || !skillConfig) {
    console.error("Lỗi: Người chơi hoặc cấu hình kỹ năng không hợp lệ.");
    return;
  }

  const {
    objectivePrefix,
    xpObjectivePrefix,
    nextXpObjectivePrefix,
    nameKey, // nameKey của skill chính
    skillLevels,
  } = skillConfig;

  const currentLevel = getPlayerProperty(player, `skill:${objectivePrefix}`, 0);
  const currentXp = getPlayerProperty(player, `skill:${xpObjectivePrefix}`, 0);
  let nextXp = getPlayerProperty(
    player,
    `skill:${nextXpObjectivePrefix}`,
    skillConfig.baseXp || baseXpConstant
  );

  if (currentXp >= nextXp) {
    const newLevel = currentLevel + 1; // Cấp độ mới của skill chính

    // Tăng cấp độ kỹ năng chính
    setPlayerProperty(player, `skill:${objectivePrefix}`, newLevel);

    // Tính toán XP cần thiết cho cấp độ tiếp theo
    const newNextXp = Math.round(
      nextXp * 1.1 + baseXpConstant * (newLevel / 10)
    );
    setPlayerProperty(player, `skill:${nextXpObjectivePrefix}`, newNextXp);

    // Đặt lại XP hiện tại hoặc trừ đi lượng XP đã dùng cho cấp độ đó
    setPlayerProperty(player, `skill:${xpObjectivePrefix}`, currentXp - nextXp);
    if (getPlayerProperty(player, `skill:${xpObjectivePrefix}`) < 0) {
      setPlayerProperty(player, `skill:${xpObjectivePrefix}`, 0);
    }

    // Cập nhật điểm kỹ năng tổng (Total Skill Points)
    const totalSkillPoints = getPlayerProperty(
      player,
      "skill:totalSkillPoint",
      0
    );
    setPlayerProperty(player, "skill:totalSkillPoint", totalSkillPoints + 1);

    // --- Cơ chế random tỉ lệ nhận điểm chỉ số chưa phân phối ---
    if (newLevel % STAT_POINT_PER_SKILL_LEVEL === 0) {
      if (Math.random() < CHANCE_TO_GET_UNSPENT_STAT_POINT) {
        const unspentStatPoints = getPlayerProperty(
          player,
          "stats:unspentPoints",
          0
        );
        setPlayerProperty(player, "stats:unspentPoints", unspentStatPoints + 1);
        player.sendMessage(
          `§b${getTranslatedText("stat_point_unspent_gain", locale, 1)}`
        );
      }
    }

    // Thông báo lên cấp skill chính
    player.sendMessage(`§r◇§2===================================§r◇`);
    player.sendMessage(
      `§r------ §r${getTranslatedText(nameKey, locale)}§r ------`
    );
    player.sendMessage(
      `§f• §a${getTranslatedText(
        "level",
        locale
      )}§r: ${currentLevel}§b =>§r ${newLevel}`
    );

    player.playSound("random.levelup", player.location);

    // Xử lý mở khóa và tăng cấp kỹ năng con
    const checkAndLevelUpSubSkill = (subSkillConfig, mainSkillNewLevel) => {
      const currentSubSkillLevel = getPlayerProperty(
        player,
        `skill:${objectivePrefix}${subSkillConfig.objectiveSuffix}`,
        0
      );

      const subSkillName = getTranslatedText(subSkillConfig.nameKey, locale);

      if (
        mainSkillNewLevel === subSkillConfig.unlockLevel &&
        currentSubSkillLevel === 0
      ) {
        // Mở khóa lần đầu (tăng từ 0 lên 1)
        setPlayerProperty(
          player,
          `skill:${objectivePrefix}${subSkillConfig.objectiveSuffix}`,
          1
        );
        player.sendMessage(
          `§f•§c ${getTranslatedText(
            "unlocked_skill",
            locale,
            subSkillName,
            1
          )}`
        );
      }
      // SỬA ĐỔI CHÍNH Ở ĐÂY: Logic tăng cấp của skill con
      else if (
        currentSubSkillLevel > 0 && // Đảm bảo skill con đã được mở khóa
        mainSkillNewLevel > subSkillConfig.unlockLevel && // Skill chính phải vượt qua cấp mở khóa của skill con
        (mainSkillNewLevel - subSkillConfig.unlockLevel) %
          subSkillConfig.levelInterval ===
          0
      ) {
        // Tăng cấp skill con
        const newSubSkillLevel = currentSubSkillLevel + 1;
        setPlayerProperty(
          player,
          `skill:${objectivePrefix}${subSkillConfig.objectiveSuffix}`,
          newSubSkillLevel
        );

        // Thông báo cụ thể cho skill 3 (nếu có baseCooldown)
        if (
          subSkillConfig.baseCooldown !== undefined &&
          subSkillConfig.cooldownReductionPerLevel !== undefined
        ) {
          const newCooldown = Math.max(
            0,
            subSkillConfig.baseCooldown -
              newSubSkillLevel * subSkillConfig.cooldownReductionPerLevel
          );
          player.sendMessage(
            `§f•§c ${getTranslatedText(
              "skill_levelup_cooldown",
              locale,
              subSkillName,
              currentSubSkillLevel,
              newSubSkillLevel,
              Math.floor(newCooldown)
            )}`
          );
        } else {
          player.sendMessage(
            `§f•§c ${getTranslatedText(
              "skill_levelup",
              locale,
              subSkillName,
              currentSubSkillLevel,
              newSubSkillLevel
            )}`
          );
        }
      }
    };

    if (skillLevels.skill1)
      checkAndLevelUpSubSkill(skillLevels.skill1, newLevel);
    if (skillLevels.skill2)
      checkAndLevelUpSubSkill(skillLevels.skill2, newLevel);
    if (skillLevels.skill3)
      checkAndLevelUpSubSkill(skillLevels.skill3, newLevel);

    // Cập nhật lại tất cả các hiệu ứng chỉ số sau khi lên cấp (quan trọng cho Health, Speed, Regen)
    applyAllStatEffects(player);

    player.sendMessage(`§r◇§2===================================§r◇`);
  }
}
