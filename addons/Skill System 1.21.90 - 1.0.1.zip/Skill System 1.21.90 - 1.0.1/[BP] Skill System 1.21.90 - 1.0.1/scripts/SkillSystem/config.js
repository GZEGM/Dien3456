// config.js

let xp = 50; // Base XP for leveling up (used in skillCore for initial nextXp)

export const resetCost = 1000; // Chi phí đặt lại

// STATS SYSTEM CONFIG
export const STAT_POINT_PER_SKILL_LEVEL = 1; // Vẫn giữ nguyên, ví dụ cứ 5 cấp skill chính sẽ có cơ hội nhận điểm
export const CHANCE_TO_GET_UNSPENT_STAT_POINT = 0.1; // Tỉ lệ 50% nhận điểm, bạn có thể điều chỉnh

class blocks {
  constructor(blockID, xp, xpType) {
    this.blockID = blockID;
    this.xp = xp;
    this.xpType = xpType;
  }
}
class entities {
  constructor(id, xp, name, texture, damage) {
    this.id = id;
    this.xp = xp;
    this.name = name;
    this.texture = texture;
    this.damage = damage;
  }
}
// Treasures (sorted by general value/rarity, then alphabetically)
const treasures = [
  // 🟢 Common / Utility (50%)
  { item: "minecraft:arrow", chance: 5 },
  { item: "minecraft:bone", chance: 5 },
  { item: "minecraft:book", chance: 4 },
  { item: "minecraft:bowl", chance: 4 },
  { item: "minecraft:bamboo", chance: 4 },
  { item: "minecraft:cocoa_beans", chance: 4 },
  { item: "minecraft:coal", chance: 4 },
  { item: "minecraft:feather", chance: 4 },
  { item: "minecraft:flint", chance: 3 },
  { item: "minecraft:gunpowder", chance: 3 },
  { item: "minecraft:ink_sac", chance: 3 },
  { item: "minecraft:leather", chance: 3 },
  { item: "minecraft:rotten_flesh", chance: 3 },
  { item: "minecraft:stick", chance: 3 },
  { item: "minecraft:string", chance: 3 },
  { item: "minecraft:sugar", chance: 2 },
  { item: "minecraft:tripwire_hook", chance: 2 },
  { item: "minecraft:glass_bottle", chance: 2 },

  // 🟡 Uncommon / Equipment (35%)
  { item: "minecraft:bow", chance: 3 },
  { item: "minecraft:compass", chance: 2.5 },
  { item: "minecraft:fishing_rod", chance: 3 },
  { item: "minecraft:leather_boots", chance: 2.5 },
  { item: "minecraft:leather_leggings", chance: 2.5 },
  { item: "minecraft:name_tag", chance: 2 },
  { item: "minecraft:saddle", chance: 2 },

  // 🔴 Rare / Valuable (15%)
  { item: "minecraft:amethyst_shard", chance: 1 },
  { item: "minecraft:blaze_rod", chance: 0.8 },
  { item: "minecraft:brick", chance: 1 },
  { item: "minecraft:diamond", chance: 0.7 },
  { item: "minecraft:emerald", chance: 0.7 },
  { item: "minecraft:enchanted_book", chance: 1 },
  { item: "minecraft:enchanted_bow", chance: 0.8 },
  { item: "minecraft:ender_pearl", chance: 0.6 },
  { item: "minecraft:ghast_tear", chance: 0.5 },
  { item: "minecraft:glow_ink_sac", chance: 1 },
  { item: "minecraft:glowstone_dust", chance: 1 },
  { item: "minecraft:gold_block", chance: 0.4 },
  { item: "minecraft:gold_ingot", chance: 0.8 },
  { item: "minecraft:iron_ingot", chance: 1 },
  { item: "minecraft:lapis_lazuli", chance: 1 },
  { item: "minecraft:nautilus_shell", chance: 0.9 },
  { item: "minecraft:nether_star", chance: 0.3 },
  { item: "minecraft:redstone", chance: 1 },
  { item: "minecraft:slime_ball", chance: 1 },
  { item: "minecraft:spider_eye", chance: 1 },
  { item: "minecraft:totem_of_undying", chance: 0.3 },
  { item: "minecraft:wither_skeleton_skull", chance: 0.2 },
];

// Ores and Stone-like blocks (grouped by type/progression, then alphabetically)
const m = [
  // Basic Stone & Variants
  new blocks("minecraft:stone", 0.1, "Stone"),
  new blocks("minecraft:cobblestone", 0.1, "Cobblestone"),
  new blocks("minecraft:andesite", 0.1, "Andesite"),
  new blocks("minecraft:diorite", 0.1, "Diorite"),
  new blocks("minecraft:granite", 0.1, "Granite"),
  new blocks("minecraft:deepslate", 0.1, "Deepslate"),
  new blocks("minecraft:tuff", 0.1, "Tuff"),
  new blocks("minecraft:dripstone_block", 0.1, "Dripstone Block"),
  new blocks("minecraft:basalt", 0.1, "Basalt"),
  new blocks("minecraft:blackstone", 0.1, "Blackstone"),
  // Coal & Redstone
  new blocks("minecraft:coal_ore", 0.2, "Coal Ore"),
  new blocks("minecraft:deepslate_coal_ore", 0.2, "Deepslate Coal Ore"),
  new blocks("minecraft:redstone_ore", 0.2, "Redstone Ore"),
  new blocks("minecraft:lit_redstone_ore", 0.2, "Lit Redstone Ore"), // Lit version
  new blocks("minecraft:deepslate_redstone_ore", 0.2, "Deepslate Redstone Ore"),
  new blocks("minecraft:lapis_ore", 0.2, "Lapis Ore"),
  new blocks("minecraft:deepslate_lapis_ore", 0.2, "Deepslate Lapis Ore"),
  new blocks("minecraft:glowstone", 0.2, "Glowstone"),
  new blocks("minecraft:amethyst_block", 0.3, "Amethyst Block"),
  new blocks("minecraft:budding_amethyst", 0.5, "Budding Amethyst"),
  // Metals
  new blocks("minecraft:copper_ore", 0.2, "Copper Ore"),
  new blocks("minecraft:deepslate_copper_ore", 0.2, "Deepslate Copper Ore"),
  new blocks("minecraft:iron_ore", 0.3, "Iron Ore"),
  new blocks("minecraft:deepslate_iron_ore", 0.3, "Deepslate Iron Ore"),
  new blocks("minecraft:raw_iron_block", 0.3, "Raw Iron Block"),
  new blocks("minecraft:gold_ore", 0.4, "Gold Ore"),
  new blocks("minecraft:deepslate_gold_ore", 0.4, "Deepslate Gold Ore"),
  new blocks("minecraft:raw_gold_block", 0.4, "Raw Gold Block"),
  // Valuable Ores
  new blocks("minecraft:emerald_ore", 0.5, "Emerald Ore"),
  new blocks("minecraft:deepslate_emerald_ore", 0.5, "Deepslate Emerald Ore"),
  new blocks("minecraft:diamond_ore", 0.5, "Diamond Ore"),
  new blocks("minecraft:deepslate_diamond_ore", 0.5, "Deepslate Diamond Ore"),
  // Nether & End
  new blocks("minecraft:netherrack", 0.05, "Netherrack"),
  new blocks("minecraft:nether_gold_ore", 0.5, "Nether Gold Ore"),
  new blocks("minecraft:quartz_ore", 0.3, "Quartz Ore"),
  new blocks("minecraft:ancient_debris", 1.0, "Ancient Debris"),
  new blocks("minecraft:obsidian", 0.8, "Obsidian"),
  new blocks("minecraft:end_stone", 0.1, "End Stone"),
];

// Logs and Wood (grouped by wood type, then by block variation)
const logs = [
  // Oak
  new blocks("minecraft:oak_log", 0.1, "Oak Log"),
  new blocks("minecraft:stripped_oak_log", 0.1, "Stripped Oak Log"),
  new blocks("minecraft:oak_wood", 0.1, "Oak Wood"),
  new blocks("minecraft:stripped_oak_wood", 0.1, "Stripped Oak Wood"),
  new blocks("minecraft:oak_leaves", 0.05, "Oak Leaves"),
  // Birch
  new blocks("minecraft:birch_log", 0.1, "Birch Log"),
  new blocks("minecraft:stripped_birch_log", 0.1, "Stripped Birch Log"),
  new blocks("minecraft:birch_wood", 0.1, "Birch Wood"),
  new blocks("minecraft:stripped_birch_wood", 0.1, "Stripped Birch Wood"),
  new blocks("minecraft:birch_leaves", 0.05, "Birch Leaves"),
  // Spruce
  new blocks("minecraft:spruce_log", 0.1, "Spruce Log"),
  new blocks("minecraft:stripped_spruce_log", 0.1, "Stripped Spruce Log"),
  new blocks("minecraft:spruce_wood", 0.1, "Spruce Wood"),
  new blocks("minecraft:stripped_spruce_wood", 0.1, "Stripped Spruce Wood"),
  new blocks("minecraft:spruce_leaves", 0.05, "Spruce Leaves"),
  // Jungle
  new blocks("minecraft:jungle_log", 0.1, "Jungle Log"),
  new blocks("minecraft:stripped_jungle_log", 0.1, "Stripped Jungle Log"),
  new blocks("minecraft:jungle_wood", 0.1, "Jungle Wood"),
  new blocks("minecraft:stripped_jungle_wood", 0.1, "Stripped Jungle Wood"),
  new blocks("minecraft:jungle_leaves", 0.05, "Jungle Leaves"),
  // Acacia
  new blocks("minecraft:acacia_log", 0.1, "Acacia Log"),
  new blocks("minecraft:stripped_acacia_log", 0.1, "Stripped Acacia Log"),
  new blocks("minecraft:acacia_wood", 0.1, "Acacia Wood"),
  new blocks("minecraft:stripped_acacia_wood", 0.1, "Stripped Acacia Wood"),
  new blocks("minecraft:acacia_leaves", 0.05, "Acacia Leaves"),
  // Dark Oak
  new blocks("minecraft:dark_oak_log", 0.1, "Dark Oak Log"),
  new blocks("minecraft:stripped_dark_oak_log", 0.1, "Stripped Dark Oak Log"),
  new blocks("minecraft:dark_oak_wood", 0.1, "Dark Oak Wood"),
  new blocks("minecraft:stripped_dark_oak_wood", 0.1, "Stripped Dark Oak Wood"),
  new blocks("minecraft:dark_oak_leaves", 0.05, "Dark Oak Leaves"),
  // Mangrove
  new blocks("minecraft:mangrove_log", 0.1, "Mangrove Log"),
  new blocks("minecraft:stripped_mangrove_log", 0.1, "Stripped Mangrove Log"),
  new blocks("minecraft:mangrove_wood", 0.1, "Mangrove Wood"),
  new blocks("minecraft:stripped_mangrove_wood", 0.1, "Stripped Mangrove Wood"),
  new blocks("minecraft:mangrove_leaves", 0.05, "Mangrove Leaves"),
  new blocks("minecraft:mangrove_roots", 0.05, "Mangrove Roots"),
  // Cherry
  new blocks("minecraft:cherry_log", 0.1, "Cherry Log"),
  new blocks("minecraft:stripped_cherry_log", 0.1, "Stripped Cherry Log"),
  new blocks("minecraft:cherry_wood", 0.1, "Cherry Wood"),
  new blocks("minecraft:stripped_cherry_wood", 0.1, "Stripped Cherry Wood"),
  new blocks("minecraft:cherry_leaves", 0.05, "Cherry Leaves"),
  // Crimson (Nether)
  new blocks("minecraft:crimson_stem", 0.1, "Crimson Stem"),
  new blocks("minecraft:stripped_crimson_stem", 0.1, "Stripped Crimson Stem"),
  new blocks("minecraft:crimson_hyphae", 0.1, "Crimson Hyphae"),
  new blocks(
    "minecraft:stripped_crimson_hyphae",
    0.1,
    "Stripped Crimson Hyphae"
  ),
  new blocks("minecraft:crimson_nylium", 0.05, "Crimson Nylium"),
  // Warped (Nether)
  new blocks("minecraft:warped_stem", 0.1, "Warped Stem"),
  new blocks("minecraft:stripped_warped_stem", 0.1, "Stripped Warped Stem"),
  new blocks("minecraft:warped_hyphae", 0.1, "Warped Hyphae"),
  new blocks("minecraft:stripped_warped_hyphae", 0.1, "Stripped Warped Hyphae"),
  new blocks("minecraft:warped_nylium", 0.05, "Warped Nylium"),
];

// Mobs (grouped by behavior: Passive, Neutral, Hostile, Boss; then alphabetically)
const mobs = [
  // Passive Mobs
  new entities("minecraft:allay", 0.5, "Allay", "minecraft:allay_spawn_egg", 0),
  new entities(
    "minecraft:armadillo",
    0.5,
    "Armadillo",
    "minecraft:armadillo_spawn_egg",
    0
  ),
  new entities("minecraft:bat", 0.3, "Bat", "minecraft:bat_spawn_egg", 1),
  new entities("minecraft:camel", 0.6, "Camel", "minecraft:camel_spawn_egg", 4),
  new entities("minecraft:cat", 0.4, "Cat", "minecraft:cat_spawn_egg", 3),
  new entities(
    "minecraft:chicken",
    0.2,
    "Chicken",
    "minecraft:chicken_spawn_egg",
    2
  ),
  new entities("minecraft:cod", 0.2, "Cod", "minecraft:cod_spawn_egg", 2),
  new entities("minecraft:cow", 0.4, "Cow", "minecraft:cow_spawn_egg", 2),
  new entities(
    "minecraft:dolphin",
    0.4,
    "Dolphin",
    "minecraft:dolphin_spawn_egg",
    3
  ),
  new entities(
    "minecraft:donkey",
    0.5,
    "Donkey",
    "minecraft:donkey_spawn_egg",
    4
  ),
  new entities("minecraft:frog", 0.4, "Frog", "minecraft:frog_spawn_egg", 2),
  new entities(
    "minecraft:glow_squid",
    0.5,
    "Glow Squid",
    "minecraft:glow_squid_spawn_egg",
    4
  ),
  new entities("minecraft:horse", 0.6, "Horse", "minecraft:horse_spawn_egg", 4),
  new entities("minecraft:llama", 0.6, "Llama", "minecraft:llama_spawn_egg", 5),
  new entities(
    "minecraft:mooshroom",
    0.4,
    "Mooshroom",
    "minecraft:mooshroom_spawn_egg",
    2
  ),
  new entities("minecraft:mule", 0.5, "Mule", "minecraft:mule_spawn_egg", 4),
  new entities(
    "minecraft:ocelot",
    0.5,
    "Ocelot",
    "minecraft:ocelot_spawn_egg",
    4
  ),
  new entities("minecraft:panda", 0.6, "Panda", "minecraft:panda_spawn_egg", 4),
  new entities(
    "minecraft:parrot",
    0.3,
    "Parrot",
    "minecraft:parrot_spawn_egg",
    1
  ),
  new entities("minecraft:pig", 0.3, "Pig", "minecraft:pig_spawn_egg", 2),
  new entities(
    "minecraft:pufferfish",
    0.2,
    "Pufferfish",
    "minecraft:pufferfish_spawn_egg",
    2
  ),
  new entities(
    "minecraft:rabbit",
    0.2,
    "Rabbit",
    "minecraft:rabbit_spawn_egg",
    1
  ),
  new entities(
    "minecraft:salmon",
    0.2,
    "Salmon",
    "minecraft:salmon_spawn_egg",
    2
  ),
  new entities("minecraft:sheep", 0.3, "Sheep", "minecraft:sheep_spawn_egg", 2),
  new entities(
    "minecraft:sniffer",
    0.4,
    "Sniffer",
    "minecraft:sniffer_spawn_egg",
    3
  ),
  new entities("minecraft:squid", 0.3, "Squid", "minecraft:squid_spawn_egg", 2),
  new entities(
    "minecraft:strider",
    0.5,
    "Strider",
    "minecraft:strider_spawn_egg",
    0
  ),
  new entities(
    "minecraft:tropical_fish",
    0.2,
    "Tropical Fish",
    "minecraft:tropical_fish_spawn_egg",
    2
  ),
  new entities(
    "minecraft:turtle",
    0.4,
    "Turtle",
    "minecraft:turtle_spawn_egg",
    3
  ),
  new entities(
    "minecraft:villager",
    0.3,
    "Villager",
    "minecraft:villager_spawn_egg",
    0
  ),
  // Neutral Mobs
  new entities(
    "minecraft:axolotl",
    0.5,
    "Axolotl",
    "minecraft:axolotl_spawn_egg",
    4
  ),
  new entities("minecraft:bee", 0.3, "Bee", "minecraft:bee_spawn_egg", 3),
  new entities(
    "minecraft:enderman",
    2.0,
    "Enderman",
    "minecraft:enderman_spawn_egg",
    7
  ),
  new entities("minecraft:fox", 0.5, "Fox", "minecraft:fox_spawn_egg", 4),
  new entities("minecraft:goat", 0.6, "Goat", "minecraft:goat_spawn_egg", 4),
  new entities(
    "minecraft:hoglin",
    1.8,
    "Hoglin",
    "minecraft:hoglin_spawn_egg",
    6
  ),
  new entities(
    "minecraft:iron_golem",
    5.0,
    "Iron Golem",
    "minecraft:iron_golem_spawn_egg",
    15
  ),
  new entities(
    "minecraft:piglin",
    1.5,
    "Piglin",
    "minecraft:piglin_spawn_egg",
    5
  ),
  new entities(
    "minecraft:polar_bear",
    0.8,
    "Polar Bear",
    "minecraft:polar_bear_spawn_egg",
    6
  ),
  new entities(
    "minecraft:snow_golem",
    0.5,
    "Snow Golem",
    "minecraft:snow_golem_spawn_egg",
    0
  ),
  new entities("minecraft:wolf", 0.5, "Wolf", "minecraft:wolf_spawn_egg", 5),
  new entities(
    "minecraft:zombified_piglin",
    1.5,
    "Zombified Piglin",
    "minecraft:zombified_piglin_spawn_egg",
    5
  ), // Renamed from piglin to zombified_piglin
  // Hostile Mobs
  new entities("minecraft:blaze", 2.5, "Blaze", "minecraft:blaze_spawn_egg", 6),
  new entities(
    "minecraft:cave_spider",
    1.0,
    "Cave Spider",
    "minecraft:cave_spider_spawn_egg",
    2
  ),
  new entities(
    "minecraft:creeper",
    1.5,
    "Creeper",
    "minecraft:creeper_spawn_egg",
    0
  ),
  new entities(
    "minecraft:drowned",
    1.1,
    "Drowned",
    "minecraft:drowned_spawn_egg",
    2
  ),
  new entities(
    "minecraft:elder_guardian",
    10.0,
    "Elder Guardian",
    "minecraft:elder_guardian_spawn_egg",
    8
  ),
  new entities(
    "minecraft:endermite",
    0.7,
    "Endermite",
    "minecraft:endermite_spawn_egg",
    2
  ),
  new entities(
    "minecraft:evoker",
    3.0,
    "Evoker",
    "minecraft:evoker_spawn_egg",
    9
  ),
  new entities("minecraft:ghast", 3.0, "Ghast", "minecraft:ghast_spawn_egg", 8),
  new entities(
    "minecraft:guardian",
    2.8,
    "Guardian",
    "minecraft:guardian_spawn_egg",
    6
  ),
  new entities("minecraft:husk", 1.0, "Husk", "minecraft:husk_spawn_egg", 2),
  new entities(
    "minecraft:magma_cube",
    1.0,
    "Magma Cube",
    "minecraft:magma_cube_spawn_egg",
    3
  ),
  new entities(
    "minecraft:phantom",
    2.2,
    "Phantom",
    "minecraft:phantom_spawn_egg",
    5
  ),
  new entities(
    "minecraft:piglin_brute",
    2.5,
    "Piglin Brute",
    "minecraft:piglin_brute_spawn_egg",
    8
  ),
  new entities(
    "minecraft:pillager",
    1.6,
    "Pillager",
    "minecraft:pillager_spawn_egg",
    4
  ),
  new entities(
    "minecraft:shulker",
    4.0,
    "Shulker",
    "minecraft:shulker_spawn_egg",
    0
  ),
  new entities(
    "minecraft:silverfish",
    0.6,
    "Silverfish",
    "minecraft:silverfish_spawn_egg",
    1
  ),
  new entities(
    "minecraft:skeleton",
    1.2,
    "Skeleton",
    "minecraft:skeleton_spawn_egg",
    3
  ),
  new entities("minecraft:slime", 0.8, "Slime", "minecraft:slime_spawn_egg", 2),
  new entities(
    "minecraft:spider",
    0.8,
    "Spider",
    "minecraft:spider_spawn_egg",
    2
  ),
  new entities("minecraft:stray", 1.3, "Stray", "minecraft:stray_spawn_egg", 3),
  new entities("minecraft:vex", 1.5, "Vex", "minecraft:vex_spawn_egg", 5),
  new entities(
    "minecraft:vindicator",
    2.0,
    "Vindicator",
    "minecraft:vindicator_spawn_egg",
    7
  ),
  new entities(
    "minecraft:warden",
    8.0,
    "Warden",
    "minecraft:warden_spawn_egg",
    15
  ),
  new entities("minecraft:witch", 1.8, "Witch", "minecraft:witch_spawn_egg", 0),
  new entities(
    "minecraft:wither_skeleton",
    3.5,
    "Wither Skeleton",
    "minecraft:wither_skeleton_spawn_egg",
    4
  ),
  new entities(
    "minecraft:zoglin",
    1.8,
    "Zoglin",
    "minecraft:zoglin_spawn_egg",
    7
  ),
  new entities(
    "minecraft:zombie",
    1.0,
    "Zombie",
    "minecraft:zombie_spawn_egg",
    2
  ),
  new entities(
    "minecraft:zombie_villager",
    1.0,
    "Zombie Villager",
    "minecraft:zombie_villager_spawn_egg",
    2
  ),
  // Boss Mobs
  new entities(
    "minecraft:ender_dragon",
    100.0,
    "Ender Dragon",
    "minecraft:ender_dragon_spawn_egg",
    25
  ),
  new entities(
    "minecraft:wither",
    50.0,
    "Wither",
    "minecraft:wither_spawn_egg",
    20
  ),
];

// Crops (grouped by type, then alphabetically)
const crops = [
  // Vegetables & Grains
  new blocks("minecraft:beetroots", 0.1, "Beetroot"),
  new blocks("minecraft:carrots", 0.1, "Carrot"),
  new blocks("minecraft:nether_wart", 0.15, "Nether Wart"),
  new blocks("minecraft:potatoes", 0.1, "Potato"),
  new blocks("minecraft:wheat", 0.1, "Wheat"),
  // Fruits & Melons
  new blocks("minecraft:cocoa_pod", 0.12, "Cocoa Beans"),
  new blocks("minecraft:melon_block", 0.2, "Melon"),
  new blocks("minecraft:pumpkin", 0.2, "Pumpkin"),
  new blocks("minecraft:sweet_berry_bush", 0.1, "Sweet Berry Bush"),
  // Other Plants
  new blocks("minecraft:bamboo", 0.05, "Bamboo"),
  new blocks("minecraft:brown_mushroom", 0.05, "Brown Mushroom"),
  new blocks("minecraft:cactus", 0.05, "Cactus"),
  new blocks("minecraft:cave_vines", 0.1, "Cave Vines"), // For Glow Berries
  new blocks("minecraft:chorus_flower", 0.2, "Chorus Flower"),
  new blocks("minecraft:chorus_plant", 0.15, "Chorus Plant"),
  new blocks("minecraft:kelp", 0.05, "Kelp"),
  new blocks("minecraft:red_mushroom", 0.05, "Red Mushroom"),
  new blocks("minecraft:reeds", 0.05, "Sugar Cane"),
];

// Max growth stage for crops
const cropsGrowth = {
  "minecraft:beetroots": 3,
  "minecraft:carrots": 7,
  "minecraft:cocoa_pod": 2,
  "minecraft:melon_block": 7, // Stalk growth
  "minecraft:nether_wart": 3,
  "minecraft:potatoes": 7,
  "minecraft:pumpkin": 7, // Stalk growth
  "minecraft:sweet_berry_bush": 3,
  "minecraft:wheat": 7,
  "minecraft:bamboo": null, // No growth state property
  "minecraft:brown_mushroom": null, // No growth state property
  "minecraft:cactus": null, // No growth state property
  "minecraft:cave_vines": 2, // Cave vines with glow berries
  "minecraft:chorus_flower": null, // No growth state property
  "minecraft:chorus_plant": null, // No growth state property
  "minecraft:kelp": null, // No growth state property
  "minecraft:red_mushroom": null, // No growth state property
  "minecraft:reeds": null, // No growth state property
};

// Soils (grouped by type, then alphabetically)
const soils = [
  // Dirt & Variants
  new blocks("minecraft:dirt", 0.5, "Dirt"),
  new blocks("minecraft:coarse_dirt", 0.5, "Coarse Dirt"),
  new blocks("minecraft:farmland", 0.5, "Farmland"),
  new blocks("minecraft:grass", 0.5, "Grass"),
  new blocks("minecraft:grass_block", 0.5, "Grass Block"),
  new blocks("minecraft:mud", 0.5, "Mud"),
  new blocks("minecraft:muddy_mangrove_roots", 0.5, "Muddy Mangrove Roots"),
  new blocks("minecraft:mycelium", 0.5, "Mycelium"),
  new blocks("minecraft:podzol", 0.5, "Podzol"),
  new blocks("minecraft:rooted_dirt", 0.5, "Rooted Dirt"),
  new blocks("minecraft:soul_soil", 0.5, "Soul Soil"),
  // Sand & Variants
  new blocks("minecraft:sand", 0.5, "Sand"),
  new blocks("minecraft:red_sand", 0.5, "Red Sand"),
  new blocks("minecraft:soul_sand", 0.5, "Soul Sand"),
  // Other
  new blocks("minecraft:clay", 0.5, "Clay"),
  new blocks("minecraft:gravel", 0.5, "Gravel"),
  new blocks("minecraft:powder_snow", 0.5, "Powder Snow"),
  new blocks("minecraft:snow", 0.5, "Snow"),
];

// Prefix tool
const pickaxe = [
  "minecraft:wooden_pickaxe",
  "minecraft:stone_pickaxe",
  "minecraft:iron_pickaxe",
  "minecraft:golden_pickaxe",
  "minecraft:diamond_pickaxe",
  "minecraft:netherite_pickaxe",
];
const axe = [
  "minecraft:wooden_axe",
  "minecraft:stone_axe",
  "minecraft:iron_axe",
  "minecraft:golden_axe",
  "minecraft:diamond_axe",
  "minecraft:netherite_axe",
];
const sword = [
  "minecraft:wooden_sword",
  "minecraft:stone_sword",
  "minecraft:iron_sword",
  "minecraft:golden_sword",
  "minecraft:diamond_sword",
  "minecraft:netherite_sword",
];
const hoe = [
  "minecraft:wooden_hoe",
  "minecraft:stone_hoe",
  "minecraft:iron_hoe",
  "minecraft:golden_hoe",
  "minecraft:diamond_hoe",
  "minecraft:netherite_hoe",
];
const shovel = [
  "minecraft:wooden_shovel",
  "minecraft:stone_shovel",
  "minecraft:iron_shovel",
  "minecraft:golden_shovel",
  "minecraft:diamond_shovel",
  "minecraft:netherite_shovel",
];
const bow = ["minecraft:bow", "minecraft:crossbow"];

const particles = {
  regen: "minecraft:villager_happy", // Placeholder
  strength: "minecraft:basic_flame_particle", // Placeholder
  lucky_block: "minecraft:basic_redstone_particle", // Placeholder
};

export const fishTypes = [
  // Fish (sorted alphabetically)
  { item: "minecraft:clownfish", name: "Clownfish", xp: 1.2 },
  { item: "minecraft:cod", name: "Raw Cod", xp: 0.5 },
  { item: "minecraft:pufferfish", name: "Pufferfish", xp: 1.5 },
  { item: "minecraft:salmon", name: "Raw Salmon", xp: 0.8 },
  { item: "minecraft:tropical_fish", name: "Tropical Fish", xp: 2.0 },

  // Junk (sorted alphabetically)
  { item: "minecraft:bamboo", name: "Bamboo", xp: 0.1 },
  { item: "minecraft:bone", name: "Bone", xp: 0.1 },
  { item: "minecraft:bowl", name: "Bowl", xp: 0.1 },
  { item: "minecraft:cocoa_beans", name: "Cocoa Beans", xp: 0.1 },
  { item: "minecraft:fishing_rod", name: "Damaged Fishing Rod", xp: 0.2 },
  { item: "minecraft:glow_ink_sac", name: "Glow Ink Sac", xp: 0.2 },
  { item: "minecraft:ink_sac", name: "Ink Sac", xp: 0.1 },
  { item: "minecraft:leather", name: "Leather", xp: 0.1 },
  { item: "minecraft:leather_boots", name: "Leather Boots", xp: 0.2 },
  { item: "minecraft:leather_leggings", name: "Leather Leggings", xp: 0.2 },
  { item: "minecraft:rotten_flesh", name: "Rotten Flesh", xp: 0.1 },
  { item: "minecraft:stick", name: "Stick", xp: 0.1 },
  { item: "minecraft:string", name: "String", xp: 0.1 },
  { item: "minecraft:tripwire_hook", name: "Tripwire Hook", xp: 0.1 },
  { item: "minecraft:water_bottle", name: "Water Bottle", xp: 0.1 },

  // Treasure (sorted alphabetically)
  { item: "minecraft:bow", name: "Bow", xp: 1.0 },
  { item: "minecraft:enchanted_book", name: "Enchanted Book", xp: 2.0 },
  { item: "minecraft:enchanted_bow", name: "Enchanted Bow", xp: 1.5 },
  { item: "minecraft:fishing_rod", name: "Enchanted Fishing Rod", xp: 1.5 },
  { item: "minecraft:name_tag", name: "Name Tag", xp: 1.0 },
  { item: "minecraft:nautilus_shell", name: "Nautilus Shell", xp: 1.5 },
  { item: "minecraft:saddle", name: "Saddle", xp: 1.0 },
];

export const treasureFish = [
  { item: "minecraft:name_tag", amount: 1 }, // Quý hiếm, không thể chế
  { item: "minecraft:nautilus_shell", amount: 1 }, // Nguyên liệu Conduit
  { item: "minecraft:saddle", amount: 1 }, // Cưỡi mob
  { item: "minecraft:heart_of_the_sea", amount: 1 }, // Siêu hiếm, chỉ từ buried treasure
  { item: "minecraft:trident", amount: 1 }, // Cực quý, chỉ có từ drowned
  { item: "minecraft:totem_of_undying", amount: 1 }, // Vật phẩm cứu mạng
  { item: "minecraft:enchanted_book", amount: 1 }, // Sách phù phép ngẫu nhiên (có thể thêm logic)
  { item: "minecraft:experience_bottle", amount: 3 }, // Cho XP nhanh
  { item: "minecraft:emerald", amount: 2 }, // Dùng giao dịch
  { item: "minecraft:diamond", amount: 1 }, // Cho cảm giác "wow"
  { item: "minecraft:netherite_scrap", amount: 1 }, // Rất xịn, phục vụ end-game
  { item: "minecraft:potion", amount: 1 }, // Có thể là potion hồi máu, water breathing...
  { item: "minecraft:glow_ink_sac", amount: 2 }, // Hiếm & đẹp
];

export const buildableBlocks = [
  // Stone & Variants
  { id: "minecraft:stone", xp: 0.1, display: "Stone" },
  { id: "minecraft:cobblestone", xp: 0.08, display: "Cobblestone" },
  { id: "minecraft:stone_bricks", xp: 0.15, display: "Stone Bricks" },
  { id: "minecraft:andesite", xp: 0.1, display: "Andesite" },
  { id: "minecraft:diorite", xp: 0.1, display: "Diorite" },
  { id: "minecraft:granite", xp: 0.1, display: "Granite" },
  { id: "minecraft:deepslate", xp: 0.12, display: "Deepslate" },
  { id: "minecraft:tuff", xp: 0.09, display: "Tuff" },
  { id: "minecraft:calcite", xp: 0.11, display: "Calcite" },
  { id: "minecraft:smooth_stone", xp: 0.13, display: "Smooth Stone" },
  { id: "minecraft:polished_andesite", xp: 0.14, display: "Polished Andesite" },
  { id: "minecraft:polished_diorite", xp: 0.14, display: "Polished Diorite" },
  { id: "minecraft:polished_granite", xp: 0.14, display: "Polished Granite" },
  {
    id: "minecraft:cracked_stone_bricks",
    xp: 0.16,
    display: "Cracked Stone Bricks",
  },
  {
    id: "minecraft:mossy_stone_bricks",
    xp: 0.16,
    display: "Mossy Stone Bricks",
  },
  {
    id: "minecraft:chiseled_stone_bricks",
    xp: 0.17,
    display: "Chiseled Stone Bricks",
  },
  { id: "minecraft:cobbled_deepslate", xp: 0.12, display: "Cobbled Deepslate" },
  {
    id: "minecraft:polished_deepslate",
    xp: 0.13,
    display: "Polished Deepslate",
  },
  { id: "minecraft:deepslate_bricks", xp: 0.15, display: "Deepslate Bricks" },
  { id: "minecraft:deepslate_tiles", xp: 0.15, display: "Deepslate Tiles" },
  {
    id: "minecraft:cracked_deepslate_bricks",
    xp: 0.16,
    display: "Cracked Deepslate Bricks",
  },
  {
    id: "minecraft:cracked_deepslate_tiles",
    xp: 0.16,
    display: "Cracked Deepslate Tiles",
  },
  {
    id: "minecraft:chiseled_deepslate",
    xp: 0.17,
    display: "Chiseled Deepslate",
  },
  { id: "minecraft:blackstone", xp: 0.1, display: "Blackstone" },
  {
    id: "minecraft:polished_blackstone",
    xp: 0.11,
    display: "Polished Blackstone",
  },
  {
    id: "minecraft:polished_blackstone_bricks",
    xp: 0.13,
    display: "Polished Blackstone Bricks",
  },
  {
    id: "minecraft:cracked_polished_blackstone_bricks",
    xp: 0.14,
    display: "Cracked Polished Blackstone Bricks",
  },
  {
    id: "minecraft:chiseled_polished_blackstone",
    xp: 0.15,
    display: "Chiseled Polished Blackstone",
  },
  { id: "minecraft:gilded_blackstone", xp: 0.18, display: "Gilded Blackstone" },

  // Dirt & Terracotta
  { id: "minecraft:dirt", xp: 0.05, display: "Dirt" },
  { id: "minecraft:coarse_dirt", xp: 0.06, display: "Coarse Dirt" },
  { id: "minecraft:grass_block", xp: 0.07, display: "Grass Block" },
  { id: "minecraft:podzol", xp: 0.08, display: "Podzol" },
  { id: "minecraft:mycelium", xp: 0.08, display: "Mycelium" },
  { id: "minecraft:rooted_dirt", xp: 0.06, display: "Rooted Dirt" },
  { id: "minecraft:mud", xp: 0.07, display: "Mud" },
  { id: "minecraft:mud_bricks", xp: 0.12, display: "Mud Bricks" },
  { id: "minecraft:terracotta", xp: 0.1, display: "Terracotta" },
  { id: "minecraft:white_terracotta", xp: 0.11, display: "White Terracotta" },
  { id: "minecraft:orange_terracotta", xp: 0.11, display: "Orange Terracotta" },
  {
    id: "minecraft:magenta_terracotta",
    xp: 0.11,
    display: "Magenta Terracotta",
  },
  {
    id: "minecraft:light_blue_terracotta",
    xp: 0.11,
    display: "Light Blue Terracotta",
  },
  { id: "minecraft:yellow_terracotta", xp: 0.11, display: "Yellow Terracotta" },
  { id: "minecraft:lime_terracotta", xp: 0.11, display: "Lime Terracotta" },
  { id: "minecraft:pink_terracotta", xp: 0.11, display: "Pink Terracotta" },
  { id: "minecraft:gray_terracotta", xp: 0.11, display: "Gray Terracotta" },
  {
    id: "minecraft:light_gray_terracotta",
    xp: 0.11,
    display: "Light Gray Terracotta",
  },
  { id: "minecraft:cyan_terracotta", xp: 0.11, display: "Cyan Terracotta" },
  { id: "minecraft:purple_terracotta", xp: 0.11, display: "Purple Terracotta" },
  { id: "minecraft:blue_terracotta", xp: 0.11, display: "Blue Terracotta" },
  { id: "minecraft:brown_terracotta", xp: 0.11, display: "Brown Terracotta" },
  { id: "minecraft:green_terracotta", xp: 0.11, display: "Green Terracotta" },
  { id: "minecraft:red_terracotta", xp: 0.11, display: "Red Terracotta" },
  { id: "minecraft:black_terracotta", xp: 0.11, display: "Black Terracotta" },
  {
    id: "minecraft:white_glazed_terracotta",
    xp: 0.15,
    display: "White Glazed Terracotta",
  },
  {
    id: "minecraft:orange_glazed_terracotta",
    xp: 0.15,
    display: "Orange Glazed Terracotta",
  },
  {
    id: "minecraft:magenta_glazed_terracotta",
    xp: 0.15,
    display: "Magenta Glazed Terracotta",
  },
  {
    id: "minecraft:light_blue_glazed_terracotta",
    xp: 0.15,
    display: "Light Blue Glazed Terracotta",
  },
  {
    id: "minecraft:yellow_glazed_terracotta",
    xp: 0.15,
    display: "Yellow Glazed Terracotta",
  },
  {
    id: "minecraft:lime_glazed_terracotta",
    xp: 0.15,
    display: "Lime Glazed Terracotta",
  },
  {
    id: "minecraft:pink_glazed_terracotta",
    xp: 0.15,
    display: "Pink Glazed Terracotta",
  },
  {
    id: "minecraft:gray_glazed_terracotta",
    xp: 0.15,
    display: "Gray Glazed Terracotta",
  },
  {
    id: "minecraft:light_gray_glazed_terracotta",
    xp: 0.15,
    display: "Light Gray Glazed Terracotta",
  },
  {
    id: "minecraft:cyan_glazed_terracotta",
    xp: 0.15,
    display: "Cyan Glazed Terracotta",
  },
  {
    id: "minecraft:purple_glazed_terracotta",
    xp: 0.15,
    display: "Purple Glazed Terracotta",
  },
  {
    id: "minecraft:blue_glazed_terracotta",
    xp: 0.15,
    display: "Blue Glazed Terracotta",
  },
  {
    id: "minecraft:brown_glazed_terracotta",
    xp: 0.15,
    display: "Brown Glazed Terracotta",
  },
  {
    id: "minecraft:green_glazed_terracotta",
    xp: 0.15,
    display: "Green Glazed Terracotta",
  },
  {
    id: "minecraft:red_glazed_terracotta",
    xp: 0.15,
    display: "Red Glazed Terracotta",
  },
  {
    id: "minecraft:black_glazed_terracotta",
    xp: 0.15,
    display: "Black Glazed Terracotta",
  },
  { id: "minecraft:white_concrete", xp: 0.12, display: "White Concrete" },
  { id: "minecraft:orange_concrete", xp: 0.12, display: "Orange Concrete" },
  { id: "minecraft:magenta_concrete", xp: 0.12, display: "Magenta Concrete" },
  {
    id: "minecraft:light_blue_concrete",
    xp: 0.12,
    display: "Light Blue Concrete",
  },
  { id: "minecraft:yellow_concrete", xp: 0.12, display: "Yellow Concrete" },
  { id: "minecraft:lime_concrete", xp: 0.12, display: "Lime Concrete" },
  { id: "minecraft:pink_concrete", xp: 0.12, display: "Pink Concrete" },
  { id: "minecraft:gray_concrete", xp: 0.12, display: "Gray Concrete" },
  {
    id: "minecraft:light_gray_concrete",
    xp: 0.12,
    display: "Light Gray Concrete",
  },
  { id: "minecraft:cyan_concrete", xp: 0.12, display: "Cyan Concrete" },
  { id: "minecraft:purple_concrete", xp: 0.12, display: "Purple Concrete" },
  { id: "minecraft:blue_concrete", xp: 0.12, display: "Blue Concrete" },
  { id: "minecraft:brown_concrete", xp: 0.12, display: "Brown Concrete" },
  { id: "minecraft:green_concrete", xp: 0.12, display: "Green Concrete" },
  { id: "minecraft:red_concrete", xp: 0.12, display: "Red Concrete" },
  { id: "minecraft:black_concrete", xp: 0.12, display: "Black Concrete" },
  {
    id: "minecraft:white_concrete_powder",
    xp: 0.08,
    display: "White Concrete Powder",
  },
  {
    id: "minecraft:orange_concrete_powder",
    xp: 0.08,
    display: "Orange Concrete Powder",
  },
  {
    id: "minecraft:magenta_concrete_powder",
    xp: 0.08,
    display: "Magenta Concrete Powder",
  },
  {
    id: "minecraft:light_blue_concrete_powder",
    xp: 0.08,
    display: "Light Blue Concrete Powder",
  },
  {
    id: "minecraft:yellow_concrete_powder",
    xp: 0.08,
    display: "Yellow Concrete Powder",
  },
  {
    id: "minecraft:lime_concrete_powder",
    xp: 0.08,
    display: "Lime Concrete Powder",
  },
  {
    id: "minecraft:pink_concrete_powder",
    xp: 0.08,
    display: "Pink Concrete Powder",
  },
  {
    id: "minecraft:gray_concrete_powder",
    xp: 0.08,
    display: "Gray Concrete Powder",
  },
  {
    id: "minecraft:light_gray_concrete_powder",
    xp: 0.08,
    display: "Light Gray Concrete Powder",
  },
  {
    id: "minecraft:cyan_concrete_powder",
    xp: 0.08,
    display: "Cyan Concrete Powder",
  },
  {
    id: "minecraft:purple_concrete_powder",
    xp: 0.08,
    display: "Purple Concrete Powder",
  },
  {
    id: "minecraft:blue_concrete_powder",
    xp: 0.08,
    display: "Blue Concrete Powder",
  },
  {
    id: "minecraft:brown_concrete_powder",
    xp: 0.08,
    display: "Brown Concrete Powder",
  },
  {
    id: "minecraft:green_concrete_powder",
    xp: 0.08,
    display: "Green Concrete Powder",
  },
  {
    id: "minecraft:red_concrete_powder",
    xp: 0.08,
    display: "Red Concrete Powder",
  },
  {
    id: "minecraft:black_concrete_powder",
    xp: 0.08,
    display: "Black Concrete Powder",
  },

  // Wood & Variants
  { id: "minecraft:oak_planks", xp: 0.09, display: "Oak Planks" },
  { id: "minecraft:spruce_planks", xp: 0.09, display: "Spruce Planks" },
  { id: "minecraft:birch_planks", xp: 0.09, display: "Birch Planks" },
  { id: "minecraft:jungle_planks", xp: 0.09, display: "Jungle Planks" },
  { id: "minecraft:acacia_planks", xp: 0.09, display: "Acacia Planks" },
  { id: "minecraft:dark_oak_planks", xp: 0.09, display: "Dark Oak Planks" },
  { id: "minecraft:mangrove_planks", xp: 0.1, display: "Mangrove Planks" },
  { id: "minecraft:cherry_planks", xp: 0.1, display: "Cherry Planks" },
  { id: "minecraft:bamboo_block", xp: 0.11, display: "Bamboo Block" },
  { id: "minecraft:stripped_oak_log", xp: 0.12, display: "Stripped Oak Log" },
  {
    id: "minecraft:stripped_spruce_log",
    xp: 0.12,
    display: "Stripped Spruce Log",
  },
  {
    id: "minecraft:stripped_birch_log",
    xp: 0.12,
    display: "Stripped Birch Log",
  },
  {
    id: "minecraft:stripped_jungle_log",
    xp: 0.12,
    display: "Stripped Jungle Log",
  },
  {
    id: "minecraft:stripped_acacia_log",
    xp: 0.12,
    display: "Stripped Acacia Log",
  },
  {
    id: "minecraft:stripped_dark_oak_log",
    xp: 0.12,
    display: "Stripped Dark Oak Log",
  },
  {
    id: "minecraft:stripped_mangrove_log",
    xp: 0.13,
    display: "Stripped Mangrove Log",
  },
  {
    id: "minecraft:stripped_cherry_log",
    xp: 0.13,
    display: "Stripped Cherry Log",
  },
  { id: "minecraft:oak_wood", xp: 0.1, display: "Oak Wood" },
  { id: "minecraft:spruce_wood", xp: 0.1, display: "Spruce Wood" },
  { id: "minecraft:birch_wood", xp: 0.1, display: "Birch Wood" },
  { id: "minecraft:jungle_wood", xp: 0.1, display: "Jungle Wood" },
  { id: "minecraft:acacia_wood", xp: 0.1, display: "Acacia Wood" },
  { id: "minecraft:dark_oak_wood", xp: 0.1, display: "Dark Oak Wood" },
  { id: "minecraft:mangrove_wood", xp: 0.11, display: "Mangrove Wood" },
  { id: "minecraft:cherry_wood", xp: 0.11, display: "Cherry Wood" },
  { id: "minecraft:oak_fence", xp: 0.05, display: "Oak Fence" },
  { id: "minecraft:spruce_fence", xp: 0.05, display: "Spruce Fence" },
  { id: "minecraft:birch_fence", xp: 0.05, display: "Birch Fence" },
  { id: "minecraft:jungle_fence", xp: 0.05, display: "Jungle Fence" },
  { id: "minecraft:acacia_fence", xp: 0.05, display: "Acacia Fence" },
  { id: "minecraft:dark_oak_fence", xp: 0.05, display: "Dark Oak Fence" },
  { id: "minecraft:mangrove_fence", xp: 0.06, display: "Mangrove Fence" },
  { id: "minecraft:cherry_fence", xp: 0.06, display: "Cherry Fence" },
  { id: "minecraft:oak_stairs", xp: 0.08, display: "Oak Stairs" },
  { id: "minecraft:spruce_stairs", xp: 0.08, display: "Spruce Stairs" },
  { id: "minecraft:birch_stairs", xp: 0.08, display: "Birch Stairs" },
  { id: "minecraft:jungle_stairs", xp: 0.08, display: "Jungle Stairs" },
  { id: "minecraft:acacia_stairs", xp: 0.08, display: "Acacia Stairs" },
  { id: "minecraft:dark_oak_stairs", xp: 0.08, display: "Dark Oak Stairs" },
  { id: "minecraft:mangrove_stairs", xp: 0.09, display: "Mangrove Stairs" },
  { id: "minecraft:cherry_stairs", xp: 0.09, display: "Cherry Stairs" },
  { id: "minecraft:oak_slab", xp: 0.04, display: "Oak Slab" },
  { id: "minecraft:spruce_slab", xp: 0.04, display: "Spruce Slab" },
  { id: "minecraft:birch_slab", xp: 0.04, display: "Birch Slab" },
  { id: "minecraft:jungle_slab", xp: 0.04, display: "Jungle Slab" },
  { id: "minecraft:acacia_slab", xp: 0.04, display: "Acacia Slab" },
  { id: "minecraft:dark_oak_slab", xp: 0.04, display: "Dark Oak Slab" },
  { id: "minecraft:mangrove_slab", xp: 0.05, display: "Mangrove Slab" },
  { id: "minecraft:cherry_slab", xp: 0.05, display: "Cherry Slab" },

  // Sand & Glass
  { id: "minecraft:sand", xp: 0.06, display: "Sand" },
  { id: "minecraft:red_sand", xp: 0.06, display: "Red Sand" },
  { id: "minecraft:sandstone", xp: 0.1, display: "Sandstone" },
  { id: "minecraft:smooth_sandstone", xp: 0.12, display: "Smooth Sandstone" },
  { id: "minecraft:cut_sandstone", xp: 0.11, display: "Cut Sandstone" },
  {
    id: "minecraft:chiseled_sandstone",
    xp: 0.13,
    display: "Chiseled Sandstone",
  },
  { id: "minecraft:glass", xp: 0.15, display: "Glass" },
  {
    id: "minecraft:white_stained_glass",
    xp: 0.16,
    display: "White Stained Glass",
  },
  {
    id: "minecraft:orange_stained_glass",
    xp: 0.16,
    display: "Orange Stained Glass",
  },
  {
    id: "minecraft:magenta_stained_glass",
    xp: 0.16,
    display: "Magenta Stained Glass",
  },
  {
    id: "minecraft:light_blue_stained_glass",
    xp: 0.16,
    display: "Light Blue Stained Glass",
  },
  {
    id: "minecraft:yellow_stained_glass",
    xp: 0.16,
    display: "Yellow Stained Glass",
  },
  {
    id: "minecraft:lime_stained_glass",
    xp: 0.16,
    display: "Lime Stained Glass",
  },
  {
    id: "minecraft:pink_stained_glass",
    xp: 0.16,
    display: "Pink Stained Glass",
  },
  {
    id: "minecraft:gray_stained_glass",
    xp: 0.16,
    display: "Gray Stained Glass",
  },
  {
    id: "minecraft:light_gray_stained_glass",
    xp: 0.16,
    display: "Light Gray Stained Glass",
  },
  {
    id: "minecraft:cyan_stained_glass",
    xp: 0.16,
    display: "Cyan Stained Glass",
  },
  {
    id: "minecraft:purple_stained_glass",
    xp: 0.16,
    display: "Purple Stained Glass",
  },
  {
    id: "minecraft:blue_stained_glass",
    xp: 0.16,
    display: "Blue Stained Glass",
  },
  {
    id: "minecraft:brown_stained_glass",
    xp: 0.16,
    display: "Brown Stained Glass",
  },
  {
    id: "minecraft:green_stained_glass",
    xp: 0.16,
    display: "Green Stained Glass",
  },
  { id: "minecraft:red_stained_glass", xp: 0.16, display: "Red Stained Glass" },
  {
    id: "minecraft:black_stained_glass",
    xp: 0.16,
    display: "Black Stained Glass",
  },
  { id: "minecraft:glass_pane", xp: 0.08, display: "Glass Pane" },
  {
    id: "minecraft:white_stained_glass_pane",
    xp: 0.09,
    display: "White Stained Glass Pane",
  },
  {
    id: "minecraft:orange_stained_glass_pane",
    xp: 0.09,
    display: "Orange Stained Glass Pane",
  },
  {
    id: "minecraft:magenta_stained_glass_pane",
    xp: 0.09,
    display: "Magenta Stained Glass Pane",
  },
  {
    id: "minecraft:light_blue_stained_glass_pane",
    xp: 0.09,
    display: "Light Blue Stained Glass Pane",
  },
  {
    id: "minecraft:yellow_stained_glass_pane",
    xp: 0.09,
    display: "Yellow Stained Glass Pane",
  },
  {
    id: "minecraft:lime_stained_glass_pane",
    xp: 0.09,
    display: "Lime Stained Glass Pane",
  },
  {
    id: "minecraft:pink_stained_glass_pane",
    xp: 0.09,
    display: "Pink Stained Glass Pane",
  },
  {
    id: "minecraft:gray_stained_glass_pane",
    xp: 0.09,
    display: "Gray Stained Glass Pane",
  },
  {
    id: "minecraft:light_gray_stained_glass_pane",
    xp: 0.09,
    display: "Light Gray Stained Glass Pane",
  },
  {
    id: "minecraft:cyan_stained_glass_pane",
    xp: 0.09,
    display: "Cyan Stained Glass Pane",
  },
  {
    id: "minecraft:purple_stained_glass_pane",
    xp: 0.09,
    display: "Purple Stained Glass Pane",
  },
  {
    id: "minecraft:blue_stained_glass_pane",
    xp: 0.09,
    display: "Blue Stained Glass Pane",
  },
  {
    id: "minecraft:brown_stained_glass_pane",
    xp: 0.09,
    display: "Brown Stained Glass Pane",
  },
  {
    id: "minecraft:green_stained_glass_pane",
    xp: 0.09,
    display: "Green Stained Glass Pane",
  },
  {
    id: "minecraft:red_stained_glass_pane",
    xp: 0.09,
    display: "Red Stained Glass Pane",
  },
  {
    id: "minecraft:black_stained_glass_pane",
    xp: 0.09,
    display: "Black Stained Glass Pane",
  },

  // Ores & Mineral Blocks
  { id: "minecraft:coal_ore", xp: 0.2, display: "Coal Ore" },
  { id: "minecraft:iron_ore", xp: 0.25, display: "Iron Ore" },
  { id: "minecraft:gold_ore", xp: 0.3, display: "Gold Ore" },
  { id: "minecraft:diamond_ore", xp: 0.4, display: "Diamond Ore" },
  { id: "minecraft:emerald_ore", xp: 0.45, display: "Emerald Ore" },
  { id: "minecraft:lapis_ore", xp: 0.28, display: "Lapis Lazuli Ore" },
  { id: "minecraft:redstone_ore", xp: 0.27, display: "Redstone Ore" },
  { id: "minecraft:copper_ore", xp: 0.22, display: "Copper Ore" },
  { id: "minecraft:nether_gold_ore", xp: 0.32, display: "Nether Gold Ore" },
  { id: "minecraft:ancient_debris", xp: 0.5, display: "Ancient Debris" },
  { id: "minecraft:iron_block", xp: 0.35, display: "Block of Iron" },
  { id: "minecraft:gold_block", xp: 0.4, display: "Block of Gold" },
  { id: "minecraft:diamond_block", xp: 0.5, display: "Block of Diamond" },
  { id: "minecraft:emerald_block", xp: 0.48, display: "Block of Emerald" },
  { id: "minecraft:lapis_block", xp: 0.33, display: "Block of Lapis Lazuli" },
  { id: "minecraft:redstone_block", xp: 0.32, display: "Block of Redstone" },
  { id: "minecraft:copper_block", xp: 0.28, display: "Block of Copper" },
  { id: "minecraft:raw_iron_block", xp: 0.27, display: "Block of Raw Iron" },
  { id: "minecraft:raw_gold_block", xp: 0.37, display: "Block of Raw Gold" },
  {
    id: "minecraft:raw_copper_block",
    xp: 0.25,
    display: "Block of Raw Copper",
  },
  { id: "minecraft:amethyst_block", xp: 0.25, display: "Amethyst Block" },
  { id: "minecraft:budding_amethyst", xp: 0.28, display: "Budding Amethyst" },

  // Natural & Nether/End Blocks
  { id: "minecraft:gravel", xp: 0.05, display: "Gravel" },
  { id: "minecraft:clay", xp: 0.07, display: "Clay" },
  { id: "minecraft:obsidian", xp: 0.25, display: "Obsidian" },
  { id: "minecraft:crying_obsidian", xp: 0.3, display: "Crying Obsidian" },
  { id: "minecraft:netherrack", xp: 0.05, display: "Netherrack" },
  { id: "minecraft:soul_sand", xp: 0.06, display: "Soul Sand" },
  { id: "minecraft:soul_soil", xp: 0.07, display: "Soul Soil" },
  { id: "minecraft:basalt", xp: 0.1, display: "Basalt" },
  { id: "minecraft:polished_basalt", xp: 0.11, display: "Polished Basalt" },
  { id: "minecraft:magma_block", xp: 0.1, display: "Magma Block" },
  { id: "minecraft:glowstone", xp: 0.15, display: "Glowstone" },
  { id: "minecraft:shroomlight", xp: 0.18, display: "Shroomlight" },
  { id: "minecraft:crimson_nylium", xp: 0.07, display: "Crimson Nylium" },
  { id: "minecraft:warped_nylium", xp: 0.07, display: "Warped Nylium" },
  { id: "minecraft:crimson_hyphae", xp: 0.1, display: "Crimson Hyphae" },
  { id: "minecraft:warped_hyphae", xp: 0.1, display: "Warped Hyphae" },
  { id: "minecraft:end_stone", xp: 0.15, display: "End Stone" },
  { id: "minecraft:purpur_block", xp: 0.2, display: "Purpur Block" },
  { id: "minecraft:purpur_pillar", xp: 0.21, display: "Purpur Pillar" },
  { id: "minecraft:end_stone_bricks", xp: 0.2, display: "End Stone Bricks" },
  { id: "minecraft:chorus_flower", xp: 0.1, display: "Chorus Flower" },
  { id: "minecraft:chorus_plant", xp: 0.08, display: "Chorus Plant" },
  { id: "minecraft:nether_wart_block", xp: 0.1, display: "Nether Wart Block" },
  { id: "minecraft:warped_wart_block", xp: 0.1, display: "Warped Wart Block" },
  { id: "minecraft:bone_block", xp: 0.1, display: "Bone Block" },
  { id: "minecraft:sculk_sensor", xp: 0.3, display: "Sculk Sensor" },
  { id: "minecraft:sculk_catalyst", xp: 0.35, display: "Sculk Catalyst" },
  { id: "minecraft:sculk_shrieker", xp: 0.32, display: "Sculk Shrieker" },
  {
    id: "minecraft:reinforced_deepslate",
    xp: 0.4,
    display: "Reinforced Deepslate",
  },

  // Crafted & Decorative Blocks
  { id: "minecraft:bricks", xp: 0.18, display: "Bricks" },
  { id: "minecraft:nether_bricks", xp: 0.19, display: "Nether Bricks" },
  { id: "minecraft:red_nether_bricks", xp: 0.2, display: "Red Nether Bricks" },
  { id: "minecraft:prismarine", xp: 0.2, display: "Prismarine" },
  { id: "minecraft:dark_prismarine", xp: 0.22, display: "Dark Prismarine" },
  { id: "minecraft:prismarine_bricks", xp: 0.21, display: "Prismarine Bricks" },
  { id: "minecraft:sea_lantern", xp: 0.25, display: "Sea Lantern" },
  { id: "minecraft:hay_block", xp: 0.08, display: "Hay Block" },
  { id: "minecraft:dried_kelp_block", xp: 0.07, display: "Dried Kelp Block" },
  { id: "minecraft:sponge", xp: 0.15, display: "Sponge" },
  { id: "minecraft:wet_sponge", xp: 0.16, display: "Wet Sponge" },
  { id: "minecraft:bookshelf", xp: 0.15, display: "Bookshelf" },
  { id: "minecraft:crafting_table", xp: 0.1, display: "Crafting Table" },
  { id: "minecraft:furnace", xp: 0.12, display: "Furnace" },
  { id: "minecraft:chest", xp: 0.12, display: "Chest" },
  { id: "minecraft:barrel", xp: 0.12, display: "Barrel" },
  { id: "minecraft:smoker", xp: 0.13, display: "Smoker" },
  { id: "minecraft:blast_furnace", xp: 0.14, display: "Blast Furnace" },
  { id: "minecraft:grindstone", xp: 0.13, display: "Grindstone" },
  { id: "minecraft:loom", xp: 0.12, display: "Loom" },
  { id: "minecraft:cartography_table", xp: 0.13, display: "Cartography Table" },
  { id: "minecraft:fletching_table", xp: 0.12, display: "Fletching Table" },
  { id: "minecraft:smithing_table", xp: 0.14, display: "Smithing Table" },
  { id: "minecraft:stonecutter", xp: 0.13, display: "Stonecutter" },
  { id: "minecraft:bell", xp: 0.2, display: "Bell" },
  { id: "minecraft:campfire", xp: 0.1, display: "Campfire" },
  { id: "minecraft:soul_campfire", xp: 0.11, display: "Soul Campfire" },
  { id: "minecraft:lantern", xp: 0.12, display: "Lantern" },
  { id: "minecraft:soul_lantern", xp: 0.13, display: "Soul Lantern" },
  { id: "minecraft:chain", xp: 0.08, display: "Chain" },
  { id: "minecraft:iron_bars", xp: 0.06, display: "Iron Bars" },
  { id: "minecraft:end_rod", xp: 0.15, display: "End Rod" },
  { id: "minecraft:honey_block", xp: 0.15, display: "Honey Block" },
  { id: "minecraft:slime_block", xp: 0.15, display: "Slime Block" },
  { id: "minecraft:shulker_box", xp: 0.2, display: "Shulker Box" }, // Generic, add specific colors if needed
  { id: "minecraft:white_shulker_box", xp: 0.2, display: "White Shulker Box" },
  {
    id: "minecraft:orange_shulker_box",
    xp: 0.2,
    display: "Orange Shulker Box",
  },
  {
    id: "minecraft:magenta_shulker_box",
    xp: 0.2,
    display: "Magenta Shulker Box",
  },
  {
    id: "minecraft:light_blue_shulker_box",
    xp: 0.2,
    display: "Light Blue Shulker Box",
  },
  {
    id: "minecraft:yellow_shulker_box",
    xp: 0.2,
    display: "Yellow Shulker Box",
  },
  { id: "minecraft:lime_shulker_box", xp: 0.2, display: "Lime Shulker Box" },
  { id: "minecraft:pink_shulker_box", xp: 0.2, display: "Pink Shulker Box" },
  { id: "minecraft:gray_shulker_box", xp: 0.2, display: "Gray Shulker Box" },
  {
    id: "minecraft:light_gray_shulker_box",
    xp: 0.2,
    display: "Light Gray Shulker Box",
  },
  { id: "minecraft:cyan_shulker_box", xp: 0.2, display: "Cyan Shulker Box" },
  {
    id: "minecraft:purple_shulker_box",
    xp: 0.2,
    display: "Purple Shulker Box",
  },
  { id: "minecraft:blue_shulker_box", xp: 0.2, display: "Blue Shulker Box" },
  { id: "minecraft:brown_shulker_box", xp: 0.2, display: "Brown Shulker Box" },
  { id: "minecraft:green_shulker_box", xp: 0.2, display: "Green Shulker Box" },
  { id: "minecraft:red_shulker_box", xp: 0.2, display: "Red Shulker Box" },
  { id: "minecraft:black_shulker_box", xp: 0.2, display: "Black Shulker Box" },
  { id: "minecraft:lectern", xp: 0.12, display: "Lectern" },
  { id: "minecraft:composter", xp: 0.07, display: "Composter" },
  { id: "minecraft:jukebox", xp: 0.15, display: "Jukebox" },
  { id: "minecraft:note_block", xp: 0.1, display: "Note Block" },
  { id: "minecraft:enchanting_table", xp: 0.25, display: "Enchanting Table" },
  { id: "minecraft:brewing_stand", xp: 0.15, display: "Brewing Stand" },
  { id: "minecraft:cauldron", xp: 0.1, display: "Cauldron" },
  { id: "minecraft:beacon", xp: 0.5, display: "Beacon" },
  { id: "minecraft:conduit", xp: 0.3, display: "Conduit" },
  { id: "minecraft:dragon_egg", xp: 1.0, display: "Dragon Egg" }, // Very rare, high XP

  // Redstone Related
  { id: "minecraft:redstone_block", xp: 0.15, display: "Redstone Block" },
  { id: "minecraft:lever", xp: 0.03, display: "Lever" },
  { id: "minecraft:stone_button", xp: 0.03, display: "Stone Button" },
  { id: "minecraft:wooden_button", xp: 0.03, display: "Wooden Button" },
  {
    id: "minecraft:stone_pressure_plate",
    xp: 0.04,
    display: "Stone Pressure Plate",
  },
  {
    id: "minecraft:wooden_pressure_plate",
    xp: 0.04,
    display: "Wooden Pressure Plate",
  },
  {
    id: "minecraft:light_weighted_pressure_plate",
    xp: 0.05,
    display: "Light Weighted Pressure Plate",
  },
  {
    id: "minecraft:heavy_weighted_pressure_plate",
    xp: 0.05,
    display: "Heavy Weighted Pressure Plate",
  },
  { id: "minecraft:target", xp: 0.08, display: "Target Block" },
  { id: "minecraft:dispenser", xp: 0.15, display: "Dispenser" },
  { id: "minecraft:dropper", xp: 0.14, display: "Dropper" },
  { id: "minecraft:observer", xp: 0.16, display: "Observer" },
  { id: "minecraft:piston", xp: 0.17, display: "Piston" },
  { id: "minecraft:sticky_piston", xp: 0.18, display: "Sticky Piston" },
  { id: "minecraft:redstone_lamp", xp: 0.15, display: "Redstone Lamp" },
  { id: "minecraft:daylight_detector", xp: 0.14, display: "Daylight Detector" },
  { id: "minecraft:tripwire_hook", xp: 0.05, display: "Tripwire Hook" },
  { id: "minecraft:detector_rail", xp: 0.06, display: "Detector Rail" },
  { id: "minecraft:powered_rail", xp: 0.06, display: "Powered Rail" },
  { id: "minecraft:activator_rail", xp: 0.06, display: "Activator Rail" },
  { id: "minecraft:rail", xp: 0.05, display: "Rail" },
  { id: "minecraft:repeater", xp: 0.07, display: "Repeater" },
  { id: "minecraft:comparator", xp: 0.08, display: "Comparator" },
  { id: "minecraft:hopper", xp: 0.12, display: "Hopper" },
  { id: "minecraft:tnt", xp: 0.15, display: "TNT" },
  { id: "minecraft:lightning_rod", xp: 0.09, display: "Lightning Rod" },

  // Doors, Trapdoors, Fences, Walls, Stairs, Slabs (Generic/Common)
  { id: "minecraft:oak_door", xp: 0.08, display: "Oak Door" },
  { id: "minecraft:spruce_door", xp: 0.08, display: "Spruce Door" },
  { id: "minecraft:birch_door", xp: 0.08, display: "Birch Door" },
  { id: "minecraft:jungle_door", xp: 0.08, display: "Jungle Door" },
  { id: "minecraft:acacia_door", xp: 0.08, display: "Acacia Door" },
  { id: "minecraft:dark_oak_door", xp: 0.08, display: "Dark Oak Door" },
  { id: "minecraft:mangrove_door", xp: 0.09, display: "Mangrove Door" },
  { id: "minecraft:cherry_door", xp: 0.09, display: "Cherry Door" },
  { id: "minecraft:iron_door", xp: 0.1, display: "Iron Door" },
  { id: "minecraft:oak_trapdoor", xp: 0.06, display: "Oak Trapdoor" },
  { id: "minecraft:spruce_trapdoor", xp: 0.06, display: "Spruce Trapdoor" },
  { id: "minecraft:birch_trapdoor", xp: 0.06, display: "Birch Trapdoor" },
  { id: "minecraft:jungle_trapdoor", xp: 0.06, display: "Jungle Trapdoor" },
  { id: "minecraft:acacia_trapdoor", xp: 0.06, display: "Acacia Trapdoor" },
  { id: "minecraft:dark_oak_trapdoor", xp: 0.06, display: "Dark Oak Trapdoor" },
  { id: "minecraft:mangrove_trapdoor", xp: 0.07, display: "Mangrove Trapdoor" },
  { id: "minecraft:cherry_trapdoor", xp: 0.07, display: "Cherry Trapdoor" },
  { id: "minecraft:iron_trapdoor", xp: 0.07, display: "Iron Trapdoor" },
  { id: "minecraft:oak_fence_gate", xp: 0.06, display: "Oak Fence Gate" },
  { id: "minecraft:spruce_fence_gate", xp: 0.06, display: "Spruce Fence Gate" },
  { id: "minecraft:birch_fence_gate", xp: 0.06, display: "Birch Fence Gate" },
  { id: "minecraft:jungle_fence_gate", xp: 0.06, display: "Jungle Fence Gate" },
  { id: "minecraft:acacia_fence_gate", xp: 0.06, display: "Acacia Fence Gate" },
  {
    id: "minecraft:dark_oak_fence_gate",
    xp: 0.06,
    display: "Dark Oak Fence Gate",
  },
  {
    id: "minecraft:mangrove_fence_gate",
    xp: 0.07,
    display: "Mangrove Fence Gate",
  },
  { id: "minecraft:cherry_fence_gate", xp: 0.07, display: "Cherry Fence Gate" },
  { id: "minecraft:cobblestone_wall", xp: 0.07, display: "Cobblestone Wall" },
  {
    id: "minecraft:mossy_cobblestone_wall",
    xp: 0.08,
    display: "Mossy Cobblestone Wall",
  },
  { id: "minecraft:stone_brick_wall", xp: 0.08, display: "Stone Brick Wall" },
  {
    id: "minecraft:mossy_stone_brick_wall",
    xp: 0.09,
    display: "Mossy Stone Brick Wall",
  },
  { id: "minecraft:andesite_wall", xp: 0.07, display: "Andesite Wall" },
  { id: "minecraft:diorite_wall", xp: 0.07, display: "Diorite Wall" },
  { id: "minecraft:granite_wall", xp: 0.07, display: "Granite Wall" },
  { id: "minecraft:brick_wall", xp: 0.08, display: "Brick Wall" },
  { id: "minecraft:prismarine_wall", xp: 0.09, display: "Prismarine Wall" },
  {
    id: "minecraft:red_sandstone_wall",
    xp: 0.08,
    display: "Red Sandstone Wall",
  },
  { id: "minecraft:sandstone_wall", xp: 0.08, display: "Sandstone Wall" },
  {
    id: "minecraft:end_stone_brick_wall",
    xp: 0.09,
    display: "End Stone Brick Wall",
  },
  { id: "minecraft:nether_brick_wall", xp: 0.09, display: "Nether Brick Wall" },
  {
    id: "minecraft:red_nether_brick_wall",
    xp: 0.1,
    display: "Red Nether Brick Wall",
  },
  {
    id: "minecraft:polished_blackstone_brick_wall",
    xp: 0.1,
    display: "Polished Blackstone Brick Wall",
  },
  {
    id: "minecraft:polished_blackstone_wall",
    xp: 0.09,
    display: "Polished Blackstone Wall",
  },
  {
    id: "minecraft:deepslate_brick_wall",
    xp: 0.09,
    display: "Deepslate Brick Wall",
  },
  {
    id: "minecraft:deepslate_tile_wall",
    xp: 0.09,
    display: "Deepslate Tile Wall",
  },
  {
    id: "minecraft:cobbled_deepslate_wall",
    xp: 0.08,
    display: "Cobbled Deepslate Wall",
  },
  { id: "minecraft:mud_brick_wall", xp: 0.08, display: "Mud Brick Wall" },
  {
    id: "minecraft:cut_red_sandstone_stairs",
    xp: 0.09,
    display: "Cut Red Sandstone Stairs",
  },
  {
    id: "minecraft:cut_sandstone_stairs",
    xp: 0.09,
    display: "Cut Sandstone Stairs",
  },
  {
    id: "minecraft:smooth_red_sandstone_stairs",
    xp: 0.1,
    display: "Smooth Red Sandstone Stairs",
  },
  {
    id: "minecraft:smooth_sandstone_stairs",
    xp: 0.1,
    display: "Smooth Sandstone Stairs",
  },
  { id: "minecraft:brick_stairs", xp: 0.09, display: "Brick Stairs" },
  { id: "minecraft:stone_stairs", xp: 0.08, display: "Stone Stairs" },
  {
    id: "minecraft:cobblestone_stairs",
    xp: 0.07,
    display: "Cobblestone Stairs",
  },
  {
    id: "minecraft:stone_brick_stairs",
    xp: 0.09,
    display: "Stone Brick Stairs",
  },
  {
    id: "minecraft:mossy_stone_brick_stairs",
    xp: 0.1,
    display: "Mossy Stone Brick Stairs",
  },
  { id: "minecraft:andesite_stairs", xp: 0.08, display: "Andesite Stairs" },
  { id: "minecraft:diorite_stairs", xp: 0.08, display: "Diorite Stairs" },
  { id: "minecraft:granite_stairs", xp: 0.08, display: "Granite Stairs" },
  {
    id: "minecraft:nether_brick_stairs",
    xp: 0.09,
    display: "Nether Brick Stairs",
  },
  {
    id: "minecraft:red_nether_brick_stairs",
    xp: 0.1,
    display: "Red Nether Brick Stairs",
  },
  { id: "minecraft:purpur_stairs", xp: 0.11, display: "Purpur Stairs" },
  { id: "minecraft:prismarine_stairs", xp: 0.1, display: "Prismarine Stairs" },
  {
    id: "minecraft:dark_prismarine_stairs",
    xp: 0.11,
    display: "Dark Prismarine Stairs",
  },
  {
    id: "minecraft:prismarine_brick_stairs",
    xp: 0.1,
    display: "Prismarine Brick Stairs",
  },
  {
    id: "minecraft:end_stone_brick_stairs",
    xp: 0.1,
    display: "End Stone Brick Stairs",
  },
  {
    id: "minecraft:polished_blackstone_stairs",
    xp: 0.1,
    display: "Polished Blackstone Stairs",
  },
  {
    id: "minecraft:polished_blackstone_brick_stairs",
    xp: 0.11,
    display: "Polished Blackstone Brick Stairs",
  },
  {
    id: "minecraft:cobbled_deepslate_stairs",
    xp: 0.08,
    display: "Cobbled Deepslate Stairs",
  },
  {
    id: "minecraft:polished_deepslate_stairs",
    xp: 0.09,
    display: "Polished Deepslate Stairs",
  },
  {
    id: "minecraft:deepslate_brick_stairs",
    xp: 0.1,
    display: "Deepslate Brick Stairs",
  },
  {
    id: "minecraft:deepslate_tile_stairs",
    xp: 0.1,
    display: "Deepslate Tile Stairs",
  },
  { id: "minecraft:mud_brick_stairs", xp: 0.09, display: "Mud Brick Stairs" },
  {
    id: "minecraft:cut_red_sandstone_slab",
    xp: 0.05,
    display: "Cut Red Sandstone Slab",
  },
  {
    id: "minecraft:cut_sandstone_slab",
    xp: 0.05,
    display: "Cut Sandstone Slab",
  },
  {
    id: "minecraft:smooth_red_sandstone_slab",
    xp: 0.06,
    display: "Smooth Red Sandstone Slab",
  },
  {
    id: "minecraft:smooth_sandstone_slab",
    xp: 0.06,
    display: "Smooth Sandstone Slab",
  },
  { id: "minecraft:brick_slab", xp: 0.05, display: "Brick Slab" },
  { id: "minecraft:stone_slab", xp: 0.04, display: "Stone Slab" },
  { id: "minecraft:cobblestone_slab", xp: 0.04, display: "Cobblestone Slab" },
  { id: "minecraft:stone_brick_slab", xp: 0.05, display: "Stone Brick Slab" },
  {
    id: "minecraft:mossy_stone_brick_slab",
    xp: 0.05,
    display: "Mossy Stone Brick Slab",
  },
  { id: "minecraft:andesite_slab", xp: 0.04, display: "Andesite Slab" },
  { id: "minecraft:diorite_slab", xp: 0.04, display: "Diorite Slab" },
  { id: "minecraft:granite_slab", xp: 0.04, display: "Granite Slab" },
  { id: "minecraft:nether_brick_slab", xp: 0.05, display: "Nether Brick Slab" },
  {
    id: "minecraft:red_nether_brick_slab",
    xp: 0.05,
    display: "Red Nether Brick Slab",
  },
  { id: "minecraft:purpur_slab", xp: 0.06, display: "Purpur Slab" },
  { id: "minecraft:prismarine_slab", xp: 0.05, display: "Prismarine Slab" },
  {
    id: "minecraft:dark_prismarine_slab",
    xp: 0.06,
    display: "Dark Prismarine Slab",
  },
  {
    id: "minecraft:prismarine_brick_slab",
    xp: 0.05,
    display: "Prismarine Brick Slab",
  },
  {
    id: "minecraft:end_stone_brick_slab",
    xp: 0.05,
    display: "End Stone Brick Slab",
  },
  {
    id: "minecraft:polished_blackstone_slab",
    xp: 0.05,
    display: "Polished Blackstone Slab",
  },
  {
    id: "minecraft:polished_blackstone_brick_slab",
    xp: 0.06,
    display: "Polished Blackstone Brick Slab",
  },
  {
    id: "minecraft:cobbled_deepslate_slab",
    xp: 0.04,
    display: "Cobbled Deepslate Slab",
  },
  {
    id: "minecraft:polished_deepslate_slab",
    xp: 0.05,
    display: "Polished Deepslate Slab",
  },
  {
    id: "minecraft:deepslate_brick_slab",
    xp: 0.05,
    display: "Deepslate Brick Slab",
  },
  {
    id: "minecraft:deepslate_tile_slab",
    xp: 0.05,
    display: "Deepslate Tile Slab",
  },
  { id: "minecraft:mud_brick_slab", xp: 0.05, display: "Mud Brick Slab" },
  { id: "minecraft:ladder", xp: 0.05, display: "Ladder" },
  { id: "minecraft:torch", xp: 0.02, display: "Torch" },
  { id: "minecraft:wall_torch", xp: 0.02, display: "Wall Torch" },
  { id: "minecraft:respawn_anchor", xp: 0.25, display: "Respawn Anchor" },
  { id: "minecraft:lodestone", xp: 0.28, display: "Lodestone" },
];

export const potionXpSources = [
  { effectId: "minecraft:speed", amplifier: 0, xp: 1, name: "Swiftness I" },
  { effectId: "minecraft:speed", amplifier: 1, xp: 2, name: "Swiftness II" },
  { effectId: "minecraft:slowness", amplifier: 0, xp: 0.5, name: "Slowness I" },
  { effectId: "minecraft:haste", amplifier: 0, xp: 1, name: "Haste I" },
  { effectId: "minecraft:haste", amplifier: 1, xp: 2, name: "Haste II" },
  { effectId: "minecraft:strength", amplifier: 0, xp: 2, name: "Strength I" },
  { effectId: "minecraft:strength", amplifier: 1, xp: 3, name: "Strength II" },
  {
    effectId: "minecraft:instant_health",
    amplifier: 0,
    xp: 2,
    name: "Healing I",
  },
  {
    effectId: "minecraft:instant_health",
    amplifier: 1,
    xp: 3,
    name: "Healing II",
  },
  {
    effectId: "minecraft:instant_damage",
    amplifier: 0,
    xp: 1,
    name: "Harming I",
  },
  {
    effectId: "minecraft:instant_damage",
    amplifier: 1,
    xp: 2,
    name: "Harming II",
  },
  { effectId: "minecraft:jump_boost", amplifier: 0, xp: 1, name: "Leaping I" },
  { effectId: "minecraft:jump_boost", amplifier: 1, xp: 2, name: "Leaping II" },
  {
    effectId: "minecraft:regeneration",
    amplifier: 0,
    xp: 2,
    name: "Regeneration I",
  },
  {
    effectId: "minecraft:regeneration",
    amplifier: 1,
    xp: 3,
    name: "Regeneration II",
  },
  {
    effectId: "minecraft:fire_resistance",
    amplifier: 0,
    xp: 1,
    name: "Fire Resistance",
  },
  {
    effectId: "minecraft:water_breathing",
    amplifier: 0,
    xp: 1,
    name: "Water Breathing",
  },
  {
    effectId: "minecraft:night_vision",
    amplifier: 0,
    xp: 1,
    name: "Night Vision",
  },
  {
    effectId: "minecraft:invisibility",
    amplifier: 0,
    xp: 1,
    name: "Invisibility",
  },
  { effectId: "minecraft:weakness", amplifier: 0, xp: 0.5, name: "Weakness" },
  { effectId: "minecraft:poison", amplifier: 0, xp: 1, name: "Poison I" },
  { effectId: "minecraft:poison", amplifier: 1, xp: 2, name: "Poison II" },
  {
    effectId: "minecraft:slow_falling",
    amplifier: 0,
    xp: 1,
    name: "Slow Falling",
  },
];

// CRAFTING

export const SPECIAL_CRAFTED_ITEMS_XP = {
  // 🛠️ Basic Utilities
  "minecraft:crafting_table": { xp: 1, nameKey: "Crafting Table" },
  "minecraft:smithing_table": { xp: 2.5, nameKey: "Smithing Table" },
  "minecraft:cartography_table": { xp: 2.0, nameKey: "Cartography Table" },
  "minecraft:fletching_table": { xp: 2.0, nameKey: "Fletching Table" },
  "minecraft:grindstone": { xp: 2.0, nameKey: "Grindstone" },
  "minecraft:anvil": { xp: 4.0, nameKey: "Anvil" },
  "minecraft:enchanting_table": { xp: 8.0, nameKey: "Enchanting Table" },
  "minecraft:jukebox": { xp: 3.5, nameKey: "Jukebox" },

  // ⚙️ Redstone Components
  "minecraft:piston": { xp: 2.5, nameKey: "Piston" },
  "minecraft:observer": { xp: 3.0, nameKey: "Observer" },
  "minecraft:comparator": { xp: 3.0, nameKey: "Redstone Comparator" },
  "minecraft:daylight_detector": { xp: 2.5, nameKey: "Daylight Detector" },

  // ⚔️ Netherite Weapons & Tools
  "minecraft:netherite_sword": { xp: 5.0, nameKey: "Netherite Sword" },
  "minecraft:netherite_pickaxe": { xp: 6.0, nameKey: "Netherite Pickaxe" },
  "minecraft:netherite_axe": { xp: 5.0, nameKey: "Netherite Axe" },
  "minecraft:netherite_hoe": { xp: 5.0, nameKey: "Netherite Hoe" },
  "minecraft:netherite_shovel": { xp: 5.0, nameKey: "Netherite Shovel" },

  // 🛡️ Netherite Armor
  "minecraft:netherite_helmet": { xp: 6.0, nameKey: "Netherite Helmet" },
  "minecraft:netherite_chestplate": {
    xp: 7.0,
    nameKey: "Netherite Chestplate",
  },
  "minecraft:netherite_leggings": { xp: 6.5, nameKey: "Netherite Leggings" },
  "minecraft:netherite_boots": { xp: 6.0, nameKey: "Netherite Boots" },

  // 🧪 Magical / Rare
  "minecraft:beacon": { xp: 15.0, nameKey: "Beacon" },
  "minecraft:end_crystal": { xp: 10.0, nameKey: "End Crystal" },
  "minecraft:respawn_anchor": { xp: 8.0, nameKey: "Respawn Anchor" },
  "minecraft:lodestone": { xp: 7.0, nameKey: "Lodestone" },
  "minecraft:shulker_box": { xp: 6.0, nameKey: "Shulker Box" },
  "minecraft:ender_chest": { xp: 7.0, nameKey: "Ender Chest" },
};

export const DEFAULT_CRAFTED_ITEM_XP = 0.05;
// Danh sách các khối chức năng mà chúng ta muốn theo dõi
export const INTERACTIVE_BLOCKS = [
  "minecraft:crafting_table",
  "minecraft:stonecutter",
  "minecraft:grindstone",
  "minecraft:loom",
  "minecraft:smithing_table",
  "minecraft:fletching_table",
  "minecraft:cartography_table",
];

export const recycleMap = {
  // Sắt
  "minecraft:iron_sword": [
    ["minecraft:iron_ingot", 1],
    ["minecraft:stick", 1],
  ],
  "minecraft:iron_pickaxe": [
    ["minecraft:iron_ingot", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:iron_shovel": [
    ["minecraft:iron_ingot", 1],
    ["minecraft:stick", 2],
  ],
  "minecraft:iron_axe": [
    ["minecraft:iron_ingot", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:iron_hoe": [
    ["minecraft:iron_ingot", 2],
    ["minecraft:stick", 2],
  ],
  "minecraft:iron_helmet": [["minecraft:iron_ingot", 5]],
  "minecraft:iron_chestplate": [["minecraft:iron_ingot", 8]],
  "minecraft:iron_leggings": [["minecraft:iron_ingot", 7]],
  "minecraft:iron_boots": [["minecraft:iron_ingot", 4]],

  // Kim cương
  "minecraft:diamond_sword": [
    ["minecraft:diamond", 2],
    ["minecraft:stick", 1],
  ],
  "minecraft:diamond_pickaxe": [
    ["minecraft:diamond", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:diamond_shovel": [
    ["minecraft:diamond", 1],
    ["minecraft:stick", 2],
  ],
  "minecraft:diamond_axe": [
    ["minecraft:diamond", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:diamond_hoe": [
    ["minecraft:diamond", 2],
    ["minecraft:stick", 2],
  ],
  "minecraft:diamond_helmet": [["minecraft:diamond", 5]],
  "minecraft:diamond_chestplate": [["minecraft:diamond", 8]],
  "minecraft:diamond_leggings": [["minecraft:diamond", 7]],
  "minecraft:diamond_boots": [["minecraft:diamond", 4]],

  // Vàng
  "minecraft:golden_sword": [
    ["minecraft:gold_ingot", 1],
    ["minecraft:stick", 1],
  ],
  "minecraft:golden_pickaxe": [
    ["minecraft:gold_ingot", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:golden_shovel": [
    ["minecraft:gold_ingot", 1],
    ["minecraft:stick", 2],
  ],
  "minecraft:golden_axe": [
    ["minecraft:gold_ingot", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:golden_hoe": [
    ["minecraft:gold_ingot", 2],
    ["minecraft:stick", 2],
  ],
  "minecraft:golden_helmet": [["minecraft:gold_ingot", 5]],
  "minecraft:golden_chestplate": [["minecraft:gold_ingot", 8]],
  "minecraft:golden_leggings": [["minecraft:gold_ingot", 7]],
  "minecraft:golden_boots": [["minecraft:gold_ingot", 4]],

  // Đá
  "minecraft:stone_sword": [
    ["minecraft:cobblestone", 1],
    ["minecraft:stick", 1],
  ],
  "minecraft:stone_pickaxe": [
    ["minecraft:cobblestone", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:stone_shovel": [
    ["minecraft:cobblestone", 1],
    ["minecraft:stick", 2],
  ],
  "minecraft:stone_axe": [
    ["minecraft:cobblestone", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:stone_hoe": [
    ["minecraft:cobblestone", 2],
    ["minecraft:stick", 2],
  ],

  // Gỗ
  "minecraft:wooden_sword": [
    ["minecraft:oak_planks", 1],
    ["minecraft:stick", 1],
  ],
  "minecraft:wooden_pickaxe": [
    ["minecraft:oak_planks", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:wooden_shovel": [
    ["minecraft:oak_planks", 1],
    ["minecraft:stick", 2],
  ],
  "minecraft:wooden_axe": [
    ["minecraft:oak_planks", 3],
    ["minecraft:stick", 2],
  ],
  "minecraft:wooden_hoe": [
    ["minecraft:oak_planks", 2],
    ["minecraft:stick", 2],
  ],

  // Da & Chainmail
  "minecraft:leather_helmet": [["minecraft:leather", 5]],
  "minecraft:leather_chestplate": [["minecraft:leather", 8]],
  "minecraft:leather_leggings": [["minecraft:leather", 7]],
  "minecraft:leather_boots": [["minecraft:leather", 4]],
  "minecraft:chainmail_helmet": [["minecraft:iron_ingot", 2]],
  "minecraft:chainmail_chestplate": [["minecraft:iron_ingot", 5]],
  "minecraft:chainmail_leggings": [["minecraft:iron_ingot", 4]],
  "minecraft:chainmail_boots": [["minecraft:iron_ingot", 2]],

  // Công cụ khác (shears, flint & steel)
  "minecraft:shears": [["minecraft:iron_ingot", 2]],
  "minecraft:flint_and_steel": [
    ["minecraft:iron_ingot", 1],
    ["minecraft:flint", 1],
  ],
};

export const transmuteMap = {
  // Gỗ xoay vòng
  "minecraft:oak_log": "minecraft:spruce_log",
  "minecraft:spruce_log": "minecraft:birch_log",
  "minecraft:birch_log": "minecraft:jungle_log",
  "minecraft:jungle_log": "minecraft:acacia_log",
  "minecraft:acacia_log": "minecraft:dark_oak_log",
  "minecraft:dark_oak_log": "minecraft:mangrove_log",
  "minecraft:mangrove_log": "minecraft:cherry_log",
  "minecraft:cherry_log": "minecraft:bamboo_block",
  "minecraft:bamboo_block": "minecraft:oak_log",

  // Đá xây dựng
  "minecraft:stone": "minecraft:cobblestone",
  "minecraft:cobblestone": "minecraft:andesite",
  "minecraft:andesite": "minecraft:diorite",
  "minecraft:diorite": "minecraft:granite",
  "minecraft:granite": "minecraft:stone",

  // Gạch xây dựng
  "minecraft:brick_block": "minecraft:mossy_cobblestone",
  "minecraft:mossy_cobblestone": "minecraft:mossy_stone_bricks",
  "minecraft:mossy_stone_bricks": "minecraft:stone_bricks",
  "minecraft:stone_bricks": "minecraft:brick_block",

  // Cát, đất
  "minecraft:sand": "minecraft:red_sand",
  "minecraft:red_sand": "minecraft:sand",
  "minecraft:dirt": "minecraft:coarse_dirt",
  "minecraft:coarse_dirt": "minecraft:podzol",
  "minecraft:podzol": "minecraft:moss_block",
  "minecraft:moss_block": "minecraft:dirt",

  // Lá cây
  "minecraft:oak_leaves": "minecraft:spruce_leaves",
  "minecraft:spruce_leaves": "minecraft:birch_leaves",
  "minecraft:birch_leaves": "minecraft:jungle_leaves",
  "minecraft:jungle_leaves": "minecraft:acacia_leaves",
  "minecraft:acacia_leaves": "minecraft:dark_oak_leaves",
  "minecraft:dark_oak_leaves": "minecraft:cherry_leaves",
  "minecraft:cherry_leaves": "minecraft:mangrove_leaves",
  "minecraft:mangrove_leaves": "minecraft:bamboo_mosaic",
  "minecraft:bamboo_mosaic": "minecraft:oak_leaves",

  // Gỗ đã xẻ
  "minecraft:oak_planks": "minecraft:spruce_planks",
  "minecraft:spruce_planks": "minecraft:birch_planks",
  "minecraft:birch_planks": "minecraft:jungle_planks",
  "minecraft:jungle_planks": "minecraft:acacia_planks",
  "minecraft:acacia_planks": "minecraft:dark_oak_planks",
  "minecraft:dark_oak_planks": "minecraft:cherry_planks",
  "minecraft:cherry_planks": "minecraft:mangrove_planks",
  "minecraft:mangrove_planks": "minecraft:bamboo_planks",
  "minecraft:bamboo_planks": "minecraft:oak_planks",

  // Gạch nether, đen, purpur, ...
  "minecraft:nether_bricks": "minecraft:red_nether_bricks",
  "minecraft:red_nether_bricks": "minecraft:deepslate",
  "minecraft:deepslate": "minecraft:polished_deepslate",
  "minecraft:polished_deepslate": "minecraft:blackstone",
  "minecraft:blackstone": "minecraft:polished_blackstone",
  "minecraft:polished_blackstone": "minecraft:purpur_block",
  "minecraft:purpur_block": "minecraft:end_stone_bricks",
  "minecraft:end_stone_bricks": "minecraft:nether_bricks",
};

export {
  xp,
  blocks,
  entities,
  treasures,
  m,
  logs,
  mobs,
  crops,
  cropsGrowth,
  soils,
  pickaxe,
  axe,
  sword,
  hoe,
  shovel,
  bow,
  particles,
};
