// lang.js
// Đây là tệp chứa các bản dịch cho các chuỗi văn bản trong game.

const translations = {
  vi_VN: {
    // Tiếng Việt
    // General messages
    failed_to_set_dynamic_property: "Không thể đặt thuộc tính động:",
    player_not_valid: "Người chơi không hợp lệ hoặc đã thoát.",
    setup_complete: "Thiết lập ban đầu hoàn tất. Chúc bạn chơi game vui vẻ!",
    level: "Cấp độ",
    money_bonus: "Tiền thưởng",
    xp_limit_adjusted:
      "Do minecraft giới hạn kí tự nên xp và nextXp của bạn đã được điều chỉnh",
    page: "Trang",
    locked: "Khoá",
    not_completed: "Chưa hoàn thành",
    completed: "Đã hoàn thành",
    in_progress: "Đang thực hiện",
    requirements: "Yêu cầu",
    progress: "Tiến trình",
    overview: "Tổng quan",
    leaderboard: "Bảng xếp hạng",
    how_to_get_xp: "Cách nhận kinh nghiệm",
    click: "Bấm",
    click_to_view_stats: "Bấm để xem chỉ số",
    click_to_setting: "Bấm để cài đặt",
    exclusive_skills: "Kĩ năng độc quyền",
    previous_page: "Trang trước",
    click_to_back_previous_page: "Bấm để về trang trước",
    next_page: "Trang tiếp",
    click_to_back_next_page: "Bấm để đến trang tiếp theo",
    back_to_skill_list: "Trở lại danh sách kĩ năng",
    click_to_back_main_skill: "Bấm để về danh sách kĩ năng chính",
    unlocked: "Đã mở khóa",
    requires_level: "Yêu cầu cấp",
    to_unlock: "để mở khóa!",
    description: "Mô tả",
    cooldown: "Thời gian hồi chiêu",
    seconds: "giây",
    stats: "Thông số",
    new_skill_unlocked: "Bạn đã mở khóa kỹ năng mới:",
    skill_levelup: "Kĩ năng lên cấp: {0}",
    levelup_message: "đã tăng từ cấp",
    to_level: "lên cấp",
    system_cooldown: "Hệ thống hồi chiêu",
    skill_levelup_cooldown:
      "{0} lên cấp! {1} từ cấp {2} lên cấp {3}! Cooldown mới: {4}s",
    cooldown_active: "Kỹ năng đang hồi chiêu. Vui lòng chờ",
    debug_stamina_drain: "Gỡ lỗi: Mất {0} stamina. Còn lại: {1}",
    received_treasure: "Bạn đã nhận được kho báu: {0} từ {1}!",
    damage: "sát thương",
    per_hit: "mỗi lượt",
    chance_to_activate: "Tỷ lệ kích hoạt {0}",
    admin_skill_manager_title: "Quản lý kỹ năng người chơi: ",
    not_done_yet: "Chưa xong",
    coming_soon: "Sắp ra mắt!",
    general_overview_title: "Tổng quan",
    total_skill_point: "Tổng điểm kỹ năng:",
    attack_level: "Cấp độ tấn công:",
    health_max: "Máu tối đa:",
    defense_level: "Cấp độ phòng thủ:",
    money: "Tiền:",
    data_title: "Dữ liệu",
    stamina_current: "Stamina hiện tại:",
    stamina_mechanics_title: "Cơ chế Stamina:",
    stamina_cost_mine_attack: "• Đào/đánh: -3 stamina",
    stamina_cost_run: "• Chạy: -5 stamina/tick",
    stamina_cost_run_jump: "• Chạy và nhảy: -10 stamina/tick",
    stamina_regen_walk: "• Đi bộ: +1 stamina/tick",
    stamina_regen_sneak: "• Lén lút: +2 stamina/tick",
    stamina_regen_idle: "• Đứng yên: +3 stamina/tick",
    setting_title: "Cài đặt",
    click_to_close: "Bấm để đóng",
    health_stamina_bar: "Thanh Máu/Stamina",
    cooldown_notification_on: "Thông báo hồi chiêu: BẬT",
    hide_health_on: "HUD Máu: BẬT",
    hide_health_off: "HUD Máu: TẮT",
    hide_armor_on: "HUD Giáp: BẬT",
    hide_armor_off: "HUD Giáp: TẮT",
    click_to_turn_off: "Bấm để TẮT",
    cooldown_notification_off: "Thông báo hồi chiêu: TẮT",
    click_to_turn_on: "Bấm để BẬT",
    back_to_general_settings: "Trở lại cài đặt chung",
    click_to_back_setting: "Bấm để trở lại cài đặt",
    mode1_title: "Chế độ 1 (Mặc định)",
    mode1_desc: "Hiện tất cả thông tin: Máu/Max HP (%), Stamina.",
    mode2_title: "Chế độ 2",
    mode2_desc: "Hiện Máu/Max HP (%), Stamina (Dòng mới).",
    mode3_title: "Chế độ 3",
    mode3_desc: "Chỉ hiện Máu/Max HP (%).",
    mode4_title: "Chế độ 4",
    mode4_desc: "Chỉ hiện Stamina.",
    mode0_title: "Chế độ 0 (TẮT)",
    mode_set_success:
      "Chế độ hiển thị thanh máu/stamina đã đặt thành Chế độ {0}.",
    leaderboard_title: "Bảng xếp hạng kỹ năng",
    leaderboard_column_player: "Người chơi",
    leaderboard_column_level: "Cấp độ",
    leaderboard_column_total_skill_points: "Tổng điểm kỹ năng",
    full_inventory: "§cTúi đồ của bạn đã đầy",

    // Language specific additions
    language_button: "Ngôn ngữ",
    language_current: "Ngôn ngữ hiện tại: {0}",
    click_to_switch_to: "Bấm để chuyển sang {0}",
    language_switched_to: "Ngôn ngữ đã chuyển sang {0}.",
    english_name: "Tiếng Anh",
    vietnamese_name: "Tiếng Việt",

    // Skill specific messages
    current_level: "Cấp độ hiện tại: ",
    next_level_progress: "Tiến trình cấp độ tiếp theo: ",
    skills_section_title: "§c*** §9Kĩ năng §c***§r",
    stat_point_unspent_gain: "§bNhận 1 điểm chỉ số chưa dùng§r",
    unlocked_skill: "§aĐã mở khóa kỹ năng mới: §r{0}",
    skill_on_cooldown: "§cKỹ năng đang hồi chiêu§r {0}s",
    skills_reset_success: "Đã reset toàn bộ kỹ năng của {0}.",
    skills_reset_cancelled: "Hủy reset kỹ năng cho {0}.",
    skill_not_unlocked: "§cKỹ năng {0} chưa được mở khóa!",

    // Mining
    mining_skill_name: "Khoáng công",
    mining_desc: "Đào khoáng để lên cấp",
    mining_skill1_name: "Gia cố",
    mining_skill1_passive_desc: "Có khả năng ngăn cúp bị mất độ bền khi đào.",
    mining_skill2_name: "Bức tốc",
    mining_skill2_passive_desc:
      "Khi đánh một thực thể bằng cúp, có khả năng kích hoạt hiệu ứng Tốc độ.",
    mining_skill3_name: "Uy vọng thợ mỏ",
    mining_skill3_active_desc:
      "Kích hoạt Đào Nhanh trong {1}s. Hồi chiêu: {0}s.",
    mining_skill3_desc_full: "Kích hoạt hiệu ứng Đào Nhanh.",
    mining_skill3_active: "Uy vọng thợ mỏ đã được kích hoạt!",
    mining_skill3_ended: "Uy vọng thợ mỏ đã kết thúc!",
    xp_from_ore: "Kinh nghiệm nhận được từ quặng",
    back_to_mining_page: "Trở lại trang Khoáng công",
    click_to_back_skill: "Bấm để trở lại trang kỹ năng",

    // Woodcutting
    woodcutting_skill_name: "Tiều phu",
    woodcutting_desc: "Chặt gỗ để lên cấp",
    woodcutting_skill1_name: "Log plus",
    woodcutting_skill1_passive_desc: "Có khả năng được thêm gỗ khi chặt.",
    woodcutting_skill2_name: "Bổ đầu",
    woodcutting_skill2_passive_desc:
      "Khi dùng rìu giết địch, có khả năng rơi đầu của địch.",
    woodcutting_skill3_name: "Tree capitator",
    woodcutting_skill3_active_desc:
      "Phá hủy toàn bộ cây khi chặt một khối gỗ trong {1}s. Hồi chiêu: {0}s.",
    woodcutting_skill3_desc_full: "Phá hủy toàn bộ cây khi chặt một khối gỗ.",
    woodcutting_skill3_active: "Tree Capitator đã được kích hoạt!",
    woodcutting_skill3_ended: "Tree Capitator đã kết thúc!",
    xp_from_wood: "Kinh nghiệm nhận được từ gỗ",
    back_to_woodcutting_page: "Trở lại trang Tiều phu",
    drop_head: "§aBạn đã nhận được §bĐầu của {0}§e trong túi đồ!",
    get_head: "§eBạn đã nhận được §bĐầu của {0}",

    // Attack
    attack_skill_name: "Kiếm pháp",
    attack_desc: "Giết quái vật để lên cấp",
    attack_skill1_name: "Experience plus",
    attack_skill1_passive_desc:
      "Có khả năng được thêm kinh nghiệm khi giết quái vật.",
    attack_skill2_name: "Xuyên giáp",
    attack_skill2_passive_desc:
      "Khi dùng kiếm đánh thực thể, có khả năng gây sát thương xuyên giáp.",
    attack_skill3_name: "Vạn kiếm quy tông",
    attack_skill3_active_desc:
      "Triệu hồi hàng vạn mũi kiếm tấn công kẻ địch xung quanh trong {1}s. Hồi chiêu: {0}s.",
    attack_skill3_desc_full:
      "Triệu hồi hàng vạn mũi kiếm tấn công kẻ địch xung quanh.",
    armor_piercing_active: "Xuyên giáp kích hoạt! Gây thêm {0} sát thương!",
    reaper_scythe_active:
      "Lưỡi hái tử thần kích hoạt! Gây thêm {0} sát thương!",
    experience_plus_active: "Kinh nghiệm cộng thêm kích hoạt!",
    attack_skill3_active: "Vạn Kiếm Quy Tông đã kích hoạt!",
    attack_skill3_ended: "Vạn Kiếm Quy Tông đã kết thúc!",
    xp_from_mob: "Kinh nghiệm nhận được từ quái",
    back_to_sword_page: "Trở lại trang Kiếm pháp",
    crit_active: "Chí mạng! Gây thêm {0} sát thương!",

    // Farming
    farming_skill_name: "Nông phu",
    farming_desc: "Trồng trọt để lên cấp",
    farming_skill1_name: "Crops plus",
    farming_skill1_passive_desc:
      "Có khả năng được thêm nông sản khi thu hoạch.",
    farming_skill2_name: "Lưỡi hái tử thần",
    farming_skill2_passive_desc:
      "Khi dùng cuốc đánh thực thể, có khả năng gây sát thương chí mạng.",
    farming_skill3_name: "Tự động trồng",
    farming_skill3_active_desc:
      "Tự động trồng lại nông sản ngay sau khi thu hoạch trong {1}s. Hồi chiêu: {0}s.",
    farming_skill3_desc_full:
      "Tự động trồng lại nông sản ngay sau khi thu hoạch.",
    farming_skill3_activated: "Tự động trồng đã được kích hoạt!",
    farming_skill3_ended: "Tự động trồng đã kết thúc!",
    xp_from_crops: "Kinh nghiệm nhận được từ nông sản",
    back_to_farming_page: "Trở lại trang Nông phu",

    // Digging
    digging_skill_name: "Đào mộ",
    digging_desc: "Đào đất để lên cấp",
    digging_skill1_name: "Kho báu ẩn dấu",
    digging_skill1_passive_desc: "Có khả năng tìm thấy kho báu khi đào đất.",
    digging_skill2_name: "Lời nguyền của kẻ trộm mộ",
    digging_skill2_passive_desc: "Tạo ra hạt particle khi di chuyển.",
    digging_skill3_name: "Đào cả thiên địa",
    digging_skill3_active_desc:
      "Triệu hồi TNT gây sát thương xung quanh trong {1}s. Hồi chiêu: {0}s.",
    digging_skill3_desc_full: "Triệu hồi TNT gây sát thương xung quanh.",
    digging_skill3_active: "Đào Cả Thiên Địa đã được kích hoạt!",
    digging_skill3_ended: "Đào Cả Thiên Địa đã kết thúc!",
    xp_from_soil: "Kinh nghiệm nhận từ đất",
    back_to_digging_page: "Trở lại trang Đào mộ",

    // Agility
    agility_skill_name: "Hoạt huyết",
    agility_desc: "Di chuyển để lên cấp",
    agility_skill1_name: "Bền bỉ",
    agility_skill1_passive_desc: "Tăng lượng Stamina tối đa.",
    stamina_increase: "Tăng Stamina",
    agility_skill2_name: "Né",
    agility_skill2_passive_desc:
      "Có khả năng tránh sát thương khi bị tấn công.",
    agility_skill3_name: "Tẩu vi thượng sách",
    agility_skill3_active_desc:
      "Khi máu dưới 20% có thể kích hoạt Tốc Độ và Kháng Sát Thương trong {0}s.",
    agility_skill3_active: "Tẩu Vi Thượng Sách đã được kích hoạt!",
    agility_skill3_ended: "Tẩu Vi Thượng Sách đã kết thúc!",
    xp_from_damage_taken: "Kinh nghiệm nhận từ sát thương nhận vào",
    back_to_agility_page: "Trở lại trang Hoạt huyết",

    // Defense
    defense_skill_name: "Cường thân",
    defense_desc: "Nhận sát thương để lên cấp",
    defense_skill1_name: "Heart of the earth",
    defense_skill1_passive_desc: "Tăng máu tối đa.",
    defense_skill2_name: "Hấp thụ",
    defense_skill2_passive_desc:
      "Có khả năng hấp thụ sát thương khi bị tấn công và chuyển hóa thành máu.",
    defense_skill2_absorb_health: "Hấp thụ sát thương! Hồi phục {0}",
    defense_skill3_name: "The shield of the god",
    defense_skill3_active_desc:
      "Bảo vệ bản thân và đẩy lùi kẻ địch xung quanh trong {1}s. Hồi chiêu: {0}s.",
    defense_skill3_desc_full: "Bảo vệ bản thân và đẩy lùi kẻ địch xung quanh.",
    defense_skill3_active: "Lá Chắn Của Thần đã được kích hoạt!",
    defense_skill3_ended: "Lá Chắn Của Thần đã kết thúc!",
    back_to_defense_page: "Trở lại trang Cường thân",

    // Ranged
    ranged_skill_name: "Xạ thủ",
    ranged_desc: "Bắn cung để lên cấp",
    ranged_skill1_name: "Dấu ấn tử vong",
    ranged_skill1_passive_desc:
      "Khi bắn trúng, có {0}% để lại dấu ấn tử vong trên mục tiêu, gây sát thương mỗi giây trong {1}s.",
    ranged_skill1_active:
      "Dấu ấn tử vong kích hoạt! Gây sát thương mỗi giây trong ",
    ranged_skill1_crit_streak: "Dấu ấn tử vong tích lũy! Chuỗi: ",
    ranged_skill2_name: "Lôi tiễn",
    ranged_skill2_passive_desc:
      "Khi bắn trúng, có {0}% triệu hồi thiên lôi oanh tạc tại vị trí mục tiêu và gây sát thương.",
    ranged_skill3_name: "Vạn tiễn xuyên tâm",
    ranged_skill3_active_desc:
      "Khi bắn trúng mục tiêu sẽ triệu hồi hàng vạn mũi tên tấn công kẻ địch. Hồi chiêu: {0}s.",
    ranged_skill3_desc_full:
      "Khi bắn trúng mục tiêu sẽ triệu hồi hàng vạn mũi tên tấn công kẻ địch.",
    ranged_skill3_active: "Vạn Tiễn Xuyên Tâm đã được kích hoạt!",
    ranged_skill3_ended: "Vạn Tiễn Xuyên Tâm đã kết thúc!",
    back_to_ranged_page: "Trở lại trang Xạ thủ",

    // Trading
    trading_skill_name: "Thương nhân",
    trading_desc: "Buôn bán để lên cấp",
    trading_skill1_name: "Mặc cả",
    trading_skill2_name: "Thương lượng",
    trading_skill3_name: "Hợp đồng vĩnh cửu",

    // Fishing
    fishing_skill_name: "Cần thủ",
    fishing_desc: "Câu cá để lên cấp",
    fishing_skill1_name: "Mồi nhử vàng",
    fishing_skill1_passive_desc: "Có khả năng tìm thấy kho báu khi câu cá.",
    fishing_skill2_name: "Lưới cá",
    fishing_skill2_passive_desc: "Có khả năng nhận thêm cá khi câu cá.",
    fishing_skill3_name: "Cá cuồng nộ",
    fishing_skill3_description:
      "Triệu hồi một đàn cá tấn công kẻ địch xung quanh.",
    fishing_skill3_active_desc:
      "Triệu hồi một đàn cá tấn công kẻ địch gần đó trong {1} giây,\ngây {2} sát thương trong bán kính {3}m. Hồi chiêu: {0}s.",
    fishing_golden_lure_activated: "Mồi nhử vàng kích hoạt! Nhận được: {0}",
    fishing_fishing_net_activated: "Lưới cá kích hoạt! Nhận thêm: {0}",
    fishing_skill3_active: "Cá cuồng nộ đã được kích hoạt!",
    fishing_skill3_ended: "Cá cuồng nộ đã kết thúc!",
    fishing_skill3_active_message: "§aBạn đã kích hoạt Cá cuồng nộ!",
    fishing_skill3_ended_message: "§eCá cuồng nộ đã kết thúc!",
    xp_from_fishing: "Kinh nghiệm nhận được từ câu cá",
    back_to_fishing_page: "Trở lại trang Cần thủ",

    // Building Skill 1
    building_skill_name: "Phụ hồ",
    building_desc: "Đặt block để lên cấp",
    building_skill1_name: "Thao Túng Vật Chất",
    building_skill1_passive_desc:
      "Khi đặt block có tỉ lệ không mất block trên tay.",
    // Building Skill 2
    building_skill2_name: "Tiếp Tế Nhanh",
    building_skill2_passive_desc:
      "Khi bạn đặt block và chỉ còn 1 block cùng loại trên tay, \nnếu trong kho đồ còn block cùng loại, hệ thống sẽ tự động lấy một stack block vào tay bạn.",
    quick_resupply_activated: "Tiếp tế nhanh đã kích hoạt!",
    // Building Skill 3
    building_skill3_name: "Thần Kiến Tạo",
    building_skill3_active_desc:
      "Kích hoạt Thần Kiến Tạo! Gây sát thương và đẩy lùi kẻ địch xung quanh, \nđồng thời tạo một cột đá 5x5 cao 3 block dưới chân bạn. \nThời gian hồi chiêu: {0}s\nThời gian hiệu lực: {1}s, Sát thương: {2}, Chiều cao cột: {3}, Kích thước cột: {4}x{4}.",
    building_skill3_active_message: "Thần Kiến Tạo đã được kích hoạt!",
    building_skill3_ended_message: "Thần Kiến Tạo đã kết thúc!",
    xp_from_block_placement: "Kinh nghiệm nhận được từ việc đặt block",
    back_to_building_page: "Trở lại trang Thợ Xây Dựng",

    // Alchemist -> Alchemizing
    alchemizing_skill_name: "Luyện Dược",
    alchemizing_desc: "Pha chế/sử dụng thuốc để lên cấp",
    alchemizing_skill1_name: "Tăng Cấp Thuốc", // Corrected
    alchemizing_skill1_passive_desc:
      "Potion bạn uống có tác dụng ngay lập tức, không delay.",
    alchemizing_skill2_name: "Miễn Nhiễm Độc Tố", // Corrected
    alchemizing_skill2_passive_desc:
      "Miễn nhiễm với Poison, giảm thời gian hiệu ứng Wither và Nausea.",
    alchemizing_skill3_name: "Bùng Nổ Phản Ứng",
    alchemizing_skill3_description:
      "Tạo vùng phản ứng 7x7 trong 5s: hồi máu đồng minh, gây poison/slowness cho địch → kết thúc nổ tung.",
    alchemizing_skill3_active_desc:
      "Tạo vùng phản ứng {0}x{0} trong {1}s: hồi máu đồng minh, gây poison/slowness cho địch. Kết thúc nổ tung gây {3} sát thương. Hồi chiêu: {2}s.",
    alchemizing_skill3_active_message: "§aBạn đã kích hoạt Bùng Nổ Phản Ứng!",
    alchemizing_skill3_ended_message: "§eBùng Nổ Phản Ứng đã kết thúc!",
    xp_from_potion_use: "Kinh nghiệm nhận được từ việc sử dụng thuốc",
    back_to_alchemizing_page: "Trở lại trang Luyện Dược",

    // Diver -> Diving
    diving_skill_name: "Thợ Lặn",
    diving_desc: "Hoạt động dưới nước để lên cấp",
    diving_skill1_name: "Thủy Sinh Thuần Thục",
    diving_skill1_passive_desc:
      "Bơi nhanh hơn, đào block dưới nước như trên cạn.",
    diving_skill2_name: "Cảm Biến Biển Sâu",
    diving_skill2_passive_desc:
      "Phát hiện rương, di tích hoặc mob dưới nước trong bán kính 15 block.",
    diving_skill3_name: "Đại Thủy Pháp",
    diving_skill3_description:
      "Bắn ra luồng nước đẩy mob xa + gây sát thương, bạn được dash theo hướng nhìn.",
    diving_skill3_active_desc:
      "Bắn ra luồng nước đẩy mob xa + gây {1} sát thương, bạn được lướt {2} khối theo hướng nhìn. Hồi chiêu: {0}s.",
    diving_skill3_active_message: "§aBạn đã kích hoạt Đại Thủy Pháp!",
    diving_skill3_ended_message: "§eĐại Thủy Pháp đã kết thúc!",
    xp_from_underwater_activity: "Kinh nghiệm nhận được từ hoạt động dưới nước",
    back_to_diving_page: "Trở lại trang Thợ Lặn",

    // Crafter -> Crafting
    crafting_skill_name: "Chế Tạo", // Corrected
    crafting_desc: "Chế tạo vật phẩm để lên cấp",
    crafting_skill1_name: "Tái Chế Phế Liệu", // Corrected
    crafting_skill1_passive_desc:
      "Sử dụng lệnh /recycle khi cầm vật phẩm đã chế tạo để phân tách nó thành nguyên liệu cơ bản.\nCó thể sử dụng mỗi {0} giây.",
    crafting_skill2_name: "Biến Đổi Vật Liệu", // Corrected
    crafting_skill2_passive_desc:
      "Cho phép bạn chuyển đổi một số loại block nhất định (ví dụ: biến gỗ Sồi thành gỗ Vân sam) bằng cách nhìn vào chúng và tương tác với một cây gậy.",
    crafting_skill3_name: "Lãnh Địa Chế Tạo", // Corrected
    crafting_skill3_description:
      "Trong 15s: Vũ khí chí mạng 100%, tăng sát thương; Công cụ đào siêu nhanh; Giáp kháng knockback + resistance. Kết thúc gây shockwave AoE.",
    crafting_skill3_active_desc:
      "Trong {1}s: Vũ khí chí mạng 100%, tăng sát thương; Công cụ đào siêu nhanh; Giáp kháng knockback + resistance. Kết thúc gây shockwave AoE {2} sát thương. Hồi chiêu: {0}s.",
    crafting_skill3_active_message: "§aBạn đã kích hoạt Lãnh Địa Chế Tạo!",
    crafting_skill3_ended_message: "§eLãnh Địa Chế Tạo đã kết thúc!",
    xp_from_crafting: "Kinh nghiệm nhận được từ việc chế tạo",
    back_to_crafting_page: "Trở lại trang Chế Tạo",

    // Summoner -> Summon
    summon_skill_name: "Triệu Hồi",
    summon_desc: "Triệu hồi pet để lên cấp",
    summon_skill1_name: "Liên Kết Huyết Ấn",
    summon_skill1_passive_desc:
      "Pet sẽ tự bảo vệ bạn, chia sẻ 25% sát thương nhận phải.",
    summon_skill2_name: "Linh Thú Bền Ý Chí",
    summon_skill2_passive_desc:
      "Pet triệu hồi tồn tại lâu hơn, giữ target tốt hơn, khó bị mất mục tiêu.",
    summon_skill3_name: "Triệu Hồi Hộ Vệ Linh",
    summon_skill3_description:
      "Gọi 3 Spirit Wolf tồn tại trong 30s, tự tìm và tấn công địch, phản công khi bạn bị đánh, glow + effect đẹp.",
    summon_skill3_active_desc:
      "Gọi {2} Spirit Wolf tồn tại trong {1}s, tự tìm và tấn công địch. Hồi chiêu: {0}s.",
    summon_skill3_active_message: "§aBạn đã kích hoạt Triệu Hồi Hộ Vệ Linh!",
    summon_skill3_ended_message: "§eTriệu Hồi Hộ Vệ Linh đã kết thúc!",
    xp_from_mob_kill_by_pet: "Kinh nghiệm nhận được từ mob bị pet giết",
    back_to_summon_page: "Trở lại trang Triệu Hồi",

    // Stats System
    your_stats_title: "Chỉ số của bạn",
    strength: "Sức mạnh",
    health: "Máu",
    regen: "Hồi phục",
    luck: "May mắn",
    intelligence: "Trí khôn",
    endurance: "Bền bỉ",
    critical_chance: "Tỷ lệ chí mạng",
    critical_damage: "Sát thương chí mạng",
    speed: "Tốc độ",
    current_stats: "Chỉ số hiện tại",
    unspent_points: "Điểm chưa dùng",
    click_to_add: "Bấm để tăng",
    click_to_reset: "Bấm để đặt lại",
    reset_confirmation_title: "Xác nhận Đặt lại",
    reset_confirmation_body:
      "Bạn có chắc chắn muốn đặt lại tất cả chỉ số? Điều này sẽ tốn {0} tiền.",
    yes_reset: "Có, Đặt lại",
    no: "Không",
    not_enough_money: "Không đủ tiền để đặt lại chỉ số!",
    stats_reset_success: "Tất cả chỉ số đã được đặt lại!",
    stat_increased: "{0} đã tăng lên {1}!",
    no_unspent_points: "Không có điểm chỉ số chưa dùng.",
    back_to_main_menu: "Trở lại menu chính",
    total_damage: "Tổng sát thương",
    armor_reduction: "Giảm sát thương",
    movement_speed: "Tốc độ di chuyển",
    xp_gain_bonus: "Thưởng XP",
    cooldown_reduction: "Giảm hồi chiêu",
    drop_rate_bonus: "Tỷ lệ rơi đồ",
    treasure_find_bonus: "Tỷ lệ tìm kho báu",
    points_returned: "Đã trả lại {0} điểm chỉ số chưa dùng.",
    cooldown_reduction_from_int: "Giảm hồi chiêu từ Trí khôn",

    // New keys for manager UI
    manage_skill_for: "Quản lý kỹ năng cho",
    manage_stats_for: "Quản lý chỉ số cho",
    manage_xp_for: "XP cho",
    current_xp: "XP hiện tại",
    adjust: "Điều chỉnh",
    click_to_adjust_xp: "Bấm để {0}{1} XP",
    click_to_adjust_stat: "Bấm để {0}{1} điểm",
    reset_all_skills: "Đặt lại toàn bộ kỹ năng",
    confirm_reset_skills:
      "Bạn có chắc chắn muốn đặt lại toàn bộ kỹ năng của {0}? Thao tác này không thể hoàn tác.",
  },
  en_US: {
    // English
    // General messages
    failed_to_set_dynamic_property: "Failed to set dynamic property:",
    player_not_valid: "Invalid player or player has left.",
    setup_complete: "Initial setup complete. Enjoy the game!",
    level: "Level",
    money_bonus: "Money Bonus",
    xp_limit_adjusted:
      "Due to Minecraft's character limit, your XP and next XP have been adjusted",
    page: "Page",
    locked: "Locked",
    not_completed: "Not Completed",
    completed: "Completed",
    in_progress: "In Progress",
    requirements: "Requirements",
    progress: "Progress",
    overview: "Overview",
    leaderboard: "Leaderboard",
    how_to_get_xp: "How to get XP",
    click: "Click",
    click_to_view_stats: "Click to view stats",
    click_to_setting: "Click for settings",
    exclusive_skills: "Exclusive Skills",
    previous_page: "Previous Page",
    click_to_back_previous_page: "Click to go back to the previous page",
    next_page: "Next Page",
    click_to_back_next_page: "Click to go to the next page",
    back_to_skill_list: "Back to Skill List",
    click_to_back_main_skill: "Click to go back to the main skill list",
    unlocked: "Unlocked",
    requires_level: "Requires Level",
    to_unlock: "to unlock!",
    description: "Description",
    cooldown: "Cooldown",
    seconds: "seconds",
    stats: "Stats",
    new_skill_unlocked: "You have unlocked a new skill:",
    skill_levelup: "Skill Leveled Up:§r {0}",
    levelup_message: "has increased from level",
    to_level: "to level",
    system_cooldown: "System Cooldown",
    skill_levelup_cooldown:
      "§r{0} §aleveled up! \n§f• §alevel §c{1}§a to level §c{2}§a! \n§f• §9New Cooldown: §r{3}s",
    cooldown_active: "Skill is on cooldown. Please wait",
    debug_stamina_drain: "Debug: Lost {0} stamina. Remaining: {1}",
    received_treasure:
      "You received treasure: §r{0} §7({2} percent) §efrom §r{1}!",
    damage: "damage",
    per_hit: "per hit",
    chance_to_activate: "Chance to activate {0}",
    admin_skill_manager_title: "Player Skill Manager: ",
    not_done_yet: "Not done yet",
    coming_soon: "Coming Soon!",
    general_overview_title: "General Overview",
    total_skill_point: "Total Skill Points",
    attack_level: "Attack Level:",
    health_max: "Max Health:",
    defense_level: "Defense Level:",
    money: "Money:",
    data_title: "Data",
    stamina_current: "Current Stamina:",
    stamina_mechanics_title: "Stamina Mechanics:",
    stamina_cost_mine_attack: "• Mining/Attacking: -3 stamina",
    stamina_cost_run: "• Running: -5 stamina/tick",
    stamina_cost_run_jump: "• Running and Jumping: -10 stamina/tick",
    stamina_regen_walk: "• Walking: +1 stamina/tick",
    stamina_regen_sneak: "• Sneaking: +2 stamina/tick",
    stamina_regen_idle: "• Standing Still: +3 stamina/tick",
    setting_title: "Settings",
    click_to_close: "Click to close",
    health_stamina_bar: "Health/Stamina Bar",
    cooldown_notification_on: "Cooldown Notification: §aON",
    hide_health_on: "Health Hud: §aON",
    hide_health_off: "Health Hud: §cOFF",
    hide_armor_on: "Armor Hud: §aON",
    hide_armor_off: "Armor Hud: §cOFF",
    click_to_turn_off: "Click to turn §cOFF",
    cooldown_notification_off: "Cooldown Notification: §cOFF",
    click_to_turn_on: "Click to turn §aON",
    back_to_general_settings: "Back to General Settings",
    click_to_back_setting: "Click to back to settings",
    mode1_title: "Mode 1 (Default)",
    mode1_desc: "Display all info: Health/Max HP (%), Stamina.",
    mode2_title: "Mode 2",
    mode2_desc: "Display Health/Max HP (%), Stamina (New Line).",
    mode3_title: "Mode 3",
    mode3_desc: "Display Health/Max HP (%) only.",
    mode4_title: "Mode 4",
    mode4_desc: "Display Stamina only.",
    mode0_title: "Mode 0 (OFF)",
    mode_set_success: "Health/Stamina display mode set to Mode {0}.",
    leaderboard_title: "Skill Leaderboard",
    leaderboard_column_player: "Player",
    leaderboard_column_level: "Level",
    leaderboard_column_total_skill_points: "Total Skill Points",
    full_inventory: "§cYour inventory is full",

    // Language specific additions
    language_button: "Language",
    language_current: "Current Language: {0}",
    click_to_switch_to: "Click to switch to {0}",
    language_switched_to: "Language switched to {0}.",
    english_name: "English",
    vietnamese_name: "Vietnamese",

    // Skill specific messages
    current_level: "Current Level: ",
    next_level_progress: "Next Level Progress: ",
    skills_section_title: "§c*** §9Skills §c***§r",
    stat_point_unspent_gain: "§bGain an unspent stat point§r",
    unlocked_skill: "§aUnlocked new skill: §r{0}",
    skill_on_cooldown: "§cSkill On Cooldown§r {0}s",
    skills_reset_success: "All skills for {0} have been reset.",
    skills_reset_cancelled: "Cancelled skill reset for {0}.",
    skill_not_unlocked: "§cSkill {0} is not unlocked!",

    // Mining
    mining_skill_name: "Mining",
    mining_desc: "Mine minerals to level up",
    mining_skill1_name: "Reinforcement",
    mining_skill1_passive_desc:
      "Has a chance to prevent pickaxe durability loss when mining.",
    mining_skill2_name: "Burst Speed",
    mining_skill2_passive_desc:
      "When hitting an entity with a pickaxe, has a chance to activate Speed effect.",
    mining_skill3_name: "Miner's Ambition",
    mining_skill3_active_desc: "Activates Haste for {1}s. Cooldown: {0}s.",
    mining_skill3_desc_full: "Activates Haste effect.",
    mining_skill3_active: "Miner's Ambition has been activated!",
    mining_skill3_ended: "Miner's Ambition has ended!",
    xp_from_ore: "XP gained from ores",
    back_to_mining_page: "Back to Mining Page",
    click_to_back_skill: "Click to go back to skill page",

    // Woodcutting
    woodcutting_skill_name: "Woodcutting",
    woodcutting_desc: "Chop wood to level up",
    woodcutting_skill1_name: "Log Plus",
    woodcutting_skill1_passive_desc:
      "Has a chance to gain extra wood when chopping.",
    woodcutting_skill2_name: "Head Splitter",
    woodcutting_skill2_passive_desc:
      "When killing an enemy with an axe, has a chance for the enemy to drop their head.",
    woodcutting_skill3_name: "Tree Capitator",
    woodcutting_skill3_active_desc:
      "Destroys the entire tree when chopping one log for {1}s. Cooldown: {0}s.",
    woodcutting_skill3_desc_full:
      "Destroys the entire tree when chopping one log.",
    woodcutting_skill3_active: "Tree Capitator has been activated!",
    woodcutting_skill3_ended: "Tree Capitator has ended!",
    xp_from_wood: "XP gained from wood",
    back_to_woodcutting_page: "Back to Woodcutting Page",
    drop_head: "§aYou have received a §b{0}'s Skull§e in your inventory!",
    get_head: "§eYou have gotten the §b{0}'s skull",

    // Attack
    attack_skill_name: "Swordplay",
    attack_desc: "Kill monsters to level up",
    attack_skill1_name: "Experience Plus",
    attack_skill1_passive_desc:
      "Has a chance to gain extra experience when killing monsters.",
    attack_skill2_name: "Armor Pierce",
    attack_skill2_passive_desc:
      "When hitting an entity with a sword, has a chance to deal armor-piercing damage.",
    attack_skill3_name: "Myriad Swords Return",
    attack_skill3_active_desc:
      "Summons myriad swords to attack surrounding enemies for {1}s. Cooldown: {0}s.",
    attack_skill3_desc_full:
      "Summons myriad swords to attack surrounding enemies.",
    armor_piercing_active:
      "Armor Pierce activated! Deals {0} additional damage!",
    reaper_scythe_active:
      "Reaper's Scythe activated! Deals {0} additional damage!",
    experience_plus_active: "Experience Plus activated!",
    attack_skill3_active: "Myriad Swords Return has activated!",
    attack_skill3_ended: "Myriad Swords Return has ended!",
    xp_from_mob: "XP gained from mobs",
    back_to_sword_page: "Back to Swordplay Page",
    crit_active: "Critical hit! Deal an additional {0} damage!",

    // Farming
    farming_skill_name: "Farming",
    farming_desc: "Farm crops to level up",
    farming_skill1_name: "Crops Plus",
    farming_skill1_passive_desc:
      "Has a chance to gain extra crops when harvesting.",
    farming_skill2_name: "Reaper's Scythe",
    farming_skill2_passive_desc:
      "When hitting an entity with a hoe, has a chance to deal critical damage.",
    farming_skill3_name: "Auto-Plant",
    farming_skill3_active_desc:
      "Automatically replants crops immediately after harvesting for {1}s. Cooldown: {0}s.",
    farming_skill3_desc_full:
      "Automatically replants crops immediately after harvesting.",
    farming_skill3_activated: "Auto-Plant has been activated!",
    farming_skill3_ended: "Auto-Plant has ended!",
    xp_from_crops: "XP gained from crops",
    back_to_farming_page: "Back to Farming Page",

    // Digging
    digging_skill_name: "Digging",
    digging_desc: "Dig dirt to level up",
    digging_skill1_name: "Hidden Treasure",
    digging_skill1_passive_desc: "Has a chance to find treasure when digging.",
    digging_skill2_name: "Tomb Raider's Curse",
    digging_skill2_passive_desc: "Generates particles when moving.",
    digging_skill3_name: "Dig the Earth",
    digging_skill3_active_desc:
      "Summons TNT to damage surrounding enemies for {1}s. Cooldown: {0}s.",
    digging_skill3_desc_full: "Summons TNT to damage surrounding enemies.",
    digging_skill3_active: "Dig the Earth has been activated!",
    digging_skill3_ended: "Dig the Earth has ended!",
    xp_from_soil: "XP gained from soil",
    back_to_digging_page: "Back to Digging Page",

    // Agility
    agility_skill_name: "Agility",
    agility_desc: "Move to level up",
    agility_skill1_name: "Endurance",
    agility_skill1_passive_desc: "Increases maximum Stamina.",
    stamina_increase: "Stamina Increase",
    agility_skill2_name: "Dodge",
    agility_skill2_passive_desc: "Has a chance to avoid damage when attacked.",
    agility_skill3_name: "Best Retreat",
    agility_skill3_active_desc:
      "When health is below 20%, can activate Speed and Damage Resistance for {0}s.",
    agility_skill3_active: "Best Retreat has been activated!",
    agility_skill3_ended: "Best Retreat has ended!",
    xp_from_damage_taken: "XP gained from damage taken",
    back_to_agility_page: "Back to Agility Page",

    // Defense
    defense_skill_name: "Defense",
    defense_desc: "Take damage to level up",
    defense_skill1_name: "Heart of the Earth",
    defense_skill1_passive_desc: "Increases maximum health.",
    defense_skill2_name: "Absorb",
    defense_skill2_passive_desc:
      "Has a chance to absorb damage when attacked and convert it into health.",
    defense_skill2_absorb_health: "Damage absorbed! Healed {0}",
    defense_skill3_name: "The Shield of the God",
    defense_skill3_active_desc:
      "Protects yourself and repels surrounding enemies for {1}s. Cooldown: {0}s.",
    defense_skill3_desc_full:
      "Protects yourself and repels surrounding enemies.",
    defense_skill3_active: "God's Shield has been activated!",
    defense_skill3_ended: "God's Shield has ended!",
    back_to_defense_page: "Back to Defense Page",

    // Ranged
    ranged_skill_name: "Archery",
    ranged_desc: "Shoot bows to level up",
    ranged_skill1_name: "Mark of Death",
    ranged_skill1_passive_desc:
      "When hitting, has a {0}% chance to leave a mark of death on the target,\ndealing damage per second for {1}s.",
    ranged_skill1_active:
      "Mark of Death activated! Deals damage per second for ",
    ranged_skill1_crit_streak: "Mark of Death stacked! Streak: ",
    ranged_skill2_name: "Thunder Arrow",
    ranged_skill2_passive_desc:
      "When hitting, has a {0}% chance to summon lightning at the target's location and deal damage.",
    ranged_skill3_name: "Thousand Arrows Pierce Heart",
    ranged_skill3_active_desc:
      "When hitting a target, summons myriad arrows to attack enemies. Cooldown: {0}s.",
    ranged_skill3_desc_full:
      "When hitting a target, summons myriad arrows to attack enemies.",
    ranged_skill3_active: "Thousand Arrows Pierce Heart has been activated!",
    ranged_skill3_ended: "Thousand Arrows Pierce Heart has ended!",
    back_to_ranged_page: "Back to Archery Page",

    // Trading
    trading_skill_name: "Merchant",
    trading_desc: "Trade to level up",
    trading_skill1_name: "Bargain",
    trading_skill2_name: "Negotiate",
    trading_skill3_name: "Eternal Contract",

    // Fishing
    fishing_skill_name: "Fisherman",
    fishing_desc: "Fish to level up",
    fishing_skill1_name: "Golden Lure",
    fishing_skill1_passive_desc: "Has a chance to find treasure when fishing.",
    fishing_skill2_name: "Fishing Net",
    fishing_skill2_passive_desc:
      "Has a chance to gain extra fish when fishing.",
    fishing_skill3_name: "Fish Flurry",
    fishing_skill3_description:
      "Summons a flurry of fish to attack nearby enemies.",
    fishing_skill3_active_desc:
      "Summon a flurry of fish to attack \nnearby enemies for {1} seconds, dealing {2} damage \nwithin a {3}m radius. Cooldown: {0}s.",
    fishing_golden_lure_activated: "Golden Lure activated! Received: {0}",
    fishing_fishing_net_activated: "Fishing Net activated! Received extra: {0}",
    fishing_skill3_active: "Fish Flurry has been activated!",
    fishing_skill3_ended: "Fish Flurry has ended!",
    fishing_skill3_active_message: "§aYou activate Fish Flurry!",
    fishing_skill3_ended_message: "§eFish Flurry has ended!",
    xp_from_fishing: "XP gained from fishing",
    back_to_fishing_page: "Back to Fisherman Page",

    // Builder -> Building
    building_skill_name: "Building",
    building_desc: "Place block to level up",
    building_skill1_name: "Material Manipulation",
    building_skill1_passive_desc:
      "When placing a block, there is a chance the block will not be consumed from your hand.",
    // Building Skill 2
    building_skill2_name: "Quick Resupply",
    building_skill2_passive_desc:
      "When you place a block and only have 1 of that block type left in your hand, \nif you have more of the same block in your inventory, the system will automatically transfer \na stack of that block to your hand.",
    quick_resupply_activated: "Quick Resupply activated!",
    building_skill3_name: "Architect's Fury",
    building_skill3_description:
      "Deals knockback + AoE damage to nearby mobs and erects a 3x3, \n3-story stone column under your feet.",
    building_skill3_active_desc:
      "Deals knockback + {2} AoE damage to nearby mobs and erects a {4}x{4}, \n{3}-story stone column under your feet. Cooldown: {0}s. Duration: {1}s.",
    building_skill3_active_message: "§aYou activated Architect's Fury!",
    building_skill3_ended_message: "§eArchitect's Fury has ended!",
    xp_from_block_placement: "XP from block placement",
    back_to_building_page: "Back to Building Page",

    // Alchemist -> Alchemizing
    alchemizing_skill_name: "Alchemizing",
    alchemizing_desc: "Brew/use potions to level up",
    alchemizing_skill1_name: "Potion Level Up",
    alchemizing_skill1_passive_desc: "Have {0}% increase effect level",
    alchemizing_skill2_name: "Poison Immunity",
    alchemizing_skill2_passive_desc:
      "Immune to Poison, reduces Wither and Nausea effect duration.",
    alchemizing_skill3_name: "Reaction Burst",

    alchemizing_skill3_active_desc:
      "Creates a {0}x{0} reaction zone for {1}s: heals allies, poisons/slows enemies. \nEnds with an explosion dealing {3} damage. Cooldown: {2}s.",
    alchemizing_skill3_active_message: "§aYou activated Reaction Burst!",
    alchemizing_skill3_ended_message: "§eReaction Burst has ended!",
    xp_from_potion_use: "XP from potion use",
    back_to_alchemizing_page: "Back to Alchemizing Page",

    // Diver -> Diving
    diving_skill_name: "Diving",
    diving_desc: "Perform underwater activities to level up",
    diving_skill1_name: "Aquatic Mastery",
    diving_skill1_passive_desc:
      "Swim faster, mine blocks underwater as on land.",
    diving_skill2_name: "Deep Sea Sonar",
    diving_skill2_passive_desc:
      "Detects chests, ruins, or mobs underwater within a 15 block radius.",
    diving_skill3_name: "Hydro Blast",
    diving_skill3_description:
      "Fires a stream of water pushing mobs away + dealing damage, you dash in your nhìn direction.",
    diving_skill3_active_desc:
      "Fires a stream of water pushing mobs away + dealing {1} damage, \nyou dash {2} blocks in your looking direction. Cooldown: {0}s.",
    diving_skill3_active_message: "§aYou activated Hydro Blast!",
    diving_skill3_ended_message: "§eHydro Blast has ended!",
    xp_from_underwater_activity: "XP from underwater activities",
    back_to_diving_page: "Back to Diving Page",

    // Crafter -> Crafting
    crafting_skill_name: "Crafting",
    crafting_desc: "Craft items to level up",
    crafting_skill1_name: "Scrap Recycler",
    crafting_skill1_passive_desc:
      "Use the /recycle command while holding a crafted item to \nbreak it down into base materials.\nUsable once every {0} seconds.",

    crafting_skill2_name: "Material Transmute",
    crafting_skill2_passive_desc:
      "Allows you to transmute certain blocks (like turning Oak Wood into Spruce) \nby looking at them and interacting with a stick.",

    crafting_skill3_name: "Crafting Domain",

    crafting_skill3_active_desc:
      "Summons a portal pulling all within 3 blocks into the \nCrafting Domain - a spherical space enclosed by crafting tables,\nwith a black hole at the top. Enemies are trapped for {1}s, taking {2} damage per second. \nTouch the black hole to exit. Cooldown: {0}s.",

    crafting_skill3_active_message: "§6You opened the §lCrafting Domain§r§6!",
    crafting_skill3_ended_message:
      "§eThe Crafting Domain collapses and fades away.",

    xp_from_crafting: "XP from crafting",
    back_to_crafting_page: "Back to Crafting Page",

    // Summoner -> Summon
    summon_skill_name: "Summon",
    summon_desc: "Summon pets to level up",
    summon_skill1_name: "Blood Pact",
    summon_skill1_passive_desc:
      "Pets will protect you, sharing 25% of damage taken.",
    summon_skill2_name: "Resilient Spirits",
    summon_skill2_passive_desc:
      "Summoned pets last longer, hold target better, harder to lose target.",
    summon_skill3_name: "Summon Spirit Guardian",
    summon_skill3_description:
      "Summons 3 Spirit Wolves for 30s, they auto-target and attack enemies, counter-attack when you are hit, glow + beautiful effects.",
    summon_skill3_active_desc:
      "Summons {2} Spirit Wolves for {1}s, they auto-target and attack enemies. Cooldown: {0}s.",
    summon_skill3_active_message: "§aYou activated Summon Spirit Guardian!",
    summon_skill3_ended_message: "§eSummon Spirit Guardian has ended!",
    xp_from_mob_kill_by_pet: "XP gained from mobs killed by pets",
    back_to_summon_page: "Back to Summon Page",

    // Stats System
    your_stats_title: "Your Stats",
    strength: "Strength",
    health: "Health",
    regen: "Regen",
    luck: "Luck",
    intelligence: "Intelligence",
    endurance: "Endurance",
    critical_chance: "Critical Chance",
    critical_damage: "Critical Damage",
    speed: "Speed",
    current_stats: "Current Stats",
    unspent_points: "Unspent Points",
    click_to_add: "Click to add",
    click_to_reset: "Click to reset",
    reset_confirmation_title: "Reset Confirmation",
    reset_confirmation_body:
      "Are you sure you want to reset all stats? This will cost {0} money.",
    yes_reset: "Yes, Reset",
    no: "No",
    not_enough_money: "Not enough money to reset stats!",
    stats_reset_success: "All stats have been reset!",
    stat_increased: "{0} increased to {1}!",
    no_unspent_points: "No unspent stat points.",
    back_to_main_menu: "Back to Main Menu",
    total_damage: "Total Damage",
    armor_reduction: "Damage Reduction",
    movement_speed: "Movement Speed",
    xp_gain_bonus: "XP Gain Bonus",
    cooldown_reduction: "Cooldown Reduction",
    drop_rate_bonus: "Drop Rate Bonus",
    treasure_find_bonus: "Treasure Find Bonus",
    points_returned: "Returned {0} unspent stat points.",
    cooldown_reduction_from_int: "Cooldown Reduction from Intelligence",

    // New keys for manager UI
    manage_skill_for: "Manage Skills for",
    manage_stats_for: "Manage Stats for",
    manage_xp_for: "XP for",
    current_xp: "Current XP",
    adjust: "Adjust",
    click_to_adjust_xp: "Click to {0}{1} XP",
    click_to_adjust_stat: "Click to {0}{1} points",
    reset_all_skills: "Reset All Skills",
    confirm_reset_skills:
      "Are you sure you want to reset all skills for {0}? This action cannot be undone.",
  },
};

/**
 * Lấy ngôn ngữ ưu tiên của người chơi.
 * Hiện tại mặc định là 'vi_VN'. Có thể mở rộng để lấy từ cài đặt của người chơi.
 * @param {import("@minecraft/server").Player} player Người chơi
 * @returns {string} Mã ngôn ngữ (ví dụ: 'vi_VN', 'en_US').
 */
export function getPlayerLocale(player) {
  // Read from dynamic property, default to "en_US" if not found
  let playerLocale;
  try {
    playerLocale = player.getDynamicProperty("skill:playerLocale");
  } catch (e) {}
  return playerLocale || "en_US";
}

/**
 * Lấy bản dịch cho một khóa văn bản.
 * @param {string} key Khóa văn bản cần dịch.
 * @param {string} locale Mã ngôn ngữ (ví dụ: 'vi_VN').
 * @param {...any} args Các đối số để điền vào chuỗi dịch (nếu có placeholder).
 * @returns {string} Chuỗi văn bản đã dịch hoặc khóa nếu không tìm thấy bản dịch.
 */
export function getTranslatedText(key, locale = "en_US", ...args) {
  let text = translations[locale]?.[key] || translations["en_US"]?.[key] || key; // Ưu tiên locale, sau đó là en_US, cuối cùng là key

  // Thay thế các placeholder {0}, {1}, ... bằng các đối số truyền vào
  if (args.length > 0) {
    text = text.replace(/{(\d+)}/g, (match, number) => {
      return typeof args[number] !== "undefined" ? args[number] : match;
    });
  }
  return text;
}
