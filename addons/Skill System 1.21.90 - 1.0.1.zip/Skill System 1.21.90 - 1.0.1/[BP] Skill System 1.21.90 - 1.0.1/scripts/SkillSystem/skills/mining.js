// skills/mining.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { m, pickaxe } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "mining";
const config = skillConfig[SKILL_ID];

const miningSkill3Cooldown = new CooldownManager("miningSkill3");

export async function minerLevelUp(player) {
  handleSkillLevelUp(player, config);
}

export async function minerPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpOres, miningSkills);
}

export async function miningSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "mining_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((10 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "mining_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((20 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0; // Use 0 if not defined

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );

      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      ); // Ensure minimum 1 second in UI
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "mining_skill3_active_desc",
        locale,
        finalCooldownSeconds,
        finalDurationSeconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(totalIntelligenceReductionPercentage * 100)}%`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    minerPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Mining (Khai thác).
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpOres(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_ore", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = m.length; // 'm' is the array for ores
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const oreConfig = m[i];
    // Standardized XP calculation: base_ore_xp * (1 + currentSkillLevel * 0.1)
    const baseOreXp = oreConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseOreXp + baseOreXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${oreConfig.blockID}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${oreConfig.blockID}`],
      `${oreConfig.blockID}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpOres(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpOres(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

export function activateMiningSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  const remainingCooldown = miningSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  player.sendMessage(`§a${getTranslatedText("mining_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  player.addEffect("haste", finalDurationSeconds * 20, {
    amplifier: 225,
    showParticles: false,
  });
  player.addEffect("night_vision", finalDurationSeconds * 20, {
    amplifier: 0,
    showParticles: false,
  });

  miningSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  system.runTimeout(() => {
    player.sendMessage(`§e${getTranslatedText("mining_skill3_ended", locale)}`);
  }, finalDurationSeconds * 20);
}

world.afterEvents.playerBreakBlock.subscribe(async (eventData) => {
  const player = eventData.player;
  const block = eventData.block;
  const brokenBlockTypeId = eventData.brokenBlockPermutation.type.id;
  const item = player
    .getComponent("minecraft:inventory")
    .container.getItem(player.selectedSlotIndex);

  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0 || !item) return;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  if (!pickaxe.includes(item.typeId)) {
    return;
  }

  const oreConfig = m.find((o) => o.blockID === brokenBlockTypeId);
  if (oreConfig) {
    const currentMiningLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
    // Standardized XP calculation: base_ore_xp * (1 + currentSkillLevel * 0.1)
    let xpGain = oreConfig.xp * (1 + currentMiningLevel * 0.1);
    xpGain += xpGain * xpBonusFromInt;

    setPlayerProperty(
      player,
      `skill:xpMining`,
      getPlayerProperty(player, `skill:xpMining`) + xpGain
    );
    minerLevelUp(player);

    const skill1Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
    if (
      skill1Level > 0 &&
      Math.random() * 100 < ((10 + skill1Level) / 100) * 100
    ) {
      if (item.hasComponent("minecraft:durability")) {
        const durabilityComponent = item.getComponent("minecraft:durability");
        if (
          durabilityComponent.maxDurability - durabilityComponent.damage > 0 &&
          durabilityComponent.damage > 0
        ) {
          durabilityComponent.damage -= 1;
          player
            .getComponent("minecraft:inventory")
            .container.setItem(player.selectedSlotIndex, item);
        }
      }
    }
  }
});

world.afterEvents.entityHitEntity.subscribe((eventData) => {
  const attacker = eventData.damagingEntity;
  const victim = eventData.hitEntity;

  if (attacker && attacker instanceof Player) {
    const item = attacker
      .getComponent("minecraft:inventory")
      .container.getItem(attacker.selectedSlotIndex);
    if (!item || !pickaxe.includes(item.typeId)) return;

    const miningSkill2Level = getPlayerProperty(
      attacker,
      `skill:${SKILL_ID}Skill2`
    );
    const luckLevel = getPlayerStat(attacker, "luck");
    const chanceBonus = luckLevel * STATS_CONFIG.luck.dropChanceMultiplier;

    if (
      miningSkill2Level > 0 &&
      Math.random() * 100 < ((20 + miningSkill2Level) / 100) * 100 + chanceBonus
    ) {
      attacker.runCommand(`effect @s speed 10 4 true`);
    }
  }
});
