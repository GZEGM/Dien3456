// skills/summon.js
import {
  world,
  system,
  Player,
  EntityTypes,
  EffectTypes,
} from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "summon"; // Đã đổi tên thành "summon"
const config = skillConfig[SKILL_ID];

const summonSkill3Cooldown = new CooldownManager("summonSkill3"); // Đã đổi tên
const FEED_COOLDOWN_ID = "summonFeedCooldown";
const feedCooldownManager = new CooldownManager(FEED_COOLDOWN_ID);

// Map để lưu trữ các Spirit Wolf được triệu hồi bởi người chơi
const summonedWolves = new Map(); // Key: playerId, Value: Set<wolfEntityId>

// Bản đồ để lưu trữ mục tiêu raycast tạm thời cho mỗi người chơi
const playerPotentialFeedTarget = new Map(); // Key: playerId, Value: { entityId: string, itemTypeId: string }

// Helper for basic vector operations (since Vector3 is not directly importable)
function vecAdd(v1, v2) {
  return { x: v1.x + v2.x, y: v1.y + v2.y, z: v1.z + v2.z };
}
function vecSub(v1, v2) {
  return { x: v1.x - v2.x, y: v1.y - v2.y, z: v1.z - v2.z };
}
function vecMulScalar(v, s) {
  return { x: v.x * s, y: v.y * s, z: v.z * s };
}
function vecDot(v1, v2) {
  return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}
function vecLengthSq(v) {
  return v.x * v.x + v.y * v.y + v.z * v.z;
}
function vecLength(v) {
  return Math.sqrt(vecLengthSq(v));
}
function vecNormalize(v) {
  const len = vecLength(v);
  return len === 0
    ? { x: 0, y: 0, z: 0 }
    : { x: v.x / len, y: v.y / len, z: v.z / len };
}
function vecDistance(v1, v2) {
  return vecLength(vecSub(v1, v2));
}

/**
 * Thực hiện raycast thủ công từ vị trí mắt của người chơi để tìm thực thể.
 * @param {import("@minecraft/server").Player} player
 * @param {number} maxDistance
 * @param {number} stepSize - Kích thước bước cho raycast (nhỏ hơn để chính xác hơn)
 * @returns {import("@minecraft/server").Entity | null}
 */
function raycast(player, maxDistance = 5, stepSize = 0.1) {
  const startLocation = player.getEyeLocation();
  const direction = player.getViewDirection();
  const normalizedDirection = vecNormalize(direction);

  let closestHitEntity = null;
  let minDistance = Infinity;

  // Iterate along the ray
  for (let i = 0; i <= maxDistance; i += stepSize) {
    const currentRayPoint = vecAdd(
      startLocation,
      vecMulScalar(normalizedDirection, i)
    );

    // Query entities around the current point on the ray
    const nearbyEntities = player.dimension.getEntities({
      location: currentRayPoint,
      maxDistance: stepSize * 2, // Search in a small sphere around the current point
      excludeTypes: ["minecraft:player"],
    });

    for (const entity of nearbyEntities) {
      if (!entity.isValid || entity.id === player.id) continue;

      const entityCenter = entity.location; // Assuming location is good enough as center
      const distanceToEntity = vecDistance(currentRayPoint, entityCenter);

      // Basic check if the entity is actually "on the ray" and not just nearby
      // This threshold (e.g., 1.0) might need tuning based on entity sizes.
      if (distanceToEntity <= 1.0) {
        // If the ray point is close to the entity
        const actualDistanceToPlayer = vecDistance(startLocation, entityCenter);
        if (actualDistanceToPlayer < minDistance) {
          closestHitEntity = entity;
          minDistance = actualDistanceToPlayer;
        }
      }
    }
  }
  return closestHitEntity;
}

/**
 * Hàm lên cấp cho kỹ năng Summon.
 * @param {import("@minecraft/server").Player} player
 */
export async function summonLevelUp(player) {
  // Đã đổi tên hàm
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Summon.
 * @param {import("@minecraft/server").Player} player
 */
export async function summonPage(player) {
  // Đã đổi tên hàm
  await createSkillDetailsPage(player, SKILL_ID, xpPetKills, summonSkills); // Đã đổi tên hàm
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Summon.
 * @param {import("@minecraft/server").Player} player
 */
export async function summonSkills(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "summon_skill1_passive_desc", // Đã đổi tên key
        locale
      )}`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "summon_skill2_passive_desc", // Đã đổi tên key
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const numWolves = skill3Config.numWolves;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * skill3Config.durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "summon_skill3_active_desc", // Đã đổi tên key
        locale,
        finalCooldownSeconds,
        finalDurationSeconds,
        numWolves
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(":", "")}: ${
        finalCooldownTicks / 20
      }s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(
        totalIntelligenceReductionPercentage * 100
      )}%\n§7Summoned Wolves: ${numWolves}`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    summonPage, // Đã đổi tên hàm
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Summon.
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpPetKills(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_mob_kill_by_pet", locale)} (Page ${
      page + 1
    })`
  );

  // TODO: Định nghĩa danh sách các mob và XP nhận được khi pet giết
  const mobXpSources = [
    { id: "minecraft:zombie", xp: 1.0, display: "Zombie" },
    { id: "minecraft:skeleton", xp: 1.2, display: "Skeleton" },
    { id: "minecraft:creeper", xp: 1.5, display: "Creeper" },
    { id: "minecraft:spider", xp: 0.8, display: "Spider" },
    { id: "minecraft:enderman", xp: 3.0, display: "Enderman" },
  ];

  const ITEMS_PER_PAGE = 45;
  const totalItems = mobXpSources.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex;
    const mobConfig = mobXpSources[i];
    const baseMobXp = mobConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseMobXp + baseMobXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm,
      `${mobConfig.display}`,
      [
        `\n§3${finalXp.toFixed(1)}§a ✦§r/${mobConfig.id.replace(
          "minecraft:",
          ""
        )}`,
      ],
      `textures/items/${mobConfig.id.replace("minecraft:", "")}_spawn_egg`, // Icon placeholder
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    if (page > 0) {
      Form.button(
        45,
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow"
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52,
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow"
      );
    }
  }

  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier"
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45:
        if (page > 0) {
          xpPetKills(player, page - 1);
        }
        break;
      case 52:
        if (page < totalPages - 1) {
          xpPetKills(player, page + 1);
        }
        break;
      case 53:
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        break;
    }
  }
}

// /**
//  * Kích hoạt kỹ năng Triệu Hồi Hộ Vệ Linh (Skill 3 của Summon).
//  * @param {import("@minecraft/server").Player} player
//  */
// export function activateSummonSkill3(player) {
//   // Đã đổi tên hàm
//   const locale = getPlayerLocale(player);
//   const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

//   if (skill3Level === 0) {
//     player.sendMessage(
//       `§c${getTranslatedText(
//         "skill_not_unlocked",
//         locale,
//         getTranslatedText(config.skillLevels.skill3.nameKey, locale)
//       )}`
//     );
//     return;
//   }

//   const skill3Config = config.skillLevels.skill3;
//   const baseCooldownTicks = skill3Config.baseCooldown * 20;
//   const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
//   const baseDurationSeconds = skill3Config.baseDurationSeconds;
//   const numWolves = skill3Config.numWolves;
//   const wolfBaseDamage = skill3Config.wolfBaseDamage;
//   const wolfDamageIncreasePerLevel = skill3Config.wolfDamageIncreasePerLevel;
//   const wolfHealthBonus = skill3Config.wolfHealthBonus;
//   const wolfTargetRange = skill3Config.wolfTargetRange;

//   const intelligenceLevel = getPlayerStat(player, "intelligence");
//   const cooldownPercentageReductionPerIntelligenceLevel =
//     STATS_CONFIG.intelligence.cooldownReduction || 0;

//   const cooldownAfterSkillLevelTicks = Math.max(
//     20,
//     baseCooldownTicks - skill3Level * cooldownReductionPerLevel
//   );

//   const totalIntelligenceReductionPercentage = Math.min(
//     0.95,
//     intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
//   );

//   const finalCooldownTicks = Math.floor(
//     cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
//   );

//   const finalDurationSeconds =
//     baseDurationSeconds + skill3Level * skill3Config.durationIncreasePerLevel;

//   const remainingCooldown = summonSkill3Cooldown.getRemainingCooldown(player); // Đã đổi tên
//   let cooldownNotification = getPlayerProperty(
//     player,
//     "skill:cooldownNotification"
//   );
//   if (remainingCooldown > 0) {
//     if (player.isSneaking && cooldownNotification) {
//       player.sendMessage(
//         `§e${getTranslatedText(
//           "skill_on_cooldown",
//           locale,
//           Math.ceil(remainingCooldown / 20)
//         )}`
//       );
//     }
//     return;
//   }

//   player.sendMessage(
//     `§a${getTranslatedText("summon_skill3_active_message", locale)}`
//   ); // Đã đổi tên key
//   player.playSound("mob.wolf.howl", player.location); // Âm thanh kích hoạt

//   summonSkill3Cooldown.setCooldown(player, finalCooldownTicks); // Đã đổi tên

//   system.run(() => {
//     const spawnedWolves = new Set();
//     if (!summonedWolves.has(player.id)) {
//       summonedWolves.set(player.id, new Set());
//     }

//     for (let i = 0; i < numWolves; i++) {
//       const wolf = player.dimension.spawnEntity(
//         EntityTypes.get("minecraft:wolf"),
//         player.location
//       );
//       if (wolf) {
//         wolf.addTag(`summon_wolf_${player.id}`); // Đã đổi tên tag
//         wolf.addTag("is_summoned_pet"); // Tag chung cho pet
//         wolf.setDynamicProperty("summoner_owner_id", player.id); // Vẫn giữ "summoner_owner_id" cho dynamic property

//         // wolf.addEffect("strength", finalDurationSeconds * 20, {
//         //   amplifier: 5,
//         //   showParticles: false,
//         // }); // Tăng sát thương
//         // wolf.addEffect("health_boost", finalDurationSeconds * 20, {
//         //   amplifier: Math.floor(wolfHealthBonus / 2) - 1,
//         //   showParticles: false,
//         // }); // Tăng máu (Health Boost amplifier là số tim, mỗi tim 2 máu)

//         // Đặt wolf thành tame và ngồi để nó không chạy lung tung ngay lập tức
//         wolf.triggerEvent("minecraft:on_tame");
//         // wolf.trySetSitting(true);

//         // Sau 1 khoảng thời gian ngắn, cho wolf đứng dậy và bắt đầu tìm mục tiêu
//         system.runTimeout(() => {
//           if (wolf.isValid) {
//             //  wolf.trySetSitting(false);
//           }
//         }, 20); // 1 giây sau

//         summonedWolves.get(player.id).add(wolf.id);
//         spawnedWolves.add(wolf); // Thêm vào set tạm thời để quản lý vòng đời
//       }
//     }

//     // Logic tìm và tấn công địch cho các wolf
//     let wolfAttackInterval = system.runInterval(() => {
//       if (!player.isValid || !player.hasTag("skill:summonSkill3Active")) {
//         // Đã đổi tên tag
//         system.clearRun(wolfAttackInterval);
//         // Dọn dẹp các wolf còn lại nếu skill kết thúc sớm
//         for (const wolfId of summonedWolves.get(player.id) || []) {
//           const wolf = world.getEntity(wolfId);
//           if (wolf && wolf.isValid) {
//             wolf.remove(); // Xóa wolf
//           }
//         }
//         summonedWolves.delete(player.id);
//         return;
//       }

//       for (const wolfId of summonedWolves.get(player.id) || []) {
//         const wolf = world.getEntity(wolfId);
//         if (!wolf || !wolf.isValid) {
//           summonedWolves.get(player.id).delete(wolfId); // Xóa khỏi danh sách nếu không còn hợp lệ
//           continue;
//         }

//         // Tìm mục tiêu gần nhất nếu không có mục tiêu hoặc mục tiêu đã chết/xa
//         const target = wolf.target;
//         if (
//           !target ||
//           !target.isValid ||
//           target.location.distance(wolf.location) > wolfTargetRange ||
//           target.getComponent("health").current <= 0 // Kiểm tra nếu mục tiêu đã chết
//         ) {
//           const nearbyEntities = wolf.dimension.getEntities({
//             location: wolf.location,
//             maxDistance: wolfTargetRange,
//             excludeTypes: ["minecraft:player", "minecraft:wolf"], // Không tấn công player và wolf khác
//             families: ["monster"], // Chỉ tấn công quái vật
//           });

//           // Mở rộng mục tiêu để bao gồm cả động vật
//           const potentialTargets = nearbyEntities.filter((entity) => {
//             const isMonster =
//               entity.hasTag("monster") ||
//               (entity.typeId.includes("minecraft:") &&
//                 !entity.typeId.includes("animal") &&
//                 !entity.typeId.includes("player")); // Example check for monster
//             const isAnimal =
//               entity.hasTag("animal") ||
//               [
//                 "minecraft:cow",
//                 "minecraft:pig",
//                 "minecraft:sheep",
//                 "minecraft:chicken",
//                 "minecraft:fox",
//                 "minecraft:cat",
//                 "minecraft:ocelot",
//                 "minecraft:horse",
//                 "minecraft:donkey",
//                 "minecraft:llama",
//                 "minecraft:panda",
//                 "minecraft:polar_bear",
//                 "minecraft:axolotl",
//                 "minecraft:mooshroom",
//                 "minecraft:goat",
//               ].includes(entity.typeId); // Example check for animal

//             // Không tấn công pet hoặc sói được triệu hồi/thuần hóa của người chơi khác
//             if (
//               entity.hasTag("tamed_by_player") ||
//               entity.hasTag("is_summoned_pet")
//             ) {
//               return false;
//             }
//             return isMonster || isAnimal;
//           });

//           if (potentialTargets.length > 0) {
//             potentialTargets.sort(
//               (a, b) =>
//                 a.location.distance(wolf.location) -
//                 b.location.distance(wolf.location)
//             );
//             wolf.target = potentialTargets[0]; // Đặt mục tiêu là mob/animal gần nhất
//           } else {
//             // Nếu không có mob/animal, wolf có thể theo người chơi
//           }
//         }
//       }
//     }, 20); // Kiểm tra mục tiêu mỗi 1 giây

//     player.addTag("skill:summonSkill3Active"); // Đã đổi tên tag

//     system.runTimeout(() => {
//       player.sendMessage(
//         `§e${getTranslatedText("summon_skill3_ended_message", locale)}`
//       ); // Đã đổi tên key
//       player.removeTag("skill:summonSkill3Active"); // Đã đổi tên tag
//       system.clearRun(wolfAttackInterval); // Dừng vòng lặp tấn công

//       // Xử lý tự bạo và xóa tất cả các wolf được triệu hồi bởi người chơi này
//       for (const wolfId of summonedWolves.get(player.id) || []) {
//         const wolf = world.getEntity(wolfId);
//         if (wolf && wolf.isValid) {
//           // Logic tự bạo: gây sát thương lên các thực thể xung quanh
//           const explosionRadius = 3; // Bán kính vụ nổ
//           const explosionDamage = 10; // Sát thương của vụ nổ (có thể cấu hình)

//           const nearbyEntities = wolf.dimension.getEntities({
//             location: wolf.location,
//             maxDistance: explosionRadius,
//             excludeTypes: ["minecraft:player", "minecraft:wolf"],
//           });

//           for (const entity of nearbyEntities) {
//             if (entity.isValid && entity.hasComponent("health")) {
//               entity.applyDamage(explosionDamage, {
//                 cause: "explosion",
//                 damagingEntity: wolf,
//               });
//             }
//           }

//           // Hiệu ứng và âm thanh vụ nổ nhỏ
//           wolf.dimension.spawnParticle(
//             "minecraft:basic_flame_particle",
//             wolf.location,
//             { x: 0.5, y: 0.5, z: 0.5 }
//           );
//           wolf.dimension.spawnParticle(
//             "minecraft:large_smoke_particle",
//             wolf.location,
//             { x: 0.5, y: 0.5, z: 0.5 }
//           );
//           wolf.dimension.playSound("random.explode", wolf.location, {
//             volume: 0.5,
//             pitch: 1.0,
//           });

//           wolf.remove(); // Xóa wolf sau khi tự bạo
//         }
//       }
//       summonedWolves.delete(player.id); // Xóa danh sách wolf của player
//     }, finalDurationSeconds * 20);
//   });
// }

// Passive Skill 1: Liên Kết Huyết Ấn (Blood Pact)
world.afterEvents.entityHurt.subscribe((eventData) => {
  const victim = eventData.hurtEntity;
  if (!(victim instanceof Player)) return; // Chỉ xử lý khi player bị tấn công

  const skill1Level = getPlayerProperty(victim, `skill:${SKILL_ID}Skill1`);
  if (skill1Level > 0) {
    const ownerId = victim.id;
    const activeWolves = summonedWolves.get(ownerId) || new Set();

    if (activeWolves.size > 0) {
      const damageToShare = eventData.damage * 0.25; // Chia sẻ 25% sát thương
      eventData.damage -= damageToShare; // Giảm sát thương người chơi nhận

      // Chia sẻ sát thương cho mỗi wolf
      for (const wolfId of activeWolves) {
        const wolf = world.getEntity(wolfId);
        if (wolf && wolf.isValid) {
          wolf.applyDamage(damageToShare / activeWolves.size, {
            // Chia đều sát thương cho các wolf
            cause: "magic", // Hoặc cause phù hợp
            damagingEntity: eventData.damagingEntity, // Kẻ tấn công ban đầu
          });
          wolf.dimension.spawnParticle(
            "minecraft:redstone_dust_particle",
            wolf.location
          ); // Hiệu ứng máu
        }
      }
    }
  }
});

// Passive Skill 2: Linh Thú Bền Ý Chí (Resilient Spirits)
// Logic này sẽ được tích hợp trực tiếp vào activateSummonSkill3
// (Tăng thời gian tồn tại, tăng HP cho wolf)
// Đối với "giữ target tốt hơn, khó bị mất mục tiêu", cần một vòng lặp liên tục
// kiểm tra target của wolf và đặt lại nếu cần. Điều này đã được thêm vào skill3.

// --- Cơ chế cộng kinh nghiệm khi cho ăn (0.1 cho động vật, 0.2 cho pet triệu hồi) ---
world.beforeEvents.itemUse.subscribe((eventData) => {
  const player = eventData.source;
  const itemStack = eventData.itemStack;

  if (!(player instanceof Player)) return;

  // Danh sách các vật phẩm được coi là "thức ăn"
  const foodItems = [
    "minecraft:wheat",
    "minecraft:carrot",
    "minecraft:potato",
    "minecraft:cooked_beef",
    "minecraft:cooked_porkchop",
    "minecraft:fish",
    "minecraft:chicken",
    "minecraft:mutton",
    "minecraft:rabbit",
    "minecraft:beef",
    "minecraft:porkchop",
    "minecraft:rotten_flesh",
    "minecraft:spider_eye",
    "minecraft:golden_apple",
    "minecraft:enchanted_golden_apple",
    "minecraft:bread",
    "minecraft:apple",
    "minecraft:sweet_berries",
    "minecraft:glow_berries",
  ];

  if (!foodItems.includes(itemStack.typeId)) return;

  // Nếu người chơi đang trong cooldown, chặn hành động
  if (feedCooldownManager.getRemainingCooldown(player) > 0) {
    // Tùy chọn: player.sendMessage("Bạn cần chờ thêm...");
    eventData.cancel = true; // Hủy việc sử dụng vật phẩm nếu đang cooldown để tránh tiêu thụ vật phẩm
    return;
  }

  // Thực hiện raycast để tìm thực thể mà người chơi đang nhìn vào
  const hitEntity = raycast(player, 5); // Tầm nhìn 5 khối

  if (hitEntity) {
    // Kiểm tra xem thực thể có phải là động vật hoặc pet hợp lệ không
    const animalTypes = [
      "minecraft:cow",
      "minecraft:pig",
      "minecraft:sheep",
      "minecraft:chicken",
      "minecraft:wolf",
      "minecraft:fox",
      "minecraft:cat",
      "minecraft:ocelot",
      "minecraft:horse",
      "minecraft:donkey",
      "minecraft:llama",
      "minecraft:panda",
      "minecraft:polar_bear",
      "minecraft:axolotl",
      "minecraft:mooshroom",
      "minecraft:goat",
    ];

    const isSummonedPet = hitEntity.hasTag("is_summoned_pet");
    const isAnimal = animalTypes.includes(hitEntity.typeId);

    // Chỉ lưu mục tiêu nếu đó là pet triệu hồi hoặc một động vật hoang dã
    if (isSummonedPet || (isAnimal && !isSummonedPet)) {
      // Đảm bảo không phải pet triệu hồi nếu là động vật hoang dã
      playerPotentialFeedTarget.set(player.id, {
        entityId: hitEntity.id,
        itemTypeId: itemStack.typeId, // Lưu cả loại vật phẩm để xác nhận sau
      });
      // Không hủy eventData.cancel ở đây để cho phép vật phẩm được "ăn"
    }
  }
});

world.afterEvents.itemCompleteUse.subscribe((eventData) => {
  const player = eventData.source;
  const itemStack = eventData.itemStack; // Vật phẩm đã hoàn thành việc sử dụng

  if (!(player instanceof Player)) return;

  const potentialTarget = playerPotentialFeedTarget.get(player.id);

  // Kiểm tra xem có mục tiêu tiềm năng đã được lưu trữ không
  // Và vật phẩm đã sử dụng có khớp với vật phẩm đã được lưu trữ không (tránh lỗi)
  if (potentialTarget && potentialTarget.itemTypeId === itemStack.typeId) {
    const hitEntity = world.getEntity(potentialTarget.entityId);

    if (hitEntity && hitEntity.isValid) {
      const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
      if (hasSetup === 0) return;

      const currentSummonerLevel = getPlayerProperty(
        player,
        `skill:${SKILL_ID}`
      );
      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const xpBonusFromInt =
        intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

      let xpGain = 0;
      let isSummonedPet = false;

      // Kiểm tra nếu là pet được triệu hồi (0.2 XP)
      if (hitEntity.hasTag("is_summoned_pet")) {
        xpGain = 0.2 * (1 + currentSummonerLevel * 0.1);
        xpGain += xpGain * xpBonusFromInt;
        isSummonedPet = true;
      } else {
        // Nếu không phải pet triệu hồi, kiểm tra xem có phải là động vật hoang dã không (0.1 XP)
        const animalTypes = [
          "minecraft:cow",
          "minecraft:pig",
          "minecraft:sheep",
          "minecraft:chicken",
          "minecraft:wolf",
          "minecraft:fox",
          "minecraft:cat",
          "minecraft:ocelot",
          "minecraft:horse",
          "minecraft:donkey",
          "minecraft:llama",
          "minecraft:panda",
          "minecraft:polar_bear",
          "minecraft:axolotl",
          "minecraft:mooshroom",
          "minecraft:goat",
        ];

        if (animalTypes.includes(hitEntity.typeId)) {
          xpGain = 0.1 * (1 + currentSummonerLevel * 0.1);
          xpGain += xpGain * xpBonusFromInt;
        }
      }

      if (xpGain > 0) {
        feedCooldownManager.setCooldown(player, 20); // 1 giây cooldown

        setPlayerProperty(
          player,
          `skill:xpSummon`,
          getPlayerProperty(player, `skill:xpSummon`) + xpGain
        );
        summonLevelUp(player); // Gọi hàm lên cấp sau khi cộng XP

        const locale = getPlayerLocale(player);
        if (isSummonedPet) {
          player.sendMessage(
            `§a${getTranslatedText(
              "feed_pet_xp_message",
              locale,
              xpGain.toFixed(2)
            )}`
          );
        } else {
          player.sendMessage(
            `§a${getTranslatedText(
              "feed_animal_xp_message",
              locale,
              xpGain.toFixed(2)
            )}`
          );
        }
      }
    }
    // Xóa mục tiêu đã lưu trữ sau khi xử lý
    playerPotentialFeedTarget.delete(player.id);
  }
});

// --- Cơ chế cộng kinh nghiệm khi pet giết mob (0.3 XP) ---
world.afterEvents.entityDie.subscribe((eventData) => {
  const mob = eventData.deadEntity;
  const killer = eventData.damageSource.damagingEntity;

  // Kiểm tra nếu kẻ giết là một wolf được triệu hồi HOẶC pet đã được thuần hóa
  // Lưu ý: tag "tamed_by_player" sẽ chỉ có nếu một addon khác gán nó.
  // Nếu không, chỉ "is_summoned_pet" là đáng tin cậy.
  if (
    killer &&
    (killer.hasTag("is_summoned_pet") || killer.hasTag("tamed_by_player"))
  ) {
    const ownerId =
      killer.getDynamicProperty("summoner_owner_id") ||
      killer.getDynamicProperty("tamer_id");
    if (ownerId) {
      const player = world.getEntity(ownerId);
      if (player && player instanceof Player) {
        const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
        if (hasSetup === 0) return;

        const currentSummonerLevel = getPlayerProperty(
          player,
          `skill:${SKILL_ID}`
        );
        const intelligenceLevel = getPlayerStat(player, "intelligence");
        const xpBonusFromInt =
          intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

        const mobXpSources = [
          { id: "minecraft:zombie", xp: 1.0 },
          { id: "minecraft:skeleton", xp: 1.2 },
          { id: "minecraft:creeper", xp: 1.5 },
          { id: "minecraft:spider", xp: 0.8 },
          { id: "minecraft:enderman", xp: 3.0 },
          // Thêm các loại mob khác nếu cần
        ];

        const mobConfig = mobXpSources.find((m) => m.id === mob.typeId);
        if (mobConfig) {
          let xpGain = mobConfig.xp * (1 + currentSummonerLevel * 0.1);
          xpGain += xpGain * xpBonusFromInt;

          // Áp dụng tỷ lệ 0.3 cho trường hợp pet giết mob
          xpGain *= 0.3;

          setPlayerProperty(
            player,
            `skill:xpSummon`,
            getPlayerProperty(player, `skill:xpSummon`) + xpGain
          );
          summonLevelUp(player); // Gọi hàm lên cấp sau khi cộng XP
        }
      }
    }
  } else {
    return;
  }
});

// HÀM entityTame ĐÃ BỊ XÓA BỎ VÌ KHÔNG TỒN TẠI TRONG API.
// Nếu bạn có một addon khác gán tag "tamed_by_player" và "tamer_id" khi thuần hóa,
// thì logic này sẽ hoạt động. Ngược lại, chỉ các pet được triệu hồi mới được tính.
// world.afterEvents.entityTame.subscribe((eventData) => { ... });

// Passive Skill 1: Liên Kết Huyết Ấn (Blood Pact)
world.afterEvents.entityHurt.subscribe((eventData) => {
  const victim = eventData.hurtEntity;
  if (!(victim instanceof Player)) return; // Chỉ xử lý khi player bị tấn công

  const skill1Level = getPlayerProperty(victim, `skill:${SKILL_ID}Skill1`);
  if (skill1Level > 0) {
    const ownerId = victim.id;
    const activeWolves = summonedWolves.get(ownerId) || new Set();

    if (activeWolves.size > 0) {
      const damageToShare = eventData.damage * 0.25; // Chia sẻ 25% sát thương
      eventData.damage -= damageToShare; // Giảm sát thương người chơi nhận

      // Chia sẻ sát thương cho mỗi wolf
      for (const wolfId of activeWolves) {
        const wolf = world.getEntity(wolfId);
        if (wolf && wolf.isValid) {
          wolf.applyDamage(damageToShare / activeWolves.size, {
            // Chia đều sát thương cho các wolf
            cause: "magic", // Hoặc cause phù hợp
            damagingEntity: eventData.damagingEntity, // Kẻ tấn công ban đầu
          });
          wolf.dimension.spawnParticle(
            "minecraft:redstone_dust_particle",
            wolf.location
          ); // Hiệu ứng máu
        }
      }
    }
  }
});

// Passive Skill 2: Linh Thú Bền Ý Chí (Resilient Spirits)
// Logic này sẽ được tích hợp trực tiếp vào activateSummonSkill3
// (Tăng thời gian tồn tại, tăng HP cho wolf)
// Đối với "giữ target tốt hơn, khó bị mất mục tiêu", cần một vòng lặp liên tục
// kiểm tra target của wolf và đặt lại nếu cần. Điều này đã được thêm vào skill3.

/**
 * Kích hoạt kỹ năng Triệu Hồi Hộ Vệ Linh (Skill 3 của Summon).
 * @param {import("@minecraft/server").Player} player
 */
export function activateSummonSkill3(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    player.sendMessage(
      `§c${getTranslatedText(
        "skill_not_unlocked",
        locale,
        getTranslatedText(config.skillLevels.skill3.nameKey, locale)
      )}`
    );
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const numWolves = skill3Config.numWolves;
  const wolfBaseDamage = skill3Config.wolfBaseDamage;
  const wolfDamageIncreasePerLevel = skill3Config.wolfDamageIncreasePerLevel;
  const wolfHealthBonus = skill3Config.wolfHealthBonus;
  const wolfTargetRange = skill3Config.wolfTargetRange;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  const cooldownAfterSkillLevelTicks = Math.max(
    20,
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  const totalIntelligenceReductionPercentage = Math.min(
    0.95,
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * skill3Config.durationIncreasePerLevel;

  const remainingCooldown = summonSkill3Cooldown.getRemainingCooldown(player); // Đã đổi tên
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  player.sendMessage(
    `§a${getTranslatedText("summon_skill3_active_message", locale)}`
  ); // Đã đổi tên key
  player.playSound("mob.wolf.howl", player.location); // Âm thanh kích hoạt

  summonSkill3Cooldown.setCooldown(player, finalCooldownTicks); // Đã đổi tên

  system.run(() => {
    const spawnedWolves = new Set();
    if (!summonedWolves.has(player.id)) {
      summonedWolves.set(player.id, new Set());
    }

    for (let i = 0; i < numWolves; i++) {
      const wolf = player.dimension.spawnEntity(
        EntityTypes.get("minecraft:wolf"),
        player.location
      );
      if (wolf) {
        wolf.addTag(`summon_wolf_${player.id}`); // Đã đổi tên tag
        wolf.addTag("is_summoned_pet"); // Tag chung cho pet
        wolf.setDynamicProperty("summoner_owner_id", player.id); // Vẫn giữ "summoner_owner_id" cho dynamic property

        // wolf.addEffect("strength", finalDurationSeconds * 20, {
        //   amplifier: 5,
        //   showParticles: false,
        // }); // Tăng sát thương
        // wolf.addEffect("health_boost", finalDurationSeconds * 20, {
        //   amplifier: Math.floor(wolfHealthBonus / 2) - 1,
        //   showParticles: false,
        // }); // Tăng máu (Health Boost amplifier là số tim, mỗi tim 2 máu)

        // Đặt wolf thành tame và ngồi để nó không chạy lung tung ngay lập tức
        wolf.triggerEvent("minecraft:on_tame");
        // wolf.trySetSitting(true);

        // Sau 1 khoảng thời gian ngắn, cho wolf đứng dậy và bắt đầu tìm mục tiêu
        system.runTimeout(() => {
          if (wolf.isValid) {
            //  wolf.trySetSitting(false);
          }
        }, 20); // 1 giây sau

        summonedWolves.get(player.id).add(wolf.id);
        spawnedWolves.add(wolf); // Thêm vào set tạm thời để quản lý vòng đời
      }
    }

    // Logic tìm và tấn công địch cho các wolf
    let wolfAttackInterval = system.runInterval(() => {
      if (!player.isValid || !player.hasTag("skill:summonSkill3Active")) {
        // Đã đổi tên tag
        system.clearRun(wolfAttackInterval);
        // Dọn dẹp các wolf còn lại nếu skill kết thúc sớm
        for (const wolfId of summonedWolves.get(player.id) || []) {
          const wolf = world.getEntity(wolfId);
          if (wolf && wolf.isValid) {
            wolf.remove(); // Xóa wolf
          }
        }
        summonedWolves.delete(player.id);
        return;
      }

      for (const wolfId of summonedWolves.get(player.id) || []) {
        const wolf = world.getEntity(wolfId);
        if (!wolf || !wolf.isValid) {
          summonedWolves.get(player.id).delete(wolfId); // Xóa khỏi danh sách nếu không còn hợp lệ
          continue;
        }

        // Tìm mục tiêu gần nhất nếu không có mục tiêu hoặc mục tiêu đã chết/xa
        const target = wolf.target;
        if (
          !target ||
          !target.isValid ||
          target.location.distance(wolf.location) > wolfTargetRange ||
          target.getComponent("health").current <= 0 // Kiểm tra nếu mục tiêu đã chết
        ) {
          const nearbyEntities = wolf.dimension.getEntities({
            location: wolf.location,
            maxDistance: wolfTargetRange,
            excludeTypes: ["minecraft:player", "minecraft:wolf"], // Không tấn công player và wolf khác
            families: ["monster"], // Chỉ tấn công quái vật
          });

          // Mở rộng mục tiêu để bao gồm cả động vật
          const potentialTargets = nearbyEntities.filter((entity) => {
            const isMonster =
              entity.hasTag("monster") ||
              (entity.typeId.includes("minecraft:") &&
                !entity.typeId.includes("animal") &&
                !entity.typeId.includes("player")); // Example check for monster
            const isAnimal =
              entity.hasTag("animal") ||
              [
                "minecraft:cow",
                "minecraft:pig",
                "minecraft:sheep",
                "minecraft:chicken",
                "minecraft:fox",
                "minecraft:cat",
                "minecraft:ocelot",
                "minecraft:horse",
                "minecraft:donkey",
                "minecraft:llama",
                "minecraft:panda",
                "minecraft:polar_bear",
                "minecraft:axolotl",
                "minecraft:mooshroom",
                "minecraft:goat",
              ].includes(entity.typeId); // Example check for animal

            // Không tấn công pet hoặc sói được triệu hồi/thuần hóa của người chơi khác
            if (
              entity.hasTag("tamed_by_player") ||
              entity.hasTag("is_summoned_pet")
            ) {
              return false;
            }
            return isMonster || isAnimal;
          });

          if (potentialTargets.length > 0) {
            potentialTargets.sort(
              (a, b) =>
                a.location.distance(wolf.location) -
                b.location.distance(wolf.location)
            );
            wolf.target = potentialTargets[0]; // Đặt mục tiêu là mob/animal gần nhất
          } else {
            // Nếu không có mob/animal, wolf có thể theo người chơi
          }
        }
      }
    }, 20); // Kiểm tra mục tiêu mỗi 1 giây

    player.addTag("skill:summonSkill3Active"); // Đã đổi tên tag

    system.runTimeout(() => {
      player.sendMessage(
        `§e${getTranslatedText("summon_skill3_ended_message", locale)}`
      ); // Đã đổi tên key
      player.removeTag("skill:summonSkill3Active"); // Đã đổi tên tag
      system.clearRun(wolfAttackInterval); // Dừng vòng lặp tấn công

      // Xử lý tự bạo và xóa tất cả các wolf được triệu hồi bởi người chơi này
      for (const wolfId of summonedWolves.get(player.id) || []) {
        const wolf = world.getEntity(wolfId);
        if (wolf && wolf.isValid) {
          // Logic tự bạo: gây sát thương lên các thực thể xung quanh
          const explosionRadius = 3; // Bán kính vụ nổ
          const explosionDamage = 10; // Sát thương của vụ nổ (có thể cấu hình)

          const nearbyEntities = wolf.dimension.getEntities({
            location: wolf.location,
            maxDistance: explosionRadius,
            excludeTypes: ["minecraft:player", "minecraft:wolf"],
          });

          for (const entity of nearbyEntities) {
            if (entity.isValid && entity.hasComponent("health")) {
              entity.applyDamage(explosionDamage, {
                cause: "explosion",
                damagingEntity: wolf,
              });
            }
          }

          // Hiệu ứng và âm thanh vụ nổ nhỏ
          wolf.dimension.spawnParticle(
            "minecraft:basic_flame_particle",
            wolf.location,
            { x: 0.5, y: 0.5, z: 0.5 }
          );
          wolf.dimension.spawnParticle(
            "minecraft:large_smoke_particle",
            wolf.location,
            { x: 0.5, y: 0.5, z: 0.5 }
          );
          wolf.dimension.playSound("random.explode", wolf.location, {
            volume: 0.5,
            pitch: 1.0,
          });

          wolf.remove(); // Xóa wolf sau khi tự bạo
        }
      }
      summonedWolves.delete(player.id); // Xóa danh sách wolf của player
    }, finalDurationSeconds * 20);
  });
}
