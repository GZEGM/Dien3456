// skills/agility.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";

import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";
const agilitySkill3Cooldown = new CooldownManager("agilitySkill3");
const SKILL_ID = "agility";
const config = skillConfig[SKILL_ID];

/**
 * Hàm lên cấp cho kỹ năng Agility (Hoạt huyết).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function agilityLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Agility (Hoạt huyết).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function agilityPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpAgility, agilitySkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Agility (Hoạt huyết).
 * @param {import("@minecraft/server").Player} player
 */
export async function agilitySkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "agility_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText("stamina_increase", locale)}: ${Math.floor(
        level * 10
      )}`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "agility_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((2 + level) / 100) * 100)
      )}%`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20; // Convert to ticks
      const cooldownReductionPerLevel =
        skill3Config.cooldownReductionPerLevel * 20; // Convert to ticks
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second (20 ticks)
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = finalCooldownTicks / 20; // Convert back to seconds for display

      const finalDurationSeconds =
        baseDurationSeconds + level * durationIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "agility_skill3_active_desc",
        locale,
        Math.floor(finalDurationSeconds) // Use the calculated duration in seconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "") // Clean up any formatting from translation if needed
        .replace(":", "")}: ${Math.floor(
        finalCooldownSeconds
      )}s\n§7Duration: ${Math.floor(finalDurationSeconds)}s`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    agilityPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Agility (Hoạt huyết).
 * @param {import("@minecraft/server").Player} player
 */
export async function xpAgility(player) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(getTranslatedText("experience", locale));

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  // Since Agility XP is based on damage taken, we can show an estimated XP gain per unit of damage
  // For display, let's assume a base damage of 1 to show per-damage XP.
  const baseDamage = 1;
  let estimatedXpPerDamage = baseDamage * (1 + currentSkillLevel * 0.05);
  estimatedXpPerDamage += estimatedXpPerDamage * xpBonusFromInt;

  Form.button(
    0,
    getTranslatedText("xp_from_damage_taken", locale),
    [`\n§3${estimatedXpPerDamage.toFixed(1)}§a ✦§r/sát thương nhận`],
    `textures/items/iron_chestplate`,
    1,
    false
  );

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      // No other cases needed as there's no pagination
    }
  }
}

// Xử lý sự kiện khi người chơi nhận sát thương để tăng XP Agility và kích hoạt kỹ năng Né (Agility Skill 2)
world.afterEvents.entityHurt.subscribe((eventData) => {
  // Sử dụng beforeEvents để can thiệp sát thương
  const entity = eventData.hurtEntity;
  const damage = eventData.damage; // Sát thương ban đầu
  const attacker = eventData.damageSource?.damagingEntity;
  const locale = getPlayerLocale(entity);

  if (entity instanceof Player) {
    const locale = getPlayerLocale(entity);
    const hasSetup = getPlayerProperty(entity, "skill:setUpStartLevel", 0);
    if (hasSetup === 0) return;

    // Lấy chỉ số Intelligence
    const intelligenceLevel = getPlayerStat(entity, "intelligence");
    const xpBonusFromInt =
      intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

    const currentAgilityLevel = getPlayerProperty(entity, `skill:${SKILL_ID}`);
    // Standardized XP calculation: base_damage * (1 + currentSkillLevel * 0.05)
    let xpGain = damage * (1 + currentAgilityLevel * 0.05);
    xpGain += xpGain * xpBonusFromInt; // Cộng thêm XP từ Intelligence

    setPlayerProperty(
      entity,
      `skill:xpAgility`,
      getPlayerProperty(entity, `skill:xpAgility`) + xpGain
    );
    agilityLevelUp(entity);

    // Skill 2: Né
    const skill2Level = getPlayerProperty(entity, `skill:${SKILL_ID}Skill2`);
    const enduranceLevel = getPlayerStat(entity, "endurance"); // Lấy chỉ số Endurance
    // Tỷ lệ né tăng theo Agility Skill 2 và Endurance
    if (
      skill2Level > 0 &&
      Math.random() * 100 <
        ((2 + skill2Level) / 100) * 100 + enduranceLevel * 0.1
    ) {
      // 0.1% né/điểm Endurance
      let healthCmp = entity.getComponent("minecraft:health");
      let currentHealth = healthCmp.currentValue;

      const desiredHealthAfterHit = currentHealth + damage;

      healthCmp.setCurrentValue(desiredHealthAfterHit);

      entity.sendMessage(
        `§e${getTranslatedText("agility_skill2_name", locale)}`
      );
    }

    // Skill 3: Tẩu vi thượng sách (kích hoạt khi máu thấp)
    const skill3Level = getPlayerProperty(entity, `skill:${SKILL_ID}Skill3`);
    const currentHealth = entity.getComponent("minecraft:health").currentValue;
    const maxHealth = entity.getComponent("minecraft:health").effectiveMax;

    if (
      skill3Level > 0 &&
      currentHealth / maxHealth < 0.2 &&
      currentHealth > 0
    ) {
      activateAgilitySkill3(entity);
    }
  }
});

// ==================== SKILL 3 ====================

export function activateAgilitySkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = agilitySkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(`§a${getTranslatedText("agility_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động
  player.runCommand(
    `effect @s speed ${finalDurationSeconds} ${skill3Level + 3} true`
  );
  player.runCommand(
    `effect @s resistance ${finalDurationSeconds} ${skill3Level + 3} true`
  );

  // Đặt cooldown
  agilitySkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(
      `§e${getTranslatedText("agility_skill3_ended", locale)}`
    );
  }, finalDurationSeconds * 20);
}
