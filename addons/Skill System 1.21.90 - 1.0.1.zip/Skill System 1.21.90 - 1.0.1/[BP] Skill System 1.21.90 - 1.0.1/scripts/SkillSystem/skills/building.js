// skills/building.js
import {
  world,
  system,
  Player,
  BlockPermutation,
  BlockTypes,
  // EntityQueryOptions,
  // Vector,
  ItemStack,
} from "@minecraft/server"; // Added Vector, ItemStack
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import {
  getPlayerProperty,
  setPlayerProperty,
  handleQuickResupply,
} from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { buildableBlocks } from "../config.js";
import { skillConfig } from "../skillConfig.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "building";
const config = skillConfig[SKILL_ID];
const buildingSkill3Cooldown = new CooldownManager("buildingSkill3");

export async function buildingLevelUp(player) {
  handleSkillLevelUp(player, config);
}

export async function buildingPage(player) {
  await createSkillDetailsPage(
    player,
    SKILL_ID,
    xpBlocksPlaced,
    buildingSkills
  );
}

export async function buildingSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "building_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(Math.min(0.5 + 0.02 * level, 0.75) * 100) // Updated chance display
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "building_skill2_passive_desc",
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const damage =
        skill3Config.baseDamage + level * skill3Config.damageIncreasePerLevel;
      const radius = skill3Config.radius;
      const columnHeight = skill3Config.columnHeight;
      const columnSize = skill3Config.columnSize;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;
      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );
      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * skill3Config.durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "building_skill3_active_desc",
        locale,
        finalCooldownSeconds,
        finalDurationSeconds,
        damage.toFixed(1),
        columnHeight,
        columnSize
      )}\n\n§c================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "damage",
        locale
      )}: ${damage.toFixed(1)}`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    buildingPage,
    skillSpecificDescriptions,
    activateBuildingSkill3 // Pass the active skill function
  );
}

/**
 * Skill 1: Thao Túng Vật Chất (Manipulate Material)
 * When placing a block, there's a chance the player doesn't consume the block from their hand.
 */
world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const player = event.player;
  const levelSkill1 = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
  if (levelSkill1 <= 0) return;

  const chance = Math.min(0.05 + 0.02 * levelSkill1, 0.75); // Increased max chance
  if (Math.random() < chance) {
    const inv = player.getComponent("inventory").container;
    const itemInHand = inv.getItem(player.selectedSlotIndex);

    if (itemInHand && itemInHand.typeId === event.block.typeId) {
      itemInHand.amount++;
      inv.setItem(player.selectedSlotIndex, itemInHand);
      // player.sendMessage("§a🧱 Không tốn block!"); // Message for success
    }
  }

  const levelSkill2 = getPlayerProperty(player, `skill:${SKILL_ID}Skill2`);
  if (levelSkill2 <= 0) return;
  handleQuickResupply(player, event.block);
});

/**
 * Skill 3: Thần Kiến Tạo (God of Creation)
 * Triggers knockback + AoE damage to nearby mobs and builds a 5x5 stone pillar 3 blocks high under the player.
 * @param {import("@minecraft/server").Player} player
 */
export async function activateBuildingSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);
  if (skill3Level <= 0) {
    return;
  }
  const skill3Config = config.skillLevels.skill3;
  const columnSize = skill3Config.columnSize;
  const columnHeight = skill3Config.columnHeight;

  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  const remainingCooldown = buildingSkill3Cooldown.getRemainingCooldown(player);
  if (remainingCooldown > 0) {
    const showCD = getPlayerProperty(player, "skill:cooldownNotification");
    if (showCD && player.isSneaking) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(
    `§a${getTranslatedText("building_skill3_active_message", locale)}`
  );
  player.playSound("block.beacon.activate", player.location);

  // Gọi hàm tạo cột
  raiseColumnAtLookOrEntity(player, {
    size: columnSize,
    height: columnHeight,
    delayPerLayer: 4,
    restoreAfterTicks: finalDurationSeconds * 20,
    maxDistance: 10,
    onFail: () => {
      buildingSkill3Cooldown.setCooldown(player, 0);
    },
  });

  buildingSkill3Cooldown.setCooldown(player, finalCooldownTicks);
}

export function raiseColumnAtLookOrEntity(player, options = {}) {
  const {
    size = 3,
    height = 5,
    delayPerLayer = 4,
    restoreAfterTicks = 200,
    maxDistance = 10,
    onFail = () => {}, // Keep onFail for other potential failures, but remove from the "no target" case
  } = options;

  const dimension = player.dimension;
  const halfSize = Math.floor(size / 2);
  const originalBlocks = [];

  // 📌 Ưu tiên entity
  const viewEntities = player.getEntitiesFromViewDirection({ maxDistance });
  const targetEntity = viewEntities?.[0]?.entity;

  // Nếu không có entity → check block
  const viewBlock = player.getBlockFromViewDirection({ maxDistance });
  const targetBlock = viewBlock?.block;

  let columnCenter;

  if (targetEntity) {
    columnCenter = {
      x: Math.floor(targetEntity.location.x),
      y: Math.floor(targetEntity.location.y),
      z: Math.floor(targetEntity.location.z),
    };
  } else if (targetBlock) {
    columnCenter = {
      x: targetBlock.location.x,
      y: targetBlock.location.y,
      z: targetBlock.location.z,
    };
  } else {
    // ❌ Không có entity/block → tính vị trí từ hướng nhìn
    const viewVector = player.getViewDirection(); // { x, y, z }
    const eyeLoc = player.getHeadLocation(); // Cho chính xác hơn player.location

    columnCenter = {
      x: Math.floor(eyeLoc.x + viewVector.x * maxDistance),
      y: Math.floor(eyeLoc.y + viewVector.y * maxDistance),
      z: Math.floor(eyeLoc.z + viewVector.z * maxDistance),
    };
  }

  // 📦 Lấy block mẫu xung quanh
  const nearbySamples = [];
  const sampleRadius = 4;

  for (let x = -sampleRadius; x <= sampleRadius; x++) {
    for (let y = -1; y <= 3; y++) {
      for (let z = -sampleRadius; z <= sampleRadius; z++) {
        const pos = {
          x: columnCenter.x + x,
          y: columnCenter.y + y,
          z: columnCenter.z + z,
        };
        const blk = dimension.getBlock(pos);
        if (
          blk &&
          blk.typeId !== "minecraft:air" &&
          !blk.isLiquid &&
          blk.typeId !== "minecraft:barrier"
        ) {
          nearbySamples.push(blk.permutation);
        }
      }
    }
  }

  if (nearbySamples.length === 0) {
    nearbySamples.push(BlockPermutation.resolve("minecraft:stone"));
  }

  // 🧱 Nâng từng lớp
  for (let yOffset = 0; yOffset < height; yOffset++) {
    if (yOffset === 0) {
      const entities = dimension.getEntities({
        location: {
          x: columnCenter.x + 0.5,
          y: columnCenter.y,
          z: columnCenter.z + 0.5,
        },
        maxDistance: size + 1,
        excludeFamilies: ["player"],
      });

      for (const entity of entities) {
        // ✅ Teleport về giữa trụ (giữ nguyên rotation)
        const newLoc = {
          x: columnCenter.x + 0.5,
          y: columnCenter.y + 1,
          z: columnCenter.z + 0.5,
        };

        try {
          entity.teleport(newLoc, {
            facingLocation: entity.location, // hoặc player.location
          });
        } catch (e) {
          console.warn("Teleport entity fail:", e);
        }
        const skill3Config = config.skillLevels.skill3;
        const level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);
        entity.applyDamage(
          skill3Config.baseDamage + level * skill3Config.damageIncreasePerLevel
        ); // hoặc scale theo skill level
        // const dx = entity.location.x - columnCenter.x;
        // const dz = entity.location.z - columnCenter.z;
        // const mag = Math.sqrt(dx * dx + dz * dz);
        // const kx = mag ? dx / mag : 0;
        // const kz = mag ? dz / mag : 0;
        // entity.applyKnockback(kx, kz, 1.2, 0.4);
      }
    }
    system.runTimeout(() => {
      for (let xOffset = -halfSize; xOffset <= halfSize; xOffset++) {
        for (let zOffset = -halfSize; zOffset <= halfSize; zOffset++) {
          const pos = {
            x: columnCenter.x + xOffset,
            y: columnCenter.y + yOffset,
            z: columnCenter.z + zOffset,
          };

          const blk = dimension.getBlock(pos);
          if (blk) {
            const isSensitive =
              blk.getComponent("inventory") ||
              blk.typeId.endsWith("command_block");

            if (!isSensitive) {
              originalBlocks.push({ pos, old: blk.permutation });
              const rand =
                nearbySamples[Math.floor(Math.random() * nearbySamples.length)];
              dimension.setBlockPermutation(pos, rand);
            }
          }
        }
      }
    }, yOffset * delayPerLayer);
  }

  // 🔁 Khôi phục sau restoreAfterTicks với animation từng lớp từ trên xuống
  system.runTimeout(() => {
    // Sort originalBlocks by y-coordinate in descending order for top-down restoration
    originalBlocks.sort((a, b) => b.pos.y - a.pos.y);

    let currentLayerY = -1;
    let layerCount = 0;

    for (const { pos, old } of originalBlocks) {
      if (pos.y !== currentLayerY) {
        currentLayerY = pos.y;
        layerCount++;
      }

      system.runTimeout(() => {
        dimension.setBlockPermutation(pos, old);
      }, (height - (pos.y - columnCenter.y) - 1) * delayPerLayer); // Calculate delay based on height from top
    }
    // player.sendMessage("§7Cột đã biến mất.");
  }, restoreAfterTicks);
}

export async function xpBlocksPlaced(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_block_placement", locale)} (Page ${
      page + 1
    })`
  );
  const ITEMS_PER_PAGE = 45;
  const totalItems = buildableBlocks.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);
  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex;
    const blockConfig = buildableBlocks[i];
    const baseBlockXp = blockConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseBlockXp + baseBlockXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm,
      `${blockConfig.display} §7(${blockConfig.id})`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${blockConfig.display}`],
      `${blockConfig.id}`,
      1,
      true
    );
  }

  if (totalPages > 1) {
    if (page > 0) {
      Form.button(
        45,
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_back_previous_page", locale)}`],
        "textures/items/arrow",
        1,
        true
      );
    }
    if (page < totalPages - 1) {
      Form.button(
        52,
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_back_next_page", locale)}`],
        "textures/items/arrow",
        1,
        true
      );
    }
  }

  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45:
        if (page > 0) {
          xpBlocksPlaced(player, page - 1);
        }
        break;
      case 52:
        if (page < totalPages - 1) {
          xpBlocksPlaced(player, page + 1);
        }
        break;
      case 53:
        buildingPage(player);
        break;
    }
  }
}
