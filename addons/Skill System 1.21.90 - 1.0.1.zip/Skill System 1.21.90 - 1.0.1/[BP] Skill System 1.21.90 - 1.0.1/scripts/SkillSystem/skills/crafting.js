// skills/crafting.js
import {
  world,
  system,
  Player,
  ItemStack,
  ItemTypes,
  EffectTypes,
  BlockTypes,
} from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty, MathRound } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import {
  INTERACTIVE_BLOCKS,
  SPECIAL_CRAFTED_ITEMS_XP, // Import từ config.js
  DEFAULT_CRAFTED_ITEM_XP,
  recycleMap, // Import từ config.js
  transmuteMap,
} from "../config.js"; // Đảm bảo đường dẫn này đúng tới file config.js
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "crafting"; // Đã đổi tên thành "crafting"
const config = skillConfig[SKILL_ID];

const craftingSkill3Cooldown = new CooldownManager("craftingSkill3"); // Đã đổi tên
const craftingSkill1Cooldown = new CooldownManager("craftingSkill1");
// Map để theo dõi trạng thái mở giao diện của người chơi
// Key: Player.id, Value: { initialInventory: Map<string, number>, initialRotation: { x: number, y: number }, interactedBlockLocation: Vector3, isInteracting: boolean, interactionStartTime: number }
const playerInteractionState = new Map();

// XÓA BỎ ĐỊNH NGHĨA SPECIAL_CRAFTED_ITEMS_XP CỤC BỘ TẠI ĐÂY
// const SPECIAL_CRAFTED_ITEMS_XP = { ... };

/**
 * Hàm lên cấp cho kỹ năng Crafting.
 * @param {import("@minecraft/server").Player} player
 */
export async function craftingLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Crafting.
 * @param {import("@minecraft/server").Player} player
 */
export async function craftingPage(player) {
  await createSkillDetailsPage(
    player,
    SKILL_ID,
    xpCraftedItems,
    craftingSkills
  );
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Crafting.
 * @param {import("@minecraft/server").Player} player
 */
export async function craftingSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) => {
      const skill1Config = config.skillLevels.skill1;
      const baseCooldownTicks = skill1Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill1Config.cooldownReductionPerLevel;
      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );
      return `\n§7•Passive: ${getTranslatedText(
        "crafting_skill1_passive_desc",
        locale,
        finalCooldownSeconds
      )}`;
    },
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "crafting_skill2_passive_desc",
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const shockwaveDamage = skill3Config.shockwaveDamage;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * skill3Config.durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "crafting_skill3_active_desc",
        locale,
        finalCooldownSeconds,
        finalDurationSeconds,
        shockwaveDamage.toFixed(1)
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(
        totalIntelligenceReductionPercentage * 100
      )}%\n§7Shockwave Damage: ${shockwaveDamage.toFixed(1)}♥`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    craftingPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Crafting.
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpCraftedItems(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_crafting", locale)} (Page ${page + 1})`
  );

  const xpSourcesToDisplay = Object.keys(SPECIAL_CRAFTED_ITEMS_XP).map(
    (itemId) => ({
      id: itemId,
      xp: SPECIAL_CRAFTED_ITEMS_XP[itemId].xp,
      nameKey: SPECIAL_CRAFTED_ITEMS_XP[itemId].nameKey,
    })
  );

  // Add the generic entry using the new DEFAULT_CRAFTED_ITEM_XP constant
  if (
    DEFAULT_CRAFTED_ITEM_XP !== undefined &&
    DEFAULT_CRAFTED_ITEM_XP !== null
  ) {
    // Check if it's defined
    xpSourcesToDisplay.unshift({
      id: "default_crafted_item",
      xp: DEFAULT_CRAFTED_ITEM_XP,
      nameKey: "generic_crafted_item",
    });
  }

  const ITEMS_PER_PAGE = 45;
  const totalItems = xpSourcesToDisplay.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex;
    const craftedConfig = xpSourcesToDisplay[i];

    // SỬA LỖI: Sử dụng getTranslatedText để lấy tên hiển thị
    const displayName = getTranslatedText(craftedConfig.nameKey, locale);

    const baseCraftedXp = craftedConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseCraftedXp + baseCraftedXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm,
      `${displayName}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${displayName}`],
      `${
        craftedConfig.id === "default_crafted_item"
          ? "minecraft:crafting_table"
          : craftedConfig.id
      }`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    if (page > 0) {
      Form.button(
        45,
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow"
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52,
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow"
      );
    }
  }

  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier"
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45:
        if (page > 0) {
          xpCraftedItems(player, page - 1);
        }
        break;
      case 52:
        if (page < totalPages - 1) {
          xpCraftedItems(player, page + 1);
        }
        break;
      case 53:
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        break;
    }
  }
}

/**
 * Kích hoạt kỹ năng Phù Chú Linh Hồn (Skill 3 của Crafting).
 * @param {import("@minecraft/server").Player} player
 */
// 🌟 Skill 1: Scrap Recycler
export function activateScrapRecycler(player) {
  const locale = getPlayerLocale(player);
  const skill1Config = config.skillLevels.skill1;
  const level = getPlayerProperty(player, `skill:craftingSkill1`);
  const baseCooldownTicks = skill1Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill1Config.cooldownReductionPerLevel;
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  const cooldownAfterSkillLevelTicks = Math.max(
    20,
    baseCooldownTicks - level * cooldownReductionPerLevel
  );

  const totalIntelligenceReductionPercentage = Math.min(
    0.95,
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const remainingCooldown = craftingSkill1Cooldown.getRemainingCooldown(player);
  if (remainingCooldown > 0) {
    const showCD = getPlayerProperty(player, "skill:cooldownNotification");
    if (showCD) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }
  const container = player.getComponent("minecraft:inventory").container;
  const slot = player.selectedSlotIndex;
  const heldItem = container.getItem(slot);

  if (!heldItem) {
    player.sendMessage("§cHold an item to recycle.");
    return;
  }

  const itemId = heldItem.typeId;
  const recipe = recycleMap[itemId];

  if (!recipe) {
    player.sendMessage("§eThis item cannot be recycled.");
    return;
  }

  // Xoá item khỏi tay người chơi
  container.setItem(slot, undefined);

  for (const [material, count] of recipe) {
    player.runCommand(`give @s ${material} ${count}`);
  }

  player.sendMessage("§aRecycled into:");
  for (const [material, count] of recipe) {
    player.sendMessage(`§b- ${material.replace("minecraft:", "")}: ${count}`);
  }
  craftingSkill1Cooldown.setCooldown(player, finalCooldownTicks);
  player.playSound("random.anvil_use", player.location);
}

// 🧱 Skill 2: Material Transmute
export function activateMaterialTransmute(player) {
  const blockHit = player.getBlockFromViewDirection({ maxDistance: 5 });
  if (!blockHit || !blockHit.block) {
    player.sendMessage("§cLook at a valid block to transmute.");
    return;
  }

  const id = blockHit.block.typeId;
  const newId = transmuteMap[id];
  if (!newId) {
    player.sendMessage(`§eThis block cannot be transmuted.`);
    return;
  }

  const loc = blockHit.block.location;
  player.dimension.getBlock(loc).setType(newId);
  player.playSound("random.pop", loc);
  player.spawnParticle("happy_villager", loc);

  // player.sendMessage(
  //   `§aTransmuted ${id.replace("minecraft:", "")} to ${newId.replace(
  //     "minecraft:",
  //     ""
  //   )}!`
  // );
}

function isAirBlock(dimension, loc) {
  const block = dimension.getBlock(loc);
  return block && block.typeId === "minecraft:air";
}

function isAreaAir(dimension, center, radius) {
  for (let x = -radius; x <= radius; x++) {
    for (let y = -radius; y <= radius; y++) {
      for (let z = -radius; z <= radius; z++) {
        const dx = center.x + x;
        const dy = center.y + y;
        const dz = center.z + z;
        const distSq = x * x + y * y + z * z;
        if (distSq <= radius * radius) {
          const loc = { x: dx, y: dy, z: dz };
          if (!isAirBlock(dimension, loc)) return false;
        }
      }
    }
  }
  return true;
}

function createCraftingSphere(dimension, center, radius) {
  for (let x = -radius; x <= radius; x++) {
    for (let y = -radius; y <= radius; y++) {
      for (let z = -radius; z <= radius; z++) {
        const dx = center.x + x;
        const dy = center.y + y;
        const dz = center.z + z;
        const distSq = x * x + y * y + z * z;
        const loc = { x: dx, y: dy, z: dz };

        if (
          distSq >= (radius - 1) * (radius - 1) &&
          distSq <= radius * radius
        ) {
          dimension.getBlock(loc).setType("minecraft:crafting_table");
        } else if (
          dy === center.y + radius - 1 &&
          distSq <= (radius - 1) * (radius - 1)
        ) {
          // Nóc bằng concrete
          dimension.getBlock(loc).setType("minecraft:black_concrete");
        } else if (distSq <= (radius - 2) * (radius - 2)) {
          dimension.getBlock(loc).setType("minecraft:light_block_15");
        }
      }
    }
  }
}

function randomNearby(loc, range = 2) {
  return {
    x: loc.x + (Math.random() * range * 2 - range),
    y: loc.y,
    z: loc.z + (Math.random() * range * 2 - range),
  };
}

export function activateCraftingSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);
  if (skill3Level === 0) {
    return;
  }
  const skill3Config = config.skillLevels.skill3;

  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  const remainingCooldown = craftingSkill3Cooldown.getRemainingCooldown(player);
  if (remainingCooldown > 0) {
    const showCD = getPlayerProperty(player, "skill:cooldownNotification");
    if (showCD && player.isSneaking) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  const dimension = player.dimension;
  const origin = player.location;
  const radius = 12;
  let sphereCenter = {
    x: Math.floor(origin.x),
    y: 200,
    z: Math.floor(origin.z),
  };
  let found = false;
  for (let i = 0; i < 8; i++) {
    if (isAreaAir(dimension, sphereCenter, radius)) {
      found = true;
      break;
    }
    sphereCenter.x += 4;
  }

  if (!found) {
    player.sendMessage("§cNot enough space to summon Crafting Domain.");
    return;
  }

  const shockwaveDamage = skill3Config.shockwaveDamage;
  const portalIn = { ...origin };
  const originalLocation = { ...player.location };

  player.sendMessage(
    `§a${getTranslatedText("crafting_skill3_active_message", locale)}`
  );
  player.playSound("random.levelup", player.location);
  craftingSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  createCraftingSphere(dimension, sphereCenter, radius);

  const portalOutY = sphereCenter.y + radius - 1;

  // Teleport all entities in radius 3 to sphere
  const nearbyEntities = dimension.getEntities({
    location: origin,
    maxDistance: 3,
  });
  for (const e of nearbyEntities) {
    e.teleport({
      x: sphereCenter.x + 0.5,
      y: sphereCenter.y - 8,
      z: sphereCenter.z + 0.5,
    });
    e.addTag("inside_crafting_domain");
  }

  const tickInterval = system.runInterval(() => {
    // spawn entry particle
    dimension.spawnParticle("poke:cube_cosmetic", {
      x: portalIn.x + 0.5,
      y: portalIn.y + 1,
      z: portalIn.z + 0.5,
    });

    // spawn entire top layer exit particle
    for (let x = -radius / 4 + 1; x < radius / 4; x++) {
      for (let z = -radius / 4 + 1; z < radius / 4; z++) {
        const distSq = x * x + z * z;
        if (distSq <= (radius - 1) * (radius - 1)) {
          dimension.spawnParticle("poke:cube_cosmetic", {
            x: sphereCenter.x + x + 0.5,
            y: portalOutY,
            z: sphereCenter.z + z + 0.5,
          });
        }
      }
    }

    // entry detection
    const inPortal = dimension.getEntities({
      location: portalIn,
      maxDistance: 1,
    });
    for (const entity of inPortal) {
      if (!entity.hasTag("inside_crafting_domain")) {
        entity.teleport({
          x: sphereCenter.x + 0.5,
          y: sphereCenter.y - 8,
          z: sphereCenter.z + 0.5,
        });
      }
    }

    // exit detection
    const outEntities = dimension.getEntities({
      location: { x: sphereCenter.x, y: portalOutY, z: sphereCenter.z },
      maxDistance: radius,
    });
    for (const entity of outEntities) {
      const ey = entity.location.y;
      if (
        entity.hasTag("inside_crafting_domain") &&
        Math.abs(ey - portalOutY) <= 2
      ) {
        const safeLoc = randomNearby(portalIn, 2);
        entity.teleport(safeLoc);
        entity.removeTag("inside_crafting_domain");
      }
    }
  });

  player.addTag("inside_crafting_domain");

  system.runTimeout(() => {
    system.clearRun(tickInterval);

    const entities = dimension.getEntities({
      location: sphereCenter,
      maxDistance: radius,
    });
    for (const entity of entities) {
      if (entity.hasTag("inside_crafting_domain")) {
        entity.teleport(randomNearby(portalIn));
        entity.removeTag("inside_crafting_domain");
      }
    }

    player.sendMessage(
      `§e${getTranslatedText("crafting_skill3_ended_message", locale)}`
    );
    dimension.createExplosion(player.location, shockwaveDamage / 2, {
      breaksBlocks: false,
      causesFire: false,
      allowUnderwater: true,
    });
    player.playSound("explosion.fuse", player.location);

    for (let x = -radius; x <= radius; x++) {
      for (let y = -radius; y <= radius; y++) {
        for (let z = -radius; z <= radius; z++) {
          const dx = sphereCenter.x + x;
          const dy = sphereCenter.y + y;
          const dz = sphereCenter.z + z;
          const distSq = x * x + y * y + z * z;
          const loc = { x: dx, y: dy, z: dz };
          if (distSq <= radius * radius) {
            dimension.getBlock(loc).setType("minecraft:air");
          }
        }
      }
    }
  }, baseDurationSeconds * 20);
}

/**
 * Lấy snapshot inventory của người chơi.
 * @param {import("@minecraft/server").Player} player
 * @returns {Map<string, number>} Map của itemId và số lượng
 */
function getInventorySnapshot(player) {
  const inventory = player.getComponent("inventory");
  const snapshot = new Map();
  if (inventory) {
    for (let i = 0; i < inventory.container.size; i++) {
      const item = inventory.container.getItem(i);
      if (item) {
        snapshot.set(
          item.typeId,
          (snapshot.get(item.typeId) || 0) + item.amount
        );
      }
    }
  }
  return snapshot;
}

/**
 * Chuyển đổi Map inventory thành chuỗi định dạng "itemId: quantity".
 * @param {Map<string, number>} inventoryMap
 * @returns {string} Chuỗi biểu diễn inventory.
 */
function inventoryMapToString(inventoryMap) {
  if (inventoryMap.size === 0) {
    return "Empty";
  }
  return Array.from(inventoryMap.entries())
    .map(([id, amount]) => `${id.replace("minecraft:", "")}: ${amount}`)
    .join(", ");
}

/**
 * So sánh hai Map để kiểm tra sự bằng nhau.
 * @param {Map<string, number>} map1
 * @param {Map<string, number>} map2
 * @returns {boolean} True nếu hai Map bằng nhau, ngược lại False.
 */
function areMapsEqual(map1, map2) {
  if (map1.size !== map2.size) {
    return false;
  }
  for (let [key, val] of map1) {
    if (map2.get(key) !== val) {
      return false;
    }
  }
  return true;
}

/**
 * Tính toán khoảng cách giữa hai Vector3.
 * @param {Vector3} loc1
 * @param {Vector3} loc2
 * @returns {number} Khoảng cách giữa hai điểm.
 */
function getDistance(loc1, loc2) {
  const dx = loc1.x - loc2.x;
  const dy = loc1.y - loc2.y;
  const dz = loc1.z - loc2.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/**
 * Tính toán XP nhận được từ các vật phẩm đã thay đổi trong inventory.
 * Chỉ cộng XP cho các vật phẩm có số lượng tăng lên.
 * @param {import("@minecraft/server").Player} player
 * @param {Map<string, number>} oldInventorySnapshot
 * @param {Map<string, number>} newInventorySnapshot
 */
function calculateAndAwardXP(
  player,
  oldInventorySnapshot,
  newInventorySnapshot
) {
  const currentCrafterLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;
  let totalXPGain = 0;
  const gainedItems = [];

  for (const [itemId, newAmount] of newInventorySnapshot.entries()) {
    const oldAmount = oldInventorySnapshot.get(itemId) || 0;
    const craftedAmount = newAmount - oldAmount;

    if (craftedAmount > 0) {
      // Use the imported DEFAULT_CRAFTED_ITEM_XP
      let baseXP = DEFAULT_CRAFTED_ITEM_XP;

      // Check if it's a special item from the imported SPECIAL_CRAFTED_ITEMS_XP
      if (SPECIAL_CRAFTED_ITEMS_XP[itemId]) {
        baseXP = SPECIAL_CRAFTED_ITEMS_XP[itemId].xp; // Access the .xp property
        // console.warn(`LUM`); // Your original debug log
      }

      // console.warn(SPECIAL_CRAFTED_ITEMS_XP[itemId]); // Your original debug log

      let xpGain = baseXP * craftedAmount * (1 + currentCrafterLevel * 0.1);
      xpGain += xpGain * xpBonusFromInt;
      totalXPGain += xpGain;
      gainedItems.push(`${itemId.replace("minecraft:", "")}: ${craftedAmount}`);
    }
  }

  // Debug: Log các vật phẩm đã được thêm vào inventory
  // if (gainedItems.length > 0) {
  //   player.sendMessage(`§7[Debug] Gained items: ${gainedItems.join(", ")}`);
  // }

  if (totalXPGain > 0) {
    setPlayerProperty(
      player,
      `skill:xpCrafting`,
      getPlayerProperty(player, `skill:xpCrafting`) + totalXPGain
    );
    craftingLevelUp(player);
    // player.sendMessage(
    //   `§a+${totalXPGain.toFixed(1)} XP for crafting/smelting!`
    // );
  }
}

// Lắng nghe sự kiện tương tác với khối (interactWithBlock)
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const { player, block } = event;
  const blockTypeId = block.typeId;

  if (INTERACTIVE_BLOCKS.includes(blockTypeId)) {
    const initialInventory = getInventorySnapshot(player);
    // Lưu trạng thái khi người chơi mở giao diện
    playerInteractionState.set(player.id, {
      initialInventory: initialInventory,
      initialRotation: player.getRotation(),
      interactedBlockLocation: block.location,
      isInteracting: true, // Đánh dấu là đang tương tác
      interactionStartTime: Date.now(), // Lưu thời gian bắt đầu tương tác
    });
  }
});

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
    if (hasSetup === 0 || !player.isValid) continue;

    const state = playerInteractionState.get(player.id);
    if (!state || !state.isInteracting) continue;

    const currentRotation = player.getRotation();
    const currentInventorySnapshot = getInventorySnapshot(player);

    const isMoving =
      MathRound(player.getVelocity().x) !== 0 ||
      MathRound(player.getVelocity().y) !== 0 ||
      MathRound(player.getVelocity().z) !== 0;

    const rotationChanged =
      Math.abs(currentRotation.x - state.initialRotation.x) > 5 ||
      Math.abs(currentRotation.y - state.initialRotation.y) > 5;

    const inventoryChanged = !areMapsEqual(
      state.initialInventory,
      currentInventorySnapshot
    );

    if (isMoving || rotationChanged) {
      if (inventoryChanged) {
        calculateAndAwardXP(
          player,
          state.initialInventory,
          currentInventorySnapshot
        );
      }

      playerInteractionState.delete(player.id);
    }
  }
}, 10); // Every 0.5 seconds
