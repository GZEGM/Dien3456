// skills/digging.js
import { world, system, Player, ItemStack } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import {
  getPlayerProperty,
  setPlayerProperty,
  tryAddItemToPlayerInventory,
  summonCrystalandLightningAt,
} from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { soils, treasures } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js"; // IMPORT MỚI: Get stats
import { CooldownManager } from "../../Modules/cooldownManager.js";

const diggingSkill3Cooldown = new CooldownManager("diggingSkill3");
const SKILL_ID = "digging";
const config = skillConfig[SKILL_ID];

/**
 * Hàm lên cấp cho kỹ năng Digging (Đào mộ).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function diggingLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Digging (Đào mộ).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function diggingPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpSoils, diggingSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Digging (Đào mộ).
 * @param {import("@minecraft/server").Player} player
 */
export async function diggingSkills(player) {
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "digging_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((2 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "digging_skill2_passive_desc",
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20; // Convert to ticks
      const cooldownReductionPerLevel =
        skill3Config.cooldownReductionPerLevel * 20; // Convert to ticks
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second (20 ticks)
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = finalCooldownTicks / 20; // Convert back to seconds for display

      const finalDurationSeconds =
        baseDurationSeconds + level * durationIncreasePerLevel;

      return `\n§7•Active: ${getTranslatedText(
        "digging_skill3_active_desc",
        locale,
        Math.floor(finalCooldownSeconds), // Use the calculated cooldown in seconds
        Math.floor(finalDurationSeconds) // Use the calculated duration in seconds
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "") // Clean up any formatting from translation if needed
        .replace(":", "")}: ${Math.floor(
        finalCooldownSeconds
      )}s\n§7Duration: ${Math.floor(finalDurationSeconds)}s`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    diggingPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Digging (Đào mộ).
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpSoils(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_soil", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = soils.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence"); // Lấy chỉ số Intelligence
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const soilConfig = soils[i];
    // Standardized XP calculation: base_soil_xp * (1 + currentSkillLevel * 0.1)
    const baseSoilXp = soilConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseSoilXp + baseSoilXp * xpBonusFromInt; // Cộng thêm XP từ Intelligence
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${soilConfig.xpType}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${soilConfig.xpType}`],
      `${soilConfig.blockID}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpSoils(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpSoils(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

// Xử lý sự kiện khi người chơi phá hủy block đất

world.afterEvents.playerBreakBlock.subscribe(async (eventData) => {
  const player = eventData.player;
  const block = eventData.block;
  const brokenBlockTypeId = eventData.brokenBlockPermutation.type.id;
  const locale = getPlayerLocale(player);
  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0) return;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;
  const luckLevel = getPlayerStat(player, "luck");
  const treasureChanceBonus =
    luckLevel * STATS_CONFIG.luck.treasureChanceMultiplier;

  const soilConfig = soils.find((s) => s.blockID === brokenBlockTypeId);
  if (soilConfig) {
    const currentDiggingLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
    // Standardized XP calculation: base_soil_xp * (1 + currentSkillLevel * 0.1)
    let xpGain = soilConfig.xp * (1 + currentDiggingLevel * 0.1);
    xpGain += xpGain * xpBonusFromInt;

    setPlayerProperty(
      player,
      `skill:xpDigging`,
      getPlayerProperty(player, `skill:xpDigging`) + xpGain
    );
    diggingLevelUp(player);

    const skill1Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
    if (
      skill1Level > 0 &&
      Math.random() * 100 < 2 + skill1Level + treasureChanceBonus
    ) {
      // Lấy random theo tỉ lệ "chance"
      const roll = Math.random() * 100;
      let cumulative = 0;
      let selectedTreasure = null;

      for (const entry of treasures) {
        cumulative += entry.chance;
        if (roll < cumulative) {
          selectedTreasure = entry.item;
          break;
        }
      }

      if (selectedTreasure) {
        const treasureItemStack = new ItemStack(selectedTreasure, 1);
        const inventoryComp = player.getComponent("minecraft:inventory");
        const container = inventoryComp?.container;

        const added = tryAddItemToPlayerInventory(player, treasureItemStack);
        if (added) {
          const itemChance =
            treasures.find((t) => t.item === selectedTreasure)?.chance ?? 0;
          player.sendMessage(
            `§e${getTranslatedText(
              "received_treasure",
              locale,
              selectedTreasure.replace("minecraft:", ""),
              soilConfig.xpType,
              itemChance * 10
            )}`
          );
        }
      }
    }

    // ======================= SKILL 3 ========================

    const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

    if (player.hasTag("skill:activateDiggingSkill3")) {
      // Trừ số lần sử dụng
      let usesLeft = getPlayerProperty(
        player,
        "skill:diggingSkill3_usesLeft",
        0
      );
      if (usesLeft <= 0) return;
      usesLeft--;
      setPlayerProperty(player, "skill:diggingSkill3_usesLeft", usesLeft);

      player.runCommand(`effect @s speed 3 4 true`);

      system.runTimeout(() => {
        player.runCommand(`effect @s resistance 6 255 true`);
        summonCrystalandLightningAt(block.location, block.dimension);
      }, 40);

      // Nếu đã dùng hết số lần
    }
  }
});

// ========================= SKILL 3 ========================

export function activateDiggingSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = diggingSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(`§a${getTranslatedText("digging_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động (tương tự woodcutting)
  player.addTag("skill:activateDiggingSkill3");
  setPlayerProperty(player, "skill:diggingSkill3_usesLeft", skill3Level);

  // Đặt cooldown
  diggingSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(
      `§e${getTranslatedText("digging_skill3_ended", locale)}`
    );
    player.removeTag("skill:activateDiggingSkill3"); // Gỡ tag khi hết hiệu ứng
  }, finalDurationSeconds * 20);
}
