// skills/alchemizing.js
import {
  world,
  system,
  Player,
  EffectTypes,
  ItemComponentTypes,
} from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { potionXpSources } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";

const SKILL_ID = "alchemizing"; // Đã đổi tên thành "alchemizing"
const config = skillConfig[SKILL_ID];

const alchemizingSkill3Cooldown = new CooldownManager("alchemizingSkill3"); // Đã đổi tên

/**
 * Hàm lên cấp cho kỹ năng Alchemizing.
 * @param {import("@minecraft/server").Player} player
 */
export async function alchemizingLevelUp(player) {
  // Đã đổi tên hàm
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Alchemizing.
 * @param {import("@minecraft/server").Player} player
 */
export async function alchemizingPage(player) {
  // Đã đổi tên hàm
  await createSkillDetailsPage(
    player,
    SKILL_ID,
    xpPotionsUsed,
    alchemizingSkills
  ); // Đã đổi tên hàm
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Alchemizing.
 * @param {import("@minecraft/server").Player} player
 */
export async function alchemizingSkills(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "alchemizing_skill1_passive_desc", // Đã đổi tên key
        locale,
        Math.floor((level / 100) * 100)
      )}`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "alchemizing_skill2_passive_desc", // Đã đổi tên key
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const explosionDamage = skill3Config.explosionDamage;
      const radius = skill3Config.radius;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * skill3Config.durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "alchemizing_skill3_active_desc", // Đã đổi tên key
        locale,
        radius,
        finalDurationSeconds,
        finalCooldownSeconds,
        explosionDamage.toFixed(1),
        radius
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7Explosion Damage: ${explosionDamage.toFixed(
        1
      )}\n§7Radius: ${radius}m`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    alchemizingPage, // Đã đổi tên hàm
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Alchemizing.
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpPotionsUsed(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_potion_use", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45;
  const totalItems = potionXpSources.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex;
    const potionConfig = potionXpSources[i];
    const basePotionXp = potionConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = basePotionXp + basePotionXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm,
      `${potionConfig.name}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${potionConfig.name}`],
      `textures/items/potion_bottle_splash`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    if (page > 0) {
      Form.button(
        45,
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow"
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52,
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow"
      );
    }
  }

  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier"
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45:
        if (page > 0) {
          xpPotionsUsed(player, page - 1);
        }
        break;
      case 52:
        if (page < totalPages - 1) {
          xpPotionsUsed(player, page + 1);
        }
        break;
      case 53:
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        break;
    }
  }
}

/**
 * Kích hoạt kỹ năng Bùng Nổ Phản Ứng (Skill 3 của Alchemizing).
 * @param {import("@minecraft/server").Player} player
 */
export function activateAlchemizingSkill3(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const healingPerTick = skill3Config.healingPerTick;
  const poisonDurationTicks = skill3Config.poisonDuration * 20;
  const slownessDurationTicks = skill3Config.slownessDuration * 20;
  const explosionDamage = skill3Config.explosionDamage;
  const radius = skill3Config.radius;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  const cooldownAfterSkillLevelTicks = Math.max(
    20,
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  const totalIntelligenceReductionPercentage = Math.min(
    0.95,
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * skill3Config.durationIncreasePerLevel;

  const remainingCooldown =
    alchemizingSkill3Cooldown.getRemainingCooldown(player); // Đã đổi tên
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  player.sendMessage(
    `§a${getTranslatedText("alchemizing_skill3_active_message", locale)}`
  ); // Đã đổi tên key
  player.playSound("random.fizz", player.location); // Âm thanh kích hoạt

  alchemizingSkill3Cooldown.setCooldown(player, finalCooldownTicks); // Đã đổi tên

  system.run(() => {
    let reactionZoneInterval = system.runInterval(() => {
      if (!player.isValid || !player.hasTag("skill:alchemizingSkill3Active")) {
        // Đã đổi tên tag
        system.clearRun(reactionZoneInterval);
        return;
      }

      const entitiesInArea = player.dimension.getEntities({
        location: player.location,
        maxDistance: radius,
      });

      for (const entity of entitiesInArea) {
        if (!entity.isValid) continue;

        // Hồi máu đồng minh
        if (entity.hasTag("ally") && entity.id !== player.id) {
          const healthComp = entity.getComponent("minecraft:health");
          if (healthComp) {
            const current = healthComp.currentValue;
            const max = healthComp.effectiveMax;
            const healed = Math.min(current + healingPerTick, max);
            healthComp.setCurrentValue(healed);

            entity.dimension.spawnParticle("minecraft:heart_particle", {
              x: entity.location.x,
              y: entity.location.y + 1,
              z: entity.location.z,
            });
          }
        } else if (
          entity.typeId.startsWith("minecraft:") &&
          entity.id !== player.id
        ) {
          try {
            entity.addEffect("minecraft:poison", poisonDurationTicks * 10, {
              amplifier: 0,
              showParticles: false,
            });
            entity.addEffect("minecraft:slowness", slownessDurationTicks * 10, {
              amplifier: 0,
              showParticles: false,
            });
          } catch (e) {}

          const offsetX = (Math.random() - 0.5) * radius * 2;
          const offsetZ = (Math.random() - 0.5) * radius * 2;
          const offsetY = Math.random();

          player.dimension.spawnParticle("minecraft:splash_spell_emitter", {
            x: player.location.x + offsetX,
            y: player.location.y + offsetY,
            z: player.location.z + offsetZ,
          });
        }
      }
    }, 10); // Chạy mỗi 0.5 giây (10 ticks)

    player.addTag("skill:alchemizingSkill3Active"); // Đã đổi tên tag để quản lý trạng thái

    system.runTimeout(() => {
      player.sendMessage(
        `§e${getTranslatedText("alchemizing_skill3_ended_message", locale)}`
      ); // Đã đổi tên key
      player.removeTag("skill:alchemizingSkill3Active"); // Đã đổi tên tag

      const entitiesInArea = player.dimension.getEntities({
        location: player.location,
        maxDistance: radius,
      });

      for (const entity of entitiesInArea) {
        if (!entity.isValid) continue;

        // Hồi máu đồng minh
        if (
          (entity instanceof Player || entity.hasTag("ally")) &&
          entity.id !== player.id
        ) {
          entity.addEffect("minecraft:resistance", 60, {
            amplifier: 255,
            showParticles: false,
          });
        }
      }

      system.clearRun(reactionZoneInterval); // Dừng vòng lặp vùng phản ứng

      // Gây nổ khi kết thúc
      player.addEffect("minecraft:resistance", 60, {
        amplifier: 255,
        showParticles: false,
      });
      player.dimension.createExplosion(player.location, explosionDamage / 2, {
        breaksBlocks: false, // Không phá hủy block
        causesFire: false,
        allowUnderwater: true,
      });

      player.playSound("explosion.fuse", player.location); // Âm thanh nổ
    }, finalDurationSeconds * 20);
  });
}

const recentlyDrank = new Map(); // playerId → tick

world.afterEvents.itemCompleteUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  if (!(player instanceof Player) || item?.typeId != "minecraft:potion") return;

  // đánh dấu: vừa uống thuốc tại tick hiện tại
  const now = Date.now();
  recentlyDrank.set(player.id, now);
  // player.sendMessage(`📌 [DEBUG] Bạn vừa uống potion: ${item.typeId} @ ${now}`);
});

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  if (
    !(player instanceof Player) ||
    item?.typeId != "minecraft:splash_potion" ||
    item?.typeId != "minecraft:lingering_potion"
  )
    return;

  // đánh dấu: vừa uống thuốc tại tick hiện tại
  const now = Date.now();
  recentlyDrank.set(player.id, now);
  // player.sendMessage(`📌 [DEBUG] Bạn vừa uống potion: ${item.typeId} @ ${now}`);
});

world.afterEvents.effectAdd.subscribe((event) => {
  const { effect, entity } = event;
  if (!(entity instanceof Player)) return;

  const now = Date.now();
  const lastDrink = recentlyDrank.get(entity.id);
  const delta = now - (lastDrink ?? 0);

  // if (!lastDrink || delta > 50000) {
  //   recentlyDrank.delete(entity.id);
  //   return;
  // }

  const effectId = effect.typeId;
  const amp = effect.amplifier;
  const duration = effect.duration;

  // 🔍 Tìm config đúng hiệu ứng và đúng cấp
  const config = potionXpSources.find(
    (p) => p.effectId === effectId && p.amplifier === amp
  );

  if (!config) {
    recentlyDrank.delete(entity.id);
    return;
  }

  // ✅ Tính XP
  const intelligence = getPlayerStat(entity, "intelligence");
  const bonus = intelligence * STATS_CONFIG.intelligence.xpMultiplier;
  const alchemistLevel = getPlayerProperty(entity, `skill:${SKILL_ID}`);

  let xpGain = config.xp * (1 + alchemistLevel * 0.1);
  xpGain += xpGain * bonus;

  const oldXp = getPlayerProperty(entity, `skill:xpAlchemizing`);
  const newXp = oldXp + xpGain;

  setPlayerProperty(entity, `skill:xpAlchemizing`, newXp);
  alchemizingLevelUp(entity);

  // entity.sendMessage(
  //   `🧪 Nhận ${xpGain.toFixed(1)} XP từ ${config.name} (cấp ${amp + 1})`
  // );
  // entity.sendMessage(`📌 [DEBUG] XP: ${oldXp} → ${newXp}`);

  recentlyDrank.delete(entity.id);
  // SKILL 1
  const levelSkill1 = getPlayerProperty(entity, `skill:${SKILL_ID}Skill1`);
  if (levelSkill1 > 0 && amp < 255) {
    let chance = levelSkill1;
    if (Math.random() * 100 <= chance) {
      entity.addEffect(effectId, duration * 20, {
        amplifier: amp + 1,
        showParticles: false,
      });
      entity.sendMessage(`Effect level up`);
    }
  }
  // SKILL 2
  const levelSkill2 = getPlayerProperty(entity, `skill:${SKILL_ID}Skill2`);
  if (levelSkill2 > 0) {
    if (effectId == "minecraft:poison") {
      entity.removeEffect("minecraft:poison");
    }
  }
});
