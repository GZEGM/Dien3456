import {
  world,
  system,
  CommandPermissionLevel,
  CustomCommandStatus,
  Player,
  CustomCommandParamType,
  ItemTypes,
  ItemStack,
} from "@minecraft/server";

import { activateMiningSkill3 } from "./mining.js";
import { activateWoodcuttingSkill3 } from "./woodcutting";
import { activateAttackSkill3 } from "./attack.js";
import { activateFarmingSkill3 } from "./farming.js";
import { activateDiggingSkill3 } from "./digging.js";
import { activateBuildingSkill3 } from "./building.js";
import { activateAlchemizingSkill3 } from "./alchemizing.js";
import {
  activateScrapRecycler,
  activateMaterialTransmute,
  activateCraftingSkill3,
} from "./crafting.js";
import { activateDivingSkill3 } from "./diving.js";
// import { activateSummonSkill3 } from "./summon.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  // Mining Skill 3
  if (item && item.typeId.endsWith("_pickaxe")) {
    activateMiningSkill3(player);
  }

  // Woodcutting Skill 3
  if (item && item.typeId.endsWith("_axe")) {
    activateWoodcuttingSkill3(player);
  }

  // Attack Skill 3
  if (item && item.typeId.endsWith("_sword")) {
    activateAttackSkill3(player);
  }

  // Farming Skill 3
  if (item && item.typeId.endsWith("_hoe")) {
    activateFarmingSkill3(player);
  }

  // Digging Skill 3
  if (item && item.typeId.endsWith("_shovel")) {
    activateDiggingSkill3(player);
  }

  // Building Skill 3
  if (item && item.typeId == "minecraft:stone_bricks") {
    activateBuildingSkill3(player);
  }

  // Alchemizing Skill 3
  if (item && item.typeId == "minecraft:blaze_powder") {
    activateAlchemizingSkill3(player);
  }

  // Crafting SKill 2
  if (item && item.typeId == "minecraft:stick") {
    activateMaterialTransmute(player);
  }
  // Crafting Skill 3
  if (item && item.typeId == "minecraft:crafting_table") {
    activateCraftingSkill3(player);
  }

  // Diving Skill 3
  if (item && item.typeId == "minecraft:heart_of_the_sea") {
    activateDivingSkill3(player);
  }

  // // Summon Skill 3
  // if (item && item.typeId == "minecraft:bone") {
  //   activateSummonSkill3(player);
  // }
});

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    if (player.hasTag("skill:vanKiemQuyTongActive")) {
      const skill3Level = getPlayerProperty(player, `skill:attackSkill3`);
      player.runCommand(
        `execute as @e[tag="vanKiemQuyTongTarget_${player.name}"] at @s run particle dienkon:sword ~~3~`
      );
      player.runCommand(
        `execute as @e[tag="vanKiemQuyTongTarget_${
          player.name
        }"] at @s run damage @s ${skill3Level + 2} ram_attack entity "${
          player.name
        }"`
      );
    }

    // God's Shield
    if (player.hasTag("skill:theShieldOfTheGodActive")) {
      const skill3Level = getPlayerProperty(player, `skill:defenseSkill3`);
      player.addEffect("resistance", 10, {
        amplifier: skill3Level,
        showParticles: false,
      });
      player.runCommand(
        `execute at @s run particle azalea:fallingchant1 ~~1.5~`
      );
      player.runCommand(
        `execute as @e[type=!item,type=!arrow,name=!"${player.name}",r=3] at @s if block ^^^-1 air run tp @s ^^^-1`
      );
      //entity.applyKnockback(9,9,8,0)
    }

    //Dấu ấn tử vong - ranged
    player.runCommand(
      `execute as @e[tag="skill:dauAnTuVong_${player.name}"] at @s run particle azalea:bang ~~2~ `
    );
  }
}, 5);

system.beforeEvents.startup.subscribe((init) => {
  // SKILL 1 CRAFTING
  const skillCommand = {
    name: "cmd:recycle",
    description: "Scrap Recycler",
    permissionLevel: CommandPermissionLevel.Any, // Cho phép bất kỳ ai dùng
  };

  init.customCommandRegistry.registerCommand(
    skillCommand,
    ({ sourceEntity }) => {
      const player = sourceEntity;
      const level = getPlayerProperty(player, `skill:craftingSkill1`);
      if (level <= 0)
        return {
          status: CustomCommandStatus.Failure,
          message: "Skill not unlocked yet",
        };
      if (!player || !(player instanceof Player)) {
        // Đảm bảo người dùng lệnh là người chơi
        return {
          status: CustomCommandStatus.Failure,
          message: "Skill not unlocked yet.",
        };
      }
      system.run(() => {
        activateScrapRecycler(player); // Gọi hàm mở UI kỹ năng
      });
      return {
        status: CustomCommandStatus.Success,
      };
    }
  );
});
