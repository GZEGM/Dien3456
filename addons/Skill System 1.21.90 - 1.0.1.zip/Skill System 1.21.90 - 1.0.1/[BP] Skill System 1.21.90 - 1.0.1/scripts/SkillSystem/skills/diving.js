// skills/diving.js
import { world, system, Player } from "@minecraft/server"; // Đã bỏ Vector
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty, MathRound } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js";
import { EffectTypes } from "@minecraft/server"; // Thêm EffectTypes

const SKILL_ID = "diving"; // Đã đổi tên thành "diving"
const config = skillConfig[SKILL_ID];

const divingSkill3Cooldown = new CooldownManager("divingSkill3"); // Đã đổi tên

// Define underwater XP sources globally in this module
const underwaterXpSources = [
  { activity: "walking_underwater", xp: 0.1, display: "Walking Underwater" },
  { activity: "swimming", xp: 0.2, display: "Swimming" },
  { activity: "mining_underwater", xp: 0.5, display: "Mining Underwater" },
  { activity: "killing_drowned", xp: 2, display: "Killing Drowned" },
  { activity: "finding_treasure", xp: 5, display: "Finding Treasure" },
];

/**
 * Hàm lên cấp cho kỹ năng Diving.
 * @param {import("@minecraft/server").Player} player
 */
export async function divingLevelUp(player) {
  // Đã đổi tên hàm
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Diving.
 * @param {import("@minecraft/server").Player} player
 */
export async function divingPage(player) {
  // Đã đổi tên hàm
  await createSkillDetailsPage(player, SKILL_ID, xpUnderwater, divingSkills); // Đã đổi tên hàm
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Diving.
 * @param {import("@minecraft/server").Player} player
 */
export async function divingSkills(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "diving_skill1_passive_desc", // Đã đổi tên key
        locale
      )}`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "diving_skill2_passive_desc", // Đã đổi tên key
        locale
      )}`,
    skill3: (level) => {
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDamage =
        skill3Config.baseDamage + level * skill3Config.damageIncreasePerLevel;
      const dashStrength = skill3Config.dashStrength;
      const range = skill3Config.range;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      const cooldownAfterSkillLevelTicks = Math.max(
        20,
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      const totalIntelligenceReductionPercentage = Math.min(
        0.95,
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );
      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      );

      return `\n§7•Active: ${getTranslatedText(
        "diving_skill3_active_desc", // Đã đổi tên key
        locale,
        finalCooldownSeconds,
        baseDamage.toFixed(1),
        dashStrength
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Damage: ${baseDamage.toFixed(
        1
      )}\n§7Dash Strength: ${dashStrength}\n§7Range: ${range}m\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(totalIntelligenceReductionPercentage * 100)}%`;
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    divingPage, // Đã đổi tên hàm
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Diving.
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpUnderwater(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_underwater_activity", locale)} (Page ${
      page + 1
    })`
  );

  // Định nghĩa các hoạt động dưới nước cho XP của Diver (đã được định nghĩa ở trên)
  // const underwaterXpSources = [ ... ]; // This array is now global

  const ITEMS_PER_PAGE = 45;
  const totalItems = underwaterXpSources.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex;
    const activityConfig = underwaterXpSources[i];
    const baseActivityXp = activityConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseActivityXp + baseActivityXp * xpBonusFromInt;
    Form.button(
      itemIndexInForm,
      `${activityConfig.display}`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r`],
      "minecraft:water", // Icon placeholder
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    if (page > 0) {
      Form.button(
        45,
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow"
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52,
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow"
      );
    }
  }

  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier"
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45:
        if (page > 0) {
          xpUnderwater(player, page - 1);
        }
        break;
      case 52:
        if (page < totalPages - 1) {
          xpUnderwater(player, page + 1);
        }
        break;
      case 53:
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        break;
    }
  }
}

// ========================== SKILL 1 ================
function AquaticMastery(player) {
  if (!player.isValid) return;
  const skill1Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill1`);
  if (skill1Level > 0) {
    if (player.isInWater) {
      // Bơi nhanh hơn (Speed II)
      player.addEffect("speed", 40, { amplifier: 1, showParticles: false });
      // Đào block dưới nước như trên cạn (Haste II)
      player.addEffect("haste", 40, { amplifier: 1, showParticles: false });
    }
  }
}

// ============== SKILL 2 ==================
function DeepSeaSonar(player) {
  const skill2Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill2`);
  if (skill2Level <= 0 || !player.isInWater) return;

  const radius = 15;
  const playerLoc = player.location;
  const dimension = player.dimension;

  // === Particle cho các entity ===
  const entities = dimension.getEntities({
    location: playerLoc,
    maxDistance: radius,
    excludeTypes: ["minecraft:player"],
  });

  for (const entity of entities) {
    if (!entity.isValid) continue;

    const loc = entity.location;
    // dimension.spawnParticle("minecraft:glow", loc);
    dimension.spawnParticle("minecraft:heart_particle", {
      x: loc.x,
      y: loc.y + 1,
      z: loc.z,
    });
  }

  // === Dò block và tạo hiệu ứng ===
  const ruinBlocks = [
    "minecraft:suspicious_gravel",
    "minecraft:suspicious_sand",
  ];

  for (let x = -radius; x <= radius; x++) {
    for (let y = -5; y <= 5; y++) {
      for (let z = -radius; z <= radius; z++) {
        const bx = Math.floor(playerLoc.x + x);
        const by = Math.floor(playerLoc.y + y);
        const bz = Math.floor(playerLoc.z + z);
        const blockLoc = { x: bx + 0.5, y: by + 0.5, z: bz + 0.5 };

        const block = dimension.getBlock({ x: bx, y: by, z: bz });
        if (!block) continue;

        const id = block.typeId;

        const isRuin = ruinBlocks.includes(id);
        const isChest = id === "minecraft:chest" || id === "minecraft:barrel";

        if (isRuin || isChest) {
          // === Sóng sonic đi lên trời từ block ===
          const verticalSteps = radius;
          for (let i = 0; i < verticalSteps; i++) {
            const upLoc = {
              x: blockLoc.x,
              y: blockLoc.y + i,
              z: blockLoc.z,
            };
            dimension.spawnParticle("poke:aqua_ring_particle", upLoc);
          }
        }
      }
    }
  }
}

/**
 * Kích hoạt kỹ năng Đại Thủy Pháp (Skill 3 của Diving).
 * @param {import("@minecraft/server").Player} player
 */
export function activateDivingSkill3(player) {
  // Đã đổi tên hàm
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDamage =
    skill3Config.baseDamage + skill3Level * skill3Config.damageIncreasePerLevel;
  const dashStrength = skill3Config.dashStrength;
  const pushStrength = skill3Config.pushStrength;
  const range = skill3Config.range;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  const cooldownAfterSkillLevelTicks = Math.max(
    20,
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  const totalIntelligenceReductionPercentage = Math.min(
    0.95,
    //1,
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const remainingCooldown = divingSkill3Cooldown.getRemainingCooldown(player); // Đã đổi tên
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  player.sendMessage(
    `§a${getTranslatedText("diving_skill3_active_message", locale)}`
  ); // Đã đổi tên key
  player.playSound("random.splash", player.location); // Âm thanh kích hoạt

  divingSkill3Cooldown.setCooldown(player, finalCooldownTicks); // Đã đổi tên

  system.run(() => {
    const playerViewDirection = player.getViewDirection();
    const startLocation = player.location;

    // Dash người chơi
    player.applyImpulse({
      x: playerViewDirection.x * dashStrength,
      y: playerViewDirection.y * dashStrength * 0.5, // Giảm dash Y để không bay quá cao
      z: playerViewDirection.z * dashStrength,
    });

    // Bắn luồng nước và gây damage/knockback
    // Tạo một "tia" nước bằng cách lặp qua các điểm trên đường thẳng
    for (let i = 1; i <= range; i++) {
      const rayLocation = {
        x: startLocation.x + playerViewDirection.x * i,
        y: startLocation.y + playerViewDirection.y * i + 1, // +1 để ở tầm mắt
        z: startLocation.z + playerViewDirection.z * i,
      };

      // Hiệu ứng hạt nước
      player.dimension.spawnParticle(
        "minecraft:water_splash_particle",
        rayLocation
      );
      player.dimension.spawnParticle(
        "minecraft:water_splash_particle",
        rayLocation
      );

      // Tìm mob trong bán kính nhỏ xung quanh điểm hiện tại của tia nước
      const entitiesInRay = player.dimension.getEntities({
        location: rayLocation,
        maxDistance: 1.5, // Bán kính nhỏ để bắt mob trong đường đi của tia nước
        excludeTypes: ["minecraft:player", "minecraft:fishing_hook"],
      });

      for (const entity of entitiesInRay) {
        if (entity.isValid) {
          entity.applyDamage(baseDamage);
          // Tính toán vector hướng từ người chơi đến entity
          const dx = entity.location.x - player.location.x;
          const dy = entity.location.y - player.location.y;
          const dz = entity.location.z - player.location.z;

          // Tính độ lớn của vector để chuẩn hóa
          const magnitude = Math.sqrt(dx * dx + dy * dy + dz * dz);

          let normalizedDirection = { x: 0, y: 0, z: 0 };
          if (magnitude > 0) {
            normalizedDirection.x = dx / magnitude;
            normalizedDirection.y = dy / magnitude;
            normalizedDirection.z = dz / magnitude;
          }

          // Hệ số nhân cho lực đẩy ngang, có thể điều chỉnh
          const knockbackHorizontalMultiplier = 2;
          // Lực đẩy cố định theo chiều dọc để hất lên, có thể điều chỉnh
          const knockbackVerticalForce = 0.5; // Ví dụ: 0.5 hoặc 1.0

          // Áp dụng impulse để mô phỏng knockback
          entity.applyImpulse({
            x:
              normalizedDirection.x *
              //dashStrength *
              knockbackHorizontalMultiplier,
            y: knockbackVerticalForce, // Lực đẩy lên cố định
            z:
              normalizedDirection.z *
              //dashStrength *
              knockbackHorizontalMultiplier,
          });
        }
      }
    }
  });
}

/**
 * Calculates the final XP for a given base activity XP, considering skill level and intelligence.
 * @param {import("@minecraft/server").Player} player
 * @param {number} baseActivityXp
 * @returns {number} The final calculated XP.
 */
function calculateFinalXp(player, baseActivityXp) {
  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence");
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;
  // Base XP is affected by skill level
  const xpAfterSkillLevel = baseActivityXp * (1 + currentSkillLevel * 0.1);
  // Final XP includes intelligence bonus
  const finalXp = xpAfterSkillLevel + xpAfterSkillLevel * xpBonusFromInt;
  return finalXp;
}

/**
 * Grants XP for the Diving skill.
 * @param {import("@minecraft/server").Player} player
 * @param {number} xpAmount The amount of XP to grant.
 * @param {string} activityName The name of the activity for logging/debugging (optional).
 */
function grantDivingXp(player, xpAmount, activityName = "") {
  setPlayerProperty(
    player,
    `skill:xpDiving`,
    getPlayerProperty(player, `skill:xpDiving`) + xpAmount
  );
  // player.sendMessage(`§a+${xpAmount.toFixed(2)} XP for ${activityName}`); // Optional: for debugging/feedback
  divingLevelUp(player);
}

// --- XP Gain Mechanisms ---

// XP for Walking Underwater / Swimming
system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
    if (hasSetup === 0 || !player.isValid) continue;

    AquaticMastery(player);
    DeepSeaSonar(player);

    const playerVelocity = player.getVelocity();
    // Using a small threshold for movement to account for floating point inaccuracies
    const isMoving =
      Math.abs(playerVelocity.x) > 0.001 ||
      Math.abs(playerVelocity.y) > 0.001 ||
      Math.abs(playerVelocity.z) > 0.001;

    if (player.isInWater && isMoving) {
      let xpGain = 0;
      let activitySource = null;

      // Distinguish between walking underwater (on ground in water) and swimming (in water, not on ground, moving)
      if (player.isSwimming) {
        activitySource = underwaterXpSources.find(
          (s) => s.activity === "swimming"
        );
      }
      if (player.isInWater && isMoving && !player.isSwimming) {
        activitySource = underwaterXpSources.find(
          (s) => s.activity === "walking_underwater"
        );
      }

      if (activitySource) {
        xpGain = calculateFinalXp(player, activitySource.xp);
        grantDivingXp(player, xpGain, activitySource.display);
        // player.sendMessage(`+${xpGain}`);
      }
    }
  }
}, 20); // Every 1 second (20 ticks)

// XP for Mining Underwater
world.afterEvents.playerBreakBlock.subscribe((event) => {
  const player = event.player;
  const blockLocation = event.block.location;

  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0 || !player.isValid) return;

  // Check if the player is in water or if the broken block was covered by water
  const blockAbove = player.dimension.getBlock({
    x: blockLocation.x,
    y: blockLocation.y + 1,
    z: blockLocation.z,
  });
  if (player.isInWater && blockAbove && blockAbove.isLiquid) {
    const source = underwaterXpSources.find(
      (s) => s.activity === "mining_underwater"
    );
    if (source) {
      const xpGain = calculateFinalXp(player, source.xp);
      grantDivingXp(player, xpGain, source.display);
      // player.sendMessage(`+${xpGain}`);
    }
  }
});

// XP for Killing Drowned
world.afterEvents.entityDie.subscribe((event) => {
  const deadEntity = event.deadEntity;
  const damagingEntity = event.damageSource.damagingEntity;

  // Ensure the killer is a player and the killed entity is a drowned
  if (
    deadEntity.typeId === "minecraft:drowned" &&
    damagingEntity instanceof Player
  ) {
    const player = damagingEntity;
    const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
    if (hasSetup === 0 || !player.isValid) return;

    const source = underwaterXpSources.find(
      (s) => s.activity === "killing_drowned"
    );
    if (source) {
      const xpGain = calculateFinalXp(player, source.xp);
      grantDivingXp(player, xpGain, source.display);
      // player.sendMessage(`+${xpGain}`);
    }
  }
});

// XP for Finding Treasure (Opening Chests/Barrels Underwater)
const TREASURE_CHEST_XP_DP_PREFIX = "diving:treasure_chest_xp_given:"; // Prefix for world dynamic property keys

world.afterEvents.playerInteractWithBlock.subscribe((event) => {
  const player = event.player;
  const block = event.block;
  const blockLocation = block.location; // Get the location object

  const hasSetup = getPlayerProperty(player, "skill:setUpStartLevel", 0);
  if (hasSetup === 0 || !player.isValid) return;

  // Check if the interacted block is a chest-like block that can contain treasure
  const isTreasureBlock = [
    "minecraft:chest",
    "minecraft:barrel",
    "minecraft:shulker_box",
  ].includes(block.typeId);

  if (isTreasureBlock) {
    // Determine if the chest is underwater. Heuristic: block itself is waterlogged, or block above is water, or player is in water.
    const blockAbove = player.dimension.getBlock({
      x: blockLocation.x,
      y: blockLocation.y + 1,
      z: blockLocation.z,
    });
    const isUnderwater =
      block.isLiquid || (blockAbove && blockAbove.isLiquid) || player.isInWater;

    if (isUnderwater) {
      const chestUniqueKey = `${blockLocation.x}_${blockLocation.y}_${blockLocation.z}`;
      const dpKey = `${TREASURE_CHEST_XP_DP_PREFIX}${chestUniqueKey}`;
      // Use dimension-level dynamic properties for chest state
      const hasXpBeenGiven = getPlayerProperty(player, dpKey);

      if (!hasXpBeenGiven) {
        // Check if the chest is empty
        const inventoryComponent = block.getComponent("minecraft:inventory");
        let isEmpty = true;
        if (inventoryComponent) {
          const container = inventoryComponent.container;
          if (container) {
            // If emptySlotsCount is less than container.size, it means there are items
            if (container.emptySlotsCount < container.size) {
              isEmpty = false;
            }
          }
        }

        if (!isEmpty) {
          // Only grant XP if the chest is NOT empty
          const source = underwaterXpSources.find(
            (s) => s.activity === "finding_treasure"
          );
          if (source) {
            const xpGain = calculateFinalXp(player, source.xp);
            grantDivingXp(player, xpGain, source.display);

            // Mark this chest's location as having granted XP in the dimension
            setPlayerProperty(player, dpKey, true);
          }
        } else {
          setPlayerProperty(player, dpKey, true);
        }
      }
    }
  }
});
