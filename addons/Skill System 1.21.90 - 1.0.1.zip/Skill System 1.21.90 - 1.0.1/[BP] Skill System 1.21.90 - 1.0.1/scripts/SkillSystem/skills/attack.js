// skills/attack.js
import { world, system, Player } from "@minecraft/server";
import ChestFormData from "../../Modules/ChestForms.js";
import { ForceOpen } from "../../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "../utils.js";
import { getTranslatedText, getPlayerLocale } from "../lang.js";
import { handleSkillLevelUp } from "../skillCore.js";
import {
  createSkillDetailsPage,
  createExclusiveSkillsPage,
} from "../skillUI.js";
import { skillConfig } from "../skillConfig.js";
import { mobs } from "../config.js";
import { getPlayerStat, STATS_CONFIG } from "../playerStats.js";
import { CooldownManager } from "../../Modules/cooldownManager.js"; // Đảm bảo đường dẫn đúng đến CooldownManager.js

const SKILL_ID = "attack";
const config = skillConfig[SKILL_ID];

// Khởi tạo CooldownManager cho skill 3 của Attack
const attackSkill3Cooldown = new CooldownManager("attackSkill3"); // DÒNG MỚI

/**
 * Hàm lên cấp cho kỹ năng Attack (Kiếm pháp).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillCore.
 * @param {import("@minecraft/server").Player} player
 */
export async function attackLevelUp(player) {
  handleSkillLevelUp(player, config);
}

/**
 * Hiển thị trang chi tiết kỹ năng Attack (Kiếm pháp).
 * Hàm này giờ chỉ gọi hàm tổng quát từ skillUI.
 * @param {import("@minecraft/server").Player} player
 */
export async function swordPage(player) {
  await createSkillDetailsPage(player, SKILL_ID, xpMobs, attackSkills);
}

/**
 * Hiển thị trang kỹ năng độc quyền cho Attack (Kiếm pháp).
 * @param {import("@minecraft/server").Player} player
 */
export async function attackSkills(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  const skillSpecificDescriptions = {
    skill1: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "attack_skill1_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor(((5 + level) / 100) * 100)
      )}%`,
    skill2: (level) =>
      `\n§7•Passive: ${getTranslatedText(
        "attack_skill2_passive_desc",
        locale
      )}\n\n§7${getTranslatedText(
        "chance_to_activate",
        locale,
        Math.floor((level / 100) * 100)
      )}%`,
    skill3: (level) => {
      // DÒNG MỚI: Bắt đầu tính toán cooldown có chỉ số Intelligence cho hiển thị UI
      const skill3Config = config.skillLevels.skill3;
      const baseCooldownTicks = skill3Config.baseCooldown * 20;
      const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
      const baseDurationSeconds = skill3Config.baseDurationSeconds;
      const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

      const intelligenceLevel = getPlayerStat(player, "intelligence");
      // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
      const cooldownPercentageReductionPerIntelligenceLevel =
        STATS_CONFIG.intelligence.cooldownReduction || 0;

      // Calculate cooldown after skill level reduction
      const cooldownAfterSkillLevelTicks = Math.max(
        20, // Ensure it's at least 1 second
        baseCooldownTicks - level * cooldownReductionPerLevel
      );

      // Calculate total percentage reduction from intelligence
      const totalIntelligenceReductionPercentage = Math.min(
        0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
        intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
      );

      // Apply intelligence reduction
      const finalCooldownTicks = Math.floor(
        cooldownAfterSkillLevelTicks *
          (1 - totalIntelligenceReductionPercentage)
      );

      const finalCooldownSeconds = Math.max(
        1,
        Math.floor(finalCooldownTicks / 20)
      ); // Ensure minimum 1 second in UI
      const finalDurationSeconds = Math.floor(
        baseDurationSeconds + level * durationIncreasePerLevel
      );

      return `\n§7•Active: ${getTranslatedText(
        "attack_skill3_active_desc",
        locale,
        finalCooldownSeconds, // DÒNG ĐÃ THAY ĐỔI
        finalDurationSeconds // DÒNG ĐÃ THAY ĐỔI
      )}\n\n§c ================ §2${getTranslatedText(
        "stats",
        locale
      )}§c ================\n§7${getTranslatedText("cooldown", locale)
        .replace("§7(", "")
        .replace(
          ":",
          ""
        )}: ${finalCooldownSeconds}s\n§7Duration: ${finalDurationSeconds}s\n§7${getTranslatedText(
        "cooldown_reduction_from_int",
        locale
      )}: ${Math.floor(totalIntelligenceReductionPercentage * 100)}%`; // DÒNG ĐÃ THAY ĐỔI VÀ THÊM
    },
  };

  await createExclusiveSkillsPage(
    player,
    SKILL_ID,
    swordPage,
    skillSpecificDescriptions
  );
}

/**
 * Hiển thị trang nguồn kinh nghiệm cho kỹ năng Attack (Kiếm pháp).
 * (Sử dụng chung với Ranged vì cùng là XP từ mobs)
 * @param {import("@minecraft/server").Player} player
 * @param {number} page - Trang hiện tại (mặc định là 0)
 */
export async function xpMobs(player, page = 0) {
  const locale = getPlayerLocale(player);
  let Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("xp_from_mob", locale)} (Page ${page + 1})`
  );

  const ITEMS_PER_PAGE = 45; // Max slots for items: 0 to 43 (total 44)
  const totalItems = mobs.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

  const startIndex = page * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const currentSkillLevel = getPlayerProperty(player, `skill:${SKILL_ID}`);
  const intelligenceLevel = getPlayerStat(player, "intelligence"); // Lấy chỉ số Intelligence
  const xpBonusFromInt =
    intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

  for (let i = startIndex; i < endIndex; i++) {
    const itemIndexInForm = i - startIndex; // Map to 0-43 range
    const mobConfig = mobs[i];
    // Standardized XP calculation: base_mob_xp * (1 + currentSkillLevel * 0.1)
    const baseMobXp = mobConfig.xp * (1 + currentSkillLevel * 0.1);
    const finalXp = baseMobXp + baseMobXp * xpBonusFromInt; // Cộng thêm XP từ Intelligence
    Form.button(
      itemIndexInForm, // Use itemIndexInForm for the button slot
      `${mobConfig.name} §7(${mobConfig.id})`,
      [`\n§3${finalXp.toFixed(1)}§a ✦§r/${mobConfig.name}`],
      `${mobConfig.texture}`,
      1,
      true
    );
  }

  // Add navigation buttons
  if (totalPages > 1) {
    // Only show pagination buttons if there's more than one page
    if (page > 0) {
      Form.button(
        45, // Slot for Previous Page
        getTranslatedText("previous_page", locale),
        [`§7${getTranslatedText("click_to_go_previous_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }

    if (page < totalPages - 1) {
      Form.button(
        52, // Slot for Next Page
        getTranslatedText("next_page", locale),
        [`§7${getTranslatedText("click_to_go_next_page", locale)}`],
        "textures/items/arrow", // Placeholder texture
        1,
        true
      );
    }
  }

  // Always add back to skill list button at slot 53
  Form.button(
    53,
    getTranslatedText("back_to_skill_list", locale),
    [`§7${getTranslatedText("click_to_back_main_skill", locale)}`],
    "minecraft:barrier",
    1,
    true
  );

  let res = await ForceOpen(player, Form);
  if (!res.canceled) {
    switch (res.selection) {
      case 45: // Previous Page
        if (page > 0) {
          xpMobs(player, page - 1); // Recursive call for previous page
        }
        break;
      case 52: // Next Page
        if (page < totalPages - 1) {
          xpMobs(player, page + 1); // Recursive call for next page
        }
        break;
      case 53: // Back to Skill List
        const { Skill } = await import("../main.js");
        Skill(player);
        break;
      default:
        // Handle item selection if needed, though for XP pages, typically not
        break;
    }
  }
}

// Hàm xử lý khi quái vật bị giết để tăng XP Attack và áp dụng hiệu ứng chỉ số
world.afterEvents.entityDie.subscribe((eventData) => {
  const killer = eventData.damageSource.damagingEntity;
  const diedEntity = eventData.deadEntity;

  if (killer && killer instanceof Player) {
    const locale = getPlayerLocale(killer);
    const hasSetup = getPlayerProperty(killer, "skill:setUpStartLevel", 0);
    if (hasSetup === 0) return;

    // Lấy chỉ số Intelligence của người chơi
    const intelligenceLevel = getPlayerStat(killer, "intelligence");
    const xpBonusFromInt =
      intelligenceLevel * STATS_CONFIG.intelligence.xpMultiplier;

    // Tìm XP cho mob đã chết
    const mobConfig = mobs.find((m) => m.id === diedEntity.typeId);
    if (mobConfig) {
      const currentAttackLevel = getPlayerProperty(killer, `skill:${SKILL_ID}`);
      // Standardized XP calculation: base_mob_xp * (1 + currentSkillLevel * 0.1)
      let xpGain = mobConfig.xp * (1 + currentAttackLevel * 0.1);
      xpGain += xpGain * xpBonusFromInt; // Cộng thêm XP từ Intelligence

      setPlayerProperty(
        killer,
        `skill:xpAttack`,
        getPlayerProperty(killer, `skill:xpAttack`) + xpGain
      );
      attackLevelUp(killer);

      // =============== SKILL 1 ==================

      const skill1Level = getPlayerProperty(killer, `skill:${SKILL_ID}Skill1`);

      if (
        skill1Level > 0 &&
        Math.random() * 100 < ((5 + skill1Level) / 100) * 100
      ) {
        killer.runCommand(`xp ${Math.floor(xpGain)} @s`); // Using Math.floor to ensure integer XP for command
      }
    }
  }
});

// Xử lý sát thương để áp dụng chỉ số Strength, Critical Chance, Critical Damage
world.afterEvents.entityHurt.subscribe((event) => {
  const entity = event.hurtEntity;
  const attacker = event.damageSource?.damagingEntity;
  const damage = event.damage;
  const locale = getPlayerLocale(attacker);

  if (!attacker || !(attacker instanceof Player)) return;

  const strengthLevel = getPlayerStat(attacker, "strength");
  const critChance = getPlayerStat(attacker, "critical_chance");
  const critDamage = getPlayerStat(attacker, "critical_damage");

  let bonusDamage = 0;
  let isCritical = false;

  // Tính sát thương cộng thêm từ strength
  if (strengthLevel > 0) {
    bonusDamage += strengthLevel * (STATS_CONFIG.strength?.multiplier ?? 0);
  }

  // Tính chí mạng
  const chance = critChance * (STATS_CONFIG.critical_chance?.multiplier ?? 0);
  if (Math.random() * 100 < chance) {
    isCritical = true;
    const bonusPercent =
      critDamage * (STATS_CONFIG.critical_damage?.multiplier ?? 0);
    bonusDamage *= 1 + bonusPercent / 100;

    // attacker.sendMessage(
    //   getTranslatedText("crit_active", locale, Math.floor(bonusDamage))
    // );
    // if (times == 0) {
    //   attacker.sendMessage(
    //     getTranslatedText("crit_active", locale, Math.floor(bonusDamage))
    //   );
    //   times++;
    // }
  }

  if (attacker != undefined && bonusDamage > 0) {
    try {
      entity.runCommand(
        `execute at @s run damage @s ${Math.floor(
          bonusDamage
        )} entity_attack entity "${attacker.name}"`
      );
      //times--;
    } catch (err) {
      console.warn("Không thể thêm sát thương:", err);
    }
  }

  // ============= SKILL 2 =============

  const skill2Level = getPlayerProperty(attacker, `skill:${SKILL_ID}Skill2`);

  if (skill2Level > 0 && Math.random() * 100 <= (skill2Level / 100) * 100) {
    // attacker.sendMessage(`Bruhh`);
    system.runTimeout(() => {
      entity.runCommand(
        `damage @s ${Math.floor(
          skill2Level + bonusDamage
        )} entity_attack entity "${attacker.name}"`
      );
    }, 10);
  }

  // =============== SKILL 3 ===================

  if (attacker.hasTag("skill:vanKiemQuyTongActive")) {
    const inventory = attacker.getComponent("minecraft:inventory");
    const heldItem = inventory.container.getItem(attacker.selectedSlotIndex);

    if (!heldItem || !heldItem.typeId.endsWith("sword")) return;

    entity.addTag(`vanKiemQuyTongTarget_${attacker.name}`);
    // attacker.sendMessage(`vanKiemQuyTongTarget_${attacker.name}`);
  }
});

// ========================= SKILL 3 ========================
// DÒNG MỚI: Thêm hàm activateAttackSkill3
export function activateAttackSkill3(player) {
  const locale = getPlayerLocale(player);
  const skill3Level = getPlayerProperty(player, `skill:${SKILL_ID}Skill3`);

  if (skill3Level === 0) {
    return;
  }

  const skill3Config = config.skillLevels.skill3;
  const baseCooldownTicks = skill3Config.baseCooldown * 20;
  const cooldownReductionPerLevel = skill3Config.cooldownReductionPerLevel;
  const baseDurationSeconds = skill3Config.baseDurationSeconds;
  const durationIncreasePerLevel = skill3Config.durationIncreasePerLevel;

  const intelligenceLevel = getPlayerStat(player, "intelligence");
  // Assume STATS_CONFIG.intelligence.cooldownReduction is a percentage reduction per level (e.g., 0.001 for 0.1%)
  const cooldownPercentageReductionPerIntelligenceLevel =
    STATS_CONFIG.intelligence.cooldownReduction || 0;

  // Calculate cooldown after skill level reduction
  const cooldownAfterSkillLevelTicks = Math.max(
    20, // Ensure it's at least 1 second
    baseCooldownTicks - skill3Level * cooldownReductionPerLevel
  );

  // Calculate total percentage reduction from intelligence
  const totalIntelligenceReductionPercentage = Math.min(
    0.95, // Cap reduction at 95% to avoid 0 or negative cooldown
    intelligenceLevel * cooldownPercentageReductionPerIntelligenceLevel
  );

  // Apply intelligence reduction
  const finalCooldownTicks = Math.floor(
    cooldownAfterSkillLevelTicks * (1 - totalIntelligenceReductionPercentage)
  );

  const finalDurationSeconds =
    baseDurationSeconds + skill3Level * durationIncreasePerLevel;

  // Kiểm tra cooldown
  const remainingCooldown = attackSkill3Cooldown.getRemainingCooldown(player);
  let cooldownNotification = getPlayerProperty(
    player,
    "skill:cooldownNotification"
  );
  if (remainingCooldown > 0) {
    if (player.isSneaking && cooldownNotification) {
      player.sendMessage(
        `§e${getTranslatedText(
          "skill_on_cooldown",
          locale,
          Math.ceil(remainingCooldown / 20)
        )}`
      );
    }
    return;
  }

  // Kích hoạt skill
  player.sendMessage(`§a${getTranslatedText("attack_skill3_active", locale)}`);
  player.playSound("random.orb", player.location);

  // Thêm tag để đánh dấu skill đang hoạt động (tương tự woodcutting)
  player.addTag("skill:vanKiemQuyTongActive");

  // Đặt cooldown
  attackSkill3Cooldown.setCooldown(player, finalCooldownTicks);

  // Thông báo hết hiệu ứng sau khi hết thời gian
  system.runTimeout(() => {
    player.sendMessage(`§e${getTranslatedText("attack_skill3_ended", locale)}`);
    player.runCommand(`tag @e remove "vanKiemQuyTongTarget_${player.name}"`);
    player.removeTag("skill:vanKiemQuyTongActive"); // Gỡ tag khi hết hiệu ứng
  }, finalDurationSeconds * 20);
}
