import { world } from "@minecraft/server";

/**
 * Lấy giá trị tiền của người chơi từ scoreboard.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @returns {number} Số tiền của người chơi.
 */
export function getMoney(player) {
  try {
    const moneyObjective = world.scoreboard.getObjective("money");
    // Trả về 0 nếu mục tiêu không tồn tại hoặc người chơi chưa có điểm
    return moneyObjective ? moneyObjective.getScore(player) || 0 : 0;
  } catch (error) {
    console.error(
      `[Error] Failed to get money for player ${player.name}: ${error}`
    );
    return 0;
  }
}

/**
 * Thêm tiền cho người chơi vào scoreboard.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {number} amount Số tiền muốn thêm.
 */
export function addMoney(player, amount) {
  try {
    player.runCommand(`scoreboard players add @s money ${amount}`);
  } catch (error) {
    console.error(
      `[Error] Failed to add money for player ${player.name}: ${error}`
    );
  }
}

export function removeMoney(player, amount) {
  try {
    player.runCommand(`scoreboard players remove @s money ${amount}`);
  } catch (error) {
    console.error(
      `[Error] Failed to add money for player ${player.name}: ${error}`
    );
  }
}

/**
 * Đặt giá trị tiền của người chơi vào scoreboard.
 * @param {import("@minecraft/server").Player} player Người chơi.
 * @param {number} amount Số tiền muốn đặt.
 */
export function setMoney(player, amount) {
  try {
    player.runCommand(`scoreboard players set @s money ${amount}`);
  } catch (error) {
    console.error(
      `[Error] Failed to set money for player ${player.name}: ${error}`
    );
  }
}

/**
 * Chuyển đổi số lớn sang định dạng rút gọn (ví dụ: 1000 -> 1K).
 * @param {number} value Số cần chuyển đổi.
 * @returns {string} Số đã định dạng.
 */
export function metricNumbers(value) {
  if (value < 1000) return value.toString();

  const types = [
    "",
    "k",
    "M",
    "B",
    "T",
    "P",
    "E",
    "Z",
    "Y",
    "R",
    "Q",
    "QQ",
    "QQQ",
    "10^42",
    "10^45",
    "10^48",
    "10^51",
    "10^54",
    "10^57",
    "10^60",
  ];

  const power = Math.floor(Math.log10(value) / 3);
  const scaled = value / Math.pow(10, power * 3);

  const suffix = types[power] || `e${power * 3}`;
  return scaled.toFixed(1).replace(/\.0$/, "") + suffix;
}
