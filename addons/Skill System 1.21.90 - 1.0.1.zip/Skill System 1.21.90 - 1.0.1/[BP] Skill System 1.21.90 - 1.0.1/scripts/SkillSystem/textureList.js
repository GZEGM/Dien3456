// This is used for set texture on custom items (Doesn't work for custom block)
export const TextureList = {
  "custom item id here": "texture path here",
  "paoitem:example": "textures/items/stick"
}