// BP/scripts/statsUI.js

import ChestFormData from "../Modules/ChestForms.js";
import { ForceOpen } from "../Modules/Forms.js";
import { getPlayerProperty, setPlayerProperty } from "./utils.js";

import { getTranslatedText, getPlayerLocale } from "./lang.js";
import {
  STATS_CONFIG,
  getPlayerStat,
  // increasePlayerStat, // Đã loại bỏ import này
  resetAllStats,
  applyAllStatEffects,
  modifyPlayerStat, // IMPORT MỚI: Dùng để tăng/giảm chỉ số
} from "./playerStats.js";
import { openPlayerSkillManagerUI } from "./main.js"; // Import Skill và openPlayerSkillManagerUI

/**
 * Hiển thị giao diện chỉ số của người chơi.
 * @param {import("@minecraft/server").Player} player
 */
export async function showPlayerStatsUI(player) {
  const locale = getPlayerLocale(player);
  const Form = new ChestFormData("large");
  Form.title(`§r§l§9${getTranslatedText("your_stats_title", locale)}`);

  const unspentPoints = getPlayerProperty(player, "stats:unspentPoints");

  // Vị trí cố định cho các chỉ số
  const statDisplayOrder = [
    "strength",
    "health",
    "regen",
    "luck",
    "intelligence",
    "endurance",
    "critical_chance",
    "critical_damage",
    "speed",
  ];

  const statPositions = {
    strength: 0,
    health: 2,
    regen: 4,
    luck: 6,

    intelligence: 18,
    endurance: 20,
    critical_chance: 22,
    critical_damage: 24,

    speed: 36,
  };

  // Tạo các nút chỉ số (không còn nút '+' trực tiếp ở đây)
  for (const statId of statDisplayOrder) {
    const statConfig = STATS_CONFIG[statId];
    const currentStatValue = getPlayerStat(player, statId);
    const buttonPos = statPositions[statId];

    if (buttonPos !== undefined) {
      let desc = [
        `§7${getTranslatedText("current_stats", locale)}: ${currentStatValue}`,
      ];

      // Thêm mô tả chi tiết cho từng chỉ số
      switch (statId) {
        case "strength":
          desc.push(
            `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
              "total_damage",
              locale
            )}`
          );
          break;
        case "health":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue * 2
            } ${getTranslatedText("health_max", locale)}`
          );
          break;
        case "regen":
          desc.push(
            `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
              "regen",
              locale
            )}/s`
          );
          break;
        case "luck":
          desc.push(
            `§7+${
              statConfig.dropChanceMultiplier * currentStatValue
            }% ${getTranslatedText("drop_rate_bonus", locale)}`
          );
          desc.push(
            `§7+${
              statConfig.treasureChanceMultiplier * currentStatValue
            }% ${getTranslatedText("treasure_find_bonus", locale)}`
          );
          break;
        case "intelligence":
          desc.push(
            `§7+${(statConfig.xpMultiplier * 100 * currentStatValue).toFixed(
              1
            )}% ${getTranslatedText("xp_gain_bonus", locale)}`
          );
          desc.push(
            `§7-${(
              statConfig.cooldownReduction *
              100 *
              currentStatValue
            ).toFixed(1)}% ${getTranslatedText("cooldown_reduction", locale)}`
          );
          break;
        case "endurance":
          desc.push(
            `§7+${(statConfig.damageReduction * 100 * currentStatValue).toFixed(
              1
            )}% ${getTranslatedText("armor_reduction", locale)}`
          );
          break;
        case "critical_chance":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue
            }% ${getTranslatedText("critical_chance", locale)}`
          );
          break;
        case "critical_damage":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue
            }% ${getTranslatedText("critical_damage", locale)}`
          );
          break;
        case "speed":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue * 100
            }% ${getTranslatedText("movement_speed", locale)}`
          );
          break;
      }

      Form.button(
        buttonPos,
        `§b${getTranslatedText(
          statConfig.displayNameKey,
          locale
        )} ${currentStatValue}`,
        desc,
        statConfig.icon,
        1,
        true // Nút chỉ số bây giờ có thể nhấp để mở UI điều chỉnh
      );
    }
  }

  // Hiển thị điểm chưa dùng (Top-right)
  Form.button(
    8,
    `§e${getTranslatedText("unspent_points", locale)}: ${unspentPoints}`,
    [],
    "textures/items/experience_bottle",
    1,
    false
  );

  // Nút Đặt lại chỉ số (Middle-bottom, slot 49)
  Form.button(
    49,
    `§c${getTranslatedText("click_to_reset", locale)}`,
    [`§7${getTranslatedText("reset_confirmation_body", locale, 1000)}`],
    "textures/ui/trash",
    1,
    true
  );

  // Nút Quay lại menu chính (Bottom-right, slot 52)
  Form.button(
    53,
    getTranslatedText("back_to_main_menu", locale),
    [],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(player, Form);

  if (!result.canceled) {
    if (result.selection === 49) {
      // Nút Đặt lại chỉ số
      const resetSuccess = await resetAllStats(player);
      if (resetSuccess) {
        showPlayerStatsUI(player); // Tải lại UI sau khi reset
      }
    } else if (result.selection === 53) {
      // Nút Quay lại
      const { Skill } = await import("./main.js");
      Skill(player);
    } else {
      // Xử lý khi người chơi bấm vào nút chỉ số để mở UI điều chỉnh
      let statIdClicked = null;
      for (const statId of statDisplayOrder) {
        if (result.selection === statPositions[statId]) {
          statIdClicked = statId;
          break;
        }
      }

      if (statIdClicked) {
        const initialStatLevel = getPlayerStat(player, statIdClicked);
        const initialUnspentPoints = getPlayerProperty(
          player,
          "stats:unspentPoints"
        );
        // Mở UI điều chỉnh chỉ số mới
        await showStatAdjustmentUI(
          player,
          statIdClicked,
          initialStatLevel,
          initialUnspentPoints,
          initialStatLevel,
          initialUnspentPoints
        );
      }
    }
  }
}

/**
 * Hiển thị giao diện điều chỉnh chỉ số chi tiết.
 * @param {import("@minecraft/server").Player} player
 * @param {string} statId ID của chỉ số đang điều chỉnh.
 * @param {number} originalStatLevel Cấp độ ban đầu của chỉ số khi UI này được mở lần đầu (để xác định giới hạn giảm).
 * @param {number} originalUnspentPoints Số điểm chưa dùng ban đầu khi UI này được mở lần đầu (không dùng trực tiếp trong hàm này, chỉ để tham chiếu).
 * @param {number} currentAdjustedStatLevel Cấp độ chỉ số hiện tại đã được điều chỉnh trong phiên này.
 * @param {number} currentUnspentPoints Số điểm chưa dùng hiện tại đã được điều chỉnh trong phiên này.
 */
export async function showStatAdjustmentUI(
  player,
  statId,
  originalStatLevel,
  originalUnspentPoints, // Giữ lại tham số này nếu bạn muốn hiển thị tổng số điểm ban đầu
  currentAdjustedStatLevel,
  currentUnspentPoints
) {
  const locale = getPlayerLocale(player);
  const statConfig = STATS_CONFIG[statId];
  const Form = new ChestFormData("large");

  Form.title(
    `§r§l§9${getTranslatedText(
      statConfig.displayNameKey,
      locale
    )}: ${currentAdjustedStatLevel}`
  );

  let desc = [
    `§7${getTranslatedText(
      "current_stats",
      locale
    )}: ${currentAdjustedStatLevel}`,
    `§7${getTranslatedText("unspent_points", locale)}: ${currentUnspentPoints}`,
    "", // Khoảng cách
  ];

  for (let i = 0; i < 54; i++) {
    Form.button(i, "", [], "textures/blocks/glass_black");
  }

  // Thêm mô tả chi tiết cho từng chỉ số (tương tự như trong showPlayerStatsUI)
  switch (statId) {
    case "strength":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel
        } ${getTranslatedText("total_damage", locale)}`
      );
      break;
    case "health":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel * 2
        } ${getTranslatedText("health_max", locale)}`
      );
      break;
    case "regen":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel
        } ${getTranslatedText("regen", locale)}/s`
      );
      break;
    case "luck":
      desc.push(
        `§7+${
          statConfig.dropChanceMultiplier * currentAdjustedStatLevel
        }% ${getTranslatedText("drop_rate_bonus", locale)}`
      );
      desc.push(
        `§7+${
          statConfig.treasureChanceMultiplier * currentAdjustedStatLevel
        }% ${getTranslatedText("treasure_find_bonus", locale)}`
      );
      break;
    case "intelligence":
      desc.push(
        `§7+${(
          statConfig.xpMultiplier *
          100 *
          currentAdjustedStatLevel
        ).toFixed(1)}% ${getTranslatedText("xp_gain_bonus", locale)}`
      );
      desc.push(
        `§7-${(
          statConfig.cooldownReduction *
          100 *
          currentAdjustedStatLevel
        ).toFixed(1)}% ${getTranslatedText("cooldown_reduction", locale)}`
      );
      break;
    case "endurance":
      desc.push(
        `§7+${(
          statConfig.damageReduction *
          100 *
          currentAdjustedStatLevel
        ).toFixed(1)}% ${getTranslatedText("armor_reduction", locale)}`
      );
      break;
    case "critical_chance":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel
        }% ${getTranslatedText("critical_chance", locale)}`
      );
      break;
    case "critical_damage":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel
        }% ${getTranslatedText("critical_damage", locale)}`
      );
      break;
    case "speed":
      desc.push(
        `§7+${
          statConfig.multiplier * currentAdjustedStatLevel * 100
        }% ${getTranslatedText("movement_speed", locale)}`
      );
      break;
  }

  // Hiển thị giá trị chỉ số hiện tại và điểm chưa dùng trong UI điều chỉnh
  Form.button(
    4, // Vị trí trung tâm hàng đầu
    `§b${getTranslatedText(statConfig.displayNameKey, locale)}`,
    desc,
    statConfig.icon,
    1,
    false
  );

  // Các nút điều chỉnh (hàng 2)
  // Các nút giảm (-)
  Form.button(
    19, // Vị trí 9 (hàng 2, cột 1)
    "§c-100",
    [
      `§7${getTranslatedText("click_to_add", locale)} -100 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_red",
    1,
    currentAdjustedStatLevel - 100 >= originalStatLevel // Chỉ có thể giảm nếu vẫn lớn hơn hoặc bằng cấp độ ban đầu
  );
  Form.button(
    20, // Vị trí 10 (hàng 2, cột 2)
    "§c-10",
    [
      `§7${getTranslatedText("click_to_add", locale)} -10 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_red",
    1,
    currentAdjustedStatLevel - 10 >= originalStatLevel
  );
  Form.button(
    21, // Vị trí 11 (hàng 2, cột 3)
    "§c-1",
    [
      `§7${getTranslatedText("click_to_add", locale)} -1 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_red",
    1,
    currentAdjustedStatLevel - 1 >= originalStatLevel
  );

  // Các nút tăng (+)
  Form.button(
    23, // Vị trí 15 (hàng 2, cột 7)
    "§a+1",
    [
      `§7${getTranslatedText("click_to_add", locale)} 1 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_green",
    1,
    currentUnspentPoints >= 1 // Chỉ có thể tăng nếu có đủ điểm chưa dùng
  );
  Form.button(
    24, // Vị trí 16 (hàng 2, cột 8)
    "§a+10",
    [
      `§7${getTranslatedText("click_to_add", locale)} 10 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_green",
    1,
    currentUnspentPoints >= 10 // Chỉ có thể tăng nếu có đủ điểm chưa dùng
  );
  Form.button(
    25, // Vị trí 17 (hàng 2, cột 9)
    "§a+100",
    [
      `§7${getTranslatedText("click_to_add", locale)} 100 ${getTranslatedText(
        statConfig.displayNameKey,
        locale
      )}`,
    ],
    "textures/blocks/glass_green",
    1,
    currentUnspentPoints >= 100 // Chỉ có thể tăng nếu có đủ điểm chưa dùng
  );

  // Nút Xác nhận
  Form.button(
    40, // Vị trí giữa hàng 3
    `§2${getTranslatedText("yes_reset", locale)}`, // Tái sử dụng "Có, Đặt lại" cho "Xác nhận"
    [
      `§7${getTranslatedText("click_to_add", locale)} ${
        currentAdjustedStatLevel - originalStatLevel
      } ${getTranslatedText(statConfig.displayNameKey, locale)}`,
    ],
    "textures/ui/confirm",
    1,
    currentAdjustedStatLevel !== originalStatLevel // Chỉ bật nếu có thay đổi
  );

  // Nút Quay lại (không áp dụng thay đổi)
  Form.button(
    53, // Vị trí cuối cùng của hàng 3 (hoặc vị trí khác phù hợp)
    getTranslatedText("back_to_main_menu", locale), // Tái sử dụng "Trở lại menu chính"
    [],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(player, Form);

  if (!result.canceled) {
    let newAdjustedStatLevel = currentAdjustedStatLevel;
    let newUnspentPoints = currentUnspentPoints;
    let allocatedAmount = 0; // Lượng điểm được thêm vào/bớt đi trong thao tác này

    switch (result.selection) {
      case 19: // -100
        allocatedAmount = -100;
        break;
      case 20: // -10
        allocatedAmount = -10;
        break;
      case 21: // -1
        allocatedAmount = -1;
        break;
      case 23: // +1
        allocatedAmount = 1;
        break;
      case 24: // +10
        allocatedAmount = 10;
        break;
      case 25: // +100
        allocatedAmount = 100;
        break;
      case 40: // Nút Xác nhận
        const pointsToCommit = newAdjustedStatLevel - originalStatLevel;
        if (pointsToCommit !== 0) {
          modifyPlayerStat(player, statId, pointsToCommit); // Cập nhật chỉ số thực tế
          setPlayerProperty(player, "stats:unspentPoints", newUnspentPoints); // Cập nhật điểm chưa dùng thực tế
          applyAllStatEffects(player); // Áp dụng lại hiệu ứng
          player.sendMessage(
            `§a${getTranslatedText(
              statConfig.displayNameKey,
              locale
            )} ${getTranslatedText(
              "stat_increased",
              locale,
              originalStatLevel,
              newAdjustedStatLevel
            )}`
          );
        }
        showPlayerStatsUI(player); // Quay lại UI chỉ số chính
        return; // Thoát hàm sau khi xác nhận
      case 53: // Nút Quay lại (không xác nhận)
        showPlayerStatsUI(player); // Quay lại UI chỉ số chính
        return; // Thoát hàm
    }

    if (allocatedAmount !== 0) {
      if (allocatedAmount > 0) {
        // Tăng chỉ số
        const actualAmountToAdd = Math.min(allocatedAmount, newUnspentPoints);
        newAdjustedStatLevel += actualAmountToAdd;
        newUnspentPoints -= actualAmountToAdd;
      } else {
        // Giảm chỉ số
        const actualAmountToRemove = Math.max(
          allocatedAmount,
          originalStatLevel - newAdjustedStatLevel
        ); // Đảm bảo không giảm dưới cấp độ ban đầu
        newAdjustedStatLevel += actualAmountToRemove; // actualAmountToRemove là số âm
        newUnspentPoints -= actualAmountToRemove; // newUnspentPoints sẽ tăng lên
      }
    }

    // Tự động mở lại UI điều chỉnh với các giá trị tạm thời mới
    await showStatAdjustmentUI(
      player,
      statId,
      originalStatLevel,
      originalUnspentPoints,
      newAdjustedStatLevel,
      newUnspentPoints
    );
  } else {
    // Nếu người chơi đóng form, quay lại UI chính mà không áp dụng thay đổi
    showPlayerStatsUI(player);
  }
}

/**
 * Hiển thị giao diện điều chỉnh chỉ số chi tiết cho người chơi mục tiêu (dành cho admin).
 * @param {import("@minecraft/server").Player} adminPlayer Người chơi admin.
 * @param {import("@minecraft/server").Player} targetPlayer Người chơi mục tiêu.
 */
export async function showManagerStatAdjustmentUI(adminPlayer, targetPlayer) {
  const locale = getPlayerLocale(adminPlayer);
  const Form = new ChestFormData("large");
  Form.title(
    `§r${getTranslatedText("manage_stats_for", locale)} ${targetPlayer.name}`
  );

  const statDisplayOrder = [
    "strength",
    "health",
    "regen",
    "luck",
    "intelligence",
    "endurance",
    "critical_chance",
    "critical_damage",
    "speed",
  ];
  const statPositions = {
    strength: 0,
    health: 2,
    regen: 4,
    luck: 6,
    intelligence: 18,
    endurance: 20,
    critical_chance: 22,
    critical_damage: 24,
    speed: 36,
  };

  for (const statId of statDisplayOrder) {
    const statConfig = STATS_CONFIG[statId];
    const currentStatValue = getPlayerStat(targetPlayer, statId);
    const buttonPos = statPositions[statId];

    if (buttonPos !== undefined) {
      let desc = [
        `§7${getTranslatedText("current_stats", locale)}: ${currentStatValue}`,
      ];
      // Thêm mô tả chi tiết cho từng chỉ số (tương tự như showPlayerStatsUI)
      switch (statId) {
        case "strength":
          desc.push(
            `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
              "total_damage",
              locale
            )}`
          );
          break;
        case "health":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue * 2
            } ${getTranslatedText("health_max", locale)}`
          );
          break;
        case "regen":
          desc.push(
            `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
              "regen",
              locale
            )}/s`
          );
          break;
        case "luck":
          desc.push(
            `§7+${
              statConfig.dropChanceMultiplier * currentStatValue
            }% ${getTranslatedText("drop_rate_bonus", locale)}`
          );
          desc.push(
            `§7+${
              statConfig.treasureChanceMultiplier * currentStatValue
            }% ${getTranslatedText("treasure_find_bonus", locale)}`
          );
          break;
        case "intelligence":
          desc.push(
            `§7+${(statConfig.xpMultiplier * 100 * currentStatValue).toFixed(
              1
            )}% ${getTranslatedText("xp_gain_bonus", locale)}`
          );
          desc.push(
            `§7-${(
              statConfig.cooldownReduction *
              100 *
              currentStatValue
            ).toFixed(1)}% ${getTranslatedText("cooldown_reduction", locale)}`
          );
          break;
        case "endurance":
          desc.push(
            `§7+${(statConfig.damageReduction * 100 * currentStatValue).toFixed(
              1
            )}% ${getTranslatedText("armor_reduction", locale)}`
          );
          break;
        case "critical_chance":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue
            }% ${getTranslatedText("critical_chance", locale)}`
          );
          break;
        case "critical_damage":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue
            }% ${getTranslatedText("critical_damage", locale)}`
          );
          break;
        case "speed":
          desc.push(
            `§7+${
              statConfig.multiplier * currentStatValue * 100
            }% ${getTranslatedText("movement_speed", locale)}`
          );
          break;
      }
      Form.button(
        buttonPos,
        `§b${getTranslatedText(
          statConfig.displayNameKey,
          locale
        )} ${currentStatValue}`,
        desc,
        statConfig.icon,
        1,
        true // Cho phép click để điều chỉnh
      );
    }
  }

  // Nút Quay lại
  Form.button(
    53,
    getTranslatedText("back_to_main_menu", locale),
    [],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(adminPlayer, Form);

  if (!result.canceled) {
    if (result.selection === 53) {
      openPlayerSkillManagerUI(adminPlayer, targetPlayer); // Quay lại UI quản lý chính
    } else {
      let statIdClicked = null;
      for (const statId of statDisplayOrder) {
        if (result.selection === statPositions[statId]) {
          statIdClicked = statId;
          break;
        }
      }

      if (statIdClicked) {
        // Mở UI điều chỉnh stat chi tiết cho người chơi mục tiêu
        await showManagerStatDetailAdjustmentUI(
          adminPlayer,
          targetPlayer,
          statIdClicked
        );
      }
    }
  }
}

/**
 * Hiển thị giao diện điều chỉnh chi tiết cho một chỉ số cụ thể của người chơi mục tiêu (dành cho admin).
 * @param {import("@minecraft/server").Player} adminPlayer Người chơi admin.
 * @param {import("@minecraft/server").Player} targetPlayer Người chơi mục tiêu.
 * @param {string} statId ID của chỉ số đang điều chỉnh.
 */
export async function showManagerStatDetailAdjustmentUI(
  adminPlayer,
  targetPlayer,
  statId
) {
  const locale = getPlayerLocale(adminPlayer);
  const statConfig = STATS_CONFIG[statId];
  const Form = new ChestFormData("large");

  let currentStatValue = getPlayerStat(targetPlayer, statId);

  Form.title(
    `§r${getTranslatedText("adjust", locale)} ${getTranslatedText(
      statConfig.displayNameKey,
      locale
    )}: ${currentStatValue}`
  );

  let desc = [
    `§7${getTranslatedText("current_stats", locale)}: ${currentStatValue}`,
    "", // Khoảng cách
  ];

  // Thêm mô tả chi tiết cho từng chỉ số (tương tự như showPlayerStatsUI)
  switch (statId) {
    case "strength":
      desc.push(
        `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
          "total_damage",
          locale
        )}`
      );
      break;
    case "health":
      desc.push(
        `§7+${statConfig.multiplier * currentStatValue * 2} ${getTranslatedText(
          "health_max",
          locale
        )}`
      );
      break;
    case "regen":
      desc.push(
        `§7+${statConfig.multiplier * currentStatValue} ${getTranslatedText(
          "regen",
          locale
        )}/s`
      );
      break;
    case "luck":
      desc.push(
        `§7+${
          statConfig.dropChanceMultiplier * currentStatValue
        }% ${getTranslatedText("drop_rate_bonus", locale)}`
      );
      desc.push(
        `§7+${
          statConfig.treasureChanceMultiplier * currentStatValue
        }% ${getTranslatedText("treasure_find_bonus", locale)}`
      );
      break;
    case "intelligence":
      desc.push(
        `§7+${(statConfig.xpMultiplier * 100 * currentStatValue).toFixed(
          1
        )}% ${getTranslatedText("xp_gain_bonus", locale)}`
      );
      desc.push(
        `§7-${(statConfig.cooldownReduction * 100 * currentStatValue).toFixed(
          1
        )}% ${getTranslatedText("cooldown_reduction", locale)}`
      );
      break;
    case "endurance":
      desc.push(
        `§7+${(statConfig.damageReduction * 100 * currentStatValue).toFixed(
          1
        )}% ${getTranslatedText("armor_reduction", locale)}`
      );
      break;
    case "critical_chance":
      desc.push(
        `§7+${statConfig.multiplier * currentStatValue}% ${getTranslatedText(
          "critical_chance",
          locale
        )}`
      );
      break;
    case "critical_damage":
      desc.push(
        `§7+${statConfig.multiplier * currentStatValue}% ${getTranslatedText(
          "critical_damage",
          locale
        )}`
      );
      break;
    case "speed":
      desc.push(
        `§7+${
          statConfig.multiplier * currentStatValue * 100
        }% ${getTranslatedText("movement_speed", locale)}`
      );
      break;
  }

  Form.button(
    4, // Vị trí trung tâm hàng đầu
    `§b${getTranslatedText(statConfig.displayNameKey, locale)}`,
    desc,
    statConfig.icon,
    1,
    false
  );

  // Các nút điều chỉnh (hàng 2 và 3)
  const amounts = [
    -100000, -10000, -1000, -100, -10, -1, 1, 10, 100, 1000, 10000, 100000,
  ];
  const buttonPositions = [
    9,
    10,
    11,
    12,
    13,
    14, // Row 2
    18,
    19,
    20,
    21,
    22,
    23, // Row 3
  ];

  amounts.forEach((amount, index) => {
    const buttonPos = buttonPositions[index];
    const isNegative = amount < 0;
    const absAmount = Math.abs(amount);
    const color = isNegative ? "§c" : "§a";
    const prefix = isNegative ? "-" : "+";
    // Admin có thể giảm xuống dưới 0, nên chỉ giới hạn nếu giá trị hiện tại là 0 và muốn giảm tiếp
    const isEnabled = !(isNegative && currentStatValue + amount < 0);

    Form.button(
      buttonPos,
      `${color}${prefix}${absAmount}`,
      [
        `§7${getTranslatedText(
          "click_to_adjust_stat",
          locale,
          prefix,
          absAmount
        )}`,
      ],
      isNegative ? "textures/blocks/glass_red" : "textures/blocks/glass_green",
      1,
      isEnabled
    );
  });

  // Nút Quay lại
  Form.button(
    49, // Vị trí dưới cùng giữa
    getTranslatedText("back_to_main_menu", locale),
    [],
    "minecraft:barrier",
    1,
    true
  );

  const result = await ForceOpen(adminPlayer, Form);

  if (!result.canceled) {
    let newStatValue = currentStatValue;
    let statChange = 0;

    switch (result.selection) {
      case 9:
        statChange = -100000;
        break;
      case 10:
        statChange = -10000;
        break;
      case 11:
        statChange = -1000;
        break;
      case 12:
        statChange = -100;
        break;
      case 13:
        statChange = -10;
        break;
      case 14:
        statChange = -1;
        break;
      case 18:
        statChange = 1;
        break;
      case 19:
        statChange = 10;
        break;
      case 20:
        statChange = 100;
        break;
      case 21:
        statChange = 1000;
        break;
      case 22:
        statChange = 10000;
        break;
      case 23:
        statChange = 100000;
        break;
      case 49: // Back button
        showManagerStatAdjustmentUI(adminPlayer, targetPlayer);
        return;
    }

    if (statChange !== 0) {
      newStatValue = Math.max(0, currentStatValue + statChange); // Đảm bảo không âm
      setPlayerProperty(targetPlayer, statConfig.property, newStatValue);
      applyAllStatEffects(targetPlayer); // Áp dụng lại hiệu ứng
      adminPlayer.sendMessage(
        `§aĐã điều chỉnh chỉ số ${getTranslatedText(
          statConfig.displayNameKey,
          locale
        )} cho ${targetPlayer.name} thành ${newStatValue}.`
      );

      // Tải lại UI điều chỉnh stat chi tiết
      await showManagerStatDetailAdjustmentUI(
        adminPlayer,
        targetPlayer,
        statId
      );
    }
  } else {
    // Nếu admin đóng form, quay lại UI quản lý chỉ số
    showManagerStatAdjustmentUI(adminPlayer, targetPlayer);
  }
}
