import {
  world,
  system,
  CommandPermissionLevel,
  CustomCommandStatus,
  Player,
  CustomCommandParamType,
  ItemTypes,
} from "@minecraft/server";

// Import các script chính
import "./main.js";
import "./skills/activeSkill.js";
import "./playerStats.js";
import { Skill, openPlayerSkillManagerUI } from "./main.js"; // Import Skill và hàm mới
import {
  getPlayerProperty,
  setPlayerProperty,
  resetPlayerSkills,
} from "./utils.js"; // Import các hàm tiện ích
import { skillConfig } from "./skillConfig.js"; // Import cấu hình kỹ năng
import {
  STATS_CONFIG,
  getPlayerStat,
  increasePlayerStat,
  applyAllStatEffects,
} from "./playerStats.js"; // Import cấu hình và hàm chỉ số
import { getTranslatedText, getPlayerLocale } from "./lang.js";

const prefix = "!"; // Tiền tố lệnh

/**
 * Tìm cấu hình skill dựa trên một ID hoặc một phần tên.
 * @param {string} inputId ID hoặc một phần ID của skill (case-insensitive).
 * @returns {object|null} Cấu hình skill tìm thấy hoặc null nếu không tìm thấy.
 */
function findSkillConfig(inputId) {
  const lowerInputId = inputId.toLowerCase();
  for (const skillId in skillConfig) {
    if (
      skillId.toLowerCase() === lowerInputId ||
      getTranslatedText(skillConfig[skillId].nameKey, "en_US")
        .toLowerCase()
        .includes(lowerInputId) // Tìm kiếm cả theo tên dịch
    ) {
      return skillConfig[skillId];
    }
  }
  return null;
}

/**
 * Tìm cấu hình chỉ số dựa trên một ID hoặc một phần tên hiển thị.
 * @param {string} inputId ID hoặc một phần ID/tên hiển thị của chỉ số (case-insensitive).
 * @returns {object|null} Cấu hình chỉ số tìm thấy hoặc null nếu không tìm thấy.
 */
function findStatConfig(inputId) {
  const lowerInputId = inputId.toLowerCase();
  for (const statId in STATS_CONFIG) {
    const statConfig = STATS_CONFIG[statId];
    if (
      statId.toLowerCase() === lowerInputId ||
      getTranslatedText(statConfig.displayNameKey, "en_US")
        .toLowerCase()
        .includes(lowerInputId) // Tìm kiếm cả theo tên dịch
    ) {
      return statConfig;
    }
  }
  return null;
}

// Xử lý sự kiện scriptEventReceive (ví dụ: từ /scriptevent)
system.afterEvents.scriptEventReceive.subscribe((event) => {
  const { id, message, sourceEntity: player } = event;
  if (id !== "skill:open" || !(player instanceof Player)) return; // Chỉ xử lý scriptevent có ID 'skill:open' và gửi bởi Player

  if (message.startsWith("skill_ui")) {
    system.run(() => {
      // Chạy trong system.run để tránh lỗi đồng bộ nếu UI được mở ngay lập tức
      Skill(player); // Mở UI kỹ năng chính
    });
  }
});

// Xử lý sự kiện itemUse (khi người chơi dùng một vật phẩm)
world.afterEvents.itemUse.subscribe((event) => {
  let player = event.source;
  // Kiểm tra nếu vật phẩm đang dùng là 'gui:skill'
  if (event.itemStack.typeId === "gui:skill") {
    Skill(player); // Mở UI kỹ năng chính
  }
});

// Đăng ký custom command "/cmd:skill"
system.beforeEvents.startup.subscribe((init) => {
  const skillCommand = {
    name: "cmd:skill",
    description: "Show Skill Menu",
    permissionLevel: CommandPermissionLevel.Any, // Cho phép bất kỳ ai dùng
  };

  init.customCommandRegistry.registerCommand(
    skillCommand,
    ({ sourceEntity }) => {
      const player = sourceEntity;
      if (!player || !(player instanceof Player)) {
        // Đảm bảo người dùng lệnh là người chơi
        return {
          status: CustomCommandStatus.Failure,
          message: "Lệnh này chỉ có thể dùng bởi người chơi.",
        };
      }
      system.run(() => {
        Skill(player); // Gọi hàm mở UI kỹ năng
      });
      return {
        status: CustomCommandStatus.Success,
      };
    }
  );

  const skillManagerCommand = {
    name: "cmd:skillmanager",
    description: "Manage Player Skills and Stats",
    permissionLevel: CommandPermissionLevel.Admin,
    optionalParameters: [
      {
        name: "target",
        type: CustomCommandParamType.String,
        description: "Player name",
      },
    ],
  };

  init.customCommandRegistry.registerCommand(
    skillManagerCommand,
    ({ sourceEntity }, targetPlayerName) => {
      const player = sourceEntity;
      if (!player || !(player instanceof Player)) {
        return {
          status: CustomCommandStatus.Failure,
          message: "Lệnh này chỉ có thể dùng bởi người chơi.",
        };
      }

      if (!targetPlayerName) {
        player.sendMessage("§cUse: /skillmanager <Player Name>");
        return { status: CustomCommandStatus.Failure };
      }

      const matchedPlayers = world
        .getPlayers()
        .filter((p) => p.name.toLowerCase() === targetPlayerName.toLowerCase());

      if (matchedPlayers.length === 0) {
        player.sendMessage(
          `§cKhông tìm thấy người chơi '${targetPlayerName}'.`
        );
        return { status: CustomCommandStatus.Failure };
      }

      if (matchedPlayers.length > 1) {
        player.sendMessage(
          `§cNhiều người chơi trùng tên '${targetPlayerName}'. Vui lòng chỉ định rõ hơn.`
        );
        return { status: CustomCommandStatus.Failure };
      }

      const targetPlayer = matchedPlayers[0];

      system.run(() => {
        openPlayerSkillManagerUI(player, targetPlayer);
        player.sendMessage(
          `§aĐã mở giao diện kỹ năng của '${targetPlayer.name}'.`
        );
      });

      return { status: CustomCommandStatus.Success };
    }
  );
});
