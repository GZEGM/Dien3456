// This is used for set texture on custom items (Doesn't work for custom block)
export const TextureList = {
  "gui:skill": "minecraft:book_writable",
};
