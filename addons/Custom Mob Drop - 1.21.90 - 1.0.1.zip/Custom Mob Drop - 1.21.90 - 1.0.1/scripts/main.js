// THIS ADDON MADE BY DIEN456

// ======================= Imports =======================
import { world, system, ItemStack, Player } from "@minecraft/server";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";

// ================== Constants & State ==================
const DROP_CONFIG_KEY = "mobDropConfig";
let debugLogs = [];

// Default settings cho mỗi entity
const defaultEntitySettings = {
  killDefaultDrops: true, // true by default để loại bỏ item tự nhiên
  showActionBar: false, // true by default để hiển thị thông báo action bar
  addDirectlyToInventory: true, // true by default để thêm trực tiếp vào túi đồ
};

// Dữ liệu dịch thuật cho các ngôn ngữ
const translations = {
  en: {
    mainTitle: "§lMob Drop Manager",
    mainBody: "§7Select an action to perform:",
    addMobDropButton: "Add Mob Drop",
    manageMobDropsButton: "Manage Mob Drops",
    searchItemsButton: "Search Items",
    viewDebugLogButton: "View Debug Log",
    tutorialButton: "Tutorial",
    addMobDropTitle: "§aAdd Mob Drop",
    entityTypeLabel: "§c* Entity type (e.g., minecraft:zombie)",
    displayNameLabel: "Display Name (optional)",
    tagLabel: "Tag (optional)",
    invalidInputData: "§cInvalid input data!",
    configExists: (entityType, name, tag) =>
      `§cDrop configuration for §e${entityType} (Name: ${
        name || "None"
      }, Tag: ${tag || "None"})§c already exists!`,
    dropConfigSaved: (entityType, name, tag) =>
      `§aDrop configuration for ${entityType} (Name: ${name || "None"}, Tag: ${
        tag || "None"
      }) saved successfully.`,
    mobDropListTitle: "Mob Drop List",
    mobDropListBody: "Select a mob to manage:",
    noMobsConfigured: "§cNo mobs configured for drops yet.",
    entityOptionsTitle: (entityType, name, tag) => {
      let title = `§l§bMob: ${entityType}`;
      if (name) title += ` (Name: ${name})`;
      if (tag) title += ` (Tag: ${tag})`;
      return title;
    },
    currentConfig: "§eCurrent configuration:",
    editDropsButton: "Edit Drops",
    testDropsButton: "Test Drops",
    entitySettingsButton: "Entity Settings",
    deleteConfigButton: "Delete Configuration",
    backButton: "Back",
    editQuantityTitle: (entityType, name, tag) => {
      let title = `§lEdit Mob Drop Quantity for ${entityType}`;
      if (name) title += ` (Name: ${name})`;
      if (tag) title += ` (Tag: ${tag})`;
      return title;
    },
    newQuantityLabel: "§fNew number of items:",
    invalidQuantity: "§cInvalid quantity!",
    quantityUpdated: (entityType, name, tag, count) =>
      `§aQuantity for ${entityType} (Name: ${name}, Tag: ${tag}) updated to ${count}.`,
    configDeleted: (entityType, name, tag) =>
      `§cDrop configuration for §b${entityType} (Name: ${name}, Tag: ${tag}) deleted.`,
    itemSelectionTitle: (entityType, name, tag) => {
      let title = `§lEdit Drops for ${entityType}`;
      if (name) title += ` (Name: ${name})`;
      if (tag) title += ` (Tag: ${tag})`;
      return title;
    },
    itemSelectionBody: "Select a drop to edit or add a new one:",
    noItemsConfigured: "§7No drops configured yet. Add a new drop.",
    newItemSlot: "§c[New Drop Slot]",
    editItemTitle: (index) => `§lEdit Drop: ${index}`,
    editItemBody: (itemDisplay) =>
      `What would you like to do with this drop:\n${itemDisplay}`,
    itemDetailTitle: (index, total) => `§aItem ${index}/${total}`,
    editItemDetailsButton: "Edit Drop Details",
    duplicateItemButton: "Duplicate Drop", // NEW
    deleteItemButton: "§cDelete Drop",
    backToItemSelectionButton: "Back to Drop Selection",
    confirmDeleteTitle: "§cWarning",
    confirmDeleteBody: (itemDisplayName) =>
      `Are you sure you want to delete "${itemDisplayName}"?`,
    deleteButton: "§cDelete",
    cancelButton: "Cancel",
    itemDeleted: (itemDisplayName, entityType) =>
      `§cDrop "${itemDisplayName}" deleted from ${entityType}.`,
    confirmDeleteConfigBody: (displayName) =>
      `§eAre you sure you want to §cdelete§e the drop configuration for mob ${displayName}§e?`,
    debugLogsTitle: "§bDebug Logs",
    noLogs: "§7(No logs available)",
    recentLogs: "§fRecent:",
    clearButton: "Clear",
    refreshButton: "Refresh",
    exitButton: "Exit",
    logCleared: "§a[Debug] Log cleared.",
    settingsTitle: (entityType, name, tag) => {
      let title = `§lSettings for ${entityType}`;
      if (name) title += ` (Name: ${name})`;
      if (tag) title += ` (Tag: ${tag})`;
      return title;
    },
    entityTypeReadOnly: "§fEntity Type (Read-only):",
    newDisplayNameLabel: "§fNew Display Name (optional):",
    newTagLabel: "§fNew Tag (optional):",
    killDefaultDropsLabel: "§fEnable/disable default mob drops:",
    showActionBarLabel: "§fShow Action Bar notifications:",
    addDirectlyToInventoryLabel:
      "§fAdd directly to inventory (vs. spawn on ground):",
    configMoveError: (entityType, newDisplayName, newTag) =>
      `§cError: A configuration for ${entityType} (Name: ${
        newDisplayName || "None"
      }, Tag: ${
        newTag || "None"
      }) already exists. Please choose a different name/tag combination.`,
    configMoved: (entityType, newDisplayName, newTag) =>
      `§aConfiguration for ${entityType} moved to new key (Name: ${
        newDisplayName || "None"
      }, Tag: ${newTag || "None"}).`,
    settingsSaved: "§aSettings have been saved.",
    noConfigFound: (titleDisplay) =>
      `§cError: No configuration found for ${titleDisplay}.`,
    testDropsTitle: (entityType, name, tag) => {
      let title = `§aTesting drops for ${entityType}`;
      if (name) title += ` (Name: ${name})`;
      if (tag) title += ` (Tag: ${tag})`;
      return title;
    },
    noDropsConfigured: (titleDisplay) =>
      `§cNo drops configured for ${titleDisplay}.`,
    invalidDropConfig: (dropType, identifier) =>
      `§c[Error] Invalid drop config for "${dropType || "Unknown Type"}" (${
        identifier || "Unknown"
      }).`,
    spawnedItem: (amount, displayName, chance) =>
      `§aSpawned: ${amount}x ${displayName} (Chance: ${chance}%)`,
    failedToSpawn: (itemId, message) =>
      `§c[Error] Failed to spawn item "${itemId || "Unknown"}" - ${message}`,
    inventoryFull: (displayName) =>
      `§cInventory full, dropped ${displayName} at mob's death location.`,
    tutorialTitleEN: "§l§bMob Drop Manager Tutorial",
    tutorialBodyEN:
      "§fWelcome to the Mob Drop Manager!\n\n" +
      "This addon allows you to customize what items mobs drop when killed. Here's how to use it:\n\n" +
      "§e1. Add Mob Drop:§f Configure new drop rules for entities.\n" +
      "   - You can specify an §aEntity Type§f (e.g., `minecraft:zombie`).\n" +
      "   - Optionally, add a §aDisplay Name§f (e.g., `Custom Zombie`) for named mobs.\n" +
      "   - Optionally, add a §aTag§f (e.g., `boss`) for mobs with specific tags.\n" +
      "   - Define drop details (ID, quantity, chance, lore, or scoreboard/command details).\n\n" +
      "§e2. Manage Mob Drops:§f View, edit, or delete existing configurations.\n" +
      "   - Select an entity to modify its drops or settings.\n\n" +
      "§e3. Entity Settings:§f Adjust options like disabling default drops, showing action bar notifications, or §aforcing items to drop on the ground§f instead of adding to inventory.\n\n" +
      "§e4. Drop Priority Rules:§f\n" +
      "   - The system looks for the most specific drop rule first.\n" +
      "   - Rules configured for a specific §aName§f or §aTag§f will always take priority.\n" +
      "   - A configuration with §eonly Entity Type§f (no Name/Tag) acts as a **default drop** for all mobs of that type, §cUNLESS§f they match a more specific Name or Tag configuration that you have created. If a mob has a Name or Tag but you haven't set up a specific drop for it, it will fall back to the general Type drop if one exists.",
    gotItButton: "Got it!",
    tutorialTitleVI: "§l§bHướng Dẫn Quản Lý Item Rơi từ Mob",
    tutorialBodyVI:
      "§fChào mừng bạn đến với Hệ Thống Quản Lý Item Rơi từ Mob!\n\n" +
      "Addon này cho phép bạn tùy chỉnh các vật phẩm mà mob sẽ rơi ra khi bị tiêu diệt. Dưới đây là cách sử dụng:\n\n" +
      "§e1. Thêm Item Rơi:§f Cấu hình các quy tắc rơi đồ mới cho các thực thể.\n" +
      "   - Bạn có thể chỉ định §aLoại thực thể§f (ví dụ: `minecraft:zombie`).\n" +
      "   - Tùy chọn, thêm §aTên hiển thị§f (ví dụ: `Zombie Tùy Chỉnh`) cho các mob có tên.\n" +
      "   - Tùy chọn, thêm §aThẻ (Tag)§f (ví dụ: `boss`) cho các mob có tag cụ thể.\n" +
      "   - Định nghĩa chi tiết vật phẩm (ID, số lượng, tỉ lệ, mô tả, hoặc chi tiết scoreboard/lệnh).\n\n" +
      "§e2. Quản Lý Item Rơi:§f Xem, chỉnh sửa hoặc xóa các cấu hình hiện có.\n" +
      "   - Chọn một thực thể để sửa đổi các item rơi hoặc cài đặt của nó.\n\n" +
      "§e3. Cài Đặt Thực Thể:§f Điều chỉnh các tùy chọn như tắt item rơi mặc định, hiển thị thông báo trên thanh hành động, hoặc §abuộc vật phẩm rơi ra đất§f thay vì thêm vào túi đồ.\n\n" +
      "§e4. Quy Tắc Ưu Tiên Item Rơi:§f\n" +
      "   - Hệ thống sẽ tìm kiếm quy tắc rơi đồ cụ thể nhất trước.\n" +
      "   - Các quy tắc được cấu hình cho §aTên§f hoặc §aThẻ (Tag)§f cụ thể sẽ luôn được ưu tiên cao hơn.\n" +
      "   - Một cấu hình §echỉ có Loại Thực Thể§f (không Tên/Thẻ) sẽ hoạt động như một quy tắc **rơi mặc định** cho tất cả mob cùng loại đó, §cTRỪ KHI§f chúng khớp với một cấu hình Tên hoặc Thẻ cụ thể hơn mà bạn đã tạo. Nếu một mob có Tên hoặc Thẻ nhưng bạn chưa thiết lập drop riêng cho nó, nó sẽ quay về sử dụng drop của cấu hình Loại chung (nếu có).",
    understoodButton: "Đã hiểu!",
    itemSearchTitle: "§bSearch Items",
    itemSearchPrompt: "Enter Item ID, Display Name, or Lore (partial match):",
    itemSearchCanceled: "§cItem search canceled!",
    noMatchingItems: "§cNo matching items found in configurations.",
    searchResultTitle: "§bSearch Results",
    itemFoundIn: (entityType, name, tag) => {
      let text = `Found in: ${entityType}`;
      if (name) text += ` (Name: ${name})`;
      if (tag) text += ` (Tag: ${tag})`;
      return text;
    },
    inventory_full_or_slot_issue: (itemId) =>
      `Inventory full or slot issue, dropped ${itemId} at mob's death location.`,
    fillBlanks: "§cVui lòng điền đầy đủ thông tin!",
    dropTypeLabel: "§c* Select Drop Type:",
    itemTypeOption: "Item Drop",
    scoreboardTypeOption: "Scoreboard Drop",
    commandTypeOption: "Command Drop",
    itemIdLabel: "§c* Item ID (e.g., minecraft:diamond)",
    itemDisplayNameLabel: "Display Name (optional)",
    minMaxQuantityLabel: "§c* Min-Max quantity (e.g., 1 3)",
    loreLabel: "Lore (lines separated by \\n)",
    dropChanceLabel: "§c* Drop Chance (0 - 100)",
    invalidItemInput: "§cVui lòng nhập đầy đủ và hợp lệ ID, số lượng, tỉ lệ!",
    itemSaved: (index, entityType, name, tag) =>
      `§aItem ${index} for ${entityType} (Name: ${name || "None"}, Tag: ${
        tag || "None"
      }) saved.`,
    scoreboardObjectiveLabel: "§c* Scoreboard Objective (e.g., money)",
    scoreboardActionLabel: "§c* Action:",
    scoreboardActionAdd: "Add",
    scoreboardActionSet: "Set",
    scoreboardActionRemove: "Remove",
    minMaxValueLabel: "§c* Min-Max Value (e.g., 10 50)",
    invalidScoreboardInput:
      "§cVui lòng nhập đầy đủ và hợp lệ Objective, Giá trị, Tỉ lệ!",
    scoreboardSaved: (index, entityType, name, tag) =>
      `§aScoreboard ${index} for ${entityType} (Name: ${name || "None"}, Tag: ${
        tag || "None"
      }) saved.`,
    commandLabel: "§c* Command (e.g., give @p diamond)",
    invalidCommandInput: "§cVui lòng nhập đầy đủ và hợp lệ Lệnh, Tỉ lệ!",
    commandSaved: (index, entityType, name, tag) =>
      `§aCommand ${index} for ${entityType} (Name: ${name || "None"}, Tag: ${
        tag || "None"
      }) saved.`,
    dropDuplicated: (displayName) => `§aDrop "${displayName}" duplicated!`,
  },
};

// Hàm lấy ngôn ngữ của người chơi (placeholder, cần được triển khai nếu có hệ thống ngôn ngữ người chơi)
function getPlayerLocale(player) {
  // Hiện tại chỉ trả về 'en', bạn có thể tích hợp hệ thống ngôn ngữ người chơi ở đây
  return "en";
}

// Hàm lấy chuỗi dịch thuật (sử dụng getPlayerLocale)
function getTranslatedText(key, locale, ...args) {
  const lang = locale || "en";
  const translation =
    translations[lang] && translations[lang][key]
      ? translations[lang][key]
      : translations.en[key];
  if (typeof translation === "function") {
    return translation(...args);
  }
  return translation;
}

// Hàm để thêm vật phẩm vào túi đồ của người chơi hoặc spawn ra đất nếu không thể
function tryAddItemToPlayerInventory(player, mob, itemStackToAdd, key) {
  if (!itemStackToAdd || itemStackToAdd.amount <= 0) return true;

  const inventoryComponent = player.getComponent("minecraft:inventory");
  if (!inventoryComponent || !inventoryComponent.container) {
    console.warn(
      `Lỗi: Không tìm thấy component inventory cho người chơi ${player.name}. Item ${itemStackToAdd.typeId} sẽ được spawn.`
    );
    player.dimension.spawnItem(itemStackToAdd, player.location);
    return false;
  }

  const container = inventoryComponent.container;
  let remainingAmount = itemStackToAdd.amount;

  // 1. Gộp vào các stack hiện có
  for (let i = 0; i < container.size; i++) {
    const slot = container.getItem(i);
    if (
      slot &&
      slot.typeId === itemStackToAdd.typeId &&
      slot.isStackable &&
      slot.maxAmount > 1 &&
      // So sánh lore và nameTag một cách an toàn
      (slot.getLore()?.toString() || "") ===
        (itemStackToAdd.getLore()?.toString() || "") &&
      (slot.nameTag || "") === (itemStackToAdd.nameTag || "")
    ) {
      const canAdd = slot.maxAmount - slot.amount;
      if (canAdd > 0) {
        const addAmount = Math.min(remainingAmount, canAdd);
        slot.amount += addAmount;
        container.setItem(i, slot);
        remainingAmount -= addAmount;
        if (remainingAmount <= 0) return true;
      }
    }
  }

  // 2. Thêm vào các slot trống
  for (let i = 0; i < container.size; i++) {
    const slot = container.getItem(i);
    if (!slot) {
      // Tạo một bản sao của itemStackToAdd để tránh sửa đổi bản gốc
      const newStack = itemStackToAdd.clone();
      newStack.amount = remainingAmount; // Đặt số lượng còn lại
      container.setItem(i, newStack);
      return true;
    }
  }

  // 3. Nếu không thể thêm, spawn ra ngoài

  let item = player.dimension.spawnItem(itemStackToAdd, mob.location);
  item.addTag(`drop_${key}`);
  return false;
}

// ================== Register Dynamic Property ==================
system.run(() => {
  try {
    world.propertyRegistry.registerWorldDynamicProperty(
      DROP_CONFIG_KEY,
      "string"
    );
  } catch (e) {
    // Property might already be registered in multi-load scenarios
  }
});

// ================== Utility Functions for Config Keys ==================

/**
 * Tạo một khóa duy nhất cho entity dựa trên type, name và tag.
 * @param {string} entityType
 * @param {string} [name=""]
 * @param {string} [tag=""]
 * @returns {string} Khóa định danh entity.
 */
function generateEntityKey(entityType, name = "", tag = "") {
  // Chuẩn hóa name và tag để tránh lỗi khi dùng làm key
  const safeName = name.trim().replace(/#/g, "##"); // Thay thế # để không xung đột với dấu phân cách
  const safeTag = tag.trim().replace(/#/g, "##");
  return `${entityType}#${safeName}#${safeTag}`;
}

/**
 * Phân tích khóa entity thành type, name và tag.
 * @param {string} entityKey
 * @returns {{entityType: string, name: string, tag: string}}
 */
function parseEntityKey(entityKey) {
  const parts = entityKey.split("#");
  const entityType = parts[0];
  let name = "";
  let tag = "";

  if (parts.length > 1) {
    name = parts[1].replace(/##/g, "#"); // Khôi phục lại # nếu có
  }
  if (parts.length > 2) {
    tag = parts[2].replace(/##/g, "#");
  }

  return { entityType, name, tag };
}

/**
 * Lấy toàn bộ cấu hình drop.
 * Đảm bảo mỗi entity có cấu trúc hợp lệ với cài đặt mặc định nếu chưa có.
 * @returns {object} Toàn bộ cấu hình drop.
 */
function getDropConfig() {
  const raw = world.getDynamicProperty(DROP_CONFIG_KEY);
  const config = raw ? JSON.parse(raw) : {};
  const newConfig = {}; // Cấu hình mới sau khi chuẩn hóa

  for (const entityKey in config) {
    const entityData = config[entityKey];
    let actualKey = entityKey;
    let currentSettings = { ...defaultEntitySettings };
    let currentDrops = [];

    // Kiểm tra và chuyển đổi cấu trúc cũ sang mới nếu cần
    if (!entityData.settings || !entityData.drops) {
      // Đây là cấu trúc cũ: config[entityType] = [drops array]
      currentDrops = entityData;
    } else {
      // Đây là cấu trúc mới
      currentSettings = { ...defaultEntitySettings, ...entityData.settings };
      currentDrops = entityData.drops;
    }

    // Đảm bảo các khóa entity được chuẩn hóa sang định dạng mới (entityType#name#tag)
    // Nếu key không chứa #name#tag, thì coi là name="" và tag=""
    if (!entityKey.includes("#")) {
      actualKey = generateEntityKey(entityKey, "", "");
    }

    newConfig[actualKey] = {
      settings: currentSettings,
      drops: currentDrops,
    };
  }
  return newConfig;
}

/**
 * Lưu toàn bộ cấu hình drop.
 * @param {object} config - Toàn bộ cấu hình drop để lưu.
 */
function setDropConfig(config) {
  world.setDynamicProperty(DROP_CONFIG_KEY, JSON.stringify(config));
}

// ================== Main Menu Trigger ==================
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  if (!item || item.typeId !== "item:mob_drop") return;

  const form = new ActionFormData()
    .title(getTranslatedText("mainTitle", getPlayerLocale(player)))
    .body(getTranslatedText("mainBody"))
    .button(getTranslatedText("addMobDropButton", getPlayerLocale(player)))
    .button(getTranslatedText("manageMobDropsButton", getPlayerLocale(player)))
    .button(getTranslatedText("searchItemsButton", getPlayerLocale(player)))
    .button(getTranslatedText("viewDebugLogButton", getPlayerLocale(player)))
    .button(getTranslatedText("tutorialButton", getPlayerLocale(player)));

  form.show(player).then((res) => {
    if (res.canceled) return;
    switch (res.selection) {
      case 0:
        openAddEntityForm(player);
        break;
      case 1:
        openDropManagerUI(player);
        break;
      case 2:
        openItemSearchForm(player);
        break;
      case 3:
        openDebugLogForm(player);
        break;
      case 4:
        openLanguageSelectionForm(player);
        break;
    }
  });
});

// ================== FORM: Add New Mob Drop ==================
function openAddEntityForm(player) {
  const form = new ModalFormData()
    .title(getTranslatedText("addMobDropTitle", getPlayerLocale(player)))
    .textField(
      getTranslatedText("entityTypeLabel", getPlayerLocale(player)),
      "minecraft:zombie"
    )
    .textField(
      getTranslatedText("displayNameLabel", getPlayerLocale(player)),
      ""
    )
    .textField(getTranslatedText("tagLabel", getPlayerLocale(player)), "")
    .toggle(
      getTranslatedText("killDefaultDropsLabel", getPlayerLocale(player)),
      { defaultValue: true }
    )
    .toggle(getTranslatedText("showActionBarLabel", getPlayerLocale(player)))
    .toggle(
      getTranslatedText("addDirectlyToInventoryLabel", getPlayerLocale(player))
    );

  form.show(player).then((res) => {
    if (res.cancelationReason === "UserBusy") return openAddEntityForm(player);
    if (res.canceled) return;

    const [
      entityType,
      entityName,
      entityTag,
      killDefaultDrops,
      showActionBar,
      addDirectlyToInventory,
    ] = res.formValues;

    const entityKey = generateEntityKey(entityType, entityName, entityTag);

    const config = getDropConfig();

    if (!entityType) {
      player.sendMessage(
        getTranslatedText("invalidInputData", getPlayerLocale(player))
      );
      return;
    }

    if (config[entityKey]) {
      const { name, tag } = parseEntityKey(entityKey);
      player.sendMessage(
        getTranslatedText(
          "configExists",
          getPlayerLocale(player),
          entityType,
          name,
          tag
        )
      );
      return;
    }

    const newEntityData = {
      settings: {
        killDefaultDrops: killDefaultDrops,
        showActionBar: showActionBar,
        addDirectlyToInventory: addDirectlyToInventory,
      },
      drops: [], // Start with an empty drops array
    };

    config[entityKey] = newEntityData;
    setDropConfig(config);

    // After creating the entity config, go directly to drop selection
    openDropItemSelectionForm(player, entityKey, newEntityData.drops);
  });
}

// ================== FORM: Drop Type Selection ==================
function openDropTypeSelectionForm(
  player,
  entityKey,
  currentItems,
  itemIndex,
  isEdit = false
) {
  const form = new ActionFormData()
    .title(
      getTranslatedText("editItemTitle", getPlayerLocale(player), itemIndex + 1)
    )
    .body(getTranslatedText("dropTypeLabel", getPlayerLocale(player)))
    .button(getTranslatedText("itemTypeOption", getPlayerLocale(player)))
    .button(getTranslatedText("scoreboardTypeOption", getPlayerLocale(player)))
    .button(getTranslatedText("commandTypeOption", getPlayerLocale(player)))
    .button(getTranslatedText("backToItemSelectionButton", player));

  form.show(player).then((res) => {
    if (res.canceled || res.selection === 3) {
      // Back button or canceled
      openDropItemSelectionForm(player, entityKey, currentItems);
      return;
    }

    const selectedType = res.selection; // 0: Item, 1: Scoreboard, 2: Command

    if (selectedType === 0) {
      openItemDropForm(player, entityKey, currentItems, itemIndex, isEdit);
    } else if (selectedType === 1) {
      openScoreboardDropForm(
        player,
        entityKey,
        currentItems,
        itemIndex,
        isEdit
      );
    } else if (selectedType === 2) {
      openCommandDropForm(player, entityKey, currentItems, itemIndex, isEdit);
    }
  });
}

// ================== FORMS: Specific Drop Types ==================

function openItemDropForm(
  player,
  entityKey,
  currentItems,
  currentItemIndex,
  isEdit = false
) {
  const existing = currentItems[currentItemIndex] || {};
  const form = new ModalFormData()
    .title(
      getTranslatedText(
        "itemDetailTitle",
        getPlayerLocale(player),
        currentItemIndex + 1,
        currentItems.length
      )
    )
    .textField(getTranslatedText("itemIdLabel", getPlayerLocale(player)), "", {
      defaultValue: existing.itemId || "",
    })
    .textField(
      getTranslatedText("itemDisplayNameLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue: existing.displayName || "",
      }
    )
    .textField(
      getTranslatedText("minMaxQuantityLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue:
          existing.min && existing.max ? `${existing.min} ${existing.max}` : "",
      }
    )
    .textField(getTranslatedText("loreLabel", getPlayerLocale(player)), "", {
      defaultValue: (existing.lore || []).join("\\n"),
    })
    .textField(
      getTranslatedText("dropChanceLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue: existing.chance?.toString() || "",
      }
    );

  form.show(player).then((res) => {
    if (res.canceled) {
      openDropItemSelectionForm(player, entityKey, currentItems);
      return;
    }

    const [itemId, displayName, rangeStr, loreStr, chanceStr] = res.formValues;
    const [minStr, maxStr] = (rangeStr || "").split(" ");
    const min = parseInt(minStr);
    const max = parseInt(maxStr);
    const chance = parseFloat(chanceStr);
    const loreLines = loreStr ? loreStr.split("\\n") : [];

    if (
      !itemId ||
      isNaN(min) ||
      isNaN(max) ||
      isNaN(chance) ||
      min <= 0 ||
      max <= 0 ||
      min > max ||
      chance < 0 ||
      chance > 100
    ) {
      player.sendMessage(
        getTranslatedText("invalidItemInput", getPlayerLocale(player))
      );
      return openItemDropForm(
        player,
        entityKey,
        currentItems,
        currentItemIndex,
        true
      );
    }

    currentItems[currentItemIndex] = {
      type: "item",
      itemId,
      displayName: displayName?.trim() || "",
      min,
      max,
      chance,
      lore: loreLines,
    };

    const config = getDropConfig();
    config[entityKey].drops = currentItems;
    setDropConfig(config);
    const { entityType, name, tag } = parseEntityKey(entityKey);
    player.sendMessage(
      getTranslatedText(
        "itemSaved",
        getPlayerLocale(player),
        currentItemIndex + 1,
        entityType,
        name,
        tag
      )
    );

    openDropItemSelectionForm(player, entityKey, currentItems);
  });
}

function openScoreboardDropForm(
  player,
  entityKey,
  currentItems,
  currentItemIndex,
  isEdit = false
) {
  const existing = currentItems[currentItemIndex] || {};
  const form = new ModalFormData()
    .title(
      getTranslatedText(
        "editItemTitle",
        getPlayerLocale(player),
        currentItemIndex + 1
      )
    )
    .textField(
      getTranslatedText("scoreboardObjectiveLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue: existing.objective || "",
      }
    )
    .dropdown(
      getTranslatedText("scoreboardActionLabel", getPlayerLocale(player)),
      [
        getTranslatedText("scoreboardActionAdd", getPlayerLocale(player)),
        getTranslatedText("scoreboardActionSet", getPlayerLocale(player)),
        getTranslatedText("scoreboardActionRemove", getPlayerLocale(player)),
      ],
      {
        defaultValue:
          existing.action === "set" ? 1 : existing.action === "remove" ? 2 : 0,
      } // Default to Add
    )
    .textField(
      getTranslatedText("minMaxValueLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue:
          existing.valueMin && existing.valueMax
            ? `${existing.valueMin} ${existing.valueMax}`
            : "",
      }
    )
    .textField(
      getTranslatedText("dropChanceLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue: existing.chance?.toString() || "",
      }
    );

  form.show(player).then((res) => {
    if (res.canceled) {
      openDropItemSelectionForm(player, entityKey, currentItems);
      return;
    }

    const [objective, actionIndex, valueRangeStr, chanceStr] = res.formValues;
    const [minStr, maxStr] = (valueRangeStr || "").split(" ");
    const valueMin = parseInt(minStr);
    const valueMax = parseInt(maxStr);
    const chance = parseFloat(chanceStr);

    const actionMap = ["add", "set", "remove"];
    const action = actionMap[actionIndex];

    if (
      !objective ||
      isNaN(valueMin) ||
      isNaN(valueMax) ||
      isNaN(chance) ||
      valueMin < 0 ||
      valueMax < valueMin ||
      chance < 0 ||
      chance > 100
    ) {
      player.sendMessage(
        getTranslatedText("invalidScoreboardInput", getPlayerLocale(player))
      );
      return openScoreboardDropForm(
        player,
        entityKey,
        currentItems,
        currentItemIndex,
        true
      );
    }

    currentItems[currentItemIndex] = {
      type: "scoreboard",
      objective: objective.trim(),
      action: action,
      valueMin: valueMin,
      valueMax: valueMax,
      chance: chance,
    };

    const config = getDropConfig();
    config[entityKey].drops = currentItems;
    setDropConfig(config);
    const { entityType, name, tag } = parseEntityKey(entityKey);
    player.sendMessage(
      getTranslatedText(
        "scoreboardSaved",
        getPlayerLocale(player),
        currentItemIndex + 1,
        entityType,
        name,
        tag
      )
    );

    openDropItemSelectionForm(player, entityKey, currentItems);
  });
}

function openCommandDropForm(
  player,
  entityKey,
  currentItems,
  currentItemIndex,
  isEdit = false
) {
  const existing = currentItems[currentItemIndex] || {};
  const form = new ModalFormData()
    .title(
      getTranslatedText(
        "editItemTitle",
        getPlayerLocale(player),
        currentItemIndex + 1
      )
    )
    .textField(getTranslatedText("commandLabel", getPlayerLocale(player)), "", {
      defaultValue: existing.command || "",
    })
    .textField(
      getTranslatedText("dropChanceLabel", getPlayerLocale(player)),
      "",
      {
        defaultValue: existing.chance?.toString() || "",
      }
    );

  form.show(player).then((res) => {
    if (res.canceled) {
      openDropItemSelectionForm(player, entityKey, currentItems);
      return;
    }

    const [command, chanceStr] = res.formValues;
    const chance = parseFloat(chanceStr);

    if (!command || isNaN(chance) || chance < 0 || chance > 100) {
      player.sendMessage(
        getTranslatedText("invalidCommandInput", getPlayerLocale(player))
      );
      return openCommandDropForm(
        player,
        entityKey,
        currentItems,
        currentItemIndex,
        true
      );
    }

    currentItems[currentItemIndex] = {
      type: "command",
      command: command.trim(),
      chance: chance,
    };

    const config = getDropConfig();
    config[entityKey].drops = currentItems;
    setDropConfig(config);
    const { entityType, name, tag } = parseEntityKey(entityKey);
    player.sendMessage(
      getTranslatedText(
        "commandSaved",
        getPlayerLocale(player),
        currentItemIndex + 1,
        entityType,
        name,
        tag
      )
    );

    openDropItemSelectionForm(player, entityKey, currentItems);
  });
}

// ================== Mob Death Drop Handling ==================
world.afterEvents.entityDie.subscribe((event) => {
  const { deadEntity, damageSource } = event;
  const killer = damageSource.damagingEntity;
  // Removed the 'if (!(killer instanceof Player)) return;' line
  // This allows the logic to proceed even if the killer is not a player.

  if (!(killer instanceof Player)) return;

  const config = getDropConfig();
  const entityType = deadEntity.typeId;
  const entityName = deadEntity.nameTag || "";
  const entityTags = deadEntity.getTags();

  let entityConfig = null;
  let matchedKey = null;

  // --- PRIORITY MATCHING LOGIC STARTS ---

  // 1. Highest priority: Match Type + Name + ALL Tags
  const exactTagKey = generateEntityKey(
    entityType,
    entityName,
    entityTags.sort().join(",")
  );
  if (config[exactTagKey]) {
    entityConfig = config[exactTagKey];
    matchedKey = exactTagKey;
  }

  // 2. Next: Match Type + Name (regardless of tags)
  if (!entityConfig && entityName) {
    const nameOnlyKey = generateEntityKey(entityType, entityName, "");
    if (config[nameOnlyKey]) {
      entityConfig = config[nameOnlyKey];
      matchedKey = nameOnlyKey;
    }
  }

  // 3. Next: Match Type + any single Tag
  if (!entityConfig && entityTags.length > 0) {
    for (const tag of entityTags) {
      const tagOnlyKey = generateEntityKey(entityType, "", tag);
      if (config[tagOnlyKey]) {
        entityConfig = config[tagOnlyKey];
        matchedKey = tagOnlyKey;
        break;
      }
    }
  }

  // 4. Fallback: Match Type only
  if (!entityConfig) {
    const typeOnlyKey = generateEntityKey(entityType, "", "");
    if (config[typeOnlyKey]) {
      entityConfig = config[typeOnlyKey];
      matchedKey = typeOnlyKey;
    }
  }

  // --- PRIORITY MATCHING LOGIC ENDS ---

  if (!entityConfig || !entityConfig.drops || entityConfig.drops.length === 0)
    return;

  const dropList = entityConfig.drops;
  const settings = entityConfig.settings || { ...defaultEntitySettings };

  const key = `${deadEntity.typeId}_${Math.floor(Date.now() % 100000)}`;

  for (const drop of dropList) {
    if (Math.random() * 100 > drop.chance) continue;

    try {
      if (drop.type === "item") {
        if (
          !drop ||
          typeof drop.itemId !== "string" ||
          drop.itemId.trim() === "" ||
          typeof drop.min !== "number" ||
          typeof drop.max !== "number" ||
          drop.min < 0 ||
          drop.max < drop.min ||
          (drop.lore && !Array.isArray(drop.lore))
        ) {
          DebugLog(
            `§c[DROP ERROR] Skipping item drop for ${
              deadEntity.typeId
            } (Key: ${matchedKey}): Invalid item drop structure → ${JSON.stringify(
              drop
            )}`
          );
          // Only send message to player if killer is a player
          if (killer instanceof Player) {
            killer.sendMessage(
              getTranslatedText(
                "invalidDropConfig",
                getPlayerLocale(killer),
                "Item",
                drop.itemId || "Unknown"
              )
            );
          }
          continue;
        }

        const amount =
          Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min;
        const item = new ItemStack(drop.itemId, amount);
        item.setLore(drop.lore);
        if (drop.displayName && drop.displayName.trim() !== "") {
          item.nameTag = `§r${drop.displayName}`;
        }

        const display = item.nameTag || drop.itemId;

        // Modified logic: Add to inventory only if killer is a Player AND settings allow
        if (killer instanceof Player && settings.addDirectlyToInventory) {
          const addedSuccessfully = tryAddItemToPlayerInventory(
            killer,
            deadEntity,
            item,
            key
          );
          if (addedSuccessfully) {
            if (settings.showActionBar) {
              killer.onScreenDisplay.setActionBar(`§a+${amount} ${display}`);
            }
            DebugLog(`§b${killer.name}§r received §c${amount} ${display}§r`);
          } else {
            // If inventory is full, drop on ground instead
            const dropPosition = deadEntity.location;
            const droppedItem = deadEntity.dimension.spawnItem(
              item,
              dropPosition
            );
            droppedItem?.addTag(`drop_${key}`); // Still add tag for cleaning up default drops

            if (droppedItem) {
              DebugLog(
                `§eDropped ${amount} ${display} on ground (Inventory Full for ${killer.name})`
              );
              if (settings.showActionBar) {
                killer.onScreenDisplay.setActionBar(
                  `§eDropped ${amount} ${display}`
                );
              }
            }
          }
        } else {
          // If killer is not a player, or settings don't allow direct add, always spawn on ground
          const dropPosition = deadEntity.location;
          const droppedItem = deadEntity.dimension.spawnItem(
            item,
            dropPosition
          );
          droppedItem?.addTag(`drop_${key}`);

          if (droppedItem) {
            DebugLog(
              `§eDropped ${amount} ${display} on ground (Killer: ${
                killer instanceof Player ? killer.name : killer.typeId
              })`
            );
            // Only show action bar if killer is a Player
            if (killer instanceof Player && settings.showActionBar) {
              killer.onScreenDisplay.setActionBar(
                `§eDropped ${amount} ${display}`
              );
            }
          }
        }
      } else if (drop.type === "scoreboard") {
        // Skip scoreboard drops if killer is not a Player
        if (!(killer instanceof Player)) continue;

        if (
          !drop ||
          typeof drop.objective !== "string" ||
          drop.objective.trim() === "" ||
          typeof drop.action !== "string" ||
          !["add", "set", "remove"].includes(drop.action) ||
          typeof drop.valueMin !== "number" ||
          typeof drop.valueMax !== "number" ||
          drop.valueMin < 0 ||
          drop.valueMax < drop.valueMin
        ) {
          DebugLog(
            `§c[DROP ERROR] Skipping scoreboard drop for ${
              deadEntity.typeId
            } (Key: ${matchedKey}): Invalid scoreboard drop structure → ${JSON.stringify(
              drop
            )}`
          );
          killer.sendMessage(
            getTranslatedText(
              "invalidDropConfig",
              getPlayerLocale(killer),
              "Scoreboard",
              drop.objective || "Unknown"
            )
          );
          continue;
        }

        const scoreValue =
          Math.floor(Math.random() * (drop.valueMax - drop.valueMin + 1)) +
          drop.valueMin;
        const objective = world.scoreboard.getObjective(drop.objective);

        if (objective) {
          const participant = killer.scoreboardIdentity;
          if (drop.action === "add") {
            objective.setScore(
              participant,
              objective.getScore(participant) + scoreValue
            );
            if (settings.showActionBar) {
              killer.onScreenDisplay.setActionBar(
                `§a+${scoreValue} ${drop.objective}`
              );
            }
          } else if (drop.action === "set") {
            objective.setScore(participant, scoreValue);
            if (settings.showActionBar) {
              killer.onScreenDisplay.setActionBar(
                `§aSet ${drop.objective} to ${scoreValue}`
              );
            }
          } else if (drop.action === "remove") {
            objective.setScore(
              participant,
              objective.getScore(participant) - scoreValue
            );
            if (settings.showActionBar) {
              killer.onScreenDisplay.setActionBar(
                `§c-${scoreValue} ${drop.objective}`
              );
            }
          }
          DebugLog(
            `§b${killer.name}§r executed scoreboard action: ${drop.action} ${scoreValue} on ${drop.objective}`
          );
        } else {
          DebugLog(
            `§c[DROP ERROR] Scoreboard objective "${drop.objective}" not found.`
          );
          killer.sendMessage(
            `§cError: Scoreboard objective "${drop.objective}" not found.`
          );
        }
      } else if (drop.type === "command") {
        // Skip command drops if killer is not a Player
        if (!(killer instanceof Player)) continue;

        if (
          !drop ||
          typeof drop.command !== "string" ||
          drop.command.trim() === ""
        ) {
          DebugLog(
            `§c[DROP ERROR] Skipping command drop for ${
              deadEntity.typeId
            } (Key: ${matchedKey}): Invalid command drop structure → ${JSON.stringify(
              drop
            )}`
          );
          killer.sendMessage(
            getTranslatedText(
              "invalidDropConfig",
              getPlayerLocale(killer),
              "Command",
              drop.command || "Unknown"
            )
          );
          continue;
        }
        killer.runCommand(drop.command);
        DebugLog(`§b${killer.name}§r executed command: ${drop.command}`);
        if (settings.showActionBar) {
          killer.onScreenDisplay.setActionBar(`§aExecuted command!`);
        }
      } else {
        DebugLog(
          `§c[DROP ERROR] Unknown drop type "${drop.type}" for ${deadEntity.typeId} (Key: ${matchedKey})`
        );
        // Only send message to player if killer is a player
        if (killer instanceof Player) {
          killer.sendMessage(
            `§cError: Unknown drop type "${drop.type}" configured.`
          );
        }
      }
    } catch (e) {
      // Only send message to player if killer is a player
      if (killer instanceof Player) {
        killer.sendMessage(
          getTranslatedText(
            "failedToSpawn",
            getPlayerLocale(killer),
            drop.itemId || drop.objective || drop.command || "Unknown",
            e.message
          )
        );
      }
      DebugLog(
        `[DROP ERROR] Failed to process drop for ${
          deadEntity.typeId
        } (Name: ${entityName}, Tag: ${entityTags.join(",")}): ${e.message}`
      );
    }
  }

  if (settings.killDefaultDrops) {
    const pos = deadEntity.location;
    system.runTimeout(() => {
      deadEntity.runCommand(
        `kill @e[type=item,tag=!"drop_${key}",x=${pos.x},y=${pos.y},z=${pos.z},r=2]`
      );
    }, 1);
  }
});

// ================== Drop Manager UI ==================

function openDropManagerUI(player) {
  const config = getDropConfig();
  const entityKeys = Object.keys(config).filter((key) => !key.startsWith("_")); // Lọc bỏ các key nội bộ

  if (entityKeys.length === 0) {
    player.sendMessage(
      getTranslatedText("noMobsConfigured", getPlayerLocale(player))
    );
    return;
  }

  const form = new ActionFormData()
    .title(getTranslatedText("mobDropListTitle", getPlayerLocale(player)))
    .body(getTranslatedText("mobDropListBody", getPlayerLocale(player)));

  entityKeys.forEach((entityKey) => {
    const { entityType, name, tag } = parseEntityKey(entityKey); // Phân tích key
    const entityConfig = config[entityKey];
    const drops = entityConfig?.drops || [];

    const info = drops
      .map((d, i) => {
        if (!d || !d.type) {
          return `§r#${i + 1} §c[Malformed/Unconfigured Drop]`;
        }
        let display = "";
        switch (d.type) {
          case "item":
            display = d.displayName || d.itemId;
            break;
          case "scoreboard":
            display = `Scoreboard: ${d.objective} (${d.action})`;
            break;
          case "command":
            display = `Command: ${d.command.substring(0, 20)}...`;
            break;
        }
        return `§r#${i + 1} §r${d.type}: ${display} §6(${d.chance}%)`;
      })
      .join("\n");

    let displayKey = `§b${entityType}`;
    if (name) displayKey += ` §e(Name: ${name})`;
    if (tag) displayKey += ` §a(Tag: ${tag})`;

    form.button(`${displayKey}\n${info}`);
  });

  form.show(player).then((res) => {
    if (res.canceled || res.selection === undefined) return;
    const selectedEntityKey = entityKeys[res.selection];
    openEntityDropOptionsUI(player, selectedEntityKey); // Truyền entityKey
  });
}

function openEntityDropOptionsUI(player, entityKey) {
  const config = getDropConfig();
  const entityConfig = config[entityKey];
  const dropList = entityConfig?.drops || [];
  const { entityType, name, tag } = parseEntityKey(entityKey);

  let titleDisplay = getTranslatedText(
    "entityOptionsTitle",
    getPlayerLocale(player),
    entityType,
    name,
    tag
  );

  const form = new ActionFormData()
    .title(titleDisplay)
    .body(
      `${getTranslatedText(
        "currentConfig",
        getPlayerLocale(player)
      )}\n${dropList
        .map((d, i) => {
          if (!d || !d.type) {
            return `§7#${i + 1} §c[Malformed/Unconfigured Drop]`;
          }
          let detail = "";
          switch (d.type) {
            case "item":
              detail = `§f${d.itemId} §b${
                d.displayName ? " - " + d.displayName : ""
              }\n§9Lore: §r${
                d.lore ? d.lore.join(", ") : "None"
              }\n§dQuantity: §a${d.min}-${d.max}`;
              break;
            case "scoreboard":
              detail = `§fObjective: ${d.objective}§b - Action: ${d.action}\n§dValue: §a${d.valueMin}-${d.valueMax}`;
              break;
            case "command":
              detail = `§fCommand: §a${d.command}`;
              break;
          }
          return `§7#${
            i + 1
          } §l§e${d.type.toUpperCase()} DROP§r\n${detail}\n§8| §6${d.chance}%`;
        })
        .join("\n\n")}`
    )
    .button(getTranslatedText("editDropsButton", getPlayerLocale(player)))
    .button(getTranslatedText("testDropsButton", getPlayerLocale(player)))
    .button(getTranslatedText("entitySettingsButton", getPlayerLocale(player)))
    .button(getTranslatedText("deleteConfigButton", getPlayerLocale(player)))
    .button(getTranslatedText("backButton", getPlayerLocale(player)));

  form.show(player).then((res) => {
    if (res.canceled) return;
    switch (res.selection) {
      case 0:
        openDropItemSelectionForm(player, entityKey, dropList); // Pass the actual dropList
        break;
      case 1:
        testMobDrops(player, entityKey);
        break;
      case 2:
        openEntitySettingsForm(player, entityKey);
        break;
      case 3:
        confirmDeleteDropConfig(player, entityKey);
        break;
      case 4:
        openDropManagerUI(player);
        break;
    }
  });
}

function openDropItemSelectionForm(player, entityKey, itemsToEdit) {
  const { entityType, name, tag } = parseEntityKey(entityKey);
  let titleDisplay = getTranslatedText(
    "itemSelectionTitle",
    getPlayerLocale(player),
    entityType,
    name,
    tag
  );

  const form = new ActionFormData()
    .title(titleDisplay)
    .body(getTranslatedText("itemSelectionBody", getPlayerLocale(player)));

  if (itemsToEdit.length === 0) {
    form.body(getTranslatedText("noItemsConfigured", getPlayerLocale(player)));
  } else {
    itemsToEdit.forEach((item, index) => {
      let itemDisplay = getTranslatedText(
        "newItemSlot",
        getPlayerLocale(player)
      );
      if (item.type === "item") {
        itemDisplay = `§f${item.itemId}§8 (${item.min}-${item.max}) §r | §6${item.chance}%`;
        if (item.displayName)
          itemDisplay = item.displayName + " - " + itemDisplay;
      } else if (item.type === "scoreboard") {
        itemDisplay = `§fScoreboard: ${item.objective} (${item.action}) §8(${item.valueMin}-${item.valueMax}) §r | §6${item.chance}%`;
      } else if (item.type === "command") {
        itemDisplay = `§fCommand: ${item.command.substring(0, 30)}... §r | §6${
          item.chance
        }%`;
      }
      form.button(`§eDrop ${index + 1}: §r${itemDisplay}`);
    });
  }

  form.button(`§aAdd New Drop`); // New button to add a new drop
  form.button(`Back`);

  form.show(player).then((res) => {
    if (res.canceled || res.selection === undefined) {
      openEntityDropOptionsUI(player, entityKey);
      return;
    }

    if (res.selection === itemsToEdit.length) {
      // Add New Drop button
      const newIndex = itemsToEdit.length;
      itemsToEdit.push({}); // Add a placeholder for the new drop
      openDropTypeSelectionForm(
        player,
        entityKey,
        itemsToEdit,
        newIndex,
        false
      );
      return;
    }

    if (res.selection === itemsToEdit.length + 1) {
      // Back button
      openEntityDropOptionsUI(player, entityKey);
      return;
    }

    const selectedItemIndex = res.selection;
    openItemEditOptionsForm(player, entityKey, itemsToEdit, selectedItemIndex);
  });
}

function openItemEditOptionsForm(player, entityKey, currentItems, itemIndex) {
  const item = currentItems[itemIndex];
  let itemDisplay = getTranslatedText("newItemSlot", getPlayerLocale(player));
  if (item.type === "item") {
    itemDisplay = item.displayName || item.itemId;
  } else if (item.type === "scoreboard") {
    itemDisplay = `Scoreboard: ${item.objective}`;
  } else if (item.type === "command") {
    itemDisplay = `Command: ${item.command.substring(0, 30)}...`;
  }

  const form = new ActionFormData()
    .title(
      getTranslatedText("editItemTitle", getPlayerLocale(player), itemIndex + 1)
    )
    .body(
      getTranslatedText("editItemBody", getPlayerLocale(player), itemDisplay)
    )
    .button(getTranslatedText("editItemDetailsButton", getPlayerLocale(player)))
    .button(getTranslatedText("duplicateItemButton", getPlayerLocale(player))) // NEW DUPLICATE BUTTON
    .button(getTranslatedText("deleteItemButton", getPlayerLocale(player)))
    .button(
      getTranslatedText("backToItemSelectionButton", getPlayerLocale(player))
    );

  form.show(player).then((res) => {
    if (res.canceled) {
      openDropItemSelectionForm(player, entityKey, currentItems);
      return;
    }

    switch (res.selection) {
      case 0: // Edit Item Details
        if (item.type === "item") {
          openItemDropForm(player, entityKey, currentItems, itemIndex, true);
        } else if (item.type === "scoreboard") {
          openScoreboardDropForm(
            player,
            entityKey,
            currentItems,
            itemIndex,
            true
          );
        } else if (item.type === "command") {
          openCommandDropForm(player, entityKey, currentItems, itemIndex, true);
        } else {
          // If type is not set (new slot), go to type selection
          openDropTypeSelectionForm(
            player,
            entityKey,
            currentItems,
            itemIndex,
            true
          );
        }
        break;
      case 1: // Duplicate Item
        duplicateDrop(player, entityKey, currentItems, itemIndex);
        break;
      case 2: // Delete Item
        confirmDeleteItem(player, entityKey, currentItems, itemIndex);
        break;
      case 3: // Back to Item Selection
        openDropItemSelectionForm(player, entityKey, currentItems);
        break;
    }
  });
}

function duplicateDrop(player, entityKey, currentItems, itemIndexToDuplicate) {
  const originalItem = currentItems[itemIndexToDuplicate];
  if (!originalItem) {
    player.sendMessage("§cError: No item to duplicate.");
    return;
  }

  // Create a deep copy of the item
  const duplicatedItem = JSON.parse(JSON.stringify(originalItem));

  // Insert the duplicated item right after the original
  currentItems.splice(itemIndexToDuplicate + 1, 0, duplicatedItem);

  // Update the config in storage
  const config = getDropConfig();
  if (config[entityKey]) {
    config[entityKey].drops = currentItems;
  }
  setDropConfig(config);

  let displayName =
    originalItem.displayName ||
    originalItem.itemId ||
    originalItem.objective ||
    originalItem.command ||
    "Unknown Drop";
  player.sendMessage(
    getTranslatedText("dropDuplicated", getPlayerLocale(player), displayName)
  );

  // Re-open the item selection form to show the new duplicated item
  openDropItemSelectionForm(player, entityKey, currentItems);
}

function confirmDeleteItem(player, entityKey, currentItems, itemIndexToDelete) {
  const item = currentItems[itemIndexToDelete];
  let itemDisplayName = getTranslatedText(
    "itemDetailTitle",
    getPlayerLocale(player),
    itemIndexToDelete + 1
  ); // Default for unconfigured slot
  if (item.type === "item") {
    itemDisplayName = item.displayName || item.itemId;
  } else if (item.type === "scoreboard") {
    itemDisplayName = `Scoreboard: ${item.objective}`;
  } else if (item.type === "command") {
    itemDisplayName = `Command: ${item.command.substring(0, 30)}...`;
  }

  const form = new MessageFormData()
    .title(getTranslatedText("confirmDeleteTitle", getPlayerLocale(player)))
    .body(
      getTranslatedText(
        "confirmDeleteBody",
        getPlayerLocale(player),
        itemDisplayName
      )
    )
    .button1(getTranslatedText("deleteButton", getPlayerLocale(player)))
    .button2(getTranslatedText("cancelButton", getPlayerLocale(player)));

  form.show(player).then((res) => {
    if (res.selection === 1) {
      openItemEditOptionsForm(
        player,
        entityKey,
        currentItems,
        itemIndexToDelete
      );
      return;
    }

    currentItems.splice(itemIndexToDelete, 1);

    const config = getDropConfig();
    if (config[entityKey]) {
      config[entityKey].drops = currentItems;
    }
    setDropConfig(config);

    player.sendMessage(
      getTranslatedText(
        "itemDeleted",
        getPlayerLocale(player),
        itemDisplayName,
        parseEntityKey(entityKey).entityType
      )
    );

    openDropItemSelectionForm(player, entityKey, currentItems);
  });
}

function confirmDeleteDropConfig(player, entityKey) {
  const { entityType, name, tag } = parseEntityKey(entityKey);
  let displayName = `§b${entityType}`;
  if (name) displayName += ` (Name: ${name})`;
  if (tag) displayName += ` (Tag: ${tag})`;

  const form = new ActionFormData()
    .title(getTranslatedText("confirmDeleteTitle", getPlayerLocale(player)))
    .body(
      getTranslatedText(
        "confirmDeleteConfigBody",
        getPlayerLocale(player),
        displayName
      )
    )
    .button(getTranslatedText("deleteButton", getPlayerLocale(player)))
    .button(getTranslatedText("cancelButton", getPlayerLocale(player)));

  form.show(player).then((res) => {
    if (res.canceled || res.selection === 1) {
      openEntityDropOptionsUI(player, entityKey);
      return;
    }

    const config = getDropConfig();
    delete config[entityKey];
    setDropConfig(config);

    player.sendMessage(
      getTranslatedText(
        "configDeleted",
        getPlayerLocale(player),
        entityType,
        name,
        tag
      )
    );
    openDropManagerUI(player);
  });
}

// ================== Debug Log ==================

function DebugLog(message) {
  const time = new Date().toLocaleTimeString();
  const formatted = `§7[${time}] §f${message}`;
  debugLogs.push(formatted);
  if (debugLogs.length > 1000) debugLogs.shift();
}

function openDebugLogForm(player) {
  const form = new ActionFormData().title(
    getTranslatedText("debugLogsTitle", getPlayerLocale(player))
  );

  if (debugLogs.length === 0) {
    form.body(getTranslatedText("noLogs", getPlayerLocale(player)));
  } else {
    const logText = debugLogs.slice(-10).join("\n\n");
    form.body(
      `${getTranslatedText("recentLogs", getPlayerLocale(player))}\n${logText}`
    );
  }

  form.button(getTranslatedText("clearButton", getPlayerLocale(player)));
  form.button(getTranslatedText("refreshButton", getPlayerLocale(player)));
  form.button(getTranslatedText("exitButton", getPlayerLocale(player)));

  form.show(player).then((res) => {
    if (res.canceled) return;
    if (res.selection === 0) {
      debugLogs.length = 0;
      player.sendMessage(
        getTranslatedText("logCleared", getPlayerLocale(player))
      );
    }
    if (res.selection === 1) {
      openDebugLogForm(player);
    }
  });
}

// ================== Entity Settings UI ==================
function openEntitySettingsForm(player, entityKey) {
  const config = getDropConfig();
  const entityConfig = config[entityKey];
  const { entityType, name, tag } = parseEntityKey(entityKey);

  const currentSettings = entityConfig?.settings || {
    ...defaultEntitySettings,
  };

  let titleDisplay = getTranslatedText(
    "settingsTitle",
    getPlayerLocale(player),
    entityType,
    name,
    tag
  );

  const form = new ModalFormData()
    .title(titleDisplay)
    .textField(
      getTranslatedText("entityTypeReadOnly", getPlayerLocale(player)),
      entityType,
      {
        readOnly: true,
      }
    )
    .textField(
      getTranslatedText("newDisplayNameLabel", getPlayerLocale(player)),
      "",
      { defaultValue: name }
    )
    .textField(getTranslatedText("newTagLabel", getPlayerLocale(player)), "", {
      defaultValue: tag,
    })
    .toggle(
      getTranslatedText("killDefaultDropsLabel", getPlayerLocale(player)),
      { defaultValue: currentSettings.killDefaultDrops }
    )
    .toggle(getTranslatedText("showActionBarLabel", getPlayerLocale(player)), {
      defaultValue: currentSettings.showActionBar,
    })
    .toggle(getTranslatedText("addDirectlyToInventoryLabel", player), {
      defaultValue: currentSettings.addDirectlyToInventory,
    });

  form.show(player).then((res) => {
    if (res.canceled) {
      openEntityDropOptionsUI(player, entityKey);
      return;
    }

    const [
      _,
      newDisplayName,
      newTag,
      killDefaultDrops,
      showActionBar,
      addDirectlyToInventory,
    ] = res.formValues;

    const newEntityKey = generateEntityKey(entityType, newDisplayName, newTag);

    if (newEntityKey !== entityKey) {
      if (config[newEntityKey]) {
        player.sendMessage(
          getTranslatedText(
            "configMoveError",
            getPlayerLocale(player),
            entityType,
            newDisplayName,
            newTag
          )
        );
        openEntitySettingsForm(player, entityKey);
        return;
      }

      config[newEntityKey] = { ...entityConfig };
      delete config[entityKey];
      setDropConfig(config);
      player.sendMessage(
        getTranslatedText(
          "configMoved",
          getPlayerLocale(player),
          entityType,
          newDisplayName,
          newTag
        )
      );
      entityKey = newEntityKey;
    }

    if (config[entityKey]) {
      config[entityKey].settings = {
        killDefaultDrops: killDefaultDrops,
        showActionBar: showActionBar,
        addDirectlyToInventory: addDirectlyToInventory,
      };
      setDropConfig(config);
      player.sendMessage(
        getTranslatedText("settingsSaved", getPlayerLocale(player))
      );
    } else {
      player.sendMessage(
        getTranslatedText(
          "noConfigFound",
          getPlayerLocale(player),
          titleDisplay
        )
      );
    }

    openEntityDropOptionsUI(player, entityKey);
  });
}

// ================== NEW FUNCTION: Test Mob Drops ==================
function testMobDrops(player, entityKey) {
  const config = getDropConfig();
  const entityConfig = config[entityKey];
  const dropList = entityConfig?.drops;
  const { entityType, name, tag } = parseEntityKey(entityKey);

  let displayTitle = getTranslatedText(
    "testDropsTitle",
    getPlayerLocale(player),
    entityType,
    name,
    tag
  );

  if (!dropList || dropList.length === 0) {
    player.sendMessage(
      getTranslatedText(
        "noDropsConfigured",
        getPlayerLocale(player),
        displayTitle
      )
    );
    return;
  }

  const playerLocation = player.location;
  player.sendMessage(displayTitle + ":");

  for (const drop of dropList) {
    try {
      if (Math.random() * 100 > drop.chance) continue;

      if (drop.type === "item") {
        if (
          !drop ||
          typeof drop.itemId !== "string" ||
          drop.itemId.trim() === "" ||
          typeof drop.min !== "number" ||
          typeof drop.max !== "number" ||
          drop.min < 0 ||
          drop.max < drop.min ||
          (drop.lore && !Array.isArray(drop.lore))
        ) {
          player.sendMessage(
            getTranslatedText(
              "invalidDropConfig",
              getPlayerLocale(player),
              "Item",
              drop.itemId || "Unknown"
            )
          );
          continue;
        }

        const amount =
          Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min;
        const item = new ItemStack(drop.itemId, amount);

        if (drop.lore && Array.isArray(drop.lore)) {
          item.setLore(drop.lore);
        }
        if (drop.displayName && drop.displayName.trim() !== "") {
          item.nameTag = `§r${drop.displayName}`;
        }

        world.getDimension(player.dimension.id).spawnItem(item, playerLocation);
        player.sendMessage(
          getTranslatedText(
            "spawnedItem",
            getPlayerLocale(player),
            amount,
            item.nameTag || drop.itemId,
            drop.chance
          )
        );
      } else if (drop.type === "scoreboard") {
        if (
          !drop ||
          typeof drop.objective !== "string" ||
          drop.objective.trim() === "" ||
          typeof drop.action !== "string" ||
          !["add", "set", "remove"].includes(drop.action) ||
          typeof drop.valueMin !== "number" ||
          typeof drop.valueMax !== "number" ||
          drop.valueMin < 0 ||
          drop.valueMax < drop.valueMin
        ) {
          player.sendMessage(
            getTranslatedText(
              "invalidDropConfig",
              getPlayerLocale(player),
              "Scoreboard",
              drop.objective || "Unknown"
            )
          );
          continue;
        }

        const scoreValue =
          Math.floor(Math.random() * (drop.valueMax - drop.valueMin + 1)) +
          drop.valueMin;
        const objective = world.scoreboard.getObjective(drop.objective);

        if (objective) {
          const participant = player.scoreboardIdentity;
          if (drop.action === "add") {
            objective.setScore(
              participant,
              objective.getScore(participant) + scoreValue
            );
            player.sendMessage(
              `§aTest: Added ${scoreValue} to ${drop.objective}`
            );
          } else if (drop.action === "set") {
            objective.setScore(participant, scoreValue);
            player.sendMessage(
              `§aTest: Set ${drop.objective} to ${scoreValue}`
            );
          } else if (drop.action === "remove") {
            objective.setScore(
              participant,
              objective.getScore(participant) - scoreValue
            );
            player.sendMessage(
              `§cTest: Removed ${scoreValue} from ${drop.objective}`
            );
          }
        } else {
          player.sendMessage(
            `§cError: Scoreboard objective "${drop.objective}" not found for test.`
          );
        }
      } else if (drop.type === "command") {
        if (
          !drop ||
          typeof drop.command !== "string" ||
          drop.command.trim() === ""
        ) {
          player.sendMessage(
            getTranslatedText(
              "invalidDropConfig",
              getPlayerLocale(player),
              "Command",
              drop.command || "Unknown"
            )
          );
          continue;
        }
        player.runCommand(drop.command);
        player.sendMessage(`§aTest: Executed command: ${drop.command}`);
      } else {
        player.sendMessage(
          `§cError: Unknown drop type "${drop.type}" configured for test.`
        );
      }
    } catch (e) {
      player.sendMessage(
        getTranslatedText(
          "failedToSpawn",
          getPlayerLocale(player),
          drop.itemId || drop.objective || drop.command || "Unknown",
          e.message
        )
      );
      DebugLog(
        `[TEST DROP ERROR] Failed to process drop for ${entityType} (Name: ${name}, Tag: ${tag}): ${e.message}`
      );
    }
  }
}

// ================== NEW FUNCTION: Item Search ==================
async function openItemSearchForm(player) {
  let form = new ModalFormData()
    .title(getTranslatedText("itemSearchTitle", getPlayerLocale(player)))
    .textField(
      getTranslatedText("itemSearchPrompt", getPlayerLocale(player)),
      ""
    );

  form.show(player).then(async (res) => {
    if (res.canceled) {
      player.sendMessage(
        getTranslatedText("itemSearchCanceled", getPlayerLocale(player))
      );
      return;
    }

    let searchTerm = res.formValues[0]?.toLowerCase();
    if (!searchTerm) {
      player.sendMessage(
        getTranslatedText("fillBlanks", getPlayerLocale(player))
      );
      return;
    }

    const config = getDropConfig();
    const matchingItems = [];

    for (const entityKey in config) {
      const entityData = config[entityKey];
      const { entityType, name, tag } = parseEntityKey(entityKey);
      const drops = entityData.drops || [];

      drops.forEach((drop, index) => {
        let matchFound = false;
        let displayIdentifier = "";

        if (drop.type === "item") {
          const itemId = drop.itemId?.toLowerCase() || "";
          const displayName = drop.displayName?.toLowerCase() || "";
          const lore = (drop.lore || []).map((l) => l.toLowerCase()).join(" ");
          if (
            itemId.includes(searchTerm) ||
            displayName.includes(searchTerm) ||
            lore.includes(searchTerm)
          ) {
            matchFound = true;
            displayIdentifier = drop.displayName || drop.itemId;
          }
        } else if (drop.type === "scoreboard") {
          const objective = drop.objective?.toLowerCase() || "";
          if (objective.includes(searchTerm)) {
            matchFound = true;
            displayIdentifier = `Scoreboard: ${drop.objective}`;
          }
        } else if (drop.type === "command") {
          const command = drop.command?.toLowerCase() || "";
          if (command.includes(searchTerm)) {
            matchFound = true;
            displayIdentifier = `Command: ${drop.command.substring(0, 30)}...`;
          }
        }

        if (matchFound) {
          matchingItems.push({
            entityKey: entityKey,
            entityType: entityType,
            entityName: name,
            entityTag: tag,
            itemIndex: index,
            item: drop,
            displayIdentifier: displayIdentifier,
          });
        }
      });
    }

    if (matchingItems.length === 0) {
      player.sendMessage(
        getTranslatedText("noMatchingItems", getPlayerLocale(player))
      );
      return;
    }

    let resultForm = new ActionFormData().title(
      getTranslatedText("searchResultTitle", getPlayerLocale(player))
    );

    matchingItems.forEach((match) => {
      const foundInText = getTranslatedText(
        "itemFoundIn",
        getPlayerLocale(player),
        match.entityType,
        match.entityName,
        match.entityTag
      );
      resultForm.button(`§f${match.displayIdentifier}\n§r${foundInText}`);
    });

    resultForm.show(player).then((resSelect) => {
      if (resSelect.canceled) return;

      const selectedMatch = matchingItems[resSelect.selection];
      const entityKey = selectedMatch.entityKey;
      const itemIndex = selectedMatch.itemIndex;

      // Re-fetch the config to ensure current state
      const currentConfig = getDropConfig();
      const currentDropsForEntity = currentConfig[entityKey]?.drops || [];

      // Navigate to the edit form for the selected item
      openItemEditOptionsForm(
        player,
        entityKey,
        currentDropsForEntity,
        itemIndex
      );
    });
  });
}

// =============================== TUTORIAL =================================
function openLanguageSelectionForm(player) {
  const form = new ActionFormData()
    .title(getTranslatedText("tutorialTitleEN", getPlayerLocale(player))) // Using EN title for selection
    .body(
      "§fPlease choose your preferred language for the tutorial:\n§7Vui lòng chọn ngôn ngữ bạn muốn cho hướng dẫn:"
    );

  form.button("§lEnglish").button("§lTiếng Việt");

  form.show(player).then((res) => {
    if (res.canceled) {
      return;
    }

    const selectedLanguage = res.selection === 0 ? "en" : "vi";
    openTutorialForm(player, selectedLanguage);
  });
}

function openTutorialForm(player, language = "en") {
  const isEnglish = language === "en";

  const form = new ActionFormData();

  if (isEnglish) {
    form.title(getTranslatedText("tutorialTitleEN", getPlayerLocale(player)));
    form.body(getTranslatedText("tutorialBodyEN", getPlayerLocale(player)));
    form.button(getTranslatedText("gotItButton", getPlayerLocale(player)));
  } else {
    form.title(getTranslatedText("tutorialTitleVI", getPlayerLocale(player)));
    form.body(getTranslatedText("tutorialBodyVI", getPlayerLocale(player)));
    form.button(getTranslatedText("understoodButton", getPlayerLocale(player)));
  }

  form.show(player);
}
